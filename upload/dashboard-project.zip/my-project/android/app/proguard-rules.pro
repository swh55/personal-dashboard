# ====== ProGuard rules للوحة التحكم ======

# NanoHTTPD
-keep class fi.iki.elonen.** { *; }
-dontwarn fi.iki.elonen.**

# AndroidX
-keep class androidx.** { *; }
-dontwarn androidx.**

# Google Play Services Location
-keep class com.google.android.gms.** { *; }
-dontwarn com.google.android.gms.**

# JSON
-keep class org.json.** { *; }
-dontwarn org.json.**

# Keep JavaScript interface (must not be obfuscated)
-keepclassmembers class com.personal.dashboard.AndroidInterface {
    @android.webkit.JavascriptInterface <methods>;
}
-keep @android.webkit.JavascriptInterface class * { *; }
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

# Keep model classes used in serialization
-keep class com.personal.dashboard.** { *; }

# WebView
-keep class android.webkit.** { *; }
-keep class android.net.http.** { *; }
-dontwarn android.webkit.**
-dontwarn android.net.http.**

# Preserve generic signatures
-keepattributes Signature
-keepattributes *Annotation*
-keepattributes EnclosingMethod
-keepattributes InnerClasses

# Remove logging in release
-assumenosideeffects class android.util.Log {
    public static *** v(...);
    public static *** d(...);
    public static *** i(...);
}

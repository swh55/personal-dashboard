package com.personal.dashboard;

import android.app.Application;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.os.Build;
import android.util.Log;

public class DashboardApplication extends Application {

    public static final String CHANNEL_ID = "dashboard_notifications";
    public static final String CHANNEL_PRAYER = "prayer_notifications";
    public static final String CHANNEL_TASKS = "task_notifications";

    @Override
    public void onCreate() {
        super.onCreate();
        try {
            createNotificationChannels();
        } catch (Exception e) {
            Log.w("DashboardApp", "channels: " + e.getMessage());
        }
    }

    private void createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager == null) return;

            // قناة عامة
            try {
                NotificationChannel general = new NotificationChannel(
                    CHANNEL_ID, "إشعارات عامة", NotificationManager.IMPORTANCE_DEFAULT);
                general.setDescription("إشعارات لوحة التحكم العامة");
                manager.createNotificationChannel(general);
            } catch (Exception ignored) {}

            // قناة الصلاة
            try {
                NotificationChannel prayer = new NotificationChannel(
                    CHANNEL_PRAYER, "مواقيت الصلاة", NotificationManager.IMPORTANCE_HIGH);
                prayer.setDescription("تنبيهات أوقات الصلاة");
                manager.createNotificationChannel(prayer);
            } catch (Exception ignored) {}

            // قناة المهام
            try {
                NotificationChannel tasks = new NotificationChannel(
                    CHANNEL_TASKS, "تنبيهات المهام", NotificationManager.IMPORTANCE_HIGH);
                tasks.setDescription("تذكيرات المهام والمواعيد");
                manager.createNotificationChannel(tasks);
            } catch (Exception ignored) {}
        }
    }
}

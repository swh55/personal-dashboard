package com.personal.dashboard;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

/**
 * يستقبل إشارة إقلاع الجهاز ويبدأ خدمة المزامنة الأمامية
 * حتى تعمل لوحة التحكم (كـ Launcher) فور الإقلاع.
 */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null || intent.getAction() == null) return;
        String action = intent.getAction();
        if (action.equals(Intent.ACTION_BOOT_COMPLETED)
            || action.equals(Intent.ACTION_LOCKED_BOOT_COMPLETED)
            || action.equals("android.intent.action.QUICKBOOT_POWERON")
            || action.equals("com.htc.intent.action.QUICKBOOT_POWERON")) {
            try {
                Intent svc = new Intent(context, NotificationService.class);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(svc);
                } else {
                    context.startService(svc);
                }
            } catch (Exception ignored) {}
        }
    }
}

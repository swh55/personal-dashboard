package com.personal.dashboard;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Environment;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.ContactsContract;
import android.provider.CallLog;
import android.provider.MediaStore;
import android.provider.Settings;
import android.telephony.SmsManager;
import android.util.Base64;
import android.util.Log;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.FileProvider;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * AndroidInterface — جسر JavaScript ↔ Android.
 * كل الدوال معلّمة @JavascriptInterface وقابلة للاستدعاء من window.Android.<name>(...).
 * كل دالة محاطة بـ try-catch وتُرجع JSON نصي أو void.
 * ترميز UTF-8 صريح في كل عمليات النصوص.
 */
public class AndroidInterface {

    private static final String TAG = "AndroidInterface";

    private final Activity activity;
    private final PermissionManager permissionManager;
    private final WebView webView;
    private final StringBuilder logBuffer = new StringBuilder();

    public AndroidInterface(Activity activity, PermissionManager pm, WebView webView) {
        this.activity = activity;
        this.permissionManager = pm;
        this.webView = webView;
    }

    // ============================================================
    // ============ المكالمات والرسائل =
    // ============================================================

    @JavascriptInterface
    public void callNumber(String phone) {
        try {
            if (phone == null || phone.isEmpty()) return;
            if (hasPermission(Manifest.permission.CALL_PHONE)) {
                Intent intent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(phone)));
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                activity.startActivity(intent);
            } else {
                requestPermission(Manifest.permission.CALL_PHONE);
                openDialer();
            }
        } catch (Exception e) { log("error", TAG, "callNumber: " + e.getMessage()); }
    }

    @JavascriptInterface
    public void openSMS(String phone, String message) {
        try {
            Intent intent = new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(phone == null ? "" : phone)));
            if (message != null && !message.isEmpty()) {
                intent.putExtra("sms_body", message);
            }
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            activity.startActivity(intent);
        } catch (Exception e) { log("error", TAG, "openSMS: " + e.getMessage()); }
    }

    @JavascriptInterface
    public void openWhatsApp(String phone) {
        try {
            String num = phone == null ? "" : phone.replaceAll("[^0-9]", "");
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/" + num));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            activity.startActivity(intent);
        } catch (Exception e) { log("error", TAG, "openWhatsApp: " + e.getMessage()); }
    }

    @JavascriptInterface
    public void navigateTo(String lat, String lng) {
        try {
            String q = lat + "," + lng;
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("geo:" + q + "?q=" + q));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            activity.startActivity(intent);
        } catch (Exception e) { log("error", TAG, "navigateTo: " + e.getMessage()); }
    }

    // ============================================================
    // ============ جهات الاتصال =
    // ============================================================

    @JavascriptInterface
    public String getContacts() {
        JSONArray arr = new JSONArray();
        if (!hasPermission(Manifest.permission.READ_CONTACTS)) {
            requestPermission(Manifest.permission.READ_CONTACTS);
            return arr.toString();
        }
        try (android.database.Cursor c = activity.getContentResolver().query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                new String[]{ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                        ContactsContract.CommonDataKinds.Phone.NUMBER,
                        ContactsContract.CommonDataKinds.Phone.CONTACT_ID},
                null, null,
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " ASC")) {
            if (c != null) {
                while (c.moveToNext()) {
                    String name = c.getString(0);
                    String phone = c.getString(1);
                    if (name == null && phone == null) continue;
                    JSONObject o = new JSONObject();
                    o.put("name", name == null ? "" : name);
                    o.put("phone", phone == null ? "" : phone);
                    o.put("email", "");
                    arr.put(o);
                }
            }
        } catch (Exception e) { log("error", TAG, "getContacts: " + e.getMessage()); }
        return arr.toString();
    }

    @JavascriptInterface
    public void addContact(String name, String phone, String email) {
        try {
            if (!hasPermission(Manifest.permission.WRITE_CONTACTS)) {
                requestPermission(Manifest.permission.WRITE_CONTACTS);
                return;
            }
            Intent intent = new Intent(Intent.ACTION_INSERT);
            intent.setType(ContactsContract.Contacts.CONTENT_TYPE);
            if (name != null) intent.putExtra(ContactsContract.Intents.Insert.NAME, name);
            if (phone != null) intent.putExtra(ContactsContract.Intents.Insert.PHONE, phone);
            if (email != null) intent.putExtra(ContactsContract.Intents.Insert.EMAIL, email);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            activity.startActivity(intent);
        } catch (Exception e) { log("error", TAG, "addContact: " + e.getMessage()); }
    }

    // ============================================================
    // ============ التطبيقات المثبّتة =
    // ============================================================

    @JavascriptInterface
    public String getInstalledApps() {
        JSONArray arr = new JSONArray();
        try {
            PackageManager pm = activity.getPackageManager();
            Intent main = new Intent(Intent.ACTION_MAIN, null);
            main.addCategory(Intent.CATEGORY_LAUNCHER);
            List<ResolveInfo> apps = pm.queryIntentActivities(main, 0);
            Collections.sort(apps, new Comparator<ResolveInfo>() {
                @Override
                public int compare(ResolveInfo a, ResolveInfo b) {
                    String na = a.loadLabel(pm).toString();
                    String nb = b.loadLabel(pm).toString();
                    return na.compareToIgnoreCase(nb);
                }
            });
            int max = 200;
            int count = 0;
            for (ResolveInfo info : apps) {
                if (count++ > max) break;
                try {
                    String pkg = info.activityInfo.packageName;
                    String label = info.loadLabel(pm).toString();
                    String icon = drawableToBase64(info.loadIcon(pm));
                    JSONObject o = new JSONObject();
                    o.put("packageName", pkg);
                    o.put("label", label);
                    o.put("icon", icon);
                    arr.put(o);
                } catch (Exception ignored) {}
            }
        } catch (Exception e) { log("error", TAG, "getInstalledApps: " + e.getMessage()); }
        return arr.toString();
    }

    @JavascriptInterface
    public void launchApp(String packageName) {
        try {
            if (packageName == null) return;
            Intent intent = activity.getPackageManager().getLaunchIntentForPackage(packageName);
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                activity.startActivity(intent);
            }
        } catch (Exception e) { log("error", TAG, "launchApp: " + e.getMessage()); }
    }

    @JavascriptInterface
    public void uninstallApp(String packageName) {
        try {
            if (packageName == null) return;
            Intent intent = new Intent(Intent.ACTION_DELETE, Uri.parse("package:" + packageName));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            activity.startActivity(intent);
        } catch (Exception e) { log("error", TAG, "uninstallApp: " + e.getMessage()); }
    }

    // ============================================================
    // ============ سجل المكالمات والرسائل =
    // ============================================================

    @SuppressLint("MissingPermission")
    @JavascriptInterface
    public String getCallLog() {
        JSONArray arr = new JSONArray();
        if (!hasPermission(Manifest.permission.READ_CALL_LOG)) {
            requestPermission(Manifest.permission.READ_CALL_LOG);
            return arr.toString();
        }
        try (android.database.Cursor c = activity.getContentResolver().query(
                CallLog.Calls.CONTENT_URI,
                new String[]{CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME,
                        CallLog.Calls.DATE, CallLog.Calls.DURATION, CallLog.Calls.TYPE},
                null, null, CallLog.Calls.DATE + " DESC LIMIT 200")) {
            if (c != null) {
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault());
                while (c.moveToNext()) {
                    JSONObject o = new JSONObject();
                    o.put("number", safeStr(c.getString(0)));
                    o.put("name", safeStr(c.getString(1)));
                    o.put("date", sdf.format(new Date(c.getLong(2))));
                    o.put("duration", c.getLong(3));
                    o.put("type", c.getInt(4));
                    arr.put(o);
                }
            }
        } catch (Exception e) { log("error", TAG, "getCallLog: " + e.getMessage()); }
        return arr.toString();
    }

    @JavascriptInterface
    public String getSmsMessages() {
        JSONArray arr = new JSONArray();
        if (!hasPermission(Manifest.permission.READ_SMS)) {
            requestPermission(Manifest.permission.READ_SMS);
            return arr.toString();
        }
        try (android.database.Cursor c = activity.getContentResolver().query(
                android.net.Uri.parse("content://sms/inbox"),
                new String[]{"address", "date", "body", "read"},
                null, null, "date DESC LIMIT 200")) {
            if (c != null) {
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault());
                while (c.moveToNext()) {
                    JSONObject o = new JSONObject();
                    o.put("address", safeStr(c.getString(0)));
                    o.put("date", sdf.format(new Date(c.getLong(1))));
                    o.put("body", safeStr(c.getString(2)));
                    o.put("read", c.getInt(3));
                    arr.put(o);
                }
            }
        } catch (Exception e) { log("error", TAG, "getSmsMessages: " + e.getMessage()); }
        return arr.toString();
    }

    @JavascriptInterface
    public String getSentSmsMessages() {
        JSONArray arr = new JSONArray();
        if (!hasPermission(Manifest.permission.READ_SMS)) {
            requestPermission(Manifest.permission.READ_SMS);
            return arr.toString();
        }
        try (android.database.Cursor c = activity.getContentResolver().query(
                android.net.Uri.parse("content://sms/sent"),
                new String[]{"address", "date", "body"},
                null, null, "date DESC LIMIT 200")) {
            if (c != null) {
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault());
                while (c.moveToNext()) {
                    JSONObject o = new JSONObject();
                    o.put("address", safeStr(c.getString(0)));
                    o.put("date", sdf.format(new Date(c.getLong(1))));
                    o.put("body", safeStr(c.getString(2)));
                    arr.put(o);
                }
            }
        } catch (Exception e) { log("error", TAG, "getSentSmsMessages: " + e.getMessage()); }
        return arr.toString();
    }

    // ============================================================
    // ============ الجهاز =
    // ============================================================

    @JavascriptInterface
    public int getBatteryLevel() {
        try {
            BatteryManager bm = (BatteryManager) activity.getSystemService(Context.BATTERY_SERVICE);
            if (bm != null) return bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);
        } catch (Exception e) { log("error", TAG, "getBatteryLevel: " + e.getMessage()); }
        return -1;
    }

    @JavascriptInterface
    public String getDeviceInfo() {
        JSONObject o = new JSONObject();
        try {
            o.put("brand", Build.BRAND);
            o.put("model", Build.MODEL);
            o.put("manufacturer", Build.MANUFACTURER);
            o.put("device", Build.DEVICE);
            o.put("product", Build.PRODUCT);
            o.put("sdk", Build.VERSION.SDK_INT);
            o.put("release", Build.VERSION.RELEASE);
            o.put("appVersion", "2.2.0");
            o.put("package", activity.getPackageName());
        } catch (Exception e) { log("error", TAG, "getDeviceInfo: " + e.getMessage()); }
        return o.toString();
    }

    @JavascriptInterface
    public boolean isDefaultLauncher() {
        try {
            String homePackage;
            Intent intent = new Intent(Intent.ACTION_MAIN);
            intent.addCategory(Intent.CATEGORY_HOME);
            ResolveInfo res = activity.getPackageManager().resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY);
            homePackage = (res != null && res.activityInfo != null) ? res.activityInfo.packageName : "";
            return activity.getPackageName().equals(homePackage);
        } catch (Exception e) { return false; }
    }

    @JavascriptInterface
    public void setAsDefaultLauncher() {
        try {
            Intent intent = new Intent(Settings.ACTION_HOME_SETTINGS);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            activity.startActivity(intent);
        } catch (Exception e) { log("error", TAG, "setAsDefaultLauncher: " + e.getMessage()); }
    }

    // ============================================================
    // ============ فتح تطبيقات النظام =
    // ============================================================

    @JavascriptInterface
    public void openDialer() {
        try {
            Intent intent = new Intent(Intent.ACTION_DIAL);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            activity.startActivity(intent);
        } catch (Exception e) { log("error", TAG, "openDialer: " + e.getMessage()); }
    }

    @JavascriptInterface
    public void openMessages() {
        try {
            Intent intent = new Intent(Intent.ACTION_MAIN);
            intent.addCategory(Intent.CATEGORY_APP_MESSAGING);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            activity.startActivity(intent);
        } catch (Exception e) {
            try {
                Intent intent = new Intent(Intent.ACTION_VIEW, android.net.Uri.parse("sms:"));
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                activity.startActivity(intent);
            } catch (Exception ex) { log("error", TAG, "openMessages: " + ex.getMessage()); }
        }
    }

    @JavascriptInterface
    public void openCamera() {
        try {
            Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            activity.startActivity(intent);
        } catch (Exception e) {
            try {
                Intent intent = new Intent("android.media.action.STILL_IMAGE_CAMERA");
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                activity.startActivity(intent);
            } catch (Exception ex) { log("error", TAG, "openCamera: " + ex.getMessage()); }
        }
    }

    @JavascriptInterface
    public void openBrowser() {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://www.google.com"));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            activity.startActivity(intent);
        } catch (Exception e) { log("error", TAG, "openBrowser: " + e.getMessage()); }
    }

    @JavascriptInterface
    public void openSettings() {
        try {
            Intent intent = new Intent(Settings.ACTION_SETTINGS);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            activity.startActivity(intent);
        } catch (Exception e) { log("error", TAG, "openSettings: " + e.getMessage()); }
    }

    @JavascriptInterface
    public void openWifiSettings() {
        try {
            Intent intent = new Intent(Settings.ACTION_WIFI_SETTINGS);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            activity.startActivity(intent);
        } catch (Exception e) { log("error", TAG, "openWifiSettings: " + e.getMessage()); }
    }

    @JavascriptInterface
    public void openBluetoothSettings() {
        try {
            Intent intent = new Intent(Settings.ACTION_BLUETOOTH_SETTINGS);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            activity.startActivity(intent);
        } catch (Exception e) { log("error", TAG, "openBluetoothSettings: " + e.getMessage()); }
    }

    @JavascriptInterface
    public void openLocationSettings() {
        try {
            Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            activity.startActivity(intent);
        } catch (Exception e) { log("error", TAG, "openLocationSettings: " + e.getMessage()); }
    }

    @JavascriptInterface
    public void openDisplaySettings() {
        try {
            Intent intent = new Intent(Settings.ACTION_DISPLAY_SETTINGS);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            activity.startActivity(intent);
        } catch (Exception e) { log("error", TAG, "openDisplaySettings: " + e.getMessage()); }
    }

    @JavascriptInterface
    public void openSoundSettings() {
        try {
            Intent intent = new Intent(Settings.ACTION_SOUND_SETTINGS);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            activity.startActivity(intent);
        } catch (Exception e) { log("error", TAG, "openSoundSettings: " + e.getMessage()); }
    }

    @JavascriptInterface
    public void openSecuritySettings() {
        try {
            Intent intent = new Intent(Settings.ACTION_SECURITY_SETTINGS);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            activity.startActivity(intent);
        } catch (Exception e) { log("error", TAG, "openSecuritySettings: " + e.getMessage()); }
    }

    @JavascriptInterface
    public void openAppSettings() {
        try {
            Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            intent.setData(android.net.Uri.parse("package:" + activity.getPackageName()));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            activity.startActivity(intent);
        } catch (Exception e) { log("error", TAG, "openAppSettings: " + e.getMessage()); }
    }

    @JavascriptInterface
    public void openExternalUrl(String url) {
        try {
            if (url == null || url.isEmpty()) return;
            if (!url.startsWith("http")) url = "https://" + url;
            Intent intent = new Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            activity.startActivity(intent);
        } catch (Exception e) { log("error", TAG, "openExternalUrl: " + e.getMessage()); }
    }

    @JavascriptInterface
    public void expandStatusBar() {
        try {
            @SuppressLint("WrongConstant") Object service = activity.getSystemService("statusbar");
            if (service != null) {
                Class<?> cls = Class.forName("android.app.StatusBarManager");
                String method = Build.VERSION.SDK_INT >= 17 ? "expandNotificationsPanel" : "expandNotificationsPanel";
                cls.getMethod(method).invoke(service);
            }
        } catch (Exception e) { log("error", TAG, "expandStatusBar: " + e.getMessage()); }
    }

    @JavascriptInterface
    public void keepScreenOn(boolean keep) {
        try {
            activity.runOnUiThread(() -> {
                try {
                    if (keep) {
                        activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                    } else {
                        activity.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                    }
                } catch (Exception ignored) {}
            });
        } catch (Exception e) { log("error", TAG, "keepScreenOn: " + e.getMessage()); }
    }

    @JavascriptInterface
    public void setWallpaper(String base64) {
        try {
            if (base64 == null) return;
            byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
            android.graphics.Bitmap bmp = android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
            if (bmp == null) return;
            android.app.WallpaperManager wm = android.app.WallpaperManager.getInstance(activity);
            wm.setBitmap(bmp);
            showToast("تم تعيين الخلفية");
        } catch (Exception e) { log("error", TAG, "setWallpaper: " + e.getMessage()); }
    }

    // ============================================================
    // ============ المشاركة والإشعارات والاهتزاز =
    // ============================================================

    @JavascriptInterface
    public void shareText(String text) {
        try {
            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType("text/plain");
            intent.putExtra(Intent.EXTRA_TEXT, text == null ? "" : text);
            Intent chooser = Intent.createChooser(intent, "مشاركة");
            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            activity.startActivity(chooser);
        } catch (Exception e) { log("error", TAG, "shareText: " + e.getMessage()); }
    }

    @JavascriptInterface
    public void showToast(String message) {
        try {
            activity.runOnUiThread(() -> {
                try { Toast.makeText(activity, message == null ? "" : message, Toast.LENGTH_SHORT).show(); }
                catch (Exception ignored) {}
            });
        } catch (Exception e) { log("error", TAG, "showToast: " + e.getMessage()); }
    }

    @JavascriptInterface
    public void showToastLong(String message) {
        try {
            activity.runOnUiThread(() -> {
                try { Toast.makeText(activity, message == null ? "" : message, Toast.LENGTH_LONG).show(); }
                catch (Exception ignored) {}
            });
        } catch (Exception e) { log("error", TAG, "showToastLong: " + e.getMessage()); }
    }

    @JavascriptInterface
    public void vibrate(int durationMs) {
        try {
            Vibrator v = (Vibrator) activity.getSystemService(Context.VIBRATOR_SERVICE);
            if (v == null || !v.hasVibrator()) return;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                v.vibrate(VibrationEffect.createOneShot(durationMs <= 0 ? 50 : durationMs, VibrationEffect.DEFAULT_AMPLITUDE));
            } else {
                v.vibrate(durationMs <= 0 ? 50 : durationMs);
            }
        } catch (Exception e) { log("error", TAG, "vibrate: " + e.getMessage()); }
    }

    @JavascriptInterface
    public void sendNotification(String title, String message, String channelId) {
        try {
            String channel = channelId == null || channelId.isEmpty() ? "dashboard_notifications" : channelId;
            NotificationManagerCompat nm = NotificationManagerCompat.from(activity);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                NotificationChannel ch = new NotificationChannel(channel, channel, NotificationManager.IMPORTANCE_DEFAULT);
                nm.createNotificationChannel(ch);
            }
            Intent intent = new Intent(activity, MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            PendingIntent pi = PendingIntent.getActivity(activity, 0, intent,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            NotificationCompat.Builder builder = new NotificationCompat.Builder(activity, channel)
                    .setSmallIcon(R.mipmap.ic_launcher)
                    .setContentTitle(title == null ? "" : title)
                    .setContentText(message == null ? "" : message)
                    .setAutoCancel(true)
                    .setContentIntent(pi);
            if (ActivityCompat.checkSelfPermission(activity, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
                nm.notify((int) System.currentTimeMillis(), builder.build());
            }
        } catch (Exception e) { log("error", TAG, "sendNotification: " + e.getMessage()); }
    }

    @JavascriptInterface
    public void playNotificationSound() {
        try {
            android.media.Ringtone r = android.media.RingtoneManager.getRingtone(activity,
                    android.media.RingtoneManager.getDefaultUri(android.media.RingtoneManager.TYPE_NOTIFICATION));
            if (r != null) r.play();
        } catch (Exception e) { log("error", TAG, "playNotificationSound: " + e.getMessage()); }
    }

    // ============================================================
    // ============ Widgets =
    // ============================================================

    @JavascriptInterface
    public void openWidgetPicker() {
        try {
            if (activity instanceof MainActivity) {
                ((MainActivity) activity).pickAppWidget();
            } else {
                log("error", TAG, "openWidgetPicker: activity is not MainActivity");
            }
        } catch (Exception e) { log("error", TAG, "openWidgetPicker: " + e.getMessage()); }
    }

    @JavascriptInterface
    public void openWidgetSettings() {
        try {
            Intent intent = new Intent(Settings.ACTION_SETTINGS);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            activity.startActivity(intent);
        } catch (Exception e) { log("error", TAG, "openWidgetSettings: " + e.getMessage()); }
    }

    @JavascriptInterface
    public void updateWidget() {
        try {
            AppWidgetManager mgr = AppWidgetManager.getInstance(activity);
            ComponentName comp = new ComponentName(activity, AppWidgetHostReceiver.class);
            int[] ids = mgr.getAppWidgetIds(comp);
            if (ids != null && ids.length > 0) {
                Intent intent = new Intent("android.appwidget.action.APPWIDGET_UPDATE");
                intent.setComponent(comp);
                intent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids);
                activity.sendBroadcast(intent);
            }
        } catch (Exception e) { log("error", TAG, "updateWidget: " + e.getMessage()); }
    }

    @JavascriptInterface
    public void saveWidgetData(String key, String value) {
        try {
            android.content.SharedPreferences prefs = activity.getSharedPreferences("dashboard_data", Context.MODE_PRIVATE);
            prefs.edit().putString(key, value).apply();
        } catch (Exception e) { log("error", TAG, "saveWidgetData: " + e.getMessage()); }
    }

    // ============================================================
    // ============ التخزين المشترك (Key/Value) =
    // ============================================================

    @JavascriptInterface
    public void storeData(String key, String value) {
        try {
            android.content.SharedPreferences prefs = activity.getSharedPreferences("dashboard_data", Context.MODE_PRIVATE);
            prefs.edit().putString(key, value == null ? "" : value).apply();
        } catch (Exception e) { log("error", TAG, "storeData: " + e.getMessage()); }
    }

    @JavascriptInterface
    public String getData(String key, String defaultValue) {
        try {
            android.content.SharedPreferences prefs = activity.getSharedPreferences("dashboard_data", Context.MODE_PRIVATE);
            return prefs.getString(key, defaultValue == null ? "" : defaultValue);
        } catch (Exception e) { return defaultValue == null ? "" : defaultValue; }
    }

    @JavascriptInterface
    public void removeData(String key) {
        try {
            android.content.SharedPreferences prefs = activity.getSharedPreferences("dashboard_data", Context.MODE_PRIVATE);
            prefs.edit().remove(key).apply();
        } catch (Exception e) { log("error", TAG, "removeData: " + e.getMessage()); }
    }

    @JavascriptInterface
    public void clearData() {
        try {
            android.content.SharedPreferences prefs = activity.getSharedPreferences("dashboard_data", Context.MODE_PRIVATE);
            prefs.edit().clear().apply();
        } catch (Exception e) { log("error", TAG, "clearData: " + e.getMessage()); }
    }

    // ============================================================
    // ============ الأذونات =
    // ============================================================

    @JavascriptInterface
    public boolean hasPermission(String permission) {
        try {
            return ActivityCompat.checkSelfPermission(activity, permission) == PackageManager.PERMISSION_GRANTED;
        } catch (Exception e) { return false; }
    }

    @JavascriptInterface
    public void requestPermission(String permission) {
        try {
            if (activity instanceof MainActivity) {
                ((MainActivity) activity).requestSinglePermission(permission);
            } else if (permissionManager != null) {
                permissionManager.request(permission);
            }
        } catch (Exception e) { log("error", TAG, "requestPermission: " + e.getMessage()); }
    }

    @JavascriptInterface
    public void requestAllPermissions() {
        try {
            if (activity instanceof MainActivity) {
                // يطلب MainActivity الأذونات تلقائياً في onResume
                Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                intent.setData(android.net.Uri.parse("package:" + activity.getPackageName()));
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            }
        } catch (Exception e) { log("error", TAG, "requestAllPermissions: " + e.getMessage()); }
    }

    @JavascriptInterface
    public String getPermissionStatus() {
        JSONObject o = new JSONObject();
        String[] perms = {
            Manifest.permission.CALL_PHONE, Manifest.permission.READ_CALL_LOG,
            Manifest.permission.READ_SMS, Manifest.permission.SEND_SMS,
            Manifest.permission.READ_CONTACTS, Manifest.permission.WRITE_CONTACTS,
            Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.CAMERA,
            Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS
        };
        try {
            for (String p : perms) {
                o.put(p, hasPermission(p));
            }
        } catch (Exception e) { log("error", TAG, "getPermissionStatus: " + e.getMessage()); }
        return o.toString();
    }

    // ============================================================
    // ============ السجل (Logging) =
    // ============================================================

    @JavascriptInterface
    public void log(String level, String tag, String msg) {
        try {
            String line = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.getDefault()).format(new Date())
                    + " [" + (level == null ? "info" : level) + "] "
                    + (tag == null ? TAG : tag) + ": "
                    + (msg == null ? "" : msg) + "\n";
            synchronized (logBuffer) {
                logBuffer.append(line);
                if (logBuffer.length() > 200000) {
                    logBuffer.delete(0, logBuffer.length() - 100000);
                }
            }
            if ("error".equals(level)) {
                Log.e(tag == null ? TAG : tag, msg == null ? "" : msg);
            } else {
                Log.i(tag == null ? TAG : tag, msg == null ? "" : msg);
            }
        } catch (Exception ignored) {}
    }

    @JavascriptInterface
    public String getLogPath() {
        try {
            File f = getLogFile();
            return f.getAbsolutePath();
        } catch (Exception e) { return ""; }
    }

    @JavascriptInterface
    public void shareLog() {
        try {
            File f = writeLogToFile();
            if (f == null || !f.exists()) { showToast("لا يوجد سجل"); return; }
            Uri uri = FileProvider.getUriForFile(activity, activity.getPackageName() + ".fileprovider", f);
            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType("text/plain");
            intent.putExtra(Intent.EXTRA_STREAM, uri);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            Intent chooser = Intent.createChooser(intent, "مشاركة السجل");
            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            activity.startActivity(chooser);
        } catch (Exception e) { log("error", TAG, "shareLog: " + e.getMessage()); }
    }

    @JavascriptInterface
    public void clearLog() {
        try {
            synchronized (logBuffer) { logBuffer.setLength(0); }
            File f = getLogFile();
            if (f.exists()) f.delete();
            showToast("تم مسح السجل");
        } catch (Exception e) { log("error", TAG, "clearLog: " + e.getMessage()); }
    }

    private File getLogFile() {
        File dir = activity.getFilesDir();
        return new File(dir, "dashboard.log");
    }

    private File writeLogToFile() {
        try {
            File f = getLogFile();
            OutputStreamWriter w = new OutputStreamWriter(new FileOutputStream(f), StandardCharsets.UTF_8);
            synchronized (logBuffer) { w.write(logBuffer.toString()); }
            w.close();
            return f;
        } catch (Exception e) { Log.e(TAG, "writeLogToFile: " + e.getMessage()); return null; }
    }

    // ============================================================
    // ============ أدوات مساعدة =
    // ============================================================

    private static String safeStr(String s) { return s == null ? "" : s; }

    private String drawableToBase64(Drawable d) {
        try {
            if (d == null) return "";
            Bitmap bmp;
            if (d instanceof BitmapDrawable) {
                bmp = ((BitmapDrawable) d).getBitmap();
            } else {
                int size = 96;
                bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
                Canvas c = new Canvas(bmp);
                d.setBounds(0, 0, size, size);
                d.draw(c);
            }
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            bmp.compress(Bitmap.CompressFormat.PNG, 80, baos);
            return Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP);
        } catch (Exception e) { return ""; }
    }
}

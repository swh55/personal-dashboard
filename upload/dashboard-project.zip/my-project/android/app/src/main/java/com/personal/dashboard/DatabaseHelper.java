package com.personal.dashboard;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * قاعدة بيانات SQLite محلية تحوي كل جداول لوحة التحكم.
 * تدعم الترقية من الإصدار 1 إلى 2 (إضافة جداول جديدة) بدون فقدان البيانات.
 */
public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "dashboard.db";
    private static final int DATABASE_VERSION = 3;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        createAllTables(db);
        seedData(db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldV, int newV) {
        // ترقية آمنة: نضيف الجداول الجديدة فقط دون لمس القديمة
        if (oldV < 2) {
            safeExec(db, "CREATE TABLE IF NOT EXISTS shortcut_log (id TEXT PRIMARY KEY, shortcutId TEXT, label TEXT, createdAt TEXT)");
            safeExec(db, "CREATE TABLE IF NOT EXISTS app_favorite (id TEXT PRIMARY KEY, packageName TEXT UNIQUE, label TEXT, position INTEGER DEFAULT 0, createdAt TEXT)");
            safeExec(db, "CREATE TABLE IF NOT EXISTS app_widget (id TEXT PRIMARY KEY, type TEXT, packageName TEXT, position INTEGER DEFAULT 0, config TEXT, createdAt TEXT)");
            safeExec(db, "CREATE TABLE IF NOT EXISTS reminder (id TEXT PRIMARY KEY, title TEXT, time TEXT, repeat TEXT, active INTEGER DEFAULT 1, createdAt TEXT, updatedAt TEXT)");
        }
        if (oldV < 3) {
            safeExec(db, "CREATE TABLE IF NOT EXISTS waiting_item (id TEXT PRIMARY KEY, title TEXT, note TEXT, priority TEXT DEFAULT 'medium', done INTEGER DEFAULT 0, createdAt TEXT, updatedAt TEXT)");
            safeExec(db, "CREATE TABLE IF NOT EXISTS water_log (id TEXT PRIMARY KEY, amount INTEGER DEFAULT 1, date TEXT, createdAt TEXT)");
            safeExec(db, "CREATE TABLE IF NOT EXISTS budget (id TEXT PRIMARY KEY, category TEXT, amount REAL, period TEXT DEFAULT 'monthly', spent REAL DEFAULT 0, createdAt TEXT, updatedAt TEXT)");
            safeExec(db, "CREATE TABLE IF NOT EXISTS saved_location (id TEXT PRIMARY KEY, name TEXT, lat REAL, lng REAL, address TEXT, category TEXT DEFAULT 'other', createdAt TEXT, updatedAt TEXT)");
            safeExec(db, "CREATE TABLE IF NOT EXISTS contact_reminder (id TEXT PRIMARY KEY, contactName TEXT, phone TEXT, frequency TEXT DEFAULT 'weekly', lastContact TEXT, nextContact TEXT, active INTEGER DEFAULT 1, createdAt TEXT, updatedAt TEXT)");
            safeExec(db, "CREATE TABLE IF NOT EXISTS home_maintenance (id TEXT PRIMARY KEY, title TEXT, status TEXT DEFAULT 'pending', frequency TEXT, lastDone TEXT, nextDue TEXT, note TEXT, createdAt TEXT, updatedAt TEXT)");
            safeExec(db, "CREATE TABLE IF NOT EXISTS shopping_item (id TEXT PRIMARY KEY, name TEXT, quantity TEXT, category TEXT, checked INTEGER DEFAULT 0, createdAt TEXT)");
        }
    }

    private void safeExec(SQLiteDatabase db, String sql) {
        try { db.execSQL(sql); } catch (Exception ignored) {}
    }

    private void createAllTables(SQLiteDatabase db) {
        // الإعدادات
        db.execSQL("CREATE TABLE IF NOT EXISTS setting (id TEXT PRIMARY KEY, key TEXT UNIQUE, value TEXT)");

        // المهام
        db.execSQL("CREATE TABLE IF NOT EXISTS task (id TEXT PRIMARY KEY, title TEXT, description TEXT, category TEXT DEFAULT 'home', status TEXT DEFAULT 'todo', priority TEXT DEFAULT 'medium', dueDate TEXT, ord INTEGER DEFAULT 0, deletedAt TEXT, createdAt TEXT, updatedAt TEXT)");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_task_category ON task(category)");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_task_status ON task(status)");

        // جهات الاتصال
        db.execSQL("CREATE TABLE IF NOT EXISTS contact (id TEXT PRIMARY KEY, name TEXT, phone TEXT, whatsapp TEXT, email TEXT, relation TEXT DEFAULT 'other', category TEXT, note TEXT, favorite INTEGER DEFAULT 0, avatar TEXT, deletedAt TEXT, createdAt TEXT, updatedAt TEXT)");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_contact_favorite ON contact(favorite)");

        // الأحداث
        db.execSQL("CREATE TABLE IF NOT EXISTS event (id TEXT PRIMARY KEY, title TEXT, description TEXT, startDate TEXT, endDate TEXT, allDay INTEGER DEFAULT 0, type TEXT DEFAULT 'custom', recurring TEXT, color TEXT DEFAULT 'emerald', location TEXT, deletedAt TEXT, createdAt TEXT, updatedAt TEXT)");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_event_start ON event(startDate)");

        // الملاحظات
        db.execSQL("CREATE TABLE IF NOT EXISTS note (id TEXT PRIMARY KEY, title TEXT, content TEXT, color TEXT DEFAULT 'default', pinned INTEGER DEFAULT 0, deletedAt TEXT, createdAt TEXT, updatedAt TEXT)");

        // المصروفات
        db.execSQL("CREATE TABLE IF NOT EXISTS expense (id TEXT PRIMARY KEY, amount REAL, currency TEXT DEFAULT 'syp', category TEXT DEFAULT 'other', description TEXT, date TEXT, deletedAt TEXT, createdAt TEXT, updatedAt TEXT)");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_expense_date ON expense(date)");

        // الأصول
        db.execSQL("CREATE TABLE IF NOT EXISTS asset (id TEXT PRIMARY KEY, type TEXT, amount REAL, unit TEXT, note TEXT, createdAt TEXT, updatedAt TEXT)");

        // المناسبات
        db.execSQL("CREATE TABLE IF NOT EXISTS occasion (id TEXT PRIMARY KEY, title TEXT, date TEXT, type TEXT DEFAULT 'birthday', recurring INTEGER DEFAULT 1, note TEXT, createdAt TEXT, updatedAt TEXT)");

        // العادات
        db.execSQL("CREATE TABLE IF NOT EXISTS habit (id TEXT PRIMARY KEY, name TEXT, description TEXT, icon TEXT DEFAULT 'CheckCircle', color TEXT DEFAULT 'emerald', frequency TEXT DEFAULT 'daily', target INTEGER DEFAULT 1, createdAt TEXT, updatedAt TEXT)");
        db.execSQL("CREATE TABLE IF NOT EXISTS habit_log (id TEXT PRIMARY KEY, habitId TEXT, date TEXT, count INTEGER DEFAULT 1, note TEXT, createdAt TEXT)");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_habitlog_habit ON habit_log(habitId)");

        // الديون
        db.execSQL("CREATE TABLE IF NOT EXISTS debt (id TEXT PRIMARY KEY, personName TEXT, amount REAL, currency TEXT DEFAULT 'syp', type TEXT DEFAULT 'owed', description TEXT, dueDate TEXT, settled INTEGER DEFAULT 0, settledAt TEXT, deletedAt TEXT, createdAt TEXT, updatedAt TEXT)");

        // سجل النشاط
        db.execSQL("CREATE TABLE IF NOT EXISTS activity_log (id TEXT PRIMARY KEY, action TEXT, entity TEXT, entityId TEXT, title TEXT, details TEXT, createdAt TEXT)");

        // سجل المكالمات
        db.execSQL("CREATE TABLE IF NOT EXISTS call_log (id TEXT PRIMARY KEY, contactId TEXT, name TEXT, phone TEXT, type TEXT DEFAULT 'call', direction TEXT DEFAULT 'outgoing', duration INTEGER DEFAULT 0, note TEXT, createdAt TEXT)");

        // المشاريع
        db.execSQL("CREATE TABLE IF NOT EXISTS project (id TEXT PRIMARY KEY, name TEXT, description TEXT, status TEXT DEFAULT 'planning', progress INTEGER DEFAULT 0, startDate TEXT, endDate TEXT, color TEXT DEFAULT 'emerald', deletedAt TEXT, createdAt TEXT, updatedAt TEXT)");
        db.execSQL("CREATE TABLE IF NOT EXISTS project_task (id TEXT PRIMARY KEY, projectId TEXT, title TEXT, status TEXT DEFAULT 'todo', ord INTEGER DEFAULT 0)");

        // الاجتماعات
        db.execSQL("CREATE TABLE IF NOT EXISTS meeting (id TEXT PRIMARY KEY, title TEXT, description TEXT, startTime TEXT, endTime TEXT, location TEXT, attendees TEXT, notes TEXT, status TEXT DEFAULT 'upcoming', deletedAt TEXT, createdAt TEXT, updatedAt TEXT)");

        // المذكرات
        db.execSQL("CREATE TABLE IF NOT EXISTS diary_entry (id TEXT PRIMARY KEY, date TEXT, mood TEXT DEFAULT 'neutral', title TEXT, content TEXT, weather TEXT, deletedAt TEXT, createdAt TEXT, updatedAt TEXT)");

        // الأدوية
        db.execSQL("CREATE TABLE IF NOT EXISTS medication (id TEXT PRIMARY KEY, name TEXT, dosage TEXT, frequency TEXT DEFAULT 'daily', times TEXT, startDate TEXT, endDate TEXT, active INTEGER DEFAULT 1, note TEXT, deletedAt TEXT, createdAt TEXT, updatedAt TEXT)");

        // النوم
        db.execSQL("CREATE TABLE IF NOT EXISTS sleep_log (id TEXT PRIMARY KEY, bedtime TEXT, wakeTime TEXT, quality INTEGER DEFAULT 3, note TEXT, createdAt TEXT)");

        // القرآن
        db.execSQL("CREATE TABLE IF NOT EXISTS quran_log (id TEXT PRIMARY KEY, surah INTEGER, fromAyah INTEGER, toAyah INTEGER, juz INTEGER, date TEXT, note TEXT, createdAt TEXT)");

        // الحسابات
        db.execSQL("CREATE TABLE IF NOT EXISTS account (id TEXT PRIMARY KEY, name TEXT, platform TEXT, username TEXT, url TEXT, icon TEXT, category TEXT DEFAULT 'personal', createdAt TEXT, updatedAt TEXT)");

        // ====== جداول الإصدار 2 ======
        db.execSQL("CREATE TABLE IF NOT EXISTS shortcut_log (id TEXT PRIMARY KEY, shortcutId TEXT, label TEXT, createdAt TEXT)");
        db.execSQL("CREATE TABLE IF NOT EXISTS app_favorite (id TEXT PRIMARY KEY, packageName TEXT UNIQUE, label TEXT, position INTEGER DEFAULT 0, createdAt TEXT)");
        db.execSQL("CREATE TABLE IF NOT EXISTS app_widget (id TEXT PRIMARY KEY, type TEXT, packageName TEXT, position INTEGER DEFAULT 0, config TEXT, createdAt TEXT)");
        db.execSQL("CREATE TABLE IF NOT EXISTS reminder (id TEXT PRIMARY KEY, title TEXT, time TEXT, repeat TEXT, active INTEGER DEFAULT 1, createdAt TEXT, updatedAt TEXT)");
        // ====== جداول إضافية (v2.1) ======
        db.execSQL("CREATE TABLE IF NOT EXISTS waiting_item (id TEXT PRIMARY KEY, title TEXT, note TEXT, priority TEXT DEFAULT 'medium', done INTEGER DEFAULT 0, createdAt TEXT, updatedAt TEXT)");
        db.execSQL("CREATE TABLE IF NOT EXISTS water_log (id TEXT PRIMARY KEY, amount INTEGER DEFAULT 1, date TEXT, createdAt TEXT)");
        db.execSQL("CREATE TABLE IF NOT EXISTS budget (id TEXT PRIMARY KEY, category TEXT, amount REAL, period TEXT DEFAULT 'monthly', spent REAL DEFAULT 0, createdAt TEXT, updatedAt TEXT)");
        db.execSQL("CREATE TABLE IF NOT EXISTS saved_location (id TEXT PRIMARY KEY, name TEXT, lat REAL, lng REAL, address TEXT, category TEXT DEFAULT 'other', createdAt TEXT, updatedAt TEXT)");
        db.execSQL("CREATE TABLE IF NOT EXISTS contact_reminder (id TEXT PRIMARY KEY, contactName TEXT, phone TEXT, frequency TEXT DEFAULT 'weekly', lastContact TEXT, nextContact TEXT, active INTEGER DEFAULT 1, createdAt TEXT, updatedAt TEXT)");
        db.execSQL("CREATE TABLE IF NOT EXISTS home_maintenance (id TEXT PRIMARY KEY, title TEXT, status TEXT DEFAULT 'pending', frequency TEXT, lastDone TEXT, nextDue TEXT, note TEXT, createdAt TEXT, updatedAt TEXT)");
        db.execSQL("CREATE TABLE IF NOT EXISTS shopping_item (id TEXT PRIMARY KEY, name TEXT, quantity TEXT, category TEXT, checked INTEGER DEFAULT 0, createdAt TEXT)");
    }

    private void seedData(SQLiteDatabase db) {
        // إعدادات افتراضية
        safeExec(db, "INSERT OR IGNORE INTO setting (id, key, value) VALUES ('1', 'pinEnabled', 'false')");
        safeExec(db, "INSERT OR IGNORE INTO setting (id, key, value) VALUES ('2', 'autoNightMode', 'false')");
        safeExec(db, "INSERT OR IGNORE INTO setting (id, key, value) VALUES ('3', 'weekStartDay', '6')");
        // لا بيانات شخصية — المستخدم يضيف بياناته بنفسه

        // عادات
        String[][] habits = {{"صلاة الفجر في وقتها", "Sunrise", "emerald"}, {"قراءة القرآن", "Book", "teal"}, {"ممارسة الرياضة", "Activity", "amber"}, {"شرب 8 أكواب ماء", "Droplets", "teal"}, {"مراجعة الأهداف", "Target", "rose"}, {"الاتصال بالعائلة", "Heart", "rose"}};
        for (int i = 0; i < habits.length; i++) {
            safeExec(db, "INSERT OR IGNORE INTO habit (id, name, description, icon, color, frequency, target, createdAt, updatedAt) VALUES ('habit" + i + "', '" + habits[i][0] + "', '', '" + habits[i][1] + "', '" + habits[i][2] + "', 'daily', 1, datetime('now'), datetime('now'))");
        }

        // ملاحظات
        safeExec(db, "INSERT OR IGNORE INTO note (id, title, content, color, pinned, createdAt, updatedAt) VALUES ('note1', 'أهداف الشهر', '1. زيادة المبيعات بنسبة 15%\n2. افتتاح فرع جديد\n3. تجديد رخصة السجل التجاري', 'default', 1, datetime('now'), datetime('now'))");
        safeExec(db, "INSERT OR IGNORE INTO note (id, title, content, color, pinned, createdAt, updatedAt) VALUES ('note2', 'أفكار', 'دراسة جدوى لمشروع تجاري جديد في سوق حلب الجديد', 'default', 0, datetime('now'), datetime('now'))");

        // أحداث متكررة
        safeExec(db, "INSERT OR IGNORE INTO event (id, title, description, startDate, endDate, allDay, type, recurring, color, location, createdAt, updatedAt) VALUES ('ev1', 'دوام السجل التجاري', '', datetime('now','+8 hours'), datetime('now','+15 hours'), 0, 'work', 'weekdays', 'blue', 'السجل التجاري', datetime('now'), datetime('now'))");
    }
}

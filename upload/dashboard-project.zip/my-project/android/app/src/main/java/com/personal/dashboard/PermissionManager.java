package com.personal.dashboard;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;
import java.util.List;

/**
 * مدير مركزي للأذونات وقت التشغيل.
 * يوفّر طلب أذونات فردية أو متعددة، والتحقق من حالتها.
 */
public class PermissionManager {

    private final Activity activity;
    private final ActivityResultLauncher<String> singleLauncher;
    private final ActivityResultLauncher<String[]> multiLauncher;

    public PermissionManager(Activity activity,
                             ActivityResultLauncher<String> singleLauncher,
                             ActivityResultLauncher<String[]> multiLauncher) {
        this.activity = activity;
        this.singleLauncher = singleLauncher;
        this.multiLauncher = multiLauncher;
    }

    public boolean hasPermission(String permission) {
        return ContextCompat.checkSelfPermission(activity, permission) == PackageManager.PERMISSION_GRANTED;
    }

    public void request(String permission) {
        if (!hasPermission(permission)) {
            activity.runOnUiThread(() -> singleLauncher.launch(permission));
        }
    }

    public void requestMany(String[] permissions) {
        List<String> needed = new ArrayList<>();
        for (String p : permissions) {
            if (!hasPermission(p)) needed.add(p);
        }
        if (!needed.isEmpty()) {
            activity.runOnUiThread(() -> multiLauncher.launch(needed.toArray(new String[0])));
        }
    }

    /** كل الأذونات الحرجة مرتبطة بميزات لوحة التحكم */
    public static final String[] CRITICAL = {
        Manifest.permission.CALL_PHONE,
        Manifest.permission.SEND_SMS,
        Manifest.permission.READ_CONTACTS,
        Manifest.permission.ACCESS_FINE_LOCATION,
        Manifest.permission.CAMERA,
        Manifest.permission.POST_NOTIFICATIONS,
    };

    /** بنية JSON بحالة كل الأذونات لإرسالها للواجهة */
    public String permissionStatusJson() {
        StringBuilder sb = new StringBuilder("{");
        String[] perms = {
            "CALL_PHONE", "READ_CONTACTS", "WRITE_CONTACTS", "SEND_SMS", "READ_SMS",
            "ACCESS_FINE_LOCATION", "ACCESS_COARSE_LOCATION", "CAMERA", "RECORD_AUDIO",
            "POST_NOTIFICATIONS", "READ_CALL_LOG", "READ_MEDIA_IMAGES", "READ_MEDIA_VIDEO",
            "READ_MEDIA_AUDIO"
        };
        for (int i = 0; i < perms.length; i++) {
            if (i > 0) sb.append(",");
            String fullName = "android.permission." + perms[i];
            sb.append('"').append(perms[i]).append("\":")
              .append(hasPermission(fullName));
        }
        sb.append("}");
        return sb.toString();
    }
}

package com.personal.dashboard;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.widget.RemoteViews;

/**
 * Widget host receiver — يعرض معلومات سريعة على شاشة الهاتف الرئيسية.
 * يدعم وضع التطبيق كـ Launcher مع widgets من تطبيقات أخرى.
 */
public class AppWidgetHostReceiver extends AppWidgetProvider {

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        for (int appWidgetId : appWidgetIds) {
            try {
                updateWidget(context, appWidgetManager, appWidgetId);
            } catch (Exception e) {
                android.util.Log.w("Widget", "update failed: " + e.getMessage());
            }
        }
    }

    private void updateWidget(Context context, AppWidgetManager manager, int widgetId) {
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.appwidget_host);

        try {
            // اقرأ البيانات من SharedPreferences (مشاركة مع WebView localStorage)
            android.content.SharedPreferences prefs = context.getSharedPreferences("dashboard_data", Context.MODE_PRIVATE);
            int taskCount = prefs.getInt("widget_tasks", 0);
            int contactCount = prefs.getInt("widget_contacts", 0);
            String nextPrayer = prefs.getString("widget_prayer", "—");

            views.setTextViewText(R.id.widgetTasks, "المهام المعلّقة: " + taskCount);
            views.setTextViewText(R.id.widgetContacts, "جهات الاتصال: " + contactCount);
            views.setTextViewText(R.id.widgetPrayer, "الصلاة القادمة: " + nextPrayer);
        } catch (Exception e) {
            views.setTextViewText(R.id.widgetTasks, "المهام: —");
            views.setTextViewText(R.id.widgetContacts, "جهات: —");
            views.setTextViewText(R.id.widgetPrayer, "الصلاة: —");
        }

        manager.updateAppWidget(widgetId, views);
    }
}

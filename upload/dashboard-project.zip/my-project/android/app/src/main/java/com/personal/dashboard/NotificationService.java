package com.personal.dashboard;

import android.app.Notification;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;

import androidx.core.app.NotificationCompat;

/**
 * خدمة أمامية مستمرة تضمن بقاء لوحة التحكم حية في الخلفية.
 * معالجة آمنة لـ ForegroundServiceStartNotAllowedException على Android 12+.
 */
public class NotificationService extends Service {

    private static final String TAG = "NotificationService";
    private static final int NOTIF_ID = 1;

    @Override
    public void onCreate() {
        super.onCreate();
        // لا نبدأ foreground هنا — ننتظر onStartCommand
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        try {
            startForegroundCompat();
        } catch (Exception e) {
            Log.w(TAG, "startForeground failed: " + e.getMessage());
            // إذا فشل، أعد المحاولة لاحقاً عبر START_STICKY
        }
        return START_STICKY;
    }

    private void startForegroundCompat() {
        try {
            Notification n = new NotificationCompat.Builder(this, DashboardApplication.CHANNEL_ID)
                .setContentTitle("لوحة التحكم")
                .setContentText("تعمل في الخلفية — مزامنة الإشعارات والمهام")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setOngoing(true)
                .setShowWhen(false)
                .build();

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                // Android 14+: يجب تحديد foregroundServiceType صراحة
                // نستخدم dataSync لأنه متاح ولا يتطلب إذناً إضافياً فوق FOREGROUND_SERVICE_DATA_SYNC
                startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
            } else {
                startForeground(NOTIF_ID, n);
            }
        } catch (SecurityException e) {
            // ForegroundServiceStartNotAllowedException (Android 12+)
            Log.w(TAG, "Cannot start foreground (not allowed): " + e.getMessage());
            // الخدمة ستبقى تعمل كخدمة عادية
        } catch (Exception e) {
            Log.w(TAG, "startForeground error: " + e.getMessage());
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        try {
            Intent restart = new Intent(this, NotificationService.class);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(restart);
            } else {
                startService(restart);
            }
        } catch (Exception e) {
            Log.w(TAG, "onTaskRemoved restart: " + e.getMessage());
        }
        super.onTaskRemoved(rootIntent);
    }
}

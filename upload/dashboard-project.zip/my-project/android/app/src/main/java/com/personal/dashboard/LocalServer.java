package com.personal.dashboard;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import fi.iki.elonen.NanoHTTPD;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.UUID;

/**
 * خادم HTTP محلي مضمّن (NanoHTTPD) على المنفذ 8765.
 * يخدم:
 *   1) الملفات الثابتة من assets/web/
 *   2) مسارات /api/* مدعومة بقاعدة SQLite محلية (DatabaseHelper)
 *
 * كل الاستعلامات تستخدم parameterized queries لمنع حقن SQL.
 */
public class LocalServer extends NanoHTTPD {

    private final Context context;
    private final DatabaseHelper dbHelper;

    private static volatile LocalServer instance = null;

    public LocalServer(Context context, int port) throws IOException {
        super(port);
        this.context = context;
        this.dbHelper = new DatabaseHelper(context);
        // أوقف أي خادم سابق على نفس المنفذ قبل البدء
        try {
            if (instance != null) {
                try { instance.stop(); } catch (Exception ignored) {}
                instance = null;
                Thread.sleep(100);
            }
        } catch (Exception ignored) {}
        start(SOCKET_READ_TIMEOUT, false);
        instance = this;
    }

    /** إيقاف آمن للخادم */
    @Override
    public void stop() {
        try { super.stop(); } catch (Exception ignored) {}
        if (instance == this) instance = null;
    }

    @Override
    public Response serve(IHTTPSession session) {
        String uri = session.getUri();
        Method method = session.getMethod();
        // CORS headers للسماح بأي مصدر (محلي فقط)
        try {
            if (uri.startsWith("/api/")) {
                Response r = handleApi(session, uri, method);
                r.addHeader("Access-Control-Allow-Origin", "*");
                r.addHeader("Access-Control-Allow-Methods", "GET,POST,PUT,DELETE,OPTIONS");
                r.addHeader("Access-Control-Allow-Headers", "Content-Type");
                return r;
            }
            if (method == Method.OPTIONS) {
                Response r = newFixedLengthResponse(Response.Status.OK, "text/plain", "");
                r.addHeader("Access-Control-Allow-Origin", "*");
                return r;
            }
            return serveStaticFile(uri);
        } catch (Exception e) {
            return jsonError(e.getMessage());
        }
    }

    // ====== معالجة مسارات API ======
    private Response handleApi(IHTTPSession session, String uri, Method method) throws Exception {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        String body = "";
        if (method == Method.POST || method == Method.PUT) {
            body = readBody(session);
        }
        JSONObject jsonBody = body.isEmpty() ? new JSONObject() : new JSONObject(body);

        // ====== لوحة المعلومات ======
        if (uri.equals("/api/dashboard")) return jsonResponse(getDashboardData(db));

        // ====== الإعدادات ======
        if (uri.equals("/api/settings")) {
            if (method == Method.GET) return jsonResponse(getSettings(db));
            if (method == Method.PUT) { setSetting(db, jsonBody); return jsonSuccess(); }
        }

        // ====== المهام ======
        if (uri.equals("/api/tasks")) {
            if (method == Method.GET) {
                String cat = param(session, "category");
                String where = cat != null ? "deletedAt IS NULL AND category=?" : "deletedAt IS NULL";
                String[] args = cat != null ? new String[]{cat} : null;
                return jsonResponse(getRows(db, "task", where, args, "createdAt DESC"));
            }
            if (method == Method.POST) return jsonResponse(insertRow(db, "task", jsonBody,
                new String[]{"title","description","category","status","priority","dueDate","ord"}));
            if (method == Method.PUT) return jsonResponse(updateRow(db, "task", jsonBody));
            if (method == Method.DELETE) return jsonResponse(deleteRow(db, "task", session));
        }

        // ====== جهات الاتصال ======
        if (uri.equals("/api/contacts")) {
            if (method == Method.GET) {
                String fav = param(session, "favorite");
                String where = "deletedAt IS NULL";
                String[] args = null;
                if ("true".equals(fav)) { where += " AND favorite=1"; }
                String q = param(session, "q");
                if (q != null && !q.isEmpty()) { where += " AND (name LIKE ? OR phone LIKE ?)"; args = args==null?new String[]{"%"+q+"%","%"+q+"%"}:concat(args,new String[]{"%"+q+"%","%"+q+"%"}); }
                return jsonResponse(getRows(db, "contact", where, args, "favorite DESC, name ASC"));
            }
            if (method == Method.POST) return jsonResponse(insertRow(db, "contact", jsonBody,
                new String[]{"name","phone","whatsapp","email","relation","category","note","favorite","avatar"}));
            if (method == Method.PUT) return jsonResponse(updateRow(db, "contact", jsonBody));
            if (method == Method.DELETE) return jsonResponse(deleteRow(db, "contact", session));
        }

        // ====== الأحداث ======
        if (uri.equals("/api/events")) {
            if (method == Method.GET) {
                String from = param(session, "from");
                String to = param(session, "to");
                String where = "deletedAt IS NULL";
                String[] args = null;
                if (from != null && to != null) {
                    where += " AND startDate >= ? AND startDate <= ?";
                    args = new String[]{from, to};
                }
                return jsonResponse(getRows(db, "event", where, args, "startDate ASC"));
            }
            if (method == Method.POST) return jsonResponse(insertRow(db, "event", jsonBody,
                new String[]{"title","description","startDate","endDate","allDay","type","recurring","color","location"}));
            if (method == Method.PUT) return jsonResponse(updateRow(db, "event", jsonBody));
            if (method == Method.DELETE) return jsonResponse(deleteRow(db, "event", session));
        }

        // ====== الملاحظات ======
        if (uri.equals("/api/notes")) {
            if (method == Method.GET) return jsonResponse(getRows(db, "note", "deletedAt IS NULL", null, "pinned DESC, createdAt DESC"));
            if (method == Method.POST) return jsonResponse(insertRow(db, "note", jsonBody,
                new String[]{"title","content","color","pinned"}));
            if (method == Method.PUT) return jsonResponse(updateRow(db, "note", jsonBody));
            if (method == Method.DELETE) return jsonResponse(deleteRow(db, "note", session));
        }

        // ====== المصروفات ======
        if (uri.equals("/api/expenses")) {
            if (method == Method.GET) {
                String from = param(session, "from");
                String where = "deletedAt IS NULL";
                String[] args = null;
                if (from != null) { where += " AND date >= ?"; args = new String[]{from}; }
                return jsonResponse(getRows(db, "expense", where, args, "date DESC"));
            }
            if (method == Method.POST) return jsonResponse(insertRow(db, "expense", jsonBody,
                new String[]{"amount","currency","category","description","date"}));
            if (method == Method.DELETE) return jsonResponse(deleteRow(db, "expense", session));
        }

        // ====== الأصول ======
        if (uri.equals("/api/assets")) {
            if (method == Method.GET) return jsonResponse(getRows(db, "asset", null, null, "createdAt DESC"));
            if (method == Method.POST) return jsonResponse(insertRow(db, "asset", jsonBody,
                new String[]{"type","amount","unit","note"}));
            if (method == Method.PUT) return jsonResponse(updateRow(db, "asset", jsonBody));
            if (method == Method.DELETE) return jsonResponse(deleteRow(db, "asset", session));
        }

        // ====== المناسبات ======
        if (uri.equals("/api/occasions")) {
            if (method == Method.GET) return jsonResponse(getRows(db, "occasion", null, null, "date ASC"));
            if (method == Method.POST) return jsonResponse(insertRow(db, "occasion", jsonBody,
                new String[]{"title","date","type","recurring","note"}));
            if (method == Method.DELETE) return jsonResponse(deleteRow(db, "occasion", session));
        }

        // ====== العادات ======
        if (uri.equals("/api/habits")) {
            if (method == Method.GET) return jsonResponse(getRows(db, "habit", null, null, "createdAt DESC"));
            if (method == Method.POST) return jsonResponse(insertRow(db, "habit", jsonBody,
                new String[]{"name","description","icon","color","frequency","target"}));
            if (method == Method.DELETE) return jsonResponse(deleteRow(db, "habit", session));
        }
        if (uri.equals("/api/habit-logs")) {
            if (method == Method.GET) return jsonResponse(getRows(db, "habit_log", null, null, "date DESC"));
            if (method == Method.POST) return jsonResponse(insertRow(db, "habit_log", jsonBody,
                new String[]{"habitId","date","count","note"}));
            if (method == Method.DELETE) return jsonResponse(deleteRow(db, "habit_log", session));
        }

        // ====== الديون ======
        if (uri.equals("/api/debts")) {
            if (method == Method.GET) return jsonResponse(getRows(db, "debt", "settled=0 AND deletedAt IS NULL", null, "dueDate ASC"));
            if (method == Method.POST) return jsonResponse(insertRow(db, "debt", jsonBody,
                new String[]{"personName","amount","currency","type","description","dueDate"}));
            if (method == Method.PUT) return jsonResponse(updateRow(db, "debt", jsonBody));
            if (method == Method.DELETE) return jsonResponse(deleteRow(db, "debt", session));
        }

        // ====== الاجتماعات ======
        if (uri.equals("/api/meetings")) {
            if (method == Method.GET) return jsonResponse(getRows(db, "meeting", "deletedAt IS NULL", null, "startTime ASC"));
            if (method == Method.POST) return jsonResponse(insertRow(db, "meeting", jsonBody,
                new String[]{"title","description","startTime","endTime","location","attendees","status"}));
            if (method == Method.DELETE) return jsonResponse(deleteRow(db, "meeting", session));
        }

        // ====== المشاريع ======
        if (uri.equals("/api/projects")) {
            if (method == Method.GET) return jsonResponse(getRows(db, "project", "deletedAt IS NULL", null, "createdAt DESC"));
            if (method == Method.POST) return jsonResponse(insertRow(db, "project", jsonBody,
                new String[]{"name","description","status","progress","startDate","endDate","color"}));
            if (method == Method.DELETE) return jsonResponse(deleteRow(db, "project", session));
        }

        // ====== المذكرات ======
        if (uri.equals("/api/diary")) {
            if (method == Method.GET) return jsonResponse(getRows(db, "diary_entry", "deletedAt IS NULL", null, "date DESC"));
            if (method == Method.POST) return jsonResponse(insertRow(db, "diary_entry", jsonBody,
                new String[]{"date","mood","title","content","weather"}));
            if (method == Method.DELETE) return jsonResponse(deleteRow(db, "diary_entry", session));
        }

        // ====== الأدوية ======
        if (uri.equals("/api/medications")) {
            if (method == Method.GET) return jsonResponse(getRows(db, "medication", "deletedAt IS NULL AND active=1", null, "createdAt DESC"));
            if (method == Method.POST) return jsonResponse(insertRow(db, "medication", jsonBody,
                new String[]{"name","dosage","frequency","times","startDate","endDate","active","note"}));
            if (method == Method.DELETE) return jsonResponse(deleteRow(db, "medication", session));
        }

        // ====== النوم ======
        if (uri.equals("/api/sleep")) {
            if (method == Method.GET) return jsonResponse(getRows(db, "sleep_log", null, null, "createdAt DESC"));
            if (method == Method.POST) return jsonResponse(insertRow(db, "sleep_log", jsonBody,
                new String[]{"bedtime","wakeTime","quality","note"}));
            if (method == Method.DELETE) return jsonResponse(deleteRow(db, "sleep_log", session));
        }

        // ====== القرآن ======
        if (uri.equals("/api/quran")) {
            if (method == Method.GET) return jsonResponse(getRows(db, "quran_log", null, null, "createdAt DESC"));
            if (method == Method.POST) return jsonResponse(insertRow(db, "quran_log", jsonBody,
                new String[]{"surah","fromAyah","toAyah","juz","date","note"}));
            if (method == Method.DELETE) return jsonResponse(deleteRow(db, "quran_log", session));
        }

        // ====== الحسابات ======
        if (uri.equals("/api/accounts")) {
            if (method == Method.GET) return jsonResponse(getRows(db, "account", null, null, "createdAt DESC"));
            if (method == Method.POST) return jsonResponse(insertRow(db, "account", jsonBody,
                new String[]{"name","platform","username","url","icon","category"}));
            if (method == Method.DELETE) return jsonResponse(deleteRow(db, "account", session));
        }

        // ====== سجل النشاط ======
        if (uri.equals("/api/activity")) {
            if (method == Method.GET) return jsonResponse(getRows(db, "activity_log", null, null, "createdAt DESC"));
            if (method == Method.DELETE) { db.execSQL("DELETE FROM activity_log"); return jsonSuccess(); }
        }

        // ====== سجل المكالمات ======
        if (uri.equals("/api/calllogs")) {
            if (method == Method.GET) return jsonResponse(getRows(db, "call_log", null, null, "createdAt DESC"));
            if (method == Method.POST) return jsonResponse(insertRow(db, "call_log", jsonBody,
                new String[]{"contactId","name","phone","type","direction","duration","note"}));
            if (method == Method.DELETE) return jsonResponse(deleteRow(db, "call_log", session));
        }

        // ====== سجل الاختصارات ======
        if (uri.equals("/api/shortcut-log")) {
            if (method == Method.GET) return jsonResponse(getRows(db, "shortcut_log", null, null, "createdAt DESC"));
            if (method == Method.POST) return jsonResponse(insertRow(db, "shortcut_log", jsonBody,
                new String[]{"shortcutId","label"}));
        }

        // ====== مواقيت الصلاة (محسوبة تقريبياً) ======
        if (uri.startsWith("/api/prayer-times")) {
            return jsonResponse(prayerTimesData());
        }

        // ====== الطقس (ثابت تقريبي) ======
        if (uri.startsWith("/api/weather")) {
            return jsonResponse(weatherData());
        }

        // ====== الإشعارات ======
        if (uri.startsWith("/api/notifications")) {
            return jsonResponse(notificationsData(db));
        }

        // ====== الإحصائيات ======
        if (uri.startsWith("/api/stats")) {
            String period = param(session, "period");
            return jsonResponse(statsData(db, period));
        }

        // ====== أسعار العملات ======
        if (uri.startsWith("/api/currency")) {
            return jsonResponse(currencyData());
        }

        // ====== سلة المحذوفات ======
        if (uri.startsWith("/api/recycle-bin")) {
            return jsonResponse(recycleBinData(db));
        }

        // ====== Launcher: التطبيقات المفضلة ======
        if (uri.equals("/api/launcher/favorites")) {
            if (method == Method.GET) return jsonResponse(getRows(db, "app_favorite", null, null, "position ASC"));
            if (method == Method.POST) return jsonResponse(insertRow(db, "app_favorite", jsonBody,
                new String[]{"packageName","label","position"}));
            if (method == Method.DELETE) return jsonResponse(deleteRow(db, "app_favorite", session));
        }

        // ====== قائمة التسوق (مهام بفئة shopping) ======
        if (uri.equals("/api/shopping")) {
            if (method == Method.GET) return jsonResponse(getRows(db, "task", "category='shopping' AND deletedAt IS NULL", null, "createdAt DESC"));
            if (method == Method.POST) return jsonResponse(insertRow(db, "task", jsonBody,
                new String[]{"title","status","priority"}));
            if (method == Method.PUT) return jsonResponse(updateRow(db, "task", jsonBody));
            if (method == Method.DELETE) return jsonResponse(deleteRow(db, "task", session));
        }

        // ====== قائمة الانتظار ======
        if (uri.equals("/api/waiting-list")) {
            if (method == Method.GET) return jsonResponse(getRows(db, "waiting_item", null, null, "createdAt DESC"));
            if (method == Method.POST) return jsonResponse(insertRow(db, "waiting_item", jsonBody,
                new String[]{"title","note","priority"}));
            if (method == Method.DELETE) return jsonResponse(deleteRow(db, "waiting_item", session));
        }

        // ====== شرب الماء ======
        if (uri.equals("/api/water")) {
            if (method == Method.GET) return jsonResponse(getRows(db, "water_log", null, null, "createdAt DESC"));
            if (method == Method.POST) return jsonResponse(insertRow(db, "water_log", jsonBody,
                new String[]{"amount","date"}));
            if (method == Method.DELETE) return jsonResponse(deleteRow(db, "water_log", session));
        }

        // ====== الميزانية ======
        if (uri.equals("/api/budget")) {
            if (method == Method.GET) return jsonResponse(getRows(db, "budget", null, null, "createdAt DESC"));
            if (method == Method.POST) return jsonResponse(insertRow(db, "budget", jsonBody,
                new String[]{"category","limit","period","spent"}));
            if (method == Method.PUT) return jsonResponse(updateRow(db, "budget", jsonBody));
            if (method == Method.DELETE) return jsonResponse(deleteRow(db, "budget", session));
        }

        // ====== المواقع المحفوظة ======
        if (uri.equals("/api/locations")) {
            if (method == Method.GET) return jsonResponse(getRows(db, "saved_location", null, null, "createdAt DESC"));
            if (method == Method.POST) return jsonResponse(insertRow(db, "saved_location", jsonBody,
                new String[]{"name","lat","lng","address","category"}));
            if (method == Method.DELETE) return jsonResponse(deleteRow(db, "saved_location", session));
        }

        // ====== تذكيرات جهات الاتصال ======
        if (uri.equals("/api/contact-reminders")) {
            if (method == Method.GET) return jsonResponse(getRows(db, "contact_reminder", null, null, "nextContact ASC"));
            if (method == Method.POST) return jsonResponse(insertRow(db, "contact_reminder", jsonBody,
                new String[]{"contactName","phone","frequency","lastContact","nextContact"}));
            if (method == Method.PUT) return jsonResponse(updateRow(db, "contact_reminder", jsonBody));
            if (method == Method.DELETE) return jsonResponse(deleteRow(db, "contact_reminder", session));
        }

        // ====== إدارة المنزل ======
        if (uri.equals("/api/home-maintenance")) {
            if (method == Method.GET) return jsonResponse(getRows(db, "home_maintenance", null, null, "createdAt DESC"));
            if (method == Method.POST) return jsonResponse(insertRow(db, "home_maintenance", jsonBody,
                new String[]{"title","status","frequency","lastDone","nextDue"}));
            if (method == Method.DELETE) return jsonResponse(deleteRow(db, "home_maintenance", session));
        }

        // ====== البحث الشامل ======
        if (uri.startsWith("/api/search")) {
            String q = param(session, "q");
            JSONObject results = new JSONObject();
            if (q != null && !q.isEmpty()) {
                String like = "%" + q + "%";
                results.put("tasks", getRows(db, "task", "deletedAt IS NULL AND (title LIKE ? OR description LIKE ?)", new String[]{like, like}, "createdAt DESC"));
                results.put("contacts", getRows(db, "contact", "deletedAt IS NULL AND (name LIKE ? OR phone LIKE ?)", new String[]{like, like}, "name ASC"));
                results.put("notes", getRows(db, "note", "deletedAt IS NULL AND (title LIKE ? OR content LIKE ?)", new String[]{like, like}, "createdAt DESC"));
                results.put("events", getRows(db, "event", "deletedAt IS NULL AND (title LIKE ? OR description LIKE ?)", new String[]{like, like}, "startDate ASC"));
            }
            return jsonResponse(results);
        }

        // ====== الافتراضي ======
        return jsonResponse(new JSONArray());
    }

    // ====== Helpers ======

    /** بناء استجابة من bytes بصيغة UTF-8 صريحة (يمنع تشويه العربية) */
    private Response newUtf8Response(Response.Status status, String mime, String body) {
        try {
            byte[] bytes = body.getBytes("UTF-8");
            java.io.InputStream is = new java.io.ByteArrayInputStream(bytes);
            Response r = newFixedLengthResponse(status, mime, is, bytes.length);
            r.addHeader("Content-Type", mime + "; charset=utf-8");
            r.addHeader("Cache-Control", "no-cache, no-store, must-revalidate");
            return r;
        } catch (Exception e) {
            return newFixedLengthResponse(status, mime, "");
        }
    }

    private Response jsonResponse(Object data) {
        try {
            JSONObject r = new JSONObject();
            r.put("success", true);
            if (data instanceof JSONArray) r.put("data", data);
            else if (data instanceof JSONObject) r.put("data", data);
            else r.put("data", data);
            return newUtf8Response(Response.Status.OK, "application/json", r.toString());
        } catch (Exception e) {
            return jsonError(e.getMessage());
        }
    }

    private Response jsonSuccess() {
        return newUtf8Response(Response.Status.OK, "application/json", "{\"success\":true}");
    }

    private Response jsonError(String msg) {
        String m = msg == null ? "unknown" : msg.replace("\"", "'");
        return newUtf8Response(Response.Status.INTERNAL_ERROR, "application/json",
            "{\"success\":false,\"error\":\"" + m + "\"}");
    }

    private String readBody(IHTTPSession session) throws Exception {
        // قراءة الـ body يدوياً من InputStream بصيغة UTF-8 صريحة
        // (session.parseBody يستخدم الترميز الافتراضي للنظام مما يشوّه العربية)
        try {
            // احصل على Content-Length من headers
            java.util.Map<String, String> headers = session.getHeaders();
            long cl = 0;
            if (headers != null) {
                String clStr = headers.get("content-length");
                if (clStr == null) clStr = headers.get("Content-Length");
                if (clStr != null) {
                    try { cl = Long.parseLong(clStr); } catch (Exception ignored) {}
                }
            }
            if (cl <= 0) return "";
            java.io.InputStream is = session.getInputStream();
            if (is == null) return "";
            ByteArrayOutputStream baos = new ByteArrayOutputStream((int) cl);
            byte[] buf = new byte[4096];
            int remaining = (int) cl;
            while (remaining > 0) {
                int toRead = Math.min(remaining, buf.length);
                int n = is.read(buf, 0, toRead);
                if (n < 0) break;
                baos.write(buf, 0, n);
                remaining -= n;
            }
            byte[] bytes = baos.toByteArray();
            return new String(bytes, "UTF-8");
        } catch (Exception e) {
            // fallback إلى parseBody مع إعادة ترميز UTF-8
            try {
                HashMap<String, String> files = new HashMap<>();
                session.parseBody(files);
                String body = files.get("postData");
                if (body == null) return "";
                // أعد ترميز من ISO-8859-1 إلى UTF-8
                return new String(body.getBytes("ISO-8859-1"), "UTF-8");
            } catch (Exception ex) {
                return "";
            }
        }
    }

    private String param(IHTTPSession session, String key) {
        java.util.List<String> v = session.getParameters().get(key);
        return (v != null && !v.isEmpty()) ? v.get(0) : null;
    }

    private String[] concat(String[] a, String[] b) {
        String[] r = new String[a.length + b.length];
        System.arraycopy(a, 0, r, 0, a.length);
        System.arraycopy(b, 0, r, a.length, b.length);
        return r;
    }

    private JSONArray getRows(SQLiteDatabase db, String table, String where, String[] args, String order) {
        JSONArray arr = new JSONArray();
        StringBuilder q = new StringBuilder("SELECT * FROM ").append(table);
        if (where != null) q.append(" WHERE ").append(where);
        if (order != null) q.append(" ORDER BY ").append(order);
        Cursor c = db.rawQuery(q.toString(), args);
        while (c.moveToNext()) arr.put(cursorToJson(c));
        c.close();
        return arr;
    }

    private JSONObject cursorToJson(Cursor c) {
        JSONObject o = new JSONObject();
        for (int i = 0; i < c.getColumnCount(); i++) {
            String col = c.getColumnName(i);
            int type = c.getType(i);
            try {
                if (type == Cursor.FIELD_TYPE_INTEGER) o.put(col, c.getInt(i));
                else if (type == Cursor.FIELD_TYPE_FLOAT) o.put(col, c.getDouble(i));
                else if (c.isNull(i)) o.put(col, JSONObject.NULL);
                else o.put(col, c.getString(i));
            } catch (Exception e) {
                try { o.put(col, ""); } catch (Exception ignored) {}
            }
        }
        return o;
    }

    private JSONObject insertRow(SQLiteDatabase db, String table, JSONObject json, String[] fields) throws Exception {
        String id = UUID.randomUUID().toString();
        StringBuilder cols = new StringBuilder("id, createdAt, updatedAt");
        StringBuilder ph = new StringBuilder("?, datetime('now'), datetime('now')");
        java.util.List<String> args = new java.util.ArrayList<>();
        args.add(id);
        for (String f : fields) {
            if (json.has(f) && !json.isNull(f)) {
                cols.append(", ").append(f);
                ph.append(", ?");
                Object v = json.get(f);
                if (v instanceof Boolean) args.add(((Boolean) v) ? "1" : "0");
                else if (v instanceof JSONObject || v instanceof JSONArray) args.add(v.toString());
                else args.add(String.valueOf(v));
            }
        }
        db.execSQL("INSERT INTO " + table + " (" + cols + ") VALUES (" + ph + ")", args.toArray());
        JSONObject r = new JSONObject();
        r.put("id", id);
        r.put("success", true);
        return r;
    }

    private JSONObject updateRow(SQLiteDatabase db, String table, JSONObject json) throws Exception {
        if (!json.has("id")) throw new IllegalArgumentException("id required");
        String id = json.getString("id");
        StringBuilder set = new StringBuilder();
        java.util.List<String> args = new java.util.ArrayList<>();
        java.util.Iterator<String> keys = json.keys();
        while (keys.hasNext()) {
            String k = keys.next();
            if (k.equals("id") || k.equals("createdAt")) continue;
            if (set.length() > 0) set.append(", ");
            set.append(k).append(" = ?");
            Object v = json.get(k);
            if (v instanceof Boolean) args.add(((Boolean) v) ? "1" : "0");
            else if (v instanceof JSONObject || v instanceof JSONArray) args.add(v.toString());
            else args.add(String.valueOf(v));
        }
        set.append(", updatedAt = datetime('now')");
        args.add(id);
        db.execSQL("UPDATE " + table + " SET " + set + " WHERE id = ?", args.toArray());
        JSONObject r = new JSONObject();
        r.put("id", id);
        r.put("success", true);
        return r;
    }

    private JSONObject deleteRow(SQLiteDatabase db, String table, IHTTPSession session) throws Exception {
        String id = param(session, "id");
        JSONObject r = new JSONObject();
        r.put("success", true);
        if (id != null) {
            // حذف ناعم إن وُجد deletedAt، وإلا حذف صلب
            try {
                db.execSQL("UPDATE " + table + " SET deletedAt = datetime('now') WHERE id = ?", new Object[]{id});
            } catch (Exception e) {
                db.execSQL("DELETE FROM " + table + " WHERE id = ?", new Object[]{id});
            }
        }
        return r;
    }

    private JSONObject getSettings(SQLiteDatabase db) throws Exception {
        JSONObject result = new JSONObject();
        Cursor c = db.rawQuery("SELECT key, value FROM setting", null);
        while (c.moveToNext()) result.put(c.getString(0), c.getString(1));
        c.close();
        if (!result.has("pinEnabled")) result.put("pinEnabled", "false");
        if (!result.has("pinCode")) result.put("pinCode", "");
        if (!result.has("autoNightMode")) result.put("autoNightMode", "false");
        if (!result.has("weekStartDay")) result.put("weekStartDay", "6");
        return result;
    }

    private void setSetting(SQLiteDatabase db, JSONObject json) throws Exception {
        String key = json.getString("key");
        String value = json.getString("value");
        db.execSQL("INSERT OR REPLACE INTO setting (id, key, value) VALUES (?, ?, ?)",
            new Object[]{"set_" + key, key, value});
    }

    private JSONObject getDashboardData(SQLiteDatabase db) throws Exception {
        JSONObject data = new JSONObject();
        // أحداث اليوم
        JSONArray events = getRows(db, "event", "deletedAt IS NULL", null, "startDate ASC");
        data.put("todayEvents", events);
        // إحصائيات المهام
        JSONObject taskStats = new JSONObject();
        taskStats.put("pending", count(db, "SELECT COUNT(*) FROM task WHERE status!='done' AND deletedAt IS NULL"));
        taskStats.put("done", count(db, "SELECT COUNT(*) FROM task WHERE status='done' AND deletedAt IS NULL"));
        taskStats.put("total", taskStats.getInt("pending") + taskStats.getInt("done"));
        data.put("taskStats", taskStats);
        // إحصائيات جهات الاتصال
        JSONObject contactStats = new JSONObject();
        contactStats.put("total", count(db, "SELECT COUNT(*) FROM contact WHERE deletedAt IS NULL"));
        contactStats.put("favorites", count(db, "SELECT COUNT(*) FROM contact WHERE favorite=1 AND deletedAt IS NULL"));
        data.put("contactStats", contactStats);
        // الأصول
        data.put("assets", getRows(db, "asset", null, null, "createdAt DESC"));
        // آخر المكالمات
        data.put("recentCalls", getRows(db, "call_log", null, null, "createdAt DESC"));
        // المناسبات
        data.put("occasions", getRows(db, "occasion", null, null, "date ASC"));
        data.put("todayHoliday", new JSONObject().put("isHoliday", false));
        data.put("upcomingHolidays", new JSONArray());
        return data;
    }

    private int count(SQLiteDatabase db, String sql) {
        Cursor c = db.rawQuery(sql, null);
        try { c.moveToFirst(); return c.getInt(0); } finally { c.close(); }
    }

    // ====== بيانات ثابتة تقريبية ======
    // ====== إحداثيات حلب ======
    private static final double ALEPPO_LAT = 36.2021;
    private static final double ALEPPO_LNG = 37.1343;

    /** جلب HTTP من الإنترنت (متزامن — يُستدعى من thread خادم NanoHTTPD) */
    private String httpGet(String urlStr) {
        HttpURLConnection conn = null;
        try {
            URL url = new URL(urlStr);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setConnectTimeout(8000);
            conn.setReadTimeout(8000);
            conn.setRequestProperty("User-Agent", "DashboardApp/2.1");
            int code = conn.getResponseCode();
            InputStream is = (code >= 200 && code < 300) ? conn.getInputStream() : conn.getErrorStream();
            if (is == null) return "";
            BufferedReader reader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) sb.append(line);
            reader.close();
            return sb.toString();
        } catch (Exception e) {
            return "";
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    /** مواقيت الصلاة — يجلب من Aladhan API لحلب */
    private JSONObject prayerTimesData() throws Exception {
        try {
            String date = new java.text.SimpleDateFormat("dd-MM-yyyy").format(new java.util.Date());
            String url = "https://api.aladhan.com/v1/timings/" + date + "?latitude=" + ALEPPO_LAT + "&longitude=" + ALEPPO_LNG + "&method=3";
            String body = httpGet(url);
            if (!body.isEmpty()) {
                JSONObject resp = new JSONObject(body);
                if (resp.optInt("code", 0) == 200) {
                    JSONObject d = resp.getJSONObject("data");
                    JSONObject timings = d.getJSONObject("timings");
                    JSONObject dateInfo = d.getJSONObject("date");
                    JSONObject hijri = dateInfo.optJSONObject("hijri");

                    String[][] order = {
                        {"Imsak","Imsak","الإمساك","false"},
                        {"Fajr","Fajr","الفجر","true"},
                        {"Sunrise","Sunrise","الشروق","false"},
                        {"Dhuhr","Dhuhr","الظهر","true"},
                        {"Asr","Asr","العصر","true"},
                        {"Maghrib","Maghrib","المغرب","true"},
                        {"Isha","Isha","العشاء","true"},
                        {"Midnight","Midnight","منتصف الليل","false"}
                    };
                    JSONArray arr = new JSONArray();
                    for (String[] p : order) {
                        JSONObject o = new JSONObject();
                        o.put("key", p[1]);
                        String t = timings.optString(p[1], "");
                        // Aladhan يرجع "05:30 (EET)" — نأخذ الجزء قبل المسافة
                        if (t.contains(" ")) t = t.split(" ")[0];
                        o.put("time", t);
                        o.put("name", p[2]);
                        o.put("isPrayer", Boolean.parseBoolean(p[3]));
                        arr.put(o);
                    }
                    // حساب الصلاة القادمة
                    java.util.Calendar now = java.util.Calendar.getInstance();
                    JSONObject nextPrayer = null;
                    String timeUntil = "";
                    for (int i = 0; i < arr.length(); i++) {
                        JSONObject p = arr.getJSONObject(i);
                        String time = p.optString("time", "");
                        if (time.isEmpty() || time.equals("—")) continue;
                        String[] hm = time.split(":");
                        if (hm.length < 2) continue;
                        java.util.Calendar pt = (java.util.Calendar) now.clone();
                        pt.set(java.util.Calendar.HOUR_OF_DAY, Integer.parseInt(hm[0]));
                        pt.set(java.util.Calendar.MINUTE, Integer.parseInt(hm[1]));
                        pt.set(java.util.Calendar.SECOND, 0);
                        if (pt.after(now)) {
                            nextPrayer = p;
                            long diff = pt.getTimeInMillis() - now.getTimeInMillis();
                            int hours = (int) (diff / (1000 * 60 * 60));
                            int minutes = (int) ((diff % (1000 * 60 * 60)) / (1000 * 60));
                            timeUntil = hours + " س " + minutes + " د";
                            break;
                        }
                    }
                    JSONObject data = new JSONObject();
                    data.put("timings", arr);
                    data.put("nextPrayer", nextPrayer != null ? nextPrayer : JSONObject.NULL);
                    data.put("timeUntilNext", timeUntil);
                    if (hijri != null) {
                        JSONObject month = hijri.optJSONObject("month");
                        String hijriStr = hijri.optString("day", "") + " " + (month != null ? month.optString("ar", "") : "") + " " + hijri.optString("year", "") + " هـ";
                        data.put("hijriDate", hijriStr);
                    }
                    JSONObject greg = dateInfo.optJSONObject("gregorian");
                    data.put("gregorianDate", greg != null ? greg.optString("date", "") : "");
                    data.put("timezone", "Asia/Damascus");
                    data.put("city", "حلب");
                    return data;
                }
            }
        } catch (Exception e) {
            android.util.Log.w("LocalServer", "prayer fetch failed: " + e.getMessage());
        }
        // fallback ثابت
        return prayerFallback();
    }

    private JSONObject prayerFallback() throws Exception {
        JSONObject data = new JSONObject();
        JSONArray t = new JSONArray();
        String[][] p = {
            {"Fajr","05:30","الفجر","true"},
            {"Sunrise","06:50","الشروق","false"},
            {"Dhuhr","12:15","الظهر","true"},
            {"Asr","15:30","العصر","true"},
            {"Maghrib","17:45","المغرب","true"},
            {"Isha","19:15","العشاء","true"}
        };
        for (String[] x : p) {
            JSONObject o = new JSONObject();
            o.put("key", x[0]); o.put("time", x[1]); o.put("name", x[2]); o.put("isPrayer", Boolean.parseBoolean(x[3]));
            t.put(o);
        }
        data.put("timings", t);
        data.put("nextPrayer", JSONObject.NULL);
        data.put("timeUntilNext", "");
        data.put("hijriDate", "");
        data.put("gregorianDate", "");
        data.put("city", "حلب");
        return data;
    }

    /** الطقس — يجلب من Open-Meteo API لحلب */
    private JSONObject weatherData() throws Exception {
        try {
            String url = "https://api.open-meteo.com/v1/forecast?latitude=" + ALEPPO_LAT + "&longitude=" + ALEPPO_LNG
                + "&current=temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m,wind_direction_10m,pressure_msl"
                + "&daily=weather_code,temperature_2m_max,temperature_2m_min,sunrise,sunset"
                + "&timezone=Asia/Damascus&forecast_days=5";
            String body = httpGet(url);
            if (!body.isEmpty()) {
                JSONObject resp = new JSONObject(body);
                JSONObject cur = resp.optJSONObject("current");
                JSONObject daily = resp.optJSONObject("daily");
                if (cur != null) {
                    int code = cur.optInt("weather_code", 0);
                    String[][] desc = weatherDesc(code);
                    JSONObject current = new JSONObject();
                    current.put("temperature", Math.round(cur.optDouble("temperature_2m", 0)));
                    current.put("apparentTemperature", Math.round(cur.optDouble("apparent_temperature", 0)));
                    current.put("humidity", cur.optInt("relative_humidity_2m", 0));
                    current.put("windSpeed", Math.round(cur.optDouble("wind_speed_10m", 0)));
                    current.put("windDirection", cur.optInt("wind_direction_10m", 0));
                    current.put("pressure", Math.round(cur.optDouble("pressure_msl", 0)));
                    current.put("weatherCode", code);
                    current.put("weatherDescription", desc[0]);
                    current.put("weatherIcon", desc[1]);

                    JSONArray forecast = new JSONArray();
                    if (daily != null) {
                        JSONArray times = daily.optJSONArray("time");
                        JSONArray maxT = daily.optJSONArray("temperature_2m_max");
                        JSONArray minT = daily.optJSONArray("temperature_2m_min");
                        JSONArray wc = daily.optJSONArray("weather_code");
                        JSONArray sunrise = daily.optJSONArray("sunrise");
                        JSONArray sunset = daily.optJSONArray("sunset");
                        if (times != null) {
                            for (int i = 0; i < times.length() && i < 5; i++) {
                                JSONObject f = new JSONObject();
                                f.put("date", times.getString(i));
                                f.put("maxTemp", Math.round(maxT != null ? maxT.getDouble(i) : 0));
                                f.put("minTemp", Math.round(minT != null ? minT.getDouble(i) : 0));
                                int wc2 = wc != null ? wc.getInt(i) : 0;
                                String[][] d2 = weatherDesc(wc2);
                                JSONObject w = new JSONObject();
                                w.put("ar", d2[0]); w.put("icon", d2[1]);
                                f.put("weatherCode", wc2);
                                f.put("weather", w);
                                f.put("sunrise", sunrise != null ? sunrise.getString(i) : "");
                                f.put("sunset", sunset != null ? sunset.getString(i) : "");
                                forecast.put(f);
                            }
                        }
                    }
                    JSONObject data = new JSONObject();
                    data.put("current", current);
                    data.put("forecast", forecast);
                    data.put("city", "حلب");
                    data.put("timezone", "Asia/Damascus");
                    return data;
                }
            }
        } catch (Exception e) {
            android.util.Log.w("LocalServer", "weather fetch failed: " + e.getMessage());
        }
        // fallback
        JSONObject data = new JSONObject();
        JSONObject cur = new JSONObject();
        cur.put("temperature", 22); cur.put("apparentTemperature", 22);
        cur.put("humidity", 50); cur.put("windSpeed", 10);
        cur.put("weatherCode", 0);
        cur.put("weatherDescription", "غير متاح"); cur.put("weatherIcon", "Cloud");
        data.put("current", cur);
        data.put("forecast", new JSONArray());
        data.put("city", "حلب");
        return data;
    }

    /** وصف طقس عربي + أيقونة حسب كود Open-Meteo */
    private String[][] weatherDesc(int code) {
        if (code == 0) return new String[][]{{"سماء صافية","Sun"}};
        if (code == 1) return new String[][]{{"صافي غالباً","Sun"}};
        if (code == 2) return new String[][]{{"غائم جزئياً","CloudSun"}};
        if (code == 3) return new String[][]{{"غائم","Cloud"}};
        if (code == 45 || code == 48) return new String[][]{{"ضباب","CloudFog"}};
        if (code >= 51 && code <= 55) return new String[][]{{"رذاذ","CloudDrizzle"}};
        if (code >= 61 && code <= 65) return new String[][]{{"أمطار","CloudRain"}};
        if (code >= 71 && code <= 75) return new String[][]{{"ثلوج","CloudSnow"}};
        if (code >= 80 && code <= 82) return new String[][]{{"زخات مطر","CloudRainWind"}};
        if (code >= 95) return new String[][]{{"عاصفة رعدية","CloudLightning"}};
        return new String[][]{{"غير معروف","Cloud"}};
    }

    private JSONObject notificationsData(SQLiteDatabase db) throws Exception {
        // إشعارات مبنيّة على المهام عالية الأولوية والديون المستحقة
        JSONArray notifs = new JSONArray();
        Cursor tc = db.rawQuery("SELECT title FROM task WHERE priority='high' AND status!='done' AND deletedAt IS NULL LIMIT 5", null);
        while (tc.moveToNext()) {
            JSONObject n = new JSONObject();
            n.put("id", "task_"+tc.getPosition());
            n.put("type", "task");
            n.put("title", "مهمة عالية الأولوية");
            n.put("message", tc.getString(0));
            n.put("priority", "high");
            notifs.put(n);
        }
        tc.close();
        JSONObject r = new JSONObject();
        r.put("notifications", notifs);
        r.put("count", notifs.length());
        return r;
    }

    private JSONObject statsData(SQLiteDatabase db, String period) throws Exception {
        JSONObject d = new JSONObject();
        d.put("tasksDoneThisWeek", count(db, "SELECT COUNT(*) FROM task WHERE status='done' AND updatedAt >= datetime('now','-7 days')"));
        d.put("tasksCreatedThisWeek", count(db, "SELECT COUNT(*) FROM task WHERE createdAt >= datetime('now','-7 days')"));
        d.put("habitsCompletedThisWeek", count(db, "SELECT COUNT(*) FROM habit_log WHERE date >= datetime('now','-7 days')"));
        d.put("eventsThisWeek", count(db, "SELECT COUNT(*) FROM event WHERE startDate >= datetime('now','-7 days')"));
        d.put("callsThisWeek", count(db, "SELECT COUNT(*) FROM call_log WHERE createdAt >= datetime('now','-7 days')"));
        d.put("dailyStats", new JSONArray());
        return d;
    }

    private JSONObject currencyData() throws Exception {
        JSONObject d = new JSONObject();
        d.put("usdToSYP", 12500);
        d.put("goldPerGramUSD", 78);
        d.put("goldPerGramSYP", 975000);
        d.put("goldPerGram21USD", 68.25);
        d.put("goldPerGram21SYP", 853125);
        d.put("updatedAt", "");
        d.put("note", "تقريبي");
        return d;
    }

    private JSONObject recycleBinData(SQLiteDatabase db) throws Exception {
        JSONObject d = new JSONObject();
        d.put("tasks", getRows(db, "task", "deletedAt IS NOT NULL", null, "deletedAt DESC"));
        d.put("notes", getRows(db, "note", "deletedAt IS NOT NULL", null, "deletedAt DESC"));
        d.put("events", getRows(db, "event", "deletedAt IS NOT NULL", null, "deletedAt DESC"));
        d.put("contacts", getRows(db, "contact", "deletedAt IS NOT NULL", null, "deletedAt DESC"));
        d.put("expenses", getRows(db, "expense", "deletedAt IS NOT NULL", null, "deletedAt DESC"));
        int total = count(db, "SELECT COUNT(*) FROM task WHERE deletedAt IS NOT NULL")
                  + count(db, "SELECT COUNT(*) FROM note WHERE deletedAt IS NOT NULL")
                  + count(db, "SELECT COUNT(*) FROM event WHERE deletedAt IS NOT NULL")
                  + count(db, "SELECT COUNT(*) FROM contact WHERE deletedAt IS NOT NULL")
                  + count(db, "SELECT COUNT(*) FROM expense WHERE deletedAt IS NOT NULL");
        d.put("totalCount", total);
        return d;
    }

    // ====== تقديم الملفات الثابتة ======
    private Response serveStaticFile(String uri) {
        try {
            if (uri.equals("/")) uri = "/index.html";
            String path = "web" + uri;
            InputStream is = context.getAssets().open(path);
            String mime = getMimeType(uri);
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = is.read(buf)) != -1) baos.write(buf, 0, n);
            is.close();
            byte[] bytes = baos.toByteArray();
            Response r;
            // للملفات النصية: نعيد البايتات مباشرة بصيغة UTF-8 (لا تحويل لـ String)
            // هذا يمنع تشويه الأحرف العربية لأن NanoHTTPD يستخدم file.encoding الافتراضي
            if (mime.startsWith("text") || mime.contains("json") || mime.contains("javascript") || mime.contains("xml") || mime.contains("svg")) {
                java.io.ByteArrayInputStream bais = new java.io.ByteArrayInputStream(bytes);
                r = newFixedLengthResponse(Response.Status.OK, mime, bais, bytes.length);
            } else {
                r = newFixedLengthResponse(Response.Status.OK, mime, new java.io.ByteArrayInputStream(bytes), bytes.length);
            }
            r.addHeader("Content-Type", mime);
            r.addHeader("Cache-Control", "public, max-age=3600");
            return r;
        } catch (Exception e) {
            // Fallback إلى index.html (SPA)
            try {
                InputStream is = context.getAssets().open("web/index.html");
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                byte[] buf = new byte[8192];
                int n;
                while ((n = is.read(buf)) != -1) baos.write(buf, 0, n);
                is.close();
                byte[] bytes = baos.toByteArray();
                java.io.ByteArrayInputStream bais = new java.io.ByteArrayInputStream(bytes);
                Response r = newFixedLengthResponse(Response.Status.OK, "text/html; charset=utf-8", bais, bytes.length);
                r.addHeader("Content-Type", "text/html; charset=utf-8");
                return r;
            } catch (Exception e2) {
                return newUtf8Response(Response.Status.NOT_FOUND, "text/plain", "Not found: " + uri);
            }
        }
    }

    private String getMimeType(String uri) {
        if (uri.endsWith(".html") || uri.endsWith(".htm")) return "text/html; charset=utf-8";
        if (uri.endsWith(".css")) return "text/css; charset=utf-8";
        if (uri.endsWith(".js") || uri.endsWith(".mjs")) return "application/javascript; charset=utf-8";
        if (uri.endsWith(".json")) return "application/json; charset=utf-8";
        if (uri.endsWith(".svg")) return "image/svg+xml";
        if (uri.endsWith(".png")) return "image/png";
        if (uri.endsWith(".jpg") || uri.endsWith(".jpeg")) return "image/jpeg";
        if (uri.endsWith(".gif")) return "image/gif";
        if (uri.endsWith(".webp")) return "image/webp";
        if (uri.endsWith(".ico")) return "image/x-icon";
        if (uri.endsWith(".woff2")) return "font/woff2";
        if (uri.endsWith(".woff")) return "font/woff";
        if (uri.endsWith(".ttf")) return "font/ttf";
        if (uri.endsWith(".xml")) return "application/xml; charset=utf-8";
        if (uri.endsWith(".txt")) return "text/plain; charset=utf-8";
        if (uri.endsWith(".wasm")) return "application/wasm";
        return "application/octet-stream";
    }
}

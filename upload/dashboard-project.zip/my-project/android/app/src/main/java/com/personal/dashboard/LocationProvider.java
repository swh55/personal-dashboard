package com.personal.dashboard;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Looper;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.tasks.OnSuccessListener;

import org.json.JSONObject;

/**
 * مزوّد موقع يستخدم FusedLocationProvider للحصول على موقع دقيق سريع.
 * يوفّر getLocationOnce(callback) لطلب لمرة واحدة.
 */
public class LocationProvider {

    public interface Callback {
        void onResult(String json);
    }

    private final Context context;
    private final FusedLocationProviderClient fusedClient;

    public LocationProvider(Context context) {
        this.context = context;
        this.fusedClient = LocationServices.getFusedLocationProviderClient(context);
    }

    @SuppressLint("MissingPermission")
    public void getLocationOnce(Callback cb) {
        if (!hasLocationPermission()) {
            cb.onResult("{\"success\":false,\"error\":\"no_permission\"}");
            return;
        }

        // جرّب آخر موقع معروف أولاً (سريع)
        fusedClient.getLastLocation()
            .addOnSuccessListener(location -> {
                if (location != null && isRecent(location)) {
                    cb.onResult(locationJson(location));
                } else {
                    requestFreshLocation(cb);
                }
            })
            .addOnFailureListener(e -> requestFreshLocation(cb));
    }

    @SuppressLint("MissingPermission")
    private void requestFreshLocation(Callback cb) {
        LocationRequest req = new LocationRequest.Builder(LocationRequest.PRIORITY_HIGH_ACCURACY, 5000L)
            .setMinUpdateIntervalMillis(2000L)
            .setMaxUpdates(1)
            .build();

        LocationCallback callback = new LocationCallback() {
            @Override
            public void onLocationResult(@NonNull LocationResult result) {
                Location loc = result.getLastLocation();
                if (loc != null) {
                    cb.onResult(locationJson(loc));
                } else {
                    cb.onResult("{\"success\":false,\"error\":\"no_location\"}");
                }
                fusedClient.removeLocationUpdates(this);
            }
        };

        try {
            fusedClient.requestLocationUpdates(req, callback, Looper.getMainLooper());

            // مهلة احتياطية: إن لم يصل موقع خلال 15 ثانية، أرجع fallback
            new android.os.Handler(Looper.getMainLooper()).postDelayed(() -> {
                try { fusedClient.removeLocationUpdates(callback); } catch (Exception ignored) {}
                // جرّب آخر موقع معروف مرة أخيرة
                fusedClient.getLastLocation().addOnSuccessListener(loc -> {
                    if (loc != null) cb.onResult(locationJson(loc));
                    else cb.onResult("{\"success\":false,\"error\":\"timeout\"}");
                }).addOnFailureListener(e ->
                    cb.onResult("{\"success\":false,\"error\":\"timeout\"}"));
            }, 15000);
        } catch (Exception e) {
            cb.onResult("{\"success\":false,\"error\":\"" + e.getMessage() + "\"}");
        }
    }

    private boolean isRecent(Location loc) {
        long age = System.currentTimeMillis() - loc.getTime();
        return age < 5 * 60 * 1000; // أحدث من 5 دقائق
    }

    private String locationJson(Location loc) {
        try {
            JSONObject o = new JSONObject();
            o.put("success", true);
            o.put("latitude", loc.getLatitude());
            o.put("longitude", loc.getLongitude());
            o.put("accuracy", loc.getAccuracy());
            o.put("altitude", loc.hasAltitude() ? loc.getAltitude() : 0);
            o.put("speed", loc.hasSpeed() ? loc.getSpeed() : 0);
            o.put("bearing", loc.hasBearing() ? loc.getBearing() : 0);
            o.put("provider", loc.getProvider());
            o.put("timestamp", loc.getTime());
            return o.toString();
        } catch (Exception e) {
            return "{\"success\":false,\"error\":\"json_error\"}";
        }
    }

    public boolean hasLocationPermission() {
        return ContextCompat.checkSelfPermission(context, "android.permission.ACCESS_FINE_LOCATION")
            == PackageManager.PERMISSION_GRANTED
            || ContextCompat.checkSelfPermission(context, "android.permission.ACCESS_COARSE_LOCATION")
            == PackageManager.PERMISSION_GRANTED;
    }
}

package com.personal.dashboard;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.webkit.GeolocationPermissions;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;

import androidx.activity.OnBackPressedCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;
import java.util.List;

/**
 * MainActivity — Home Launcher (Android 15 / API 35).
 *
 * - تحميل الواجهة من file:///android_asset/web/index.html (لا خادم محلي)
 * - كل البيانات في localStorage (offline-first)
 * - WebView مُعدّ بالكامل: JS, DOM storage, UTF-8, file access, mixed content
 * - طلب الأذونات في onResume (بعد اكتمال دورة الحياة)
 * - معالج أخطاء شامل + زر رجوع
 * - لا نصوص تقنية ظاهرة في الواجهة
 */
public class MainActivity extends AppCompatActivity {

    private static final String TAG = "Dashboard";
    private static final String ASSET_INDEX = "file:///android_asset/web/index.html";

    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private PermissionManager permissionManager;
    private ProgressBar loadingBar;
    private Handler mainHandler;
    private boolean permissionsRequested = false;
    private boolean foregroundServiceStarted = false;

    private final String[] REQUIRED_PERMISSIONS = buildPermissionList();

    private final ActivityResultLauncher<String[]> permissionLauncher =
        registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), result -> {
            try { requestIgnoreBatteryOptimizations(); } catch (Exception ignored) {}
        });

    private final ActivityResultLauncher<String> singlePermissionLauncher =
        registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {});

    private static String[] buildPermissionList() {
        List<String> list = new ArrayList<>();
        list.add(android.Manifest.permission.CALL_PHONE);
        list.add(android.Manifest.permission.READ_PHONE_STATE);
        list.add(android.Manifest.permission.READ_CALL_LOG);
        list.add(android.Manifest.permission.SEND_SMS);
        list.add(android.Manifest.permission.READ_SMS);
        list.add(android.Manifest.permission.READ_CONTACTS);
        list.add(android.Manifest.permission.WRITE_CONTACTS);
        list.add(android.Manifest.permission.ACCESS_FINE_LOCATION);
        list.add(android.Manifest.permission.ACCESS_COARSE_LOCATION);
        list.add(android.Manifest.permission.CAMERA);
        list.add(android.Manifest.permission.RECORD_AUDIO);
        list.add(android.Manifest.permission.POST_NOTIFICATIONS);
        if (Build.VERSION.SDK_INT < 33) {
            list.add(android.Manifest.permission.READ_EXTERNAL_STORAGE);
        } else {
            list.add(android.Manifest.permission.READ_MEDIA_IMAGES);
            list.add(android.Manifest.permission.READ_MEDIA_VIDEO);
            list.add(android.Manifest.permission.READ_MEDIA_AUDIO);
        }
        return list.toArray(new String[0]);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mainHandler = new Handler(Looper.getMainLooper());

        // ====== Global crash handler — يسجّل الخطأ ويحاول إعادة التحميل ======
        final Thread.UncaughtExceptionHandler previous = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((thread, throwable) -> {
            Log.e(TAG, "UNCAUGHT on " + thread.getName(), throwable);
            try {
                runOnUiThread(() -> {
                    try {
                        if (webView != null) {
                            webView.loadUrl(ASSET_INDEX);
                        }
                    } catch (Exception ignored) {}
                });
            } catch (Exception ignored) {}
            // لا نستدعي previous حتى لا يُغلق التطبيق نهائياً
        });

        try {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        } catch (Exception ignored) {}

        try {
            permissionManager = new PermissionManager(this, singlePermissionLauncher, permissionLauncher);
        } catch (Exception e) {
            Log.w(TAG, "PermissionManager init: " + e.getMessage());
        }

        setupLayout();

        try {
            setupWebView();
        } catch (Exception e) {
            Log.e(TAG, "setupWebView failed", e);
            return;
        }

        try {
            webView.loadUrl(ASSET_INDEX);
        } catch (Exception e) {
            Log.e(TAG, "loadUrl failed", e);
        }

        try { handleShortcutIntent(getIntent()); } catch (Exception ignored) {}
        setupBackHandling();
    }

    @Override
    protected void onResume() {
        super.onResume();
        try {
            if (webView != null) webView.onResume();
            // تأجيل كل المنطق الثقيل إلى ما بعد اكتمال دورة الحياة
            mainHandler.post(() -> {
                if (!permissionsRequested) {
                    permissionsRequested = true;
                    try { requestAllPermissions(); } catch (Exception ignored) {}
                }
                if (!foregroundServiceStarted) {
                    foregroundServiceStarted = true;
                    try { startForegroundServiceSafe(); } catch (Exception ignored) {}
                }
            });
        } catch (Exception ignored) {}
    }

    @Override
    protected void onPause() {
        super.onPause();
        try { if (webView != null) webView.onPause(); } catch (Exception ignored) {}
    }

    @Override
    protected void onDestroy() {
        try { if (webView != null) { webView.destroy(); webView = null; } } catch (Exception ignored) {}
        super.onDestroy();
    }

    /** بناء التخطيط: شريط تحميل + WebView فقط (لا نصوص تقنية) */
    private void setupLayout() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutParams(new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT));
        root.setBackgroundColor(0xFF0E0E10);

        loadingBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        loadingBar.setMax(100);
        loadingBar.setProgress(0);
        loadingBar.setVisibility(View.GONE);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 6);
        loadingBar.setLayoutParams(lp);
        root.addView(loadingBar);

        webView = new WebView(this);
        webView.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        root.addView(webView);

        setContentView(root);
    }

    @SuppressLint("SetJavaScriptEnabled")
    @SuppressWarnings("deprecation")
    private void setupWebView() {
        if (webView == null) return;
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDefaultTextEncodingName("UTF-8");
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setGeolocationEnabled(true);
        s.setCacheMode(WebSettings.LOAD_NO_CACHE);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setAllowFileAccessFromFileURLs(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        s.setUserAgentString(s.getUserAgentString() + " DashboardLauncher/2.2 (Android)");
        try { s.setRenderPriority(WebSettings.RenderPriority.HIGH); } catch (Exception ignored) {}

        try { webView.setLayerType(View.LAYER_TYPE_HARDWARE, null); } catch (Exception ignored) {}
        try { WebView.setWebContentsDebuggingEnabled(true); } catch (Exception ignored) {}

        webView.setWebViewClient(new DashboardWebViewClient());
        webView.setWebChromeClient(new DashboardWebChromeClient());

        try {
            webView.addJavascriptInterface(
                new AndroidInterface(this, permissionManager, webView), "Android");
        } catch (Exception e) {
            Log.w(TAG, "JS interface: " + e.getMessage());
        }
    }

    private void requestAllPermissions() {
        try {
            List<String> toRequest = new ArrayList<>();
            for (String p : REQUIRED_PERMISSIONS) {
                if (ContextCompat.checkSelfPermission(this, p) != PackageManager.PERMISSION_GRANTED) {
                    toRequest.add(p);
                }
            }
            if (!toRequest.isEmpty()) {
                permissionLauncher.launch(toRequest.toArray(new String[0]));
            }
        } catch (Exception e) {
            Log.w(TAG, "requestAllPermissions: " + e.getMessage());
        }
    }

    @SuppressLint("BatteryLife")
    private void requestIgnoreBatteryOptimizations() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                android.os.PowerManager pm = (android.os.PowerManager) getSystemService(POWER_SERVICE);
                if (pm != null && !pm.isIgnoringBatteryOptimizations(getPackageName())) {
                    Intent intent = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                    intent.setData(Uri.parse("package:" + getPackageName()));
                    startActivity(intent);
                }
            }
        } catch (Exception ignored) {}
    }

    /** بدء خدمة المزامنة الأمامية — آمن */
    private void startForegroundServiceSafe() {
        try {
            Intent svc = new Intent(this, NotificationService.class);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(svc);
            } else {
                startService(svc);
            }
        } catch (SecurityException e) {
            Log.w(TAG, "FG service not allowed: " + e.getMessage());
        } catch (Exception e) {
            Log.w(TAG, "FG service: " + e.getMessage());
        }
    }

    private void setupBackHandling() {
        OnBackPressedCallback callback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                try {
                    if (webView != null) {
                        webView.evaluateJavascript(
                            "if(window.Dashboard&&window.Dashboard.onBack)window.Dashboard.onBack();",
                            null);
                    }
                } catch (Exception ignored) {}
            }
        };
        getOnBackPressedDispatcher().addCallback(this, callback);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleShortcutIntent(intent);
    }

    private void handleShortcutIntent(Intent intent) {
        if (intent == null) return;
        try {
            String data = intent.getDataString();
            if (data != null && webView != null) {
                final String d = data.replace("'", "\\'");
                webView.post(() -> {
                    try {
                        webView.evaluateJavascript(
                            "window.dispatchEvent(new CustomEvent('android-shortcut',{detail:'" + d + "'}));",
                            null);
                    } catch (Exception ignored) {}
                });
            }
        } catch (Exception ignored) {}
    }

    // ====== WebViewClient ======
    private class DashboardWebViewClient extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            try {
                String url = request.getUrl().toString();
                if (url.startsWith("tel:") || url.startsWith("sms:") || url.startsWith("smsto:")
                    || url.startsWith("mailto:") || url.startsWith("geo:")
                    || url.startsWith("https://wa.me") || url.startsWith("whatsapp:")
                    || url.startsWith("intent:")) {
                    try {
                        Intent intent = new Intent(Intent.ACTION_VIEW, request.getUrl());
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(intent);
                    } catch (Exception ignored) {}
                    return true;
                }
                if (url.contains("google.com/maps")) {
                    Intent intent = new Intent(Intent.ACTION_VIEW, request.getUrl());
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                    return true;
                }
            } catch (Exception ignored) {}
            return false;
        }

        @Override
        public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
            if (loadingBar != null) {
                loadingBar.setVisibility(View.VISIBLE);
                loadingBar.setProgress(0);
            }
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            if (loadingBar != null) {
                loadingBar.setProgress(100);
                loadingBar.setVisibility(View.GONE);
            }
        }

        @Override
        public void onReceivedError(WebView view, WebResourceRequest req, WebResourceError err) {
            if (loadingBar != null) loadingBar.setVisibility(View.GONE);
            if (req.isForMainFrame()) {
                mainHandler.postDelayed(() -> {
                    if (webView != null) {
                        webView.loadUrl(ASSET_INDEX);
                    }
                }, 1500);
            }
        }
    }

    // ====== WebChromeClient ======
    private class DashboardWebChromeClient extends WebChromeClient {
        @Override
        public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback cb) {
            try { cb.invoke(origin, true, false); } catch (Exception ignored) {}
        }

        @Override
        public void onPermissionRequest(final PermissionRequest request) {
            runOnUiThread(() -> {
                try { request.grant(request.getResources()); } catch (Exception ignored) {}
            });
        }

        @Override
        public void onProgressChanged(WebView view, int newProgress) {
            if (loadingBar != null && loadingBar.getVisibility() == View.VISIBLE) {
                loadingBar.setProgress(newProgress);
            }
        }

        @Override
        public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams params) {
            if (filePathCallback != null) filePathCallback.onReceiveValue(null);
            filePathCallback = cb;
            try {
                Intent intent = params.createIntent();
                startActivityForResult(intent, 1001);
            } catch (Exception e) {
                filePathCallback = null;
                return false;
            }
            return true;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1001 && filePathCallback != null) {
            Uri[] results = null;
            if (resultCode == Activity.RESULT_OK && data != null) {
                String ds = data.getDataString();
                if (ds != null) results = new Uri[]{Uri.parse(ds)};
            }
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        }
        // ===== Widget picker result =====
        if (requestCode == 2001 && resultCode == Activity.RESULT_OK && data != null) {
            try {
                int widgetId = data.getIntExtra(android.appwidget.AppWidgetManager.EXTRA_APPWIDGET_ID, android.appwidget.AppWidgetManager.INVALID_APPWIDGET_ID);
                if (widgetId != android.appwidget.AppWidgetManager.INVALID_APPWIDGET_ID) {
                    // احفظ الـ widget ID للوصول إليه لاحقاً
                    getSharedPreferences("widgets", MODE_PRIVATE).edit().putInt("widget_" + widgetId, widgetId).apply();
                    // أضف الـ widget فعلياً كـ host view على الشاشة
                    addWidgetToScreen(widgetId);
                    // أبلغ الواجهة
                    if (webView != null) {
                        webView.evaluateJavascript("try{window.dispatchEvent(new CustomEvent('widget-added',{detail:{id:" + widgetId + "}}));}catch(e){}", null);
                    }
                    android.widget.Toast.makeText(this, "تمت إضافة الـ Widget", android.widget.Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                Log.w(TAG, "widget result: " + e.getMessage());
            }
        }
    }

    /** إضافة widget host view للشاشة */
    private void addWidgetToScreen(int widgetId) {
        try {
            android.appwidget.AppWidgetHost host = new android.appwidget.AppWidgetHost(this, 0x12345);
            android.appwidget.AppWidgetManager mgr = android.appwidget.AppWidgetManager.getInstance(this);
            android.appwidget.AppWidgetProviderInfo info = mgr.getAppWidgetInfo(widgetId);
            if (info != null) {
                android.appwidget.AppWidgetHostView hostView = host.createView(this, widgetId, info);
                hostView.setAppWidget(widgetId, info);
                // ابدأ الاستماع للتحديثات
                host.startListening();
                // احفظ الـ host view في cache (سيُضاف للواجهة عبر JS event)
                Log.i(TAG, "Widget " + widgetId + " added: " + info.provider.flattenToString());
            }
        } catch (Exception e) {
            Log.w(TAG, "addWidgetToScreen: " + e.getMessage());
        }
    }

    /** استدعاء من AndroidInterface لفتح منتقي widgets */
    public void pickAppWidget() {
        try {
            android.appwidget.AppWidgetHost host = new android.appwidget.AppWidgetHost(this, 0x12345);
            int widgetId = host.allocateAppWidgetId();
            Intent pickIntent = new Intent(android.appwidget.AppWidgetManager.ACTION_APPWIDGET_PICK);
            pickIntent.putExtra(android.appwidget.AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId);
            startActivityForResult(pickIntent, 2001);
        } catch (Exception e) {
            Log.w(TAG, "pickAppWidget: " + e.getMessage());
            android.widget.Toast.makeText(this, "تعذّر فتح منتقي Widgets: " + e.getMessage(), android.widget.Toast.LENGTH_SHORT).show();
        }
    }

    public void requestSinglePermission(String permission) {
        runOnUiThread(() -> {
            try {
                if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
                    singlePermissionLauncher.launch(permission);
                }
            } catch (Exception ignored) {}
        });
    }

    public PermissionManager getPermissionManager() { return permissionManager; }
}

import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// 8. الشارات
// GET: سرد جميع الشارات الممكنة + أيها المفتوح

// كتالوج جميع الشارات الممكنة في النظام
const ACHIEVEMENT_CATALOG: {
  type: string;
  title: string;
  description: string;
  icon: string;
}[] = [
  { type: "first_task", title: "أول إنجاز", description: "أكملت أول مهمة لك", icon: "Sparkles" },
  { type: "streak_7", title: "أسبوع متواصل", description: "7 أيام متتالية من النشاط", icon: "Flame" },
  { type: "streak_30", title: "شهر متواصل", description: "30 يوماً متتالياً من النشاط", icon: "Trophy" },
  { type: "streak_100", title: "مئة يوم", description: "100 يوم متتالي من النشاط", icon: "Crown" },
  { type: "early_bird", title: "الطائر المبكر", description: "أنجزت مهمة قبل الساعة 7 صباحاً", icon: "Sunrise" },
  { type: "night_owl", title: "بومة الليل", description: "أنجزت مهمة بعد منتصف الليل", icon: "Moon" },
  { type: "hydrated", title: "مُرتوٍ", description: "شربت 8 أكواب ماء في يوم", icon: "Droplets" },
  { type: "active_posture", title: "متحرك", description: "وقفت 8 مرات في يوم", icon: "PersonStanding" },
  { type: "habit_master", title: "سيّد العادات", description: "أكملت جميع عادات اليوم", icon: "CheckCircle" },
  { type: "budget_keeper", title: "حارس الميزانية", description: "بقيت ضمن الميزانية لشهر كامل", icon: "PiggyBank" },
  { type: "quran_reader", title: "قارئ القرآن", description: "أكملت ختمة قرآنية", icon: "BookOpen" },
  { type: "perfect_day", title: "يوم مثالي", description: "أنجزت كل مهام وعادات اليوم", icon: "Star" },
  { type: "level_5", title: "مستوى 5", description: "وصلت للمستوى الخامس", icon: "Award" },
  { type: "level_10", title: "مستوى 10", description: "وصلت للمستوى العاشر", icon: "Medal" },
  { type: "points_1000", title: "ألف نقطة", description: "جمعت 1000 نقطة", icon: "Gem" },
  { type: "points_5000", title: "خمس آلاف نقطة", description: "جمعت 5000 نقطة", icon: "Diamond" },
  { type: "happy_week", title: "أسبوع سعيد", description: "معدل سعادة 8+ لمدة أسبوع", icon: "Smile" },
  { type: "water_week", title: "أسبوع مائي", description: "حققت هدف الماء 7 أيام متتالية", icon: "Waves" },
  { type: "first_habit", title: "العادة الأولى", description: "أنشأت عادتك الأولى", icon: "Leaf" },
  { type: "first_project", title: "المشروع الأول", description: "أنشأت مشروعك الأول", icon: "Rocket" },
];

export async function GET() {
  try {
    const unlocked = await db.achievement.findMany({
      orderBy: { unlockedAt: "desc" },
    });

    const unlockedMap = new Map(unlocked.map((a) => [a.type, a]));

    // دمج الكتالوج مع السجلات المفتوحة فعلياً
    const fromCatalog = ACHIEVEMENT_CATALOG.map((c) => {
      const rec = unlockedMap.get(c.type);
      return {
        type: c.type,
        title: c.title,
        description: c.description,
        icon: c.icon,
        unlocked: !!rec,
        unlockedAt: rec?.unlockedAt ?? null,
      };
    });

    // شارات في قاعدة البيانات ليست ضمن الكتالوج
    const extra = unlocked
      .filter((u) => !ACHIEVEMENT_CATALOG.some((c) => c.type === u.type))
      .map((u) => ({
        type: u.type,
        title: u.title,
        description: u.description,
        icon: u.icon,
        unlocked: true,
        unlockedAt: u.unlockedAt,
      }));

    const result = [...fromCatalog, ...extra];

    return NextResponse.json({
      success: true,
      data: result,
      stats: {
        total: result.length,
        unlockedCount: result.filter((r) => r.unlocked).length,
        lockedCount: result.filter((r) => !r.unlocked).length,
      },
    });
  } catch (error) {
    console.error("GET achievements error:", error);
    return NextResponse.json(
      { success: false, error: "فشل جلب الشارات" },
      { status: 500 }
    );
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { type, title, description, icon } = body;

    if (!type) {
      return NextResponse.json(
        { success: false, error: "نوع الشارة مطلوب" },
        { status: 400 }
      );
    }

    const existing = await db.achievement.findUnique({ where: { type } });
    if (existing) {
      return NextResponse.json({
        success: true,
        data: existing,
        alreadyUnlocked: true,
      });
    }

    const catalogEntry = ACHIEVEMENT_CATALOG.find((c) => c.type === type);

    const achievement = await db.achievement.create({
      data: {
        type,
        title: title || catalogEntry?.title || type,
        description: description || catalogEntry?.description || "",
        icon: icon || catalogEntry?.icon || "Trophy",
      },
    });

    return NextResponse.json(
      { success: true, data: achievement, alreadyUnlocked: false },
      { status: 201 }
    );
  } catch (error) {
    console.error("POST achievement error:", error);
    return NextResponse.json(
      { success: false, error: "فشل فتح الشارة" },
      { status: 500 }
    );
  }
}

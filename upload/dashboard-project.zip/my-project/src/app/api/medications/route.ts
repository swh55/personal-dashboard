import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET() {
  try {
    const meds = await db.medication.findMany({
      where: { deletedAt: null, active: true },
      include: { logs: { orderBy: { takenAt: "desc" }, take: 10 } },
      orderBy: { createdAt: "desc" },
    });
    return NextResponse.json({ success: true, data: meds });
  } catch (error) {
    console.error("GET medications error:", error);
    return NextResponse.json({ success: false, error: "فشل جلب الأدوية" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const { name, dosage, frequency, times, note, endDate } = await req.json();
    if (!name) return NextResponse.json({ success: false, error: "اسم الدواء مطلوب" }, { status: 400 });
    const med = await db.medication.create({
      data: { name, dosage: dosage || "", frequency: frequency || "daily", times: JSON.stringify(times || ["08:00"]), note, endDate: endDate ? new Date(endDate) : null },
    });
    return NextResponse.json({ success: true, data: med }, { status: 201 });
  } catch (error) {
    console.error("POST medication error:", error);
    return NextResponse.json({ success: false, error: "فشل إضافة الدواء" }, { status: 500 });
  }
}

export async function PUT(req: NextRequest) {
  try {
    const { id, action, ...data } = await req.json();
    if (!id) return NextResponse.json({ success: false, error: "المعرف مطلوب" }, { status: 400 });
    if (action === "log") {
      const log = await db.medicationLog.create({ data: { medicationId: id } });
      return NextResponse.json({ success: true, data: log });
    }
    if (data.times) data.times = JSON.stringify(data.times);
    const med = await db.medication.update({ where: { id }, data });
    return NextResponse.json({ success: true, data: med });
  } catch (error) {
    console.error("PUT medication error:", error);
    return NextResponse.json({ success: false, error: "فشل التحديث" }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    if (!id) return NextResponse.json({ success: false, error: "المعرف مطلوب" }, { status: 400 });
    await db.medication.update({ where: { id }, data: { deletedAt: new Date() } });
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("DELETE medication error:", error);
    return NextResponse.json({ success: false, error: "فشل الحذف" }, { status: 500 });
  }
}

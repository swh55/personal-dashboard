import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// 2. صيانة المنزل
// GET: جلب كل عناصر الصيانة
// POST: إنشاء عنصر صيانة جديد
// PUT: تعليم عنصر كمُنجز (يضبط lastDone ويحسب nextDue = lastDone + intervalDays)
// DELETE: حذف عنصر حسب المعرف

export async function GET() {
  try {
    const items = await db.homeMaintenance.findMany({
      orderBy: [{ nextDue: "asc" }],
    });

    const now = new Date();
    const overdue = items.filter((i) => i.nextDue && new Date(i.nextDue) < now);

    return NextResponse.json({
      success: true,
      data: items,
      stats: {
        count: items.length,
        overdueCount: overdue.length,
      },
    });
  } catch (error) {
    console.error("GET home-maintenance error:", error);
    return NextResponse.json(
      { success: false, error: "فشل جلب سجل صيانة المنزل" },
      { status: 500 }
    );
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { item, task, lastDone, nextDue, intervalDays, note } = body;

    if (!item || !task) {
      return NextResponse.json(
        { success: false, error: "البند والمهمة مطلوبان" },
        { status: 400 }
      );
    }

    const interval = Number(intervalDays) || 90;

    // احسب تاريخ الاستحقاق التالي تلقائياً
    let computedNextDue: Date | null = null;
    if (lastDone) {
      const d = new Date(lastDone);
      d.setDate(d.getDate() + interval);
      computedNextDue = d;
    } else if (nextDue) {
      computedNextDue = new Date(nextDue);
    }

    const record = await db.homeMaintenance.create({
      data: {
        item,
        task,
        lastDone: lastDone ? new Date(lastDone) : null,
        nextDue: computedNextDue,
        intervalDays: interval,
        note: note || null,
      },
    });

    return NextResponse.json({ success: true, data: record }, { status: 201 });
  } catch (error) {
    console.error("POST home-maintenance error:", error);
    return NextResponse.json(
      { success: false, error: "فشل إضافة عنصر الصيانة" },
      { status: 500 }
    );
  }
}

export async function PUT(req: NextRequest) {
  try {
    const body = await req.json();
    const { id, done, lastDone, intervalDays, ...rest } = body;

    if (!id) {
      return NextResponse.json(
        { success: false, error: "المعرف مطلوب" },
        { status: 400 }
      );
    }

    const existing = await db.homeMaintenance.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json(
        { success: false, error: "عنصر الصيانة غير موجود" },
        { status: 404 }
      );
    }

    const data: Record<string, unknown> = { ...rest };

    const interval =
      intervalDays !== undefined ? Number(intervalDays) : existing.intervalDays;
    // تحديد آخر تنفيذ: عند تعليمه كمُنجز نستخدم الآن ما لم يُمرّر تاريخ
    const finalLastDone =
      done === true
        ? lastDone
          ? new Date(lastDone)
          : new Date()
        : lastDone
          ? new Date(lastDone)
          : existing.lastDone;

    if (done === true || lastDone || intervalDays !== undefined) {
      data.lastDone = finalLastDone;
      data.intervalDays = interval;
      // احسب الاستحقاق التالي = آخر تنفيذ + الفترة
      if (finalLastDone) {
        const d = new Date(finalLastDone);
        d.setDate(d.getDate() + interval);
        data.nextDue = d;
      }
    }

    if (rest.nextDue) data.nextDue = new Date(rest.nextDue);

    const record = await db.homeMaintenance.update({
      where: { id },
      data,
    });

    return NextResponse.json({ success: true, data: record });
  } catch (error) {
    console.error("PUT home-maintenance error:", error);
    return NextResponse.json(
      { success: false, error: "فشل تحديث عنصر الصيانة" },
      { status: 500 }
    );
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");

    if (!id) {
      return NextResponse.json(
        { success: false, error: "المعرف مطلوب" },
        { status: 400 }
      );
    }

    await db.homeMaintenance.delete({ where: { id } });
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("DELETE home-maintenance error:", error);
    return NextResponse.json(
      { success: false, error: "فشل حذف عنصر الصيانة" },
      { status: 500 }
    );
  }
}

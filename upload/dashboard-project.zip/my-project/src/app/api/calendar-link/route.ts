import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { logActivity } from "@/lib/activity";

// ربط سجل بتقويم — ينشئ حدث تقويم مرتبط بأي سجل
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { sourceType, sourceId, title, date, type, color, location, description } = body;

    if (!title || !date) {
      return NextResponse.json({ success: false, error: "العنوان والتاريخ مطلوبان" }, { status: 400 });
    }

    // التحقق من عدم وجود حدث مرتبط مسبقاً
    const existing = await db.event.findFirst({
      where: {
        title: title,
        startDate: new Date(date),
        type: type || sourceType,
      },
    });

    if (existing) {
      return NextResponse.json({ success: true, data: existing, message: "موجود مسبقاً" });
    }

    const event = await db.event.create({
      data: {
        title,
        description: description || `مرتبط بـ: ${sourceType}`,
        startDate: new Date(date),
        endDate: null,
        allDay: false,
        type: type || sourceType,
        color: color || "emerald",
        location: location || null,
      },
    });

    await logActivity("create", "event", `ربط ${sourceType} بالتقويم: ${title}`);

    return NextResponse.json({ success: true, data: event }, { status: 201 });
  } catch (error) {
    console.error("Calendar link error:", error);
    return NextResponse.json({ success: false, error: "فشل ربط التقويم" }, { status: 500 });
  }
}

// جلب كل السجلات الزمنية المربوطة
export async function GET() {
  try {
    const now = new Date();
    const next30Days = new Date();
    next30Days.setDate(now.getDate() + 30);

    const [tasks, debts, meetings, medications, occasions, events] = await Promise.all([
      db.task.findMany({ where: { dueDate: { gte: now, lte: next30Days }, status: { not: "done" } } }),
      db.debt.findMany({ where: { dueDate: { gte: now, lte: next30Days }, settled: false } }),
      db.meeting.findMany({ where: { startTime: { gte: now, lte: next30Days }, status: "upcoming" } }),
      db.medication.findMany({ where: { active: true } }),
      db.occasion.findMany(),
      db.event.findMany({ where: { startDate: { gte: now, lte: next30Days } } }),
    ]);

    // تجميع كل السجلات الزمنية في قائمة موحدة
    const timeline: Array<{
      id: string;
      title: string;
      date: string;
      type: string;
      source: string;
      color: string;
      icon: string;
    }> = [];

    tasks.forEach((t) => {
      if (t.dueDate) {
        timeline.push({
          id: `task-${t.id}`, title: `مهمة: ${t.title}`, date: t.dueDate.toISOString(),
          type: "task", source: "tasks", color: "#4285F4", icon: "CheckSquare",
        });
      }
    });

    debts.forEach((d) => {
      if (d.dueDate) {
        timeline.push({
          id: `debt-${d.id}`, title: `دين: ${d.personName}`, date: d.dueDate.toISOString(),
          type: "debt", source: "debts", color: "#FF6D00", icon: "HandCoins",
        });
      }
    });

    meetings.forEach((m) => {
      timeline.push({
        id: `meeting-${m.id}`, title: `اجتماع: ${m.title}`, date: m.startTime.toISOString(),
        type: "meeting", source: "meetings", color: "#00897B", icon: "Users",
      });
    });

    occasions.forEach((o) => {
      const nextDate = new Date(o.date);
      nextDate.setFullYear(now.getFullYear());
      if (nextDate < now) nextDate.setFullYear(now.getFullYear() + 1);
      if (nextDate <= next30Days) {
        timeline.push({
          id: `occasion-${o.id}`, title: o.title, date: nextDate.toISOString(),
          type: "birthday", source: "occasions", color: "#E91E63", icon: "Cake",
        });
      }
    });

    events.forEach((e) => {
      timeline.push({
        id: `event-${e.id}`, title: e.title, date: e.startDate.toISOString(),
        type: e.type, source: "calendar", color: "#4285F4", icon: "Calendar",
      });
    });

    // ترتيب حسب التاريخ
    timeline.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

    return NextResponse.json({ success: true, data: timeline });
  } catch (error) {
    console.error("GET timeline error:", error);
    return NextResponse.json({ success: false, error: "فشل جلب السجل الزمني" }, { status: 500 });
  }
}

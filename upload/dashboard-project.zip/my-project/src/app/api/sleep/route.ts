import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET() {
  try {
    const logs = await db.sleepLog.findMany({ orderBy: { bedtime: "desc" }, take: 30 });
    return NextResponse.json({ success: true, data: logs });
  } catch (error) {
    console.error("GET sleep error:", error);
    return NextResponse.json({ success: false, error: "فشل جلب سجل النوم" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const { bedtime, wakeTime, quality, note } = await req.json();
    if (!bedtime || !wakeTime) return NextResponse.json({ success: false, error: "وقت النوم والاستيقاظ مطلوبان" }, { status: 400 });
    const log = await db.sleepLog.create({ data: { bedtime: new Date(bedtime), wakeTime: new Date(wakeTime), quality: quality || 3, note } });
    return NextResponse.json({ success: true, data: log }, { status: 201 });
  } catch (error) {
    console.error("POST sleep error:", error);
    return NextResponse.json({ success: false, error: "فشل إضافة سجل النوم" }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    if (!id) return NextResponse.json({ success: false, error: "المعرف مطلوب" }, { status: 400 });
    await db.sleepLog.delete({ where: { id } });
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("DELETE sleep error:", error);
    return NextResponse.json({ success: false, error: "فشل حذف السجل" }, { status: 500 });
  }
}

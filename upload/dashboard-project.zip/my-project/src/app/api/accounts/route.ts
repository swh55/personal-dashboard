import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET() {
  try {
    const accounts = await db.account.findMany({
      orderBy: [{ category: "asc" }, { name: "asc" }],
    });
    return NextResponse.json({ success: true, data: accounts });
  } catch (error) {
    console.error("GET accounts error:", error);
    return NextResponse.json({ success: false, error: "فشل جلب الحسابات" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { name, platform, username, url, icon, category } = body;

    if (!name || !url) {
      return NextResponse.json({ success: false, error: "الاسم والرابط مطلوبان" }, { status: 400 });
    }

    const account = await db.account.create({
      data: {
        name,
        platform: platform || "other",
        username: username || "",
        url,
        icon: icon || null,
        category: category || "personal",
      },
    });

    return NextResponse.json({ success: true, data: account }, { status: 201 });
  } catch (error) {
    console.error("POST account error:", error);
    return NextResponse.json({ success: false, error: "فشل إضافة الحساب" }, { status: 500 });
  }
}

export async function PUT(req: NextRequest) {
  try {
    const body = await req.json();
    const { id, ...data } = body;

    if (!id) {
      return NextResponse.json({ success: false, error: "المعرف مطلوب" }, { status: 400 });
    }

    const account = await db.account.update({ where: { id }, data });
    return NextResponse.json({ success: true, data: account });
  } catch (error) {
    console.error("PUT account error:", error);
    return NextResponse.json({ success: false, error: "فشل تحديث الحساب" }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");

    if (!id) {
      return NextResponse.json({ success: false, error: "المعرف مطلوب" }, { status: 400 });
    }

    await db.account.delete({ where: { id } });
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("DELETE account error:", error);
    return NextResponse.json({ success: false, error: "فشل حذف الحساب" }, { status: 500 });
  }
}

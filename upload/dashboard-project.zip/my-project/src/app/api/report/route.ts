import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { logActivity } from "@/lib/activity";

export const runtime = "nodejs";
export const maxDuration = 30;

export async function GET() {
  try {
    const now = new Date();
    const weekStart = new Date(now);
    weekStart.setDate(now.getDate() - 7);

    // جمع كل البيانات
    const [tasks, contacts, events, notes, expenses, occasions, habits, assets, accounts, activityLogs] = await Promise.all([
      db.task.findMany(),
      db.contact.findMany(),
      db.event.findMany({ where: { startDate: { gte: weekStart } } }),
      db.note.findMany(),
      db.expense.findMany({ where: { date: { gte: weekStart } } }),
      db.occasion.findMany(),
      db.habit.findMany({ include: { logs: true } }),
      db.asset.findMany(),
      db.account.findMany(),
      db.activityLog.findMany({ take: 20, orderBy: { createdAt: "desc" } }),
    ]);

    // إحصائيات
    const pendingTasks = tasks.filter((t) => t.status !== "done").length;
    const doneTasks = tasks.filter((t) => t.status === "done").length;
    const totalExpenses = expenses.reduce((s, e) => s + (e.currency === "usd" ? e.amount * 12500 : e.amount), 0);
    const totalAssetsSYP = assets.reduce((s, a) => {
      if (a.type === "gold") return s + a.amount * 7800 * 0.875;
      if (a.type === "usd") return s + a.amount * 12500;
      return s + a.amount;
    }, 0);

    // إنشاء تقرير HTML
    const html = generateReportHTML({
      date: now.toLocaleDateString("ar-SY"),
      time: now.toLocaleTimeString("ar-SY"),
      tasks: { total: tasks.length, pending: pendingTasks, done: doneTasks },
      contacts: contacts.length,
      events: events.length,
      notes: notes.length,
      expenses: { count: expenses.length, total: totalExpenses },
      occasions: occasions.length,
      habits: habits.length,
      assets: { count: assets.length, totalSYP: totalAssetsSYP },
      accounts: accounts.length,
      recentActivity: activityLogs,
      taskList: tasks.slice(0, 10),
      expenseList: expenses.slice(0, 10),
      occasionList: occasions,
    });

    await logActivity("export", "data", "تم إنشاء تقرير PDF");

    return new NextResponse(html, {
      headers: {
        "Content-Type": "text/html; charset=utf-8",
        "Content-Disposition": `inline; filename="report-${now.toISOString().split("T")[0]}.html"`,
      },
    });
  } catch (error) {
    console.error("Report generation error:", error);
    return NextResponse.json({ success: false, error: "فشل إنشاء التقرير" }, { status: 500 });
  }
}

function generateReportHTML(data: {
  date: string; time: string;
  tasks: { total: number; pending: number; done: number };
  contacts: number; events: number; notes: number;
  expenses: { count: number; total: number };
  occasions: number; habits: number;
  assets: { count: number; totalSYP: number };
  accounts: number;
  recentActivity: Array<{ action: string; entity: string; title: string; createdAt: Date }>;
  taskList: Array<{ title: string; category: string; status: string; priority: string }>;
  expenseList: Array<{ amount: number; currency: string; description: string | null; category: string }>;
  occasionList: Array<{ title: string; date: Date }>;
}): string {
  const formatAmount = (n: number) => n.toLocaleString("en-US", { maximumFractionDigits: 0 });

  return `<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<title>تقرير لوحة التحكم - ${data.date}</title>
<style>
  @page { size: A4; margin: 20mm; }
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: 'Segoe UI', Tahoma, sans-serif; background: #fff; color: #1a1a1a; line-height: 1.6; }
  .header { text-align: center; padding: 30px 0; border-bottom: 3px solid #10b981; margin-bottom: 30px; }
  .header h1 { font-size: 28px; color: #10b981; margin-bottom: 8px; }
  .header p { color: #666; font-size: 14px; }
  .section { margin-bottom: 25px; }
  .section-title { font-size: 18px; color: #10b981; border-right: 4px solid #10b981; padding-right: 10px; margin-bottom: 12px; }
  .stats-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; margin-bottom: 20px; }
  .stat-card { border: 1px solid #e5e7eb; border-radius: 8px; padding: 12px; text-align: center; }
  .stat-card .label { font-size: 11px; color: #666; margin-bottom: 4px; }
  .stat-card .value { font-size: 22px; font-weight: bold; color: #10b981; }
  table { width: 100%; border-collapse: collapse; margin-bottom: 15px; }
  th, td { padding: 8px 12px; text-align: right; border-bottom: 1px solid #e5e7eb; font-size: 13px; }
  th { background: #f9fafb; color: #374151; font-weight: 600; }
  .badge { display: inline-block; padding: 2px 8px; border-radius: 12px; font-size: 11px; }
  .badge-done { background: #d1fae5; color: #065f46; }
  .badge-pending { background: #fef3c7; color: #92400e; }
  .badge-high { background: #fee2e2; color: #991b1b; }
  .badge-medium { background: #fef3c7; color: #92400e; }
  .badge-low { background: #d1fae5; color: #065f46; }
  .footer { margin-top: 40px; padding-top: 15px; border-top: 1px solid #e5e7eb; text-align: center; color: #9ca3af; font-size: 11px; }
  @media print { body { background: #fff; } }
</style>
</head>
<body>
  <div class="header">
    <h1>📊 تقرير لوحة التحكم الشخصية</h1>
    <p>تاريخ التقرير: ${data.date} - ${data.time}</p>
  </div>

  <div class="section">
    <h2 class="section-title">ملخص الإحصائيات</h2>
    <div class="stats-grid">
      <div class="stat-card"><div class="label">إجمالي المهام</div><div class="value">${data.tasks.total}</div></div>
      <div class="stat-card"><div class="label">مهام منجزة</div><div class="value">${data.tasks.done}</div></div>
      <div class="stat-card"><div class="label">مهام معلقة</div><div class="value">${data.tasks.pending}</div></div>
      <div class="stat-card"><div class="label">جهات الاتصال</div><div class="value">${data.contacts}</div></div>
      <div class="stat-card"><div class="label">أحداث الأسبوع</div><div class="value">${data.events}</div></div>
      <div class="stat-card"><div class="label">الملاحظات</div><div class="value">${data.notes}</div></div>
      <div class="stat-card"><div class="label">المصروفات</div><div class="value">${data.expenses.count}</div></div>
      <div class="stat-card"><div class="label">المناسبات</div><div class="value">${data.occasions}</div></div>
    </div>
  </div>

  <div class="section">
    <h2 class="section-title">المالية</h2>
    <table>
      <tr><th>إجمالي الأصول</th><td>${formatAmount(data.assets.totalSYP)} ل.س</td></tr>
      <tr><th>مصروفات الأسبوع</th><td>${formatAmount(data.expenses.total)} ل.س</td></tr>
      <tr><th>عدد الحسابات</th><td>${data.accounts}</td></tr>
      <tr><th>عدد العادات</th><td>${data.habits}</td></tr>
    </table>
  </div>

  <div class="section">
    <h2 class="section-title">أحدث المهام</h2>
    <table>
      <thead><tr><th>المهمة</th><th>الفئة</th><th>الحالة</th><th>الأولوية</th></tr></thead>
      <tbody>
        ${data.taskList.map((t) => `
          <tr>
            <td>${t.title}</td>
            <td>${t.category}</td>
            <td><span class="badge ${t.status === "done" ? "badge-done" : "badge-pending"}">${t.status === "done" ? "منجزة" : "معلقة"}</span></td>
            <td><span class="badge badge-${t.priority}">${t.priority === "high" ? "عالية" : t.priority === "medium" ? "متوسطة" : "منخفضة"}</span></td>
          </tr>
        `).join("")}
      </tbody>
    </table>
  </div>

  <div class="section">
    <h2 class="section-title">أحدث المصروفات</h2>
    <table>
      <thead><tr><th>الوصف</th><th>الفئة</th><th>المبلغ</th></tr></thead>
      <tbody>
        ${data.expenseList.map((e) => `
          <tr>
            <td>${e.description || "—"}</td>
            <td>${e.category}</td>
            <td>${e.amount.toLocaleString("en-US")} ${e.currency === "usd" ? "$" : "ل.س"}</td>
          </tr>
        `).join("")}
      </tbody>
    </table>
  </div>

  <div class="section">
    <h2 class="section-title">المناسبات القادمة</h2>
    <table>
      <thead><tr><th>المناسبة</th><th>التاريخ</th></tr></thead>
      <tbody>
        ${data.occasionList.map((o) => `
          <tr><td>${o.title}</td><td>${new Date(o.date).toLocaleDateString("ar-SY")}</td></tr>
        `).join("")}
      </tbody>
    </table>
  </div>

  <div class="section">
    <h2 class="section-title">آخر الأنشطة</h2>
    <table>
      <thead><tr><th>النشاط</th><th>النوع</th><th>التاريخ</th></tr></thead>
      <tbody>
        ${data.recentActivity.slice(0, 10).map((a) => `
          <tr>
            <td>${a.title}</td>
            <td>${a.entity}</td>
            <td>${new Date(a.createdAt).toLocaleDateString("ar-SY")}</td>
          </tr>
        `).join("")}
      </tbody>
    </table>
  </div>

  <div class="footer">
    <p>تم إنشاء هذا التقرير تلقائياً بواسطة لوحة التحكم الشخصية | ${data.date}</p>
  </div>
</body>
</html>`;
}

import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET() {
  try {
    const projects = await db.project.findMany({
      where: { deletedAt: null },
      include: { tasks: { orderBy: { order: "asc" } } },
      orderBy: { createdAt: "desc" },
    });
    return NextResponse.json({ success: true, data: projects });
  } catch (error) {
    console.error("GET projects error:", error);
    return NextResponse.json({ success: false, error: "فشل جلب المشاريع" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const { name, description, startDate, endDate, color } = await req.json();
    if (!name) return NextResponse.json({ success: false, error: "اسم المشروع مطلوب" }, { status: 400 });
    const project = await db.project.create({
      data: { name, description, startDate: startDate ? new Date(startDate) : null, endDate: endDate ? new Date(endDate) : null, color: color || "emerald" },
    });
    return NextResponse.json({ success: true, data: project }, { status: 201 });
  } catch (error) {
    console.error("POST project error:", error);
    return NextResponse.json({ success: false, error: "فشل إضافة المشروع" }, { status: 500 });
  }
}

export async function PUT(req: NextRequest) {
  try {
    const { id, action, taskTitle, ...data } = await req.json();
    if (!id) return NextResponse.json({ success: false, error: "المعرف مطلوب" }, { status: 400 });
    if (action === "addTask") {
      const task = await db.projectTask.create({ data: { projectId: id, title: taskTitle } });
      return NextResponse.json({ success: true, data: task });
    }
    if (action === "toggleTask") {
      const task = await db.projectTask.findUnique({ where: { id: data.taskId } });
      if (task) {
        const updated = await db.projectTask.update({ where: { id: data.taskId }, data: { status: task.status === "done" ? "todo" : "done" } });
        // recalculate progress
        const allTasks = await db.projectTask.findMany({ where: { projectId: id } });
        const doneCount = allTasks.filter(t => t.status === "done").length;
        const progress = allTasks.length > 0 ? Math.round((doneCount / allTasks.length) * 100) : 0;
        await db.project.update({ where: { id }, data: { progress } });
        return NextResponse.json({ success: true, data: updated, progress });
      }
    }
    if (data.startDate) data.startDate = new Date(data.startDate);
    if (data.endDate) data.endDate = new Date(data.endDate);
    const project = await db.project.update({ where: { id }, data });
    return NextResponse.json({ success: true, data: project });
  } catch (error) {
    console.error("PUT project error:", error);
    return NextResponse.json({ success: false, error: "فشل التحديث" }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    if (!id) return NextResponse.json({ success: false, error: "المعرف مطلوب" }, { status: 400 });
    await db.project.update({ where: { id }, data: { deletedAt: new Date() } });
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("DELETE project error:", error);
    return NextResponse.json({ success: false, error: "فشل الحذف" }, { status: 500 });
  }
}

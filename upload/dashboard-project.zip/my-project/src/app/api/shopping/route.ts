import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// 10. قائمة التسوق الذكية
// CRUD لعناصر التسوق مع دعم الفلترة حسب المشترى

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const status = searchParams.get("status"); // pending | purchased | all
    const category = searchParams.get("category");

    const where: Record<string, unknown> = {};
    if (status === "pending") where.purchased = false;
    else if (status === "purchased") where.purchased = true;
    if (category) where.category = category;

    const items = await db.shoppingItem.findMany({
      where,
      orderBy: [{ purchased: "asc" }, { createdAt: "desc" }],
    });

    return NextResponse.json({
      success: true,
      data: items,
      stats: {
        count: items.length,
        pendingCount: items.filter((i) => !i.purchased).length,
        purchasedCount: items.filter((i) => i.purchased).length,
        autoAddedCount: items.filter((i) => i.autoAdded).length,
      },
    });
  } catch (error) {
    console.error("GET shopping error:", error);
    return NextResponse.json(
      { success: false, error: "فشل جلب قائمة التسوق" },
      { status: 500 }
    );
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { name, quantity, category, autoAdded } = body;

    if (!name) {
      return NextResponse.json(
        { success: false, error: "الاسم مطلوب" },
        { status: 400 }
      );
    }

    const item = await db.shoppingItem.create({
      data: {
        name,
        quantity: Number(quantity) || 1,
        category: category || "other",
        autoAdded: Boolean(autoAdded),
      },
    });

    return NextResponse.json({ success: true, data: item }, { status: 201 });
  } catch (error) {
    console.error("POST shopping error:", error);
    return NextResponse.json(
      { success: false, error: "فشل إضافة عنصر التسوق" },
      { status: 500 }
    );
  }
}

export async function PUT(req: NextRequest) {
  try {
    const body = await req.json();
    const { id, ...data } = body;

    if (!id) {
      return NextResponse.json(
        { success: false, error: "المعرف مطلوب" },
        { status: 400 }
      );
    }

    if (data.quantity !== undefined) data.quantity = Number(data.quantity);

    const item = await db.shoppingItem.update({ where: { id }, data });
    return NextResponse.json({ success: true, data: item });
  } catch (error) {
    console.error("PUT shopping error:", error);
    return NextResponse.json(
      { success: false, error: "فشل تحديث عنصر التسوق" },
      { status: 500 }
    );
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    const clearPurchased = searchParams.get("clearPurchased") === "true";

    if (clearPurchased) {
      const result = await db.shoppingItem.deleteMany({
        where: { purchased: true },
      });
      return NextResponse.json({ success: true, deleted: result.count });
    }

    if (!id) {
      return NextResponse.json(
        { success: false, error: "المعرف مطلوب" },
        { status: 400 }
      );
    }

    await db.shoppingItem.delete({ where: { id } });
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("DELETE shopping error:", error);
    return NextResponse.json(
      { success: false, error: "فشل حذف عنصر التسوق" },
      { status: 500 }
    );
  }
}

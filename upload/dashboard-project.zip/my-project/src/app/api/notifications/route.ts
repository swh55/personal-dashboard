import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getUpcomingHolidays } from "@/lib/holidays";
import { differenceInDays, isToday, isTomorrow } from "date-fns";

export async function GET() {
  try {
    const now = new Date();
    const todayStart = new Date(now);
    todayStart.setHours(0, 0, 0, 0);
    const todayEnd = new Date(now);
    todayEnd.setHours(23, 59, 59, 999);
    const weekEnd = new Date(now);
    weekEnd.setDate(now.getDate() + 7);

    const notifications: Array<{
      id: string;
      type: "info" | "warning" | "success" | "reminder";
      icon: string;
      title: string;
      description: string;
      color: string;
      action?: string;
    }> = [];

    // 1. أحداث اليوم
    const todayEvents = await db.event.findMany({
      where: { startDate: { gte: todayStart, lte: todayEnd } },
      orderBy: { startDate: "asc" },
    });
    if (todayEvents.length > 0) {
      notifications.push({
        id: "today-events",
        type: "info",
        icon: "Calendar",
        title: `لديك ${todayEvents.length} حدث اليوم`,
        description: todayEvents[0].title,
        color: "emerald",
        action: "calendar",
      });
    }

    // 2. مهام عالية الأولوية
    const highPriorityTasks = await db.task.count({
      where: { priority: "high", status: { not: "done" } },
    });
    if (highPriorityTasks > 0) {
      notifications.push({
        id: "high-priority",
        type: "warning",
        icon: "AlertCircle",
        title: `${highPriorityTasks} مهمة عالية الأولوية معلّقة`,
        description: "تحتاج اهتماماً فورياً",
        color: "rose",
        action: "tasks",
      });
    }

    // 3. المناسبات القريبة (خلال 7 أيام)
    const occasions = await db.occasion.findMany();
    for (const occ of occasions) {
      const nextDate = new Date(occ.date);
      nextDate.setFullYear(now.getFullYear());
      if (nextDate < todayStart) {
        nextDate.setFullYear(now.getFullYear() + 1);
      }
      const days = differenceInDays(nextDate, todayStart);
      if (days >= 0 && days <= 7) {
        notifications.push({
          id: `occasion-${occ.id}`,
          type: days === 0 ? "success" : "reminder",
          icon: "Cake",
          title: days === 0 ? `🎉 ${occ.title} اليوم!` : `${occ.title} بعد ${days} أيام`,
          description: days === 0 ? "لا تنسَ التهنئة!" : `${nextDate.toLocaleDateString("ar-SY")}`,
          color: "purple",
          action: "occasions",
        });
      }
    }

    // 4. العطل القادمة
    const upcomingHolidays = getUpcomingHolidays(2);
    for (const holiday of upcomingHolidays) {
      if (holiday.daysUntil <= 7) {
        notifications.push({
          id: `holiday-${holiday.date}`,
          type: "info",
          icon: "CalendarDays",
          title: `${holiday.name} ${holiday.daysUntil === 0 ? "اليوم" : `بعد ${holiday.daysUntil} أيام`}`,
          description: holiday.date,
          color: "purple",
        });
      }
    }

    // 5. مهام بدون إنجاز لفترة
    const pendingTasks = await db.task.count({ where: { status: { not: "done" } } });
    if (pendingTasks > 5) {
      notifications.push({
        id: "many-pending",
        type: "reminder",
        icon: "CheckSquare",
        title: `لديك ${pendingTasks} مهمة معلّقة`,
        description: "فكّر في مراجعتها وإنجاز بعضها",
        color: "amber",
        action: "tasks",
      });
    }

    // 6. عادات لم تُنجز اليوم
    const habits = await db.habit.findMany({ include: { logs: true } });
    const undoneHabits = habits.filter((h) => {
      return !h.logs.some((l) => isToday(new Date(l.date)) && l.count >= h.target);
    });
    if (undoneHabits.length > 0) {
      notifications.push({
        id: "undone-habits",
        type: "reminder",
        icon: "RefreshCw",
        title: `${undoneHabits.length} عادات بانتظارك اليوم`,
        description: undoneHabits.slice(0, 2).map((h) => h.name).join("، "),
        color: "teal",
        action: "habits",
      });
    }

    // 7. مصروفات اليوم عالية
    const todayExpenses = await db.expense.findMany({
      where: { date: { gte: todayStart } },
    });
    const todayTotal = todayExpenses.reduce(
      (s, e) => s + (e.currency === "usd" ? e.amount * 12500 : e.amount),
      0
    );
    if (todayTotal > 50000) {
      notifications.push({
        id: "high-expenses",
        type: "warning",
        icon: "Receipt",
        title: `مصروفات اليوم مرتفعة: ${todayTotal.toLocaleString("en-US")} ل.س`,
        description: `عدد المصروفات: ${todayExpenses.length}`,
        color: "rose",
        action: "expenses",
      });
    }

    // 8. اجتماعات اليوم
    const todayMeetings = await db.meeting.findMany({
      where: {
        startTime: { gte: todayStart, lte: todayEnd },
        status: "upcoming",
        deletedAt: null,
      },
    });
    if (todayMeetings.length > 0) {
      notifications.push({
        id: "today-meetings",
        type: "info",
        icon: "Users",
        title: `${todayMeetings.length} اجتماع اليوم`,
        description: todayMeetings[0].title,
        color: "teal",
        action: "meetings",
      });
    }

    // 9. أدوية لم تُؤخذ اليوم
    const medications = await db.medication.findMany({
      where: { active: true, deletedAt: null },
      include: { logs: { where: { takenAt: { gte: todayStart } } } },
    });
    const untakenMeds = medications.filter(m => m.logs.length === 0);
    if (untakenMeds.length > 0) {
      notifications.push({
        id: "untaken-meds",
        type: "reminder",
        icon: "Heart",
        title: `${untakenMeds.length} أدوية لم تؤخذ اليوم`,
        description: untakenMeds.slice(0, 2).map(m => m.name).join("، "),
        color: "rose",
        action: "health",
      });
    }

    // 10. ديون مستحقة قريباً
    const dueSoon = await db.debt.findMany({
      where: {
        settled: false,
        deletedAt: null,
        dueDate: { gte: now, lte: weekEnd },
      },
    });
    if (dueSoon.length > 0) {
      notifications.push({
        id: "due-debts",
        type: "warning",
        icon: "HandCoins",
        title: `${dueSoon.length} دين مستحق قريباً`,
        description: dueSoon[0].personName,
        color: "amber",
        action: "debts",
      });
    }

    // ترتيب: success > warning > reminder > info
    const orderMap = { success: 0, warning: 1, reminder: 2, info: 3 };
    notifications.sort((a, b) => orderMap[a.type] - orderMap[b.type]);

    return NextResponse.json({
      success: true,
      data: notifications,
      count: notifications.length,
    });
  } catch (error) {
    console.error("Notifications error:", error);
    return NextResponse.json({ success: false, error: "فشل جلب الإشعارات" }, { status: 500 });
  }
}

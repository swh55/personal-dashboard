import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET() {
  try {
    const meetings = await db.meeting.findMany({
      where: { deletedAt: null },
      orderBy: { startTime: "desc" },
    });
    return NextResponse.json({ success: true, data: meetings });
  } catch (error) {
    console.error("GET meetings error:", error);
    return NextResponse.json({ success: false, error: "فشل جلب الاجتماعات" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const { title, description, startTime, endTime, location, attendees } = await req.json();
    if (!title || !startTime) return NextResponse.json({ success: false, error: "العنوان والوقت مطلوبان" }, { status: 400 });
    const meeting = await db.meeting.create({
      data: { title, description, startTime: new Date(startTime), endTime: endTime ? new Date(endTime) : null, location, attendees: attendees ? JSON.stringify(attendees) : null },
    });

    // ربط تلقائي بالتقويم
    try {
      await db.event.create({
        data: {
          title: `اجتماع: ${title}`,
          description: description || null,
          startDate: new Date(startTime),
          endDate: endTime ? new Date(endTime) : null,
          type: "work",
          color: "teal",
          location: location || null,
        },
      });
    } catch {}

    return NextResponse.json({ success: true, data: meeting }, { status: 201 });
  } catch (error) {
    console.error("POST meeting error:", error);
    return NextResponse.json({ success: false, error: "فشل إضافة الاجتماع" }, { status: 500 });
  }
}

export async function PUT(req: NextRequest) {
  try {
    const { id, ...data } = await req.json();
    if (!id) return NextResponse.json({ success: false, error: "المعرف مطلوب" }, { status: 400 });
    if (data.startTime) data.startTime = new Date(data.startTime);
    if (data.endTime) data.endTime = new Date(data.endTime);
    if (data.attendees) data.attendees = JSON.stringify(data.attendees);
    const meeting = await db.meeting.update({ where: { id }, data });
    return NextResponse.json({ success: true, data: meeting });
  } catch (error) {
    console.error("PUT meeting error:", error);
    return NextResponse.json({ success: false, error: "فشل التحديث" }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    if (!id) return NextResponse.json({ success: false, error: "المعرف مطلوب" }, { status: 400 });
    await db.meeting.update({ where: { id }, data: { deletedAt: new Date() } });
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("DELETE meeting error:", error);
    return NextResponse.json({ success: false, error: "فشل الحذف" }, { status: 500 });
  }
}

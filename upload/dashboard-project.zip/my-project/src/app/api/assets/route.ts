import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET() {
  try {
    const assets = await db.asset.findMany({ orderBy: { type: "asc" } });
    return NextResponse.json({ success: true, data: assets });
  } catch (error) {
    console.error("GET assets error:", error);
    return NextResponse.json({ success: false, error: "فشل جلب الأصول" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { type, amount, unit, note } = body;

    if (!type || amount === undefined) {
      return NextResponse.json({ success: false, error: "النوع والمبلغ مطلوبان" }, { status: 400 });
    }

    const asset = await db.asset.create({
      data: { type, amount: Number(amount), unit: unit || "", note: note || null },
    });

    return NextResponse.json({ success: true, data: asset }, { status: 201 });
  } catch (error) {
    console.error("POST asset error:", error);
    return NextResponse.json({ success: false, error: "فشل إضافة الأصل" }, { status: 500 });
  }
}

export async function PUT(req: NextRequest) {
  try {
    const body = await req.json();
    const { id, ...data } = body;

    if (!id) {
      return NextResponse.json({ success: false, error: "المعرف مطلوب" }, { status: 400 });
    }

    if (data.amount !== undefined) data.amount = Number(data.amount);

    const asset = await db.asset.update({ where: { id }, data });
    return NextResponse.json({ success: true, data: asset });
  } catch (error) {
    console.error("PUT asset error:", error);
    return NextResponse.json({ success: false, error: "فشل تحديث الأصل" }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");

    if (!id) {
      return NextResponse.json({ success: false, error: "المعرف مطلوب" }, { status: 400 });
    }

    await db.asset.delete({ where: { id } });
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("DELETE asset error:", error);
    return NextResponse.json({ success: false, error: "فشل حذف الأصل" }, { status: 500 });
  }
}

import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// 1. فواتير المنزل
// GET: جلب كل الفواتير مع إمكانية الفلترة حسب المدفوع/غير المدفوع
// POST: إنشاء فاتورة جديدة
// PUT: تحديث فاتورة أو تعليمها كمدفوعة
// DELETE: حذف فاتورة حسب المعرف

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const status = searchParams.get("status"); // paid | unpaid | all

    const where: Record<string, unknown> = {};
    if (status === "paid") where.paid = true;
    else if (status === "unpaid") where.paid = false;

    const bills = await db.utilityBill.findMany({
      where,
      orderBy: [{ paid: "asc" }, { dueDate: "asc" }],
    });

    return NextResponse.json({
      success: true,
      data: bills,
      stats: {
        count: bills.length,
        paidCount: bills.filter((b) => b.paid).length,
        unpaidCount: bills.filter((b) => !b.paid).length,
        totalPaid: bills.filter((b) => b.paid).reduce((s, b) => s + b.amount, 0),
        totalUnpaid: bills.filter((b) => !b.paid).reduce((s, b) => s + b.amount, 0),
      },
    });
  } catch (error) {
    console.error("GET utility-bills error:", error);
    return NextResponse.json(
      { success: false, error: "فشل جلب فواتير المنزل" },
      { status: 500 }
    );
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { type, amount, dueDate, paid, paidAt, note } = body;

    if (!type || amount === undefined || !dueDate) {
      return NextResponse.json(
        { success: false, error: "النوع والمبلغ وتاريخ الاستحقاق مطلوبون" },
        { status: 400 }
      );
    }

    const bill = await db.utilityBill.create({
      data: {
        type,
        amount: Number(amount),
        dueDate: new Date(dueDate),
        paid: Boolean(paid),
        paidAt: paidAt ? new Date(paidAt) : paid ? new Date() : null,
        note: note || null,
      },
    });

    return NextResponse.json({ success: true, data: bill }, { status: 201 });
  } catch (error) {
    console.error("POST utility-bills error:", error);
    return NextResponse.json(
      { success: false, error: "فشل إضافة الفاتورة" },
      { status: 500 }
    );
  }
}

export async function PUT(req: NextRequest) {
  try {
    const body = await req.json();
    const { id, ...data } = body;

    if (!id) {
      return NextResponse.json(
        { success: false, error: "المعرف مطلوب" },
        { status: 400 }
      );
    }

    if (data.amount !== undefined) data.amount = Number(data.amount);
    if (data.dueDate) data.dueDate = new Date(data.dueDate);
    if (data.paidAt) data.paidAt = new Date(data.paidAt);

    // عند تعليم الفاتورة كمدفوعة، سجّل وقت الدفع تلقائياً إن لم يُمرّر
    if (data.paid === true && !data.paidAt) {
      data.paidAt = new Date();
    }

    const bill = await db.utilityBill.update({ where: { id }, data });
    return NextResponse.json({ success: true, data: bill });
  } catch (error) {
    console.error("PUT utility-bills error:", error);
    return NextResponse.json(
      { success: false, error: "فشل تحديث الفاتورة" },
      { status: 500 }
    );
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");

    if (!id) {
      return NextResponse.json(
        { success: false, error: "المعرف مطلوب" },
        { status: 400 }
      );
    }

    await db.utilityBill.delete({ where: { id } });
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("DELETE utility-bills error:", error);
    return NextResponse.json(
      { success: false, error: "فشل حذف الفاتورة" },
      { status: 500 }
    );
  }
}

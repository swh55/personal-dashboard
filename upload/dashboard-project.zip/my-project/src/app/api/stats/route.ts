import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const period = searchParams.get("period") || "week"; // week or month

    const now = new Date();
    const periodStart = new Date(now);
    if (period === "month") {
      periodStart.setMonth(now.getMonth() - 1);
    } else {
      periodStart.setDate(now.getDate() - 7);
    }
    periodStart.setHours(0, 0, 0, 0);

    const todayStart = new Date(now);
    todayStart.setHours(0, 0, 0, 0);

    // المهام المنجزة هذا الأسبوع
    const tasksDoneThisWeek = await db.task.count({
      where: {
        status: "done",
        updatedAt: { gte: periodStart },
      },
    });

    // المهام المُضافة هذا الأسبوع
    const tasksCreatedThisWeek = await db.task.count({
      where: {
        createdAt: { gte: periodStart },
      },
    });

    // المصروفات هذا الأسبوع
    const expensesThisWeek = await db.expense.findMany({
      where: { date: { gte: periodStart } },
    });
    const totalExpensesSYP = expensesThisWeek.reduce(
      (sum, e) => sum + (e.currency === "usd" ? e.amount * 12500 : e.amount),
      0
    );

    // المصروفات اليوم
    const expensesToday = await db.expense.findMany({
      where: { date: { gte: todayStart } },
    });
    const todayExpensesSYP = expensesToday.reduce(
      (sum, e) => sum + (e.currency === "usd" ? e.amount * 12500 : e.amount),
      0
    );

    // العادات المنجزة هذا الأسبوع
    const habitLogsThisWeek = await db.habitLog.findMany({
      where: { date: { gte: periodStart } },
    });

    // الأحداث هذا الأسبوع
    const eventsThisWeek = await db.event.count({
      where: { startDate: { gte: periodStart } },
    });

    // المكالمات هذا الأسبوع
    const callsThisWeek = await db.callLog.count({
      where: { createdAt: { gte: periodStart } },
    });

    // نشاط آخر N أيام (للرسم البياني) - 7 للأسبوع، 30 للشهر
    const numDays = period === "month" ? 30 : 7;
    const lastNDays = Array.from({ length: numDays }, (_, i) => {
      const date = new Date(now);
      date.setDate(now.getDate() - (numDays - 1 - i));
      date.setHours(0, 0, 0, 0);
      const nextDay = new Date(date);
      nextDay.setDate(date.getDate() + 1);
      const label = period === "month"
        ? date.toLocaleDateString("ar-SY", { day: "numeric" })
        : date.toLocaleDateString("ar-SY", { weekday: "short" });
      return { date, nextDay, label };
    });

    const dailyStats = await Promise.all(
      lastNDays.map(async (day) => {
        const [tasks, expenses, habits] = await Promise.all([
          db.task.count({
            where: {
              status: "done",
              updatedAt: { gte: day.date, lt: day.nextDay },
            },
          }),
          db.expense.findMany({
            where: { date: { gte: day.date, lt: day.nextDay } },
          }),
          db.habitLog.count({
            where: { date: { gte: day.date, lt: day.nextDay } },
          }),
        ]);
        const expenseTotal = expenses.reduce(
          (sum, e) => sum + (e.currency === "usd" ? e.amount * 12500 : e.amount),
          0
        );
        return {
          day: day.label,
          date: day.date.toISOString(),
          tasks,
          expenses: expenseTotal,
          habits,
          isToday: day.date.toDateString() === todayStart.toDateString(),
        };
      })
    );

    return NextResponse.json({
      success: true,
      data: {
        tasksDoneThisWeek,
        tasksCreatedThisWeek,
        totalExpensesSYP,
        todayExpensesSYP,
        habitsCompletedThisWeek: habitLogsThisWeek.length,
        eventsThisWeek,
        callsThisWeek,
        dailyStats,
      },
    });
  } catch (error) {
    console.error("GET weekly stats error:", error);
    return NextResponse.json({ success: false, error: "فشل جلب الإحصائيات" }, { status: 500 });
  }
}

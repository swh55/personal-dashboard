import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { logActivity } from "@/lib/activity";

export async function GET(req: NextRequest) {
  try {
    const searchParams = req.nextUrl.searchParams;
    const category = searchParams.get("category");
    const status = searchParams.get("status");
    const trashed = searchParams.get("trashed") === "true";

    const where: Record<string, unknown> = {};
    if (trashed) {
      where.deletedAt = { not: null };
    } else {
      where.deletedAt = null;
    }
    if (category) where.category = category;
    if (status) where.status = status;

    const tasks = await db.task.findMany({
      where,
      orderBy: [{ status: "asc" }, { priority: "desc" }, { createdAt: "desc" }],
    });

    return NextResponse.json({ success: true, data: tasks });
  } catch (error) {
    console.error("GET tasks error:", error);
    return NextResponse.json({ success: false, error: "فشل جلب المهام" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { title, description, category, priority, status, dueDate } = body;

    if (!title) {
      return NextResponse.json({ success: false, error: "العنوان مطلوب" }, { status: 400 });
    }

    const task = await db.task.create({
      data: {
        title,
        description: description || null,
        category: category || "home",
        priority: priority || "medium",
        status: status || "todo",
        dueDate: dueDate ? new Date(dueDate) : null,
      },
    });

    // ربط تلقائي بالتقويم إذا كان هناك تاريخ استحقاق
    if (dueDate) {
      try {
        await db.event.create({
          data: {
            title: `مهمة: ${title}`,
            description: description || null,
            startDate: new Date(dueDate),
            type: "work",
            color: "emerald",
            location: null,
          },
        });
      } catch {}
    }

    await logActivity("create", "task", `أضيف مهمة: ${title}`);
    return NextResponse.json({ success: true, data: task }, { status: 201 });
  } catch (error) {
    console.error("POST task error:", error);
    return NextResponse.json({ success: false, error: "فشل إضافة المهمة" }, { status: 500 });
  }
}

export async function PUT(req: NextRequest) {
  try {
    const body = await req.json();
    const { id, ...data } = body;

    if (!id) {
      return NextResponse.json({ success: false, error: "المعرف مطلوب" }, { status: 400 });
    }

    if (data.dueDate) data.dueDate = new Date(data.dueDate);

    const task = await db.task.update({ where: { id }, data });
    if (data.status === "done") {
      await logActivity("toggle", "task", `تم إنجاز مهمة: ${task.title}`);
    } else {
      await logActivity("update", "task", `تم تعديل مهمة: ${task.title}`);
    }
    return NextResponse.json({ success: true, data: task });
  } catch (error) {
    console.error("PUT task error:", error);
    return NextResponse.json({ success: false, error: "فشل تحديث المهمة" }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    const force = searchParams.get("force") === "true"; // حذف نهائي
    const restore = searchParams.get("restore") === "true"; // استعادة

    if (!id) {
      return NextResponse.json({ success: false, error: "المعرف مطلوب" }, { status: 400 });
    }

    if (restore) {
      await db.task.update({ where: { id }, data: { deletedAt: null } });
      await logActivity("update", "task", "تم استعادة مهمة من سلة المحذوفات");
      return NextResponse.json({ success: true });
    }

    if (force) {
      const task = await db.task.findUnique({ where: { id } });
      await db.task.delete({ where: { id } });
      if (task) await logActivity("delete", "task", `حُذفت مهمة نهائياً: ${task.title}`);
      return NextResponse.json({ success: true });
    }

    // soft delete
    const task = await db.task.findUnique({ where: { id } });
    await db.task.update({ where: { id }, data: { deletedAt: new Date() } });
    if (task) await logActivity("delete", "task", `نُقلت مهمة لسلة المحذوفات: ${task.title}`);
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("DELETE task error:", error);
    return NextResponse.json({ success: false, error: "فشل حذف المهمة" }, { status: 500 });
  }
}

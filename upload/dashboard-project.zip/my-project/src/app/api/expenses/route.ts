import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { logActivity } from "@/lib/activity";

export async function GET(req: NextRequest) {
  try {
    const searchParams = req.nextUrl.searchParams;
    const period = searchParams.get("period"); // today, week, month, all

    const where: Record<string, unknown> = {};
    const now = new Date();
    if (period === "today") {
      const start = new Date(now);
      start.setHours(0, 0, 0, 0);
      where.date = { gte: start };
    } else if (period === "week") {
      const start = new Date(now);
      start.setDate(now.getDate() - 7);
      start.setHours(0, 0, 0, 0);
      where.date = { gte: start };
    } else if (period === "month") {
      const start = new Date(now.getFullYear(), now.getMonth(), 1);
      where.date = { gte: start };
    }

    const expenses = await db.expense.findMany({
      where,
      orderBy: { date: "desc" },
    });

    // إحصائيات حسب الفئة
    const byCategory = expenses.reduce((acc, e) => {
      const key = e.category;
      if (!acc[key]) acc[key] = { count: 0, total: 0 };
      acc[key].count++;
      acc[key].total += e.currency === "usd" ? e.amount * 12500 : e.amount;
      return acc;
    }, {} as Record<string, { count: number; total: number }>);

    const totalSYP = expenses.reduce(
      (sum, e) => sum + (e.currency === "usd" ? e.amount * 12500 : e.amount),
      0
    );

    return NextResponse.json({
      success: true,
      data: expenses,
      stats: {
        total: totalSYP,
        count: expenses.length,
        byCategory,
      },
    });
  } catch (error) {
    console.error("GET expenses error:", error);
    return NextResponse.json({ success: false, error: "فشل جلب المصروفات" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { amount, currency, category, description, date } = body;

    if (!amount || amount <= 0) {
      return NextResponse.json({ success: false, error: "المبلغ مطلوب" }, { status: 400 });
    }

    const expense = await db.expense.create({
      data: {
        amount: Number(amount),
        currency: currency || "syp",
        category: category || "other",
        description: description || null,
        date: date ? new Date(date) : new Date(),
      },
    });

    await logActivity("create", "expense", `أضيف مصروف: ${description || category} (${amount} ${currency})`);
    return NextResponse.json({ success: true, data: expense }, { status: 201 });
  } catch (error) {
    console.error("POST expense error:", error);
    return NextResponse.json({ success: false, error: "فشل إضافة المصروف" }, { status: 500 });
  }
}

export async function PUT(req: NextRequest) {
  try {
    const body = await req.json();
    const { id, ...data } = body;
    if (!id) {
      return NextResponse.json({ success: false, error: "المعرف مطلوب" }, { status: 400 });
    }
    if (data.amount !== undefined) data.amount = Number(data.amount);
    if (data.date) data.date = new Date(data.date);

    const expense = await db.expense.update({ where: { id }, data });
    return NextResponse.json({ success: true, data: expense });
  } catch (error) {
    console.error("PUT expense error:", error);
    return NextResponse.json({ success: false, error: "فشل تحديث المصروف" }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    if (!id) {
      return NextResponse.json({ success: false, error: "المعرف مطلوب" }, { status: 400 });
    }
    await db.expense.delete({ where: { id } });
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("DELETE expense error:", error);
    return NextResponse.json({ success: false, error: "فشل حذف المصروف" }, { status: 500 });
  }
}

import { NextResponse } from "next/server";

// جلب أسعار الذهب والعملات من API مجانية
export async function GET() {
  try {
    // محاولة جلب سعر الذهب من open.er-api.com للدولار/الليرة السورية
    let usdToSYP = 12500; // قيمة افتراضية
    try {
      const forexRes = await fetch("https://open.er-api.com/v6/latest/USD", {
        next: { revalidate: 3600 },
      });
      if (forexRes.ok) {
        const forexData = await forexRes.json();
        if (forexData.rates?.SYP) {
          usdToSYP = forexData.rates.SYP;
        }
      }
    } catch {
      // استخدام القيمة الافتراضية
    }

    // سعر الذهب التقريبي (غرام عيار 21) - قيمة تقديرية
    // في الواقع يُفضّل استخدام API مدفوع، نستخدم قيمة تقريبية محدثة
    const goldPerGramUSD = 78; // تقريبي - يُحدّث يدوياً أو من API مدفوع
    const goldPerGramSYP = goldPerGramUSD * usdToSYP;

    return NextResponse.json({
      success: true,
      data: {
        usdToSYP,
        goldPerGramUSD,
        goldPerGramSYP,
        goldPerGram21USD: goldPerGramUSD * 0.875, // عيار 21 = 21/24 من عيار 24
        goldPerGram21SYP: goldPerGramSYP * 0.875,
        updatedAt: new Date().toISOString(),
        note: "الأسعار تقريبية وقد تختلف عن أسعار السوق المحلي",
      },
    });
  } catch (error) {
    console.error("Currency API error:", error);
    return NextResponse.json({
      success: false,
      error: "تعذر جلب أسعار العملات",
      data: {
        usdToSYP: 12500,
        goldPerGramUSD: 78,
        goldPerGramSYP: 975000,
        goldPerGram21USD: 68.25,
        goldPerGram21SYP: 853125,
        updatedAt: new Date().toISOString(),
        note: "قيم افتراضية",
      },
    });
  }
}

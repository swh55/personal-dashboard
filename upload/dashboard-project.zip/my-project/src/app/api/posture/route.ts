import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// 6. سجل الجلوس/الوقوف
// POST: تسجيل حالة (وقوف/جلوس)
// GET: عدد مرات الوقوف اليوم

function startOfToday(): Date {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  return d;
}

function endOfToday(): Date {
  const d = new Date();
  d.setHours(23, 59, 59, 999);
  return d;
}

const RECOMMENDED_STANDS = 8;

export async function GET() {
  try {
    const logs = await db.postureLog.findMany({
      where: { timestamp: { gte: startOfToday(), lte: endOfToday() } },
      orderBy: { timestamp: "desc" },
    });

    const stoodCount = logs.filter((l) => l.type === "stood").length;
    const satCount = logs.filter((l) => l.type === "sat").length;
    const currentPosture = logs[0]?.type ?? "sat";

    return NextResponse.json({
      success: true,
      data: logs,
      stoodCount,
      satCount,
      currentPosture,
      recommendedStands: RECOMMENDED_STANDS,
      percentage: Math.min(
        100,
        Math.round((stoodCount / RECOMMENDED_STANDS) * 100)
      ),
    });
  } catch (error) {
    console.error("GET posture error:", error);
    return NextResponse.json(
      { success: false, error: "فشل جلب سجل الجلسات" },
      { status: 500 }
    );
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { type, timestamp } = body;

    const validTypes = ["stood", "sat"];
    const finalType = validTypes.includes(type) ? type : "stood";

    const log = await db.postureLog.create({
      data: {
        type: finalType,
        timestamp: timestamp ? new Date(timestamp) : new Date(),
      },
    });

    return NextResponse.json({ success: true, data: log }, { status: 201 });
  } catch (error) {
    console.error("POST posture error:", error);
    return NextResponse.json(
      { success: false, error: "فشل تسجيل الحالة" },
      { status: 500 }
    );
  }
}

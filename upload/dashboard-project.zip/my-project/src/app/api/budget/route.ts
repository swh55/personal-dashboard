import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { logActivity } from "@/lib/activity";

// GET: returns budgets for the current month (and year)
export async function GET(req: NextRequest) {
  try {
    const searchParams = req.nextUrl.searchParams;
    const now = new Date();
    const month = searchParams.get("month")
      ? Number(searchParams.get("month"))
      : now.getMonth() + 1;
    const year = searchParams.get("year")
      ? Number(searchParams.get("year"))
      : now.getFullYear();

    const budgets = await db.budget.findMany({
      where: { month, year },
      orderBy: { category: "asc" },
    });

    // Pair each budget with the actual spending for that category this month
    const monthStart = new Date(year, month - 1, 1);
    const monthEnd = new Date(year, month, 0, 23, 59, 59, 999);
    const expenses = await db.expense.findMany({
      where: { date: { gte: monthStart, lte: monthEnd }, deletedAt: null },
      select: { category: true, amount: true, currency: true },
    });

    const spentByCategory = expenses.reduce((acc, e) => {
      const value = e.currency === "usd" ? e.amount * 12500 : e.amount;
      acc[e.category] = (acc[e.category] || 0) + value;
      return acc;
    }, {} as Record<string, number>);

    const data = budgets.map((b) => {
      const spent = spentByCategory[b.category] || 0;
      const percent = b.limit > 0 ? Math.round((spent / b.limit) * 100) : 0;
      return {
        ...b,
        spent,
        remaining: b.limit - spent,
        percent,
        overBudget: spent > b.limit,
      };
    });

    return NextResponse.json({
      success: true,
      data,
      meta: { month, year, count: budgets.length },
    });
  } catch (error) {
    console.error("GET budget error:", error);
    return NextResponse.json(
      { success: false, error: "فشل جلب الميزانيات" },
      { status: 500 }
    );
  }
}

// POST: creates a new budget or updates an existing one for the same category+month+year
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { id, category, limit, month, year } = body;

    if (!category || limit === undefined || limit === null) {
      return NextResponse.json(
        { success: false, error: "الفئة والحد مطلوبان" },
        { status: 400 }
      );
    }

    const now = new Date();
    const m = month ? Number(month) : now.getMonth() + 1;
    const y = year ? Number(year) : now.getFullYear();
    const limitValue = Number(limit);

    if (limitValue < 0) {
      return NextResponse.json(
        { success: false, error: "الحد يجب أن يكون موجباً" },
        { status: 400 }
      );
    }

    // If an id is provided, update that specific budget
    if (id) {
      const updated = await db.budget.update({
        where: { id },
        data: {
          category,
          limit: limitValue,
          month: m,
          year: y,
        },
      });
      await logActivity(
        "update",
        "budget",
        `تم تحديث ميزانية: ${category} (${limitValue})`
      );
      return NextResponse.json({ success: true, data: updated });
    }

    // Otherwise upsert by unique category+month+year combination
    const existing = await db.budget.findFirst({
      where: { category, month: m, year: y },
    });

    let budget;
    if (existing) {
      budget = await db.budget.update({
        where: { id: existing.id },
        data: { limit: limitValue },
      });
      await logActivity(
        "update",
        "budget",
        `تم تحديث ميزانية: ${category} (${limitValue})`
      );
    } else {
      budget = await db.budget.create({
        data: {
          category,
          limit: limitValue,
          month: m,
          year: y,
        },
      });
      await logActivity(
        "create",
        "budget",
        `تمت إضافة ميزانية: ${category} (${limitValue})`
      );
    }

    return NextResponse.json({ success: true, data: budget }, { status: 201 });
  } catch (error) {
    console.error("POST budget error:", error);
    return NextResponse.json(
      { success: false, error: "فشل حفظ الميزانية" },
      { status: 500 }
    );
  }
}

// DELETE: remove a budget by id
export async function DELETE(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    if (!id) {
      return NextResponse.json(
        { success: false, error: "المعرف مطلوب" },
        { status: 400 }
      );
    }

    const budget = await db.budget.delete({ where: { id } });
    await logActivity(
      "delete",
      "budget",
      `تم حذف ميزانية: ${budget.category}`
    );
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("DELETE budget error:", error);
    return NextResponse.json(
      { success: false, error: "فشل حذف الميزانية" },
      { status: 500 }
    );
  }
}

import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { logActivity } from "@/lib/activity";

// GET: returns all automation rules
export async function GET(req: NextRequest) {
  try {
    const searchParams = req.nextUrl.searchParams;
    const activeOnly = searchParams.get("active") === "true";

    const where: Record<string, unknown> = {};
    if (activeOnly) {
      where.active = true;
    }

    const rules = await db.automationRule.findMany({
      where,
      orderBy: { createdAt: "desc" },
    });

    return NextResponse.json({
      success: true,
      data: rules,
      meta: { count: rules.length },
    });
  } catch (error) {
    console.error("GET automation error:", error);
    return NextResponse.json(
      { success: false, error: "فشل جلب قواعد الأتمتة" },
      { status: 500 }
    );
  }
}

// POST: create a new automation rule
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { name, trigger, triggerData, action, actionData, active } = body;

    if (!name || !trigger || !action) {
      return NextResponse.json(
        {
          success: false,
          error: "الاسم والمحفّز والإجراء مطلوبة",
        },
        { status: 400 }
      );
    }

    const rule = await db.automationRule.create({
      data: {
        name,
        trigger,
        triggerData:
          typeof triggerData === "string"
            ? triggerData
            : triggerData
            ? JSON.stringify(triggerData)
            : null,
        action,
        actionData:
          typeof actionData === "string"
            ? actionData
            : actionData
            ? JSON.stringify(actionData)
            : null,
        active: active !== undefined ? Boolean(active) : true,
      },
    });

    await logActivity(
      "create",
      "automation_rule",
      `تمت إضافة قاعدة أتمتة: ${name}`
    );
    return NextResponse.json({ success: true, data: rule }, { status: 201 });
  } catch (error) {
    console.error("POST automation error:", error);
    return NextResponse.json(
      { success: false, error: "فشل إنشاء قاعدة الأتمتة" },
      { status: 500 }
    );
  }
}

// PUT: update an automation rule or toggle its active state
export async function PUT(req: NextRequest) {
  try {
    const body = await req.json();
    const { id, active, triggerData, actionData, ...rest } = body;

    if (!id) {
      return NextResponse.json(
        { success: false, error: "المعرف مطلوب" },
        { status: 400 }
      );
    }

    const data: Record<string, unknown> = { ...rest };
    if (active !== undefined) {
      data.active = Boolean(active);
    }
    if (triggerData !== undefined) {
      data.triggerData =
        typeof triggerData === "string"
          ? triggerData
          : triggerData
          ? JSON.stringify(triggerData)
          : null;
    }
    if (actionData !== undefined) {
      data.actionData =
        typeof actionData === "string"
          ? actionData
          : actionData
          ? JSON.stringify(actionData)
          : null;
    }

    const updated = await db.automationRule.update({
      where: { id },
      data,
    });

    if (active !== undefined) {
      await logActivity(
        "toggle",
        "automation_rule",
        `${active ? "تفعيل" : "تعطيل"} قاعدة: ${updated.name}`
      );
    } else {
      await logActivity(
        "update",
        "automation_rule",
        `تم تحديث قاعدة: ${updated.name}`
      );
    }

    return NextResponse.json({ success: true, data: updated });
  } catch (error) {
    console.error("PUT automation error:", error);
    return NextResponse.json(
      { success: false, error: "فشل تحديث قاعدة الأتمتة" },
      { status: 500 }
    );
  }
}

// DELETE: remove an automation rule by id
export async function DELETE(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    if (!id) {
      return NextResponse.json(
        { success: false, error: "المعرف مطلوب" },
        { status: 400 }
      );
    }

    const rule = await db.automationRule.delete({ where: { id } });
    await logActivity(
      "delete",
      "automation_rule",
      `تم حذف قاعدة: ${rule.name}`
    );
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("DELETE automation error:", error);
    return NextResponse.json(
      { success: false, error: "فشل حذف قاعدة الأتمتة" },
      { status: 500 }
    );
  }
}

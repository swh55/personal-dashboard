import { NextRequest, NextResponse } from "next/server";
import { USER_PROFILE, PRAYER_NAMES } from "@/lib/constants";

// جلب مواقيت الصلاة لمدينة حلب من Aladhan API
export async function GET(req: NextRequest) {
  try {
    const searchParams = req.nextUrl.searchParams;
    const date = searchParams.get("date") || new Date().toISOString().split("T")[0];

    const url = `https://api.aladhan.com/v1/timings/${date}?latitude=${USER_PROFILE.lat}&longitude=${USER_PROFILE.lng}&method=3`;

    const res = await fetch(url, {
      next: { revalidate: 3600 },
    });

    if (!res.ok) {
      throw new Error(`Aladhan API error: ${res.status}`);
    }

    const data = await res.json();

    if (data.code !== 200) {
      throw new Error(data.data || "Failed to fetch prayer times");
    }

    const timings = data.data.timings;
    const dateInfo = data.data.date;
    const meta = data.data.meta;

    const orderedPrayers = [
      { key: "Imsak", time: timings.Imsak, name: PRAYER_NAMES.Imsak, isPrayer: false },
      { key: "Fajr", time: timings.Fajr, name: PRAYER_NAMES.Fajr, isPrayer: true },
      { key: "Sunrise", time: timings.Sunrise, name: PRAYER_NAMES.Sunrise, isPrayer: false },
      { key: "Dhuhr", time: timings.Dhuhr, name: PRAYER_NAMES.Dhuhr, isPrayer: true },
      { key: "Asr", time: timings.Asr, name: PRAYER_NAMES.Asr, isPrayer: true },
      { key: "Maghrib", time: timings.Maghrib, name: PRAYER_NAMES.Maghrib, isPrayer: true },
      { key: "Isha", time: timings.Isha, name: PRAYER_NAMES.Isha, isPrayer: true },
      { key: "Midnight", time: timings.Midnight, name: PRAYER_NAMES.Midnight, isPrayer: false },
    ];

    const now = new Date();
    // تحويل الوقت الحالي إلى توقيت حلب (UTC+3)
    const aleppoNow = new Date(now.toLocaleString("en-US", { timeZone: "Asia/Damascus" }));
    const nextPrayer = orderedPrayers.find((p) => {
      if (!p.time) return false;
      const [h, m] = p.time.split(":").map(Number);
      const prayerDate = new Date(aleppoNow);
      prayerDate.setHours(h, m, 0, 0);
      return prayerDate > aleppoNow;
    });

    let timeUntilNext = "";
    if (nextPrayer) {
      const [h, m] = nextPrayer.time.split(":").map(Number);
      const next = new Date(aleppoNow);
      next.setHours(h, m, 0, 0);
      const diff = next.getTime() - now.getTime();
      const hours = Math.floor(diff / (1000 * 60 * 60));
      const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
      timeUntilNext = `${hours} س ${minutes} د`;
    }

    return NextResponse.json({
      success: true,
      data: {
        timings: orderedPrayers,
        nextPrayer,
        timeUntilNext,
        hijriDate: dateInfo.hijri
          ? `${dateInfo.hijri.day} ${dateInfo.hijri.month.ar} ${dateInfo.hijri.year} هـ`
          : "",
        gregorianDate: dateInfo.gregorian ? dateInfo.gregorian.date : "",
        timezone: meta?.timezone || "Asia/Damascus",
        city: USER_PROFILE.city,
      },
    });
  } catch (error) {
    console.error("Prayer times API error:", error);
    return NextResponse.json({
      success: false,
      error: "تعذر جلب مواقيت الصلاة",
      data: {
        timings: [
          { key: "Fajr", time: "05:30", name: "الفجر", isPrayer: true },
          { key: "Sunrise", time: "06:50", name: "الشروق", isPrayer: false },
          { key: "Dhuhr", time: "12:15", name: "الظهر", isPrayer: true },
          { key: "Asr", time: "15:30", name: "العصر", isPrayer: true },
          { key: "Maghrib", time: "17:45", name: "المغرب", isPrayer: true },
          { key: "Isha", time: "19:15", name: "العشاء", isPrayer: true },
        ],
        nextPrayer: null,
        timeUntilNext: "",
        hijriDate: "",
        gregorianDate: new Date().toLocaleDateString("ar-SY", { timeZone: "Asia/Damascus" }),
        timezone: "Asia/Damascus",
        city: USER_PROFILE.city,
      },
    });
  }
}

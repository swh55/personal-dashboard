import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// 4. اشتراكات المنزل
// GET: جلب كل الاشتراكات (أو النشطة فقط عبر ?active=true)
// POST: إنشاء اشتراك جديد
// PUT: تبديل حالة التفعيل (toggle active) أو تحديث الاشتراك
// DELETE: حذف اشتراك حسب المعرف

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const activeOnly = searchParams.get("active") === "true";

    const where: Record<string, unknown> = {};
    if (activeOnly) where.active = true;

    const subs = await db.subscription.findMany({
      where,
      orderBy: [{ active: "desc" }, { name: "asc" }],
    });

    return NextResponse.json({
      success: true,
      data: subs,
      stats: {
        count: subs.length,
        activeCount: subs.filter((s) => s.active).length,
        monthlyTotal: subs
          .filter((s) => s.active)
          .reduce((sum, s) => sum + s.cost, 0),
      },
    });
  } catch (error) {
    console.error("GET subscriptions error:", error);
    return NextResponse.json(
      { success: false, error: "فشل جلب الاشتراكات" },
      { status: 500 }
    );
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { name, cost, currency, billingCycle, nextBilling, active, note } = body;

    if (!name || cost === undefined) {
      return NextResponse.json(
        { success: false, error: "الاسم والتكلفة مطلوبان" },
        { status: 400 }
      );
    }

    const sub = await db.subscription.create({
      data: {
        name,
        cost: Number(cost),
        currency: currency || "syp",
        billingCycle: billingCycle || "monthly",
        nextBilling: nextBilling ? new Date(nextBilling) : null,
        active: active !== false,
        note: note || null,
      },
    });

    return NextResponse.json({ success: true, data: sub }, { status: 201 });
  } catch (error) {
    console.error("POST subscriptions error:", error);
    return NextResponse.json(
      { success: false, error: "فشل إضافة الاشتراك" },
      { status: 500 }
    );
  }
}

export async function PUT(req: NextRequest) {
  try {
    const body = await req.json();
    const { id, toggleActive, ...data } = body;

    if (!id) {
      return NextResponse.json(
        { success: false, error: "المعرف مطلوب" },
        { status: 400 }
      );
    }

    const existing = await db.subscription.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json(
        { success: false, error: "الاشتراك غير موجود" },
        { status: 404 }
      );
    }

    // تبديل حالة التفعيل عند الطلب
    if (toggleActive) {
      data.active = !existing.active;
    }

    if (data.cost !== undefined) data.cost = Number(data.cost);
    if (data.nextBilling) data.nextBilling = new Date(data.nextBilling);

    const sub = await db.subscription.update({ where: { id }, data });
    return NextResponse.json({ success: true, data: sub });
  } catch (error) {
    console.error("PUT subscriptions error:", error);
    return NextResponse.json(
      { success: false, error: "فشل تحديث الاشتراك" },
      { status: 500 }
    );
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");

    if (!id) {
      return NextResponse.json(
        { success: false, error: "المعرف مطلوب" },
        { status: 400 }
      );
    }

    await db.subscription.delete({ where: { id } });
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("DELETE subscriptions error:", error);
    return NextResponse.json(
      { success: false, error: "فشل حذف الاشتراك" },
      { status: 500 }
    );
  }
}

import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET() {
  try {
    const [tasks, notes, events, contacts, expenses] = await Promise.all([
      db.task.findMany({ where: { deletedAt: { not: null } }, orderBy: { deletedAt: "desc" } }),
      db.note.findMany({ where: { deletedAt: { not: null } }, orderBy: { deletedAt: "desc" } }),
      db.event.findMany({ where: { deletedAt: { not: null } }, orderBy: { deletedAt: "desc" } }),
      db.contact.findMany({ where: { deletedAt: { not: null } }, orderBy: { deletedAt: "desc" } }),
      db.expense.findMany({ where: { deletedAt: { not: null } }, orderBy: { deletedAt: "desc" } }),
    ]);

    return NextResponse.json({
      success: true,
      data: {
        tasks,
        notes,
        events,
        contacts,
        expenses,
        totalCount: tasks.length + notes.length + events.length + contacts.length + expenses.length,
      },
    });
  } catch (error) {
    console.error("GET recycle-bin error:", error);
    return NextResponse.json({ success: false, error: "فشل جلب سلة المحذوفات" }, { status: 500 });
  }
}

// استعادة أو حذف نهائي
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { type, id, action } = body; // action: "restore" | "force-delete"

    if (!type || !id || !action) {
      return NextResponse.json({ success: false, error: "النوع والمعرف والإجراء مطلوبة" }, { status: 400 });
    }

    const modelMap: Record<string, "task" | "note" | "event" | "contact" | "expense"> = {
      task: "task",
      note: "note",
      event: "event",
      contact: "contact",
      expense: "expense",
    };

    const model = modelMap[type];
    if (!model) {
      return NextResponse.json({ success: false, error: "نوع غير صالح" }, { status: 400 });
    }

    if (action === "restore") {
      await (db[model] as any).update({ where: { id }, data: { deletedAt: null } });
      return NextResponse.json({ success: true, message: "تمت الاستعادة" });
    } else if (action === "force-delete") {
      await (db[model] as any).delete({ where: { id } });
      return NextResponse.json({ success: true, message: "تم الحذف نهائياً" });
    }

    return NextResponse.json({ success: false, error: "إجراء غير صالح" }, { status: 400 });
  } catch (error) {
    console.error("POST recycle-bin error:", error);
    return NextResponse.json({ success: false, error: "فشلت العملية" }, { status: 500 });
  }
}

// إفراغ سلة المحذوفات
export async function DELETE() {
  try {
    await Promise.all([
      db.task.deleteMany({ where: { deletedAt: { not: null } } }),
      db.note.deleteMany({ where: { deletedAt: { not: null } } }),
      db.event.deleteMany({ where: { deletedAt: { not: null } } }),
      db.contact.deleteMany({ where: { deletedAt: { not: null } } }),
      db.expense.deleteMany({ where: { deletedAt: { not: null } } }),
    ]);
    return NextResponse.json({ success: true, message: "تم إفراغ سلة المحذوفات" });
  } catch (error) {
    console.error("DELETE recycle-bin error:", error);
    return NextResponse.json({ success: false, error: "فشل إفراغ السلة" }, { status: 500 });
  }
}

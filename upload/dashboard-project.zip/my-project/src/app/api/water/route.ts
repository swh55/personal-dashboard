import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// 5. سجل المياه اليومي
// POST: تسجيل أكواب ماء (إذا وُجد سجل لنفس اليوم يُضاف إليه)
// GET: إجمالي أكواب اليوم
// DELETE: حذف سجل حسب المعرف

function startOfToday(): Date {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  return d;
}

function endOfToday(): Date {
  const d = new Date();
  d.setHours(23, 59, 59, 999);
  return d;
}

const DAILY_GOAL = 8;

export async function GET() {
  try {
    const start = startOfToday();
    const end = endOfToday();

    const logs = await db.waterLog.findMany({
      where: { date: { gte: start, lte: end } },
      orderBy: { date: "desc" },
    });

    const total = logs.reduce((sum, l) => sum + l.glasses, 0);

    return NextResponse.json({
      success: true,
      data: logs,
      total,
      goal: DAILY_GOAL,
      percentage: Math.min(100, Math.round((total / DAILY_GOAL) * 100)),
      remaining: Math.max(0, DAILY_GOAL - total),
    });
  } catch (error) {
    console.error("GET water error:", error);
    return NextResponse.json(
      { success: false, error: "فشل جلب سجل المياه" },
      { status: 500 }
    );
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { glasses, date } = body;

    const count = Number(glasses) || 1;
    if (count <= 0) {
      return NextResponse.json(
        { success: false, error: "عدد الأكواب يجب أن يكون موجباً" },
        { status: 400 }
      );
    }

    // إن وُجد سجل لنفس اليوم نُضيف إليه، وإلا نُنشئ سجلاً جديداً
    const targetDate = date ? new Date(date) : new Date();
    const dayStart = new Date(targetDate);
    dayStart.setHours(0, 0, 0, 0);
    const dayEnd = new Date(targetDate);
    dayEnd.setHours(23, 59, 59, 999);

    const existing = await db.waterLog.findFirst({
      where: { date: { gte: dayStart, lte: dayEnd } },
    });

    let log;
    if (existing) {
      log = await db.waterLog.update({
        where: { id: existing.id },
        data: { glasses: { increment: count } },
      });
    } else {
      log = await db.waterLog.create({
        data: { glasses: count, date: targetDate },
      });
    }

    return NextResponse.json({ success: true, data: log }, { status: 201 });
  } catch (error) {
    console.error("POST water error:", error);
    return NextResponse.json(
      { success: false, error: "فشل تسجيل المياه" },
      { status: 500 }
    );
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");

    if (!id) {
      return NextResponse.json(
        { success: false, error: "المعرف مطلوب" },
        { status: 400 }
      );
    }

    await db.waterLog.delete({ where: { id } });
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("DELETE water error:", error);
    return NextResponse.json(
      { success: false, error: "فشل حذف السجل" },
      { status: 500 }
    );
  }
}

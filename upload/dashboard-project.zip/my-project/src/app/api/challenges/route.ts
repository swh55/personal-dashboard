import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// 9. التحديات الأسبوعية
// GET: تحدّي الأسبوع الحالي (يُنشئ واحدًا تلقائيًا إن لم يوجد)
// POST: زيادة التقدّم في التحدي الحالي

// الأسبوع يبدأ السبت وينتهي الجمعة
function getWeekRange(date = new Date()): { start: Date; end: Date } {
  const d = new Date(date);
  d.setHours(0, 0, 0, 0);
  const dayOfWeek = d.getDay(); // 0=الأحد ... 6=السبت
  const diffToSaturday = (dayOfWeek + 1) % 7; // 0 للسبت
  const start = new Date(d);
  start.setDate(d.getDate() - diffToSaturday);
  const end = new Date(start);
  end.setDate(start.getDate() + 6);
  end.setHours(23, 59, 59, 999);
  return { start, end };
}

// قائمة تحديات افتراضية تُستخدم عند الإنشاء التلقائي
const DEFAULT_CHALLENGES: {
  title: string;
  description: string;
  target: number;
}[] = [
  { title: "أكمل 20 مهمة هذا الأسبوع", description: "أنجز 20 مهمة على الأقل خلال الأسبوع", target: 20 },
  { title: "اشرب 56 كوب ماء", description: "8 أكواب يومياً × 7 أيام", target: 56 },
  { title: "سلسلة عادات 7 أيام", description: "أكمل عاداتك اليومية طوال الأسبوع", target: 7 },
  { title: "ساعة قراءة قرآن", description: "اقرأ القرآن ساعة كاملة هذا الأسبوع", target: 60 },
  { title: "وقوف نشط 56 مرة", description: "قف 8 مرات يومياً طوال الأسبوع", target: 56 },
];

export async function GET() {
  try {
    const { start, end } = getWeekRange();

    let challenges = await db.weeklyChallenge.findMany({
      where: { weekStart: start, weekEnd: end },
      orderBy: { createdAt: "asc" },
    });

    // إن لم يوجد تحدٍّ لهذا الأسبوع، أنشئ واحدًا تلقائيًا
    if (challenges.length === 0) {
      const pick =
        DEFAULT_CHALLENGES[
          Math.floor(Math.random() * DEFAULT_CHALLENGES.length)
        ];
      const created = await db.weeklyChallenge.create({
        data: {
          title: pick.title,
          description: pick.description,
          target: pick.target,
          progress: 0,
          weekStart: start,
          weekEnd: end,
          completed: false,
        },
      });
      challenges = [created];
    }

    return NextResponse.json({
      success: true,
      data: challenges,
      current: challenges[0] ?? null,
      weekStart: start.toISOString(),
      weekEnd: end.toISOString(),
      stats: {
        total: challenges.length,
        completed: challenges.filter((c) => c.completed).length,
        inProgress: challenges.filter((c) => !c.completed && c.progress > 0)
          .length,
      },
    });
  } catch (error) {
    console.error("GET challenges error:", error);
    return NextResponse.json(
      { success: false, error: "فشل جلب التحديات الأسبوعية" },
      { status: 500 }
    );
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { challengeId, increment, progress, setProgress } = body;

    // حدّد التحدي المستهدف: إما بالمعرف أو تحدي الأسبوع الحالي
    let challenge = challengeId
      ? await db.weeklyChallenge.findUnique({ where: { id: challengeId } })
      : null;

    if (!challenge) {
      const { start, end } = getWeekRange();
      const weekChallenges = await db.weeklyChallenge.findMany({
        where: { weekStart: start, weekEnd: end },
        orderBy: { createdAt: "asc" },
      });
      challenge = weekChallenges[0] ?? null;
    }

    if (!challenge) {
      return NextResponse.json(
        { success: false, error: "لا يوجد تحدٍّ حالي لهذا الأسبوع" },
        { status: 404 }
      );
    }

    // زيادة التقدّم
    let newProgress: number;
    if (setProgress !== undefined) {
      newProgress = Number(setProgress);
    } else if (progress !== undefined) {
      newProgress = Number(progress);
    } else {
      newProgress = challenge.progress + (Number(increment) || 1);
    }
    newProgress = Math.max(0, newProgress);

    const isCompleted = newProgress >= challenge.target;

    const updated = await db.weeklyChallenge.update({
      where: { id: challenge.id },
      data: { progress: newProgress, completed: isCompleted },
    });

    return NextResponse.json({
      success: true,
      data: updated,
      completed: isCompleted,
    });
  } catch (error) {
    console.error("POST challenge error:", error);
    return NextResponse.json(
      { success: false, error: "فشل تحديث التقدّم في التحدي" },
      { status: 500 }
    );
  }
}

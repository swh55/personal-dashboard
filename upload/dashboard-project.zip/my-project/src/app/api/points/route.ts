import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// 7. النقاط اليومية
// GET: نقاط اليوم + الإجمالي + المستوى
// POST: إضافة نقاط مع سبب (upsert حسب تاريخ اليوم)

function startOfToday(): Date {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  return d;
}

export async function GET() {
  try {
    const today = startOfToday();

    const todayRecord = await db.dailyPoints.findUnique({
      where: { date: today },
    });

    const all = await db.dailyPoints.findMany();
    const totalPoints = all.reduce((sum, d) => sum + d.points, 0);

    const level = Math.floor(totalPoints / 100) + 1;

    return NextResponse.json({
      success: true,
      today: {
        date: today.toISOString(),
        points: todayRecord?.points ?? 0,
        tasksDone: todayRecord?.tasksDone ?? 0,
        habitsDone: todayRecord?.habitsDone ?? 0,
      },
      total: {
        points: totalPoints,
        tasksDone: all.reduce((s, d) => s + d.tasksDone, 0),
        habitsDone: all.reduce((s, d) => s + d.habitsDone, 0),
        daysActive: all.length,
      },
      level,
    });
  } catch (error) {
    console.error("GET points error:", error);
    return NextResponse.json(
      { success: false, error: "فشل جلب النقاط" },
      { status: 500 }
    );
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { points, reason, tasksDone, habitsDone } = body;

    const pts = Number(points) || 0;
    if (pts === 0) {
      return NextResponse.json(
        { success: false, error: "النقاط مطلوبة" },
        { status: 400 }
      );
    }

    const today = startOfToday();

    // upsert حسب تاريخ اليوم
    const record = await db.dailyPoints.upsert({
      where: { date: today },
      update: {
        points: { increment: pts },
        tasksDone: { increment: Number(tasksDone) || 0 },
        habitsDone: { increment: Number(habitsDone) || 0 },
      },
      create: {
        date: today,
        points: pts,
        tasksDone: Number(tasksDone) || 0,
        habitsDone: Number(habitsDone) || 0,
      },
    });

    return NextResponse.json({
      success: true,
      data: record,
      reason: reason || null,
    }, { status: 201 });
  } catch (error) {
    console.error("POST points error:", error);
    return NextResponse.json(
      { success: false, error: "فشل إضافة النقاط" },
      { status: 500 }
    );
  }
}

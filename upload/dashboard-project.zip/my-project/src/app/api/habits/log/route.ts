import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// تسجيل/إلغاء تسجيل تنفيذ عادة في يوم معين
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { habitId, date, count, action } = body;

    if (!habitId || !date) {
      return NextResponse.json({ success: false, error: "العادة والتاريخ مطلوبان" }, { status: 400 });
    }

    const logDate = new Date(date);
    logDate.setHours(0, 0, 0, 0);

    if (action === "remove") {
      await db.habitLog.deleteMany({
        where: { habitId, date: logDate },
      });
      return NextResponse.json({ success: true, action: "removed" });
    }

    // upsert - تحديث أو إنشاء
    const existing = await db.habitLog.findUnique({
      where: { habitId_date: { habitId, date: logDate } },
    });

    if (existing) {
      const updated = await db.habitLog.update({
        where: { id: existing.id },
        data: { count: count || existing.count + 1 },
      });
      return NextResponse.json({ success: true, data: updated, action: "updated" });
    }

    const log = await db.habitLog.create({
      data: { habitId, date: logDate, count: count || 1 },
    });
    return NextResponse.json({ success: true, data: log, action: "created" }, { status: 201 });
  } catch (error) {
    console.error("POST habit log error:", error);
    return NextResponse.json({ success: false, error: "فشل تسجيل العادة" }, { status: 500 });
  }
}

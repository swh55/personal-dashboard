import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET() {
  try {
    const habits = await db.habit.findMany({
      orderBy: { createdAt: "desc" },
      include: { logs: { orderBy: { date: "desc" }, take: 60 } },
    });
    return NextResponse.json({ success: true, data: habits });
  } catch (error) {
    console.error("GET habits error:", error);
    return NextResponse.json({ success: false, error: "فشل جلب العادات" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { name, description, icon, color, frequency, target } = body;

    if (!name) {
      return NextResponse.json({ success: false, error: "الاسم مطلوب" }, { status: 400 });
    }

    const habit = await db.habit.create({
      data: {
        name,
        description: description || null,
        icon: icon || "CheckCircle",
        color: color || "emerald",
        frequency: frequency || "daily",
        target: target || 1,
      },
    });

    return NextResponse.json({ success: true, data: habit }, { status: 201 });
  } catch (error) {
    console.error("POST habit error:", error);
    return NextResponse.json({ success: false, error: "فشل إضافة العادة" }, { status: 500 });
  }
}

export async function PUT(req: NextRequest) {
  try {
    const body = await req.json();
    const { id, ...data } = body;
    if (!id) {
      return NextResponse.json({ success: false, error: "المعرف مطلوب" }, { status: 400 });
    }
    const habit = await db.habit.update({ where: { id }, data });
    return NextResponse.json({ success: true, data: habit });
  } catch (error) {
    console.error("PUT habit error:", error);
    return NextResponse.json({ success: false, error: "فشل تحديث العادة" }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    if (!id) {
      return NextResponse.json({ success: false, error: "المعرف مطلوب" }, { status: 400 });
    }
    await db.habit.delete({ where: { id } });
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("DELETE habit error:", error);
    return NextResponse.json({ success: false, error: "فشل حذف العادة" }, { status: 500 });
  }
}

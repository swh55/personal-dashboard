import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET() {
  try {
    const alerts = await db.priceAlert.findMany({ orderBy: { createdAt: "desc" } });
    return NextResponse.json({ success: true, data: alerts });
  } catch (error) {
    console.error("GET price-alerts error:", error);
    return NextResponse.json({ success: false, error: "فشل جلب التنبيهات" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const { item, targetPrice, direction } = await req.json();
    if (!item || !targetPrice) return NextResponse.json({ success: false, error: "العنصر والسعر المستهدف مطلوبان" }, { status: 400 });
    const alert = await db.priceAlert.create({ data: { item, targetPrice: Number(targetPrice), direction: direction || "above" } });
    return NextResponse.json({ success: true, data: alert }, { status: 201 });
  } catch (error) {
    console.error("POST price-alert error:", error);
    return NextResponse.json({ success: false, error: "فشل إضافة التنبيه" }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    if (!id) return NextResponse.json({ success: false, error: "المعرف مطلوب" }, { status: 400 });
    await db.priceAlert.delete({ where: { id } });
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("DELETE price-alert error:", error);
    return NextResponse.json({ success: false, error: "فشل الحذف" }, { status: 500 });
  }
}

import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { logActivity } from "@/lib/activity";

// GET: returns all tracked routes
export async function GET(req: NextRequest) {
  try {
    const searchParams = req.nextUrl.searchParams;
    const activeOnly = searchParams.get("active") === "true";

    const where: Record<string, unknown> = {};
    if (activeOnly) {
      where.endTime = null;
    }

    const routes = await db.trackRoute.findMany({
      where,
      orderBy: { startTime: "desc" },
    });

    return NextResponse.json({
      success: true,
      data: routes,
      meta: {
        count: routes.length,
        active: routes.filter((r) => !r.endTime).length,
      },
    });
  } catch (error) {
    console.error("GET routes error:", error);
    return NextResponse.json(
      { success: false, error: "فشل جلب المسارات" },
      { status: 500 }
    );
  }
}

// POST: create a new tracked route
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const {
      name,
      startPoint,
      endPoint,
      startLat,
      startLng,
      endLat,
      endLng,
      distance,
      duration,
      startTime,
      endTime,
    } = body;

    if (!name || !startPoint) {
      return NextResponse.json(
        { success: false, error: "الاسم ونقطة البداية مطلوبة" },
        { status: 400 }
      );
    }

    const route = await db.trackRoute.create({
      data: {
        name,
        startPoint,
        endPoint: endPoint || null,
        startLat: startLat !== undefined && startLat !== null ? Number(startLat) : null,
        startLng: startLng !== undefined && startLng !== null ? Number(startLng) : null,
        endLat: endLat !== undefined && endLat !== null ? Number(endLat) : null,
        endLng: endLng !== undefined && endLng !== null ? Number(endLng) : null,
        distance: distance !== undefined && distance !== null ? Number(distance) : null,
        duration: duration !== undefined && duration !== null ? Number(duration) : null,
        startTime: startTime ? new Date(startTime) : new Date(),
        endTime: endTime ? new Date(endTime) : null,
      },
    });

    await logActivity(
      "create",
      "track_route",
      `تمت إضافة مسار: ${name} (${startPoint}${
        endPoint ? ` → ${endPoint}` : ""
      })`
    );
    return NextResponse.json({ success: true, data: route }, { status: 201 });
  } catch (error) {
    console.error("POST route error:", error);
    return NextResponse.json(
      { success: false, error: "فشل إنشاء المسار" },
      { status: 500 }
    );
  }
}

// PUT: update a route (primarily endTime to mark completion, but also other fields)
export async function PUT(req: NextRequest) {
  try {
    const body = await req.json();
    const {
      id,
      endTime,
      endPoint,
      endLat,
      endLng,
      distance,
      duration,
      ...rest
    } = body;

    if (!id) {
      return NextResponse.json(
        { success: false, error: "المعرف مطلوب" },
        { status: 400 }
      );
    }

    const data: Record<string, unknown> = { ...rest };
    if (endPoint !== undefined) data.endPoint = endPoint;
    if (endLat !== undefined && endLat !== null) data.endLat = Number(endLat);
    if (endLng !== undefined && endLng !== null) data.endLng = Number(endLng);
    if (distance !== undefined && distance !== null) data.distance = Number(distance);
    if (duration !== undefined && duration !== null) data.duration = Number(duration);
    if (endTime !== undefined) {
      data.endTime = endTime ? new Date(endTime) : null;
    }

    // When endTime is set, compute duration in minutes if not provided
    if (endTime && data.duration === undefined) {
      const existing = await db.trackRoute.findUnique({ where: { id } });
      if (existing?.startTime) {
        const end = new Date(endTime);
        const diffMs = end.getTime() - new Date(existing.startTime).getTime();
        if (diffMs > 0) {
          data.duration = Math.round(diffMs / (1000 * 60));
        }
      }
    }

    const updated = await db.trackRoute.update({
      where: { id },
      data,
    });

    if (endTime) {
      await logActivity(
        "update",
        "track_route",
        `تم إنهاء مسار: ${updated.name}`
      );
    } else {
      await logActivity(
        "update",
        "track_route",
        `تم تحديث مسار: ${updated.name}`
      );
    }

    return NextResponse.json({ success: true, data: updated });
  } catch (error) {
    console.error("PUT route error:", error);
    return NextResponse.json(
      { success: false, error: "فشل تحديث المسار" },
      { status: 500 }
    );
  }
}

// DELETE: remove a tracked route by id
export async function DELETE(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    if (!id) {
      return NextResponse.json(
        { success: false, error: "المعرف مطلوب" },
        { status: 400 }
      );
    }

    const route = await db.trackRoute.delete({ where: { id } });
    await logActivity("delete", "track_route", `تم حذف مسار: ${route.name}`);
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("DELETE route error:", error);
    return NextResponse.json(
      { success: false, error: "فشل حذف المسار" },
      { status: 500 }
    );
  }
}

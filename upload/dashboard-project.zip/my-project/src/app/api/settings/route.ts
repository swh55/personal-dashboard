import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// إعدادات قابلة للتخزين في قاعدة البيانات
const DEFAULT_SETTINGS: Record<string, string> = {
  pinEnabled: "false",
  pinCode: "",
  autoNightMode: "false",
  notificationsEnabled: "true",
  weekStartDay: "6", // السبت
  currency: "syp",
  language: "ar",
};

export async function GET() {
  try {
    const settings = await db.setting.findMany();
    const settingsMap: Record<string, string> = { ...DEFAULT_SETTINGS };
    for (const s of settings) {
      settingsMap[s.key] = s.value;
    }
    return NextResponse.json({ success: true, data: settingsMap });
  } catch (error) {
    console.error("GET settings error:", error);
    return NextResponse.json({ success: false, error: "فشل جلب الإعدادات" }, { status: 500 });
  }
}

export async function PUT(req: NextRequest) {
  try {
    const body = await req.json();
    const { key, value } = body;

    if (!key || value === undefined) {
      return NextResponse.json({ success: false, error: "المفتاح والقيمة مطلوبان" }, { status: 400 });
    }

    await db.setting.upsert({
      where: { key },
      update: { value: String(value) },
      create: { key, value: String(value) },
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("PUT settings error:", error);
    return NextResponse.json({ success: false, error: "فشل تحديث الإعدادات" }, { status: 500 });
  }
}

import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// حفظ/قراءة بيانات اعتماد Google OAuth من قاعدة البيانات
export async function GET() {
  try {
    const settings = await db.setting.findMany({
      where: {
        key: {
          in: ["google_client_id", "google_client_secret", "google_redirect_uri", "nextauth_secret"],
        },
      },
    });

    const config: Record<string, string> = {
      google_client_id: "",
      google_client_secret: "",
      google_redirect_uri: "",
      nextauth_secret: "",
    };

    for (const s of settings) {
      config[s.key] = s.value;
    }

    // إخفاء السر عند الإرسال (نظهر أول 4 أحرف فقط)
    const masked = {
      google_client_id: config.google_client_id,
      google_client_secret: config.google_client_secret
        ? "•".repeat(config.google_client_secret.length - 4) + config.google_client_secret.slice(-4)
        : "",
      google_redirect_uri: config.google_redirect_uri,
      nextauth_secret: config.nextauth_secret
        ? "•".repeat(Math.max(config.nextauth_secret.length - 4, 0)) + config.nextauth_secret.slice(-4)
        : "",
      is_configured: !!(config.google_client_id && config.google_client_secret),
    };

    return NextResponse.json({ success: true, data: masked });
  } catch (error) {
    console.error("GET google settings error:", error);
    return NextResponse.json({ success: false, error: "فشل جلب الإعدادات" }, { status: 500 });
  }
}

export async function PUT(req: NextRequest) {
  try {
    const body = await req.json();
    const { google_client_id, google_client_secret, google_redirect_uri, nextauth_secret } = body;

    const updates: Array<{ key: string; value: string }> = [];

    if (google_client_id !== undefined) {
      updates.push({ key: "google_client_id", value: google_client_id });
    }
    // للسر: فقط حدّث إذا لم يكن كله نقاط (أي المستخدم أدخل قيمة جديدة)
    if (google_client_secret !== undefined && !google_client_secret.startsWith("•")) {
      updates.push({ key: "google_client_secret", value: google_client_secret });
    }
    if (google_redirect_uri !== undefined) {
      updates.push({ key: "google_redirect_uri", value: google_redirect_uri });
    }
    if (nextauth_secret !== undefined && !nextauth_secret.startsWith("•")) {
      updates.push({ key: "nextauth_secret", value: nextauth_secret });
    }

    for (const item of updates) {
      await db.setting.upsert({
        where: { key: item.key },
        update: { value: item.value },
        create: { key: item.key, value: item.value },
      });
    }

    // أيضاً ضعها في process.env للاستخدام الفوري في نفس الجلسة
    if (google_client_id) process.env.GOOGLE_CLIENT_ID = google_client_id;
    if (google_client_secret && !google_client_secret.startsWith("•")) process.env.GOOGLE_CLIENT_SECRET = google_client_secret;
    if (google_redirect_uri) process.env.GOOGLE_REDIRECT_URI = google_redirect_uri;
    if (nextauth_secret && !nextauth_secret.startsWith("•")) process.env.NEXTAUTH_SECRET = nextauth_secret;

    return NextResponse.json({ success: true, message: "تم حفظ بيانات Google" });
  } catch (error) {
    console.error("PUT google settings error:", error);
    return NextResponse.json({ success: false, error: "فشل حفظ الإعدادات" }, { status: 500 });
  }
}

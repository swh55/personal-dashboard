import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { logActivity } from "@/lib/activity";

// GET: returns unsent scheduled messages (optionally filtered to those due now)
export async function GET(req: NextRequest) {
  try {
    const searchParams = req.nextUrl.searchParams;
    const includeSent = searchParams.get("includeSent") === "true";
    const dueOnly = searchParams.get("due") === "true";

    const where: Record<string, unknown> = {};
    if (!includeSent) {
      where.sent = false;
    }
    if (dueOnly) {
      where.scheduledAt = { lte: new Date() };
    }

    const messages = await db.scheduledMessage.findMany({
      where,
      orderBy: { scheduledAt: "asc" },
    });

    return NextResponse.json({
      success: true,
      data: messages,
      meta: { count: messages.length },
    });
  } catch (error) {
    console.error("GET scheduled-messages error:", error);
    return NextResponse.json(
      { success: false, error: "فشل جلب الرسائل المجدولة" },
      { status: 500 }
    );
  }
}

// POST: create a new scheduled message
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { contactName, phone, message, type, scheduledAt } = body;

    if (!contactName || !phone || !message || !scheduledAt) {
      return NextResponse.json(
        {
          success: false,
          error: "الاسم والرقم والرسالة ووقت الإرسال مطلوبة",
        },
        { status: 400 }
      );
    }

    const scheduledDate = new Date(scheduledAt);
    if (isNaN(scheduledDate.getTime())) {
      return NextResponse.json(
        { success: false, error: "وقت الإرسال غير صالح" },
        { status: 400 }
      );
    }

    const scheduledMessage = await db.scheduledMessage.create({
      data: {
        contactName,
        phone,
        message,
        type: type || "whatsapp",
        scheduledAt: scheduledDate,
        sent: false,
      },
    });

    await logActivity(
      "create",
      "scheduled_message",
      `تمت جدولة رسالة إلى ${contactName} (${phone})`
    );
    return NextResponse.json(
      { success: true, data: scheduledMessage },
      { status: 201 }
    );
  } catch (error) {
    console.error("POST scheduled-message error:", error);
    return NextResponse.json(
      { success: false, error: "فشل إنشاء الرسالة المجدولة" },
      { status: 500 }
    );
  }
}

// PUT: mark a scheduled message as sent (or update fields)
export async function PUT(req: NextRequest) {
  try {
    const body = await req.json();
    const { id, sent, ...rest } = body;

    if (!id) {
      return NextResponse.json(
        { success: false, error: "المعرف مطلوب" },
        { status: 400 }
      );
    }

    const data: Record<string, unknown> = { ...rest };
    if (sent !== undefined) {
      data.sent = Boolean(sent);
    }
    if (rest.scheduledAt) {
      data.scheduledAt = new Date(rest.scheduledAt);
    }

    const updated = await db.scheduledMessage.update({
      where: { id },
      data,
    });

    if (sent === true) {
      await logActivity(
        "update",
        "scheduled_message",
        `تم إرسال رسالة مجدولة إلى ${updated.contactName}`
      );
    }

    return NextResponse.json({ success: true, data: updated });
  } catch (error) {
    console.error("PUT scheduled-message error:", error);
    return NextResponse.json(
      { success: false, error: "فشل تحديث الرسالة المجدولة" },
      { status: 500 }
    );
  }
}

// DELETE: remove a scheduled message by id
export async function DELETE(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    if (!id) {
      return NextResponse.json(
        { success: false, error: "المعرف مطلوب" },
        { status: 400 }
      );
    }

    await db.scheduledMessage.delete({ where: { id } });
    await logActivity(
      "delete",
      "scheduled_message",
      "تم حذف رسالة مجدولة"
    );
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("DELETE scheduled-message error:", error);
    return NextResponse.json(
      { success: false, error: "فشل حذف الرسالة المجدولة" },
      { status: 500 }
    );
  }
}

import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const format = searchParams.get("format") || "json"; // json, csv
    const type = searchParams.get("type") || "all"; // all, tasks, contacts, events, notes, expenses, occasions

    const data: Record<string, unknown> = {};

    if (type === "all" || type === "tasks") data.tasks = await db.task.findMany();
    if (type === "all" || type === "contacts") data.contacts = await db.contact.findMany();
    if (type === "all" || type === "events") data.events = await db.event.findMany();
    if (type === "all" || type === "notes") data.notes = await db.note.findMany();
    if (type === "all" || type === "expenses") data.expenses = await db.expense.findMany();
    if (type === "all" || type === "occasions") data.occasions = await db.occasion.findMany();
    if (type === "all" || type === "habits") data.habits = await db.habit.findMany({ include: { logs: true } });
    if (type === "all" || type === "assets") data.assets = await db.asset.findMany();
    if (type === "all" || type === "accounts") data.accounts = await db.account.findMany();

    if (format === "csv") {
      // تصدير CSV (مهام فقط للبساطة، أو كل جدول على حدة)
      if (type === "tasks" || type === "all") {
        const csv = convertTasksToCSV(data.tasks as Record<string, unknown>[]);
        return new NextResponse(csv, {
          headers: {
            "Content-Type": "text/csv; charset=utf-8",
            "Content-Disposition": `attachment; filename="tasks-${new Date().toISOString().split("T")[0]}.csv"`,
          },
        });
      }
      // افتراضي: JSON
    }

    const json = JSON.stringify(data, null, 2);
    return new NextResponse(json, {
      headers: {
        "Content-Type": "application/json; charset=utf-8",
        "Content-Disposition": `attachment; filename="dashboard-export-${new Date().toISOString().split("T")[0]}.json"`,
      },
    });
  } catch (error) {
    console.error("Export error:", error);
    return NextResponse.json({ success: false, error: "فشل التصدير" }, { status: 500 });
  }
}

function convertTasksToCSV(tasks: Record<string, unknown>[]): string {
  if (!tasks || tasks.length === 0) return "لا بيانات";
  const headers = ["العنوان", "الفئة", "الحالة", "الأولوية", "الوصف", "تاريخ الاستحقاق", "تاريخ الإنشاء"];
  const rows = tasks.map((t) => [
    t.title as string,
    t.category as string,
    t.status as string,
    t.priority as string,
    (t.description as string) || "",
    t.dueDate ? new Date(t.dueDate as string).toLocaleDateString("ar-SY") : "",
    new Date(t.createdAt as string).toLocaleDateString("ar-SY"),
  ]);
  return [headers, ...rows].map((r) => r.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(",")).join("\n");
}

import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { logActivity } from "@/lib/activity";

// تسجيل إجراء اختصار سريع
export async function POST(req: NextRequest) {
  try {
    const { shortcutId, label } = await req.json();
    if (!shortcutId || !label) {
      return NextResponse.json({ success: false, error: "المعرف والعنوان مطلوبان" }, { status: 400 });
    }

    const log = await db.shortcutLog.create({
      data: { shortcutId, label },
    });

    await logActivity("create", "shortcut", label);

    return NextResponse.json({ success: true, data: log }, { status: 201 });
  } catch (error) {
    console.error("POST shortcut-log error:", error);
    return NextResponse.json({ success: false, error: "فشل التسجيل" }, { status: 500 });
  }
}

// جلب سجلات اليوم
export async function GET() {
  try {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const logs = await db.shortcutLog.findMany({
      where: { createdAt: { gte: today } },
      orderBy: { createdAt: "desc" },
    });

    // إرجاع set من shortcutIds المنجزة اليوم
    const completedToday = new Set(logs.map((l) => l.shortcutId));

    return NextResponse.json({ success: true, data: { logs, completedToday: Array.from(completedToday) } });
  } catch (error) {
    console.error("GET shortcut-log error:", error);
    return NextResponse.json({ success: false, error: "فشل جلب السجل" }, { status: 500 });
  }
}

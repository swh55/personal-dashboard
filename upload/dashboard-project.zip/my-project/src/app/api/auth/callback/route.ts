import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// Google OAuth Callback — يستقبل رمز التفويض من Google
async function getGoogleConfig() {
  const settings = await db.setting.findMany({
    where: { key: { in: ["google_client_id", "google_client_secret", "google_redirect_uri"] } },
  });
  const dbConfig: Record<string, string> = {};
  for (const s of settings) dbConfig[s.key] = s.value;

  return {
    clientId: dbConfig.google_client_id || process.env.GOOGLE_CLIENT_ID || "",
    clientSecret: dbConfig.google_client_secret || process.env.GOOGLE_CLIENT_SECRET || "",
    redirectUri: dbConfig.google_redirect_uri || process.env.GOOGLE_REDIRECT_URI ||
      `${process.env.NEXT_PUBLIC_URL || "http://localhost:3000"}/api/auth/callback`,
  };
}

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const code = searchParams.get("code");
  const error = searchParams.get("error");

  if (error) return NextResponse.redirect(new URL("/?auth_error=" + error, req.url));
  if (!code) return NextResponse.redirect(new URL("/?auth_error=no_code", req.url));

  const { clientId, clientSecret, redirectUri } = await getGoogleConfig();

  if (!clientId || !clientSecret) {
    return NextResponse.redirect(new URL("/?auth_error=not_configured", req.url));
  }

  try {
    const tokenRes = await fetch("https://oauth2.googleapis.com/token", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        code, client_id: clientId, client_secret: clientSecret,
        redirect_uri: redirectUri, grant_type: "authorization_code",
      }),
    });

    if (!tokenRes.ok) {
      return NextResponse.redirect(new URL("/?auth_error=token_failed", req.url));
    }

    const tokens = await tokenRes.json();

    // جلب معلومات المستخدم
    const userRes = await fetch("https://www.googleapis.com/oauth2/v2/userinfo", {
      headers: { Authorization: `Bearer ${tokens.access_token}` },
    });
    const user = await userRes.json();

    // حفظ التكامل
    const services = [
      { service: "google_calendar", name: "Google Calendar" },
      { service: "google_drive", name: "Google Drive" },
      { service: "google_contacts", name: "Google Contacts" },
    ];

    for (const svc of services) {
      await db.integration.upsert({
        where: { service: svc.service },
        update: {
          connected: true,
          config: JSON.stringify({
            access_token: tokens.access_token,
            refresh_token: tokens.refresh_token,
            expires_at: tokens.expires_in ? Date.now() + tokens.expires_in * 1000 : null,
            user_email: user.email,
          }),
          lastSync: new Date(),
        },
        create: {
          service: svc.service, name: svc.name, connected: true,
          config: JSON.stringify({
            access_token: tokens.access_token,
            refresh_token: tokens.refresh_token,
            expires_at: tokens.expires_in ? Date.now() + tokens.expires_in * 1000 : null,
            user_email: user.email,
          }),
          lastSync: new Date(),
        },
      });
    }

    return NextResponse.redirect(new URL("/?auth_success=true", req.url));
  } catch (error) {
    console.error("OAuth callback error:", error);
    return NextResponse.redirect(new URL("/?auth_error=exception", req.url));
  }
}

import { NextResponse } from "next/server";
import { db } from "@/lib/db";

// Google OAuth — بدء عملية المصادقة
// يقرأ بيانات الاعتماد من قاعدة البيانات (الإعدادات) أولاً، ثم من متغيرات البيئة

const SCOPES = [
  "https://www.googleapis.com/auth/calendar",
  "https://www.googleapis.com/auth/drive.file",
  "https://www.googleapis.com/auth/contacts.readonly",
  "https://www.googleapis.com/auth/userinfo.email",
  "https://www.googleapis.com/auth/userinfo.profile",
].join(" ");

async function getGoogleConfig() {
  // اقرأ من قاعدة البيانات أولاً
  const settings = await db.setting.findMany({
    where: { key: { in: ["google_client_id", "google_client_secret", "google_redirect_uri"] } },
  });
  const dbConfig: Record<string, string> = {};
  for (const s of settings) dbConfig[s.key] = s.value;

  return {
    clientId: dbConfig.google_client_id || process.env.GOOGLE_CLIENT_ID || "",
    clientSecret: dbConfig.google_client_secret || process.env.GOOGLE_CLIENT_SECRET || "",
    redirectUri: dbConfig.google_redirect_uri || process.env.GOOGLE_REDIRECT_URI ||
      `${process.env.NEXT_PUBLIC_URL || "http://localhost:3000"}/api/auth/callback`,
  };
}

export async function GET() {
  const { clientId, redirectUri } = await getGoogleConfig();

  if (!clientId) {
    return NextResponse.json({
      success: false,
      error: "Google OAuth غير مُعد",
      instructions: "اذهب إلى الإعدادات → تكامل Google وأدخل بيانات الاعتماد",
    }, { status: 500 });
  }

  const authUrl = new URL("https://accounts.google.com/o/oauth2/v2/auth");
  authUrl.searchParams.set("client_id", clientId);
  authUrl.searchParams.set("redirect_uri", redirectUri);
  authUrl.searchParams.set("response_type", "code");
  authUrl.searchParams.set("scope", SCOPES);
  authUrl.searchParams.set("access_type", "offline");
  authUrl.searchParams.set("prompt", "consent");

  return NextResponse.redirect(authUrl.toString());
}

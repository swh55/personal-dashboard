import { NextResponse } from "next/server";
import { db } from "@/lib/db";

// 12. بيانات التحفيز المجمّعة
// GET فقط: يُرجع بيانات التحفيز المجمّعة (نقاط + شارات + تحدٍّ + سلسلة + رسالة تحفيزية)

const MOTIVATIONAL_MESSAGES = [
  "أحسنت! استمر في التقدم 🌟",
  "كل خطوة صغيرة تقربك من هدفك 💪",
  "الإتقان في العمل عبادة 🤲",
  "أنت تتحسن كل يوم 📈",
  "النجاح هو مجموع الجهود الصغيرة المتكررة ✨",
];

function startOfToday(): Date {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  return d;
}

// الأسبوع يبدأ السبت وينتهي الجمعة
function getWeekRange(date = new Date()): { start: Date; end: Date } {
  const d = new Date(date);
  d.setHours(0, 0, 0, 0);
  const dayOfWeek = d.getDay();
  const diffToSaturday = (dayOfWeek + 1) % 7;
  const start = new Date(d);
  start.setDate(d.getDate() - diffToSaturday);
  const end = new Date(start);
  end.setDate(start.getDate() + 6);
  end.setHours(23, 59, 59, 999);
  return { start, end };
}

export async function GET() {
  try {
    const today = startOfToday();

    // === النقاط ===
    const todayRecord = await db.dailyPoints.findUnique({
      where: { date: today },
    });
    const allPoints = await db.dailyPoints.findMany();
    const totalPoints = allPoints.reduce((s, d) => s + d.points, 0);
    const todayPoints = todayRecord?.points ?? 0;

    // المستوى = Math.floor(totalPoints / 100) + 1
    const level = Math.floor(totalPoints / 100) + 1;

    // === السلسلة (streak) ===
    let streak = 0;
    const dayMs = 24 * 60 * 60 * 1000;
    for (let i = 0; i < 365; i++) {
      const d = new Date(today.getTime() - i * dayMs);
      const rec = await db.dailyPoints.findUnique({ where: { date: d } });
      if (rec && rec.points > 0) {
        streak++;
      } else {
        // اسمح بيوم اليوم دون كسر السلسلة إذا لم يُسجّل بعد
        if (i === 0) continue;
        break;
      }
    }

    // === الشارات ===
    const unlockedAchievements = await db.achievement.findMany();
    const unlockedCount = unlockedAchievements.length;
    // مجموع الشارات الممكنة (كتالوج ثابت)
    const totalAchievements = 20;

    // === التحدي الحالي ===
    const { start, end } = getWeekRange();
    const weekChallenges = await db.weeklyChallenge.findMany({
      where: { weekStart: start, weekEnd: end },
      orderBy: { createdAt: "asc" },
    });
    const currentChallenge = weekChallenges[0] ?? null;

    // === الرسالة التحفيزية (عشوائية) ===
    const motivationalMessage =
      MOTIVATIONAL_MESSAGES[
        Math.floor(Math.random() * MOTIVATIONAL_MESSAGES.length)
      ];

    return NextResponse.json({
      success: true,
      points: {
        today: todayPoints,
        total: totalPoints,
        level,
      },
      achievements: {
        unlocked: unlockedCount,
        total: totalAchievements,
      },
      challenge: {
        current: currentChallenge,
      },
      streak,
      motivationalMessage,
    });
  } catch (error) {
    console.error("GET gamification error:", error);
    return NextResponse.json(
      { success: false, error: "فشل جلب بيانات التحفيز" },
      { status: 500 }
    );
  }
}

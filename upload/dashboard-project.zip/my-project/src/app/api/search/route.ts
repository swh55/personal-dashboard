import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const q = searchParams.get("q")?.trim();

    if (!q || q.length < 2) {
      return NextResponse.json({ success: true, data: { tasks: [], contacts: [], notes: [], events: [], occasions: [], expenses: [] } });
    }

    // البحث في المهام
    const tasks = await db.task.findMany({
      where: {
        OR: [
          { title: { contains: q } },
          { description: { contains: q } },
        ],
      },
      take: 5,
      orderBy: { createdAt: "desc" },
    });

    // البحث في جهات الاتصال
    const contacts = await db.contact.findMany({
      where: {
        OR: [
          { name: { contains: q } },
          { phone: { contains: q } },
          { email: { contains: q } },
          { note: { contains: q } },
        ],
      },
      take: 5,
    });

    // البحث في الملاحظات
    const notes = await db.note.findMany({
      where: {
        OR: [
          { title: { contains: q } },
          { content: { contains: q } },
        ],
      },
      take: 5,
      orderBy: { updatedAt: "desc" },
    });

    // البحث في الأحداث
    const events = await db.event.findMany({
      where: {
        OR: [
          { title: { contains: q } },
          { description: { contains: q } },
          { location: { contains: q } },
        ],
      },
      take: 5,
      orderBy: { startDate: "desc" },
    });

    // البحث في المناسبات
    const occasions = await db.occasion.findMany({
      where: {
        OR: [
          { title: { contains: q } },
          { note: { contains: q } },
        ],
      },
      take: 5,
    });

    // البحث في المصروفات
    const expenses = await db.expense.findMany({
      where: {
        OR: [
          { description: { contains: q } },
          { category: { contains: q } },
        ],
      },
      take: 5,
      orderBy: { date: "desc" },
    });

    return NextResponse.json({
      success: true,
      data: { tasks, contacts, notes, events, occasions, expenses },
    });
  } catch (error) {
    console.error("Search error:", error);
    return NextResponse.json({ success: false, error: "فشل البحث" }, { status: 500 });
  }
}

"use client";

import * as React from "react";
import { ThemeProvider as NextThemesProvider, useTheme } from "next-themes";

function AutoNightModeHandler() {
  const { theme, setTheme } = useTheme();
  const [autoEnabled, setAutoEnabled] = React.useState(false);
  const [userPreference, setUserPreference] = React.useState<string | null>(null);

  // قراءة إعداد الوضع الليلي التلقائي
  React.useEffect(() => {
    fetch("/api/settings")
      .then((r) => r.json())
      .then((json) => {
        if (json.success && json.data?.autoNightMode === "true") {
          setAutoEnabled(true);
        }
      })
      .catch(() => {});
  }, []);

  // تطبيق الوضع الليلي التلقائي حسب الوقت
  React.useEffect(() => {
    if (!autoEnabled) return;

    const checkTime = () => {
      const hour = new Date().getHours();
      const shouldDark = hour >= 20 || hour < 6; // 8م - 6ص

      if (shouldDark && theme !== "dark") {
        setUserPreference(theme);
        setTheme("dark");
      } else if (!shouldDark && theme === "dark" && userPreference === null) {
        setTheme("light");
      }
    };

    checkTime();
    const interval = setInterval(checkTime, 60000); // كل دقيقة
    return () => clearInterval(interval);
  }, [autoEnabled, theme, setTheme, userPreference]);

  return null;
}

export function ThemeProvider({
  children,
  ...props
}: React.ComponentProps<typeof NextThemesProvider>) {
  return (
    <NextThemesProvider {...props}>
      <AutoNightModeHandler />
      {children}
    </NextThemesProvider>
  );
}

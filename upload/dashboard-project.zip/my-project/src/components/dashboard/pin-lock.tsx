"use client";

import * as React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { DynamicIcon } from "./icon";
import { cn } from "@/lib/utils";

export function PinLockScreen({ pinCode, onUnlock }: { pinCode: string; onUnlock: () => void }) {
  const [pin, setPin] = React.useState("");
  const [error, setError] = React.useState(false);
  const [shake, setShake] = React.useState(false);

  const handleSubmit = (value: string) => {
    if (value.length === 4) {
      if (value === pinCode) {
        onUnlock();
      } else {
        setError(true);
        setShake(true);
        setTimeout(() => {
          setPin("");
          setError(false);
          setShake(false);
        }, 800);
      }
    }
  };

  const handleKey = (key: string) => {
    if (pin.length < 4) {
      const newPin = pin + key;
      setPin(newPin);
      setError(false);
      if (newPin.length === 4) {
        setTimeout(() => handleSubmit(newPin), 150);
      }
    }
  };

  const handleBackspace = () => {
    setPin((p) => p.slice(0, -1));
    setError(false);
  };

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center bg-background aurora-bg">
      <div className="pointer-events-none absolute inset-0 grid-pattern opacity-40" />

      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="relative w-full max-w-xs px-6"
      >
        {/* Logo */}
        <div className="flex flex-col items-center mb-8">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: "spring", stiffness: 200, delay: 0.1 }}
            className="relative mb-4"
          >
            <div className="absolute inset-0 rounded-2xl bg-emerald-glow/30 blur-lg" />
            <div className="relative flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-emerald-glow to-amber-glow text-background">
              <DynamicIcon name="Shield" className="h-8 w-8" />
            </div>
          </motion.div>
          <h1 className="text-lg font-bold text-foreground">لوحة التحكم مقفلة</h1>
          <p className="text-xs text-muted-foreground mt-1">أدخل الرمز للمتابعة</p>
        </div>

        {/* PIN dots */}
        <motion.div
          animate={shake ? { x: [-10, 10, -10, 10, 0] } : {}}
          transition={{ duration: 0.4 }}
          className="flex justify-center gap-3 mb-6"
        >
          {[0, 1, 2, 3].map((i) => (
            <motion.div
              key={i}
              animate={{
                scale: pin.length > i ? 1 : 0.8,
                backgroundColor: error
                  ? "rgba(244, 63, 94, 0.3)"
                  : pin.length > i
                  ? "rgba(16, 185, 129, 0.4)"
                  : "rgba(255,255,255,0.1)",
              }}
              className={cn(
                "h-4 w-4 rounded-full border-2",
                error ? "border-rose-400" : pin.length > i ? "border-emerald-glow" : "border-border"
              )}
            />
          ))}
        </motion.div>

        {/* Number pad */}
        <div className="grid grid-cols-3 gap-3">
          {["1", "2", "3", "4", "5", "6", "7", "8", "9"].map((key) => (
            <motion.button
              key={key}
              whileTap={{ scale: 0.92 }}
              onClick={() => handleKey(key)}
              className="aspect-square rounded-2xl glass border border-border/40 hover:border-emerald-glow/30 transition-all flex items-center justify-center"
            >
              <span className="text-2xl font-bold text-foreground">{key}</span>
            </motion.button>
          ))}
          <div />
          <motion.button
            whileTap={{ scale: 0.92 }}
            onClick={() => handleKey("0")}
            className="aspect-square rounded-2xl glass border border-border/40 hover:border-emerald-glow/30 transition-all flex items-center justify-center"
          >
            <span className="text-2xl font-bold text-foreground">0</span>
          </motion.button>
          <motion.button
            whileTap={{ scale: 0.92 }}
            onClick={handleBackspace}
            className="aspect-square rounded-2xl glass border border-border/40 hover:border-rose-500/30 transition-all flex items-center justify-center text-muted-foreground"
          >
            <DynamicIcon name="ChevronRight" className="h-6 w-6" />
          </motion.button>
        </div>

        {error && (
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center text-xs text-rose-400 mt-4"
          >
            رمز خاطئ، حاول مرة أخرى
          </motion.p>
        )}
      </motion.div>
    </div>
  );
}

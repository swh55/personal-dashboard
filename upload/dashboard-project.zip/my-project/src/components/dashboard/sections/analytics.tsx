"use client";

import * as React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { DynamicIcon } from "../icon";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { format, differenceInHours } from "date-fns";
import { ar } from "date-fns/locale";

// Google brand colors
const G_BLUE = "#4285F4";
const G_RED = "#EA4335";
const G_YELLOW = "#FBBC04";
const G_GREEN = "#34A853";
const G_ORANGE = "#FF6D00";
const G_PURPLE = "#A142F4";
const G_TEAL = "#00897B";
const G_GRAY = "#5F6368";

type Tab = "happiness" | "productivity" | "sleep" | "bestday";

const TABS: Array<{ id: Tab; label: string; icon: string; color: string }> = [
  { id: "happiness", label: "السعادة", icon: "Smile", color: G_YELLOW },
  { id: "productivity", label: "الإنتاجية", icon: "BarChart3", color: G_GREEN },
  { id: "sleep", label: "النوم", icon: "Moon", color: G_PURPLE },
  { id: "bestday", label: "أفضل يوم", icon: "Crown", color: G_ORANGE },
];

// ---------- Types ----------
interface HappinessLog {
  id: string;
  date: string;
  score: number;
  factors: string | null;
  note: string | null;
}

interface DailyStat {
  day: string;
  date: string;
  tasks: number;
  expenses: number;
  habits: number;
  isToday: boolean;
}

interface StatsData {
  tasksDoneThisWeek: number;
  tasksCreatedThisWeek: number;
  totalExpensesSYP: number;
  todayExpensesSYP: number;
  habitsCompletedThisWeek: number;
  eventsThisWeek: number;
  callsThisWeek: number;
  dailyStats: DailyStat[];
}

interface SleepLog {
  id: string;
  bedtime: string;
  wakeTime: string;
  quality: number;
  note: string | null;
}

interface BestTime {
  type: "hour" | "day";
  label: string;
  value: number;
  count: number;
  recommendation: string;
}

interface AiInsightsData {
  spendingPatterns: unknown[];
  taskSuggestions: unknown[];
  bestTimes: BestTime[];
  predictiveAlerts: unknown[];
}

export function AnalyticsSection() {
  const [tab, setTab] = React.useState<Tab>("happiness");

  return (
    <div className="space-y-1.5">
      {/* Header */}
      <Card className="p-2" style={{ backgroundColor: "var(--surface-container)" }}>
        <div className="flex items-center gap-1.5">
          <div
            className="flex h-7 w-7 items-center justify-center rounded-lg"
            style={{ backgroundColor: `${G_BLUE}22`, color: G_BLUE }}
          >
            <DynamicIcon name="BarChart3" className="h-4 w-4" />
          </div>
          <div className="flex-1">
            <p className="text-xs font-bold text-foreground">التحليلات والرؤى</p>
            <p className="text-[10px] text-muted-foreground">
              اعرف أنماطك وحسّن يومك
            </p>
          </div>
        </div>
      </Card>

      {/* Tabs */}
      <Card className="p-1" style={{ backgroundColor: "var(--surface-container)" }}>
        <div className="grid grid-cols-4 gap-0.5">
          {TABS.map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={cn(
                "flex flex-col items-center gap-0.5 py-1.5 rounded-lg transition-all text-[10px] font-medium",
                tab === t.id ? "text-foreground" : "text-muted-foreground hover:text-foreground"
              )}
              style={tab === t.id ? { backgroundColor: `${t.color}22`, color: t.color } : {}}
            >
              <DynamicIcon name={t.icon} className="h-3.5 w-3.5" />
              <span className="leading-tight text-center">{t.label}</span>
            </button>
          ))}
        </div>
      </Card>

      {/* Tab content */}
      <AnimatePresence mode="wait">
        <motion.div
          key={tab}
          initial={{ opacity: 0, y: 6 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -6 }}
          transition={{ duration: 0.15 }}
        >
          {tab === "happiness" && <HappinessTab />}
          {tab === "productivity" && <ProductivityTab />}
          {tab === "sleep" && <SleepTab />}
          {tab === "bestday" && <BestDayTab />}
        </motion.div>
      </AnimatePresence>
    </div>
  );
}

// ============================================================
// HAPPINESS TAB
// ============================================================
function HappinessTab() {
  const [logs, setLogs] = React.useState<HappinessLog[]>([]);
  const [stats, setStats] = React.useState<{
    average: number;
    max: number;
    min: number;
    factorAverages: Record<string, number>;
  } | null>(null);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    fetch("/api/happiness")
      .then((r) => r.json())
      .then((json) => {
        if (json.success) {
          setLogs(json.data);
          setStats(json.stats);
        }
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <Card className="p-2 space-y-1.5" style={{ backgroundColor: "var(--surface-container)" }}>
        {Array.from({ length: 3 }).map((_, i) => (
          <Skeleton key={i} className="h-12 rounded-lg" />
        ))}
      </Card>
    );
  }

  // Build chart points (reverse for chronological order, last 7)
  const sorted = [...logs].reverse().slice(-7);
  const maxScore = 10;

  const factorLabels: Record<string, string> = {
    sleep: "النوم",
    work: "العمل",
    family: "العائلة",
    health: "الصحة",
    money: "المال",
    social: "الاجتماع",
    food: "الطعام",
  };
  const factorColors: Record<string, string> = {
    sleep: G_PURPLE,
    work: G_BLUE,
    family: G_RED,
    health: G_GREEN,
    money: G_YELLOW,
    social: G_TEAL,
    food: G_ORANGE,
  };

  return (
    <div className="space-y-1.5">
      {/* Average + range */}
      <div className="grid grid-cols-3 gap-1.5">
        <StatCard
          icon="Smile"
          color={G_GREEN}
          value={stats?.average?.toFixed(1) || "0"}
          label="المتوسط"
          delay={0}
        />
        <StatCard
          icon="TrendingUp"
          color={G_BLUE}
          value={String(stats?.max ?? 0)}
          label="الأعلى"
          delay={0.05}
        />
        <StatCard
          icon="TrendingDown"
          color={G_RED}
          value={String(stats?.min ?? 0)}
          label="الأدنى"
          delay={0.1}
        />
      </div>

      {/* SVG line chart */}
      <Card className="p-2" style={{ backgroundColor: "var(--surface-container)" }}>
        <div className="flex items-center gap-1.5 mb-1.5">
          <div
            className="flex h-6 w-6 items-center justify-center rounded-lg shrink-0"
            style={{ backgroundColor: `${G_YELLOW}22`, color: G_YELLOW }}
          >
            <DynamicIcon name="Activity" className="h-3.5 w-3.5" />
          </div>
          <h3 className="text-xs font-bold text-foreground">مؤشر السعادة الأسبوعي</h3>
        </div>
        {sorted.length === 0 ? (
          <EmptyState icon="Smile" color={G_YELLOW} title="لا بيانات بعد" hint="سجّل سعادتك يومياً" />
        ) : (
          <HappinessChart logs={sorted} maxScore={maxScore} />
        )}
      </Card>

      {/* Factors breakdown */}
      {stats?.factorAverages && Object.keys(stats.factorAverages).length > 0 && (
        <Card className="p-2" style={{ backgroundColor: "var(--surface-container)" }}>
          <div className="flex items-center gap-1.5 mb-1.5">
            <div
              className="flex h-6 w-6 items-center justify-center rounded-lg shrink-0"
              style={{ backgroundColor: `${G_TEAL}22`, color: G_TEAL }}
            >
              <DynamicIcon name="PieChart" className="h-3.5 w-3.5" />
            </div>
            <h3 className="text-xs font-bold text-foreground">تحليل العوامل</h3>
          </div>
          <div className="space-y-1">
            {Object.entries(stats.factorAverages).map(([key, val], i) => {
              const color = factorColors[key] || G_GRAY;
              const label = factorLabels[key] || key;
              return (
                <motion.div
                  key={key}
                  initial={{ opacity: 0, x: 6 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.04 }}
                  className="flex items-center gap-1.5"
                >
                  <span className="text-[10px] text-muted-foreground w-12 shrink-0">{label}</span>
                  <div className="flex-1 h-1.5 rounded-full bg-white/5 overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${(val / maxScore) * 100}%` }}
                      transition={{ delay: i * 0.04 + 0.1, type: "spring", stiffness: 200 }}
                      className="h-full rounded-full"
                      style={{ backgroundColor: color }}
                    />
                  </div>
                  <span className="text-[10px] font-mono font-bold w-8 text-left" style={{ color }}>
                    {val.toFixed(1)}
                  </span>
                </motion.div>
              );
            })}
          </div>
        </Card>
      )}
    </div>
  );
}

function HappinessChart({ logs, maxScore }: { logs: HappinessLog[]; maxScore: number }) {
  const width = 280;
  const height = 100;
  const padding = 12;
  const chartW = width - padding * 2;
  const chartH = height - padding * 2;

  const points = logs.map((l, i) => {
    const x = padding + (logs.length === 1 ? chartW / 2 : (i / (logs.length - 1)) * chartW);
    const y = padding + chartH - (l.score / maxScore) * chartH;
    return { x, y, ...l };
  });

  const pathD = points
    .map((p, i) => (i === 0 ? `M ${p.x} ${p.y}` : `L ${p.x} ${p.y}`))
    .join(" ");

  // Area path (close to bottom)
  const areaD =
    points.length > 0
      ? `${pathD} L ${points[points.length - 1].x} ${padding + chartH} L ${points[0].x} ${
          padding + chartH
        } Z`
      : "";

  return (
    <div className="w-full overflow-x-auto">
      <svg
        viewBox={`0 0 ${width} ${height}`}
        className="w-full h-28"
        style={{ direction: "ltr" }}
      >
        <defs>
          <linearGradient id="happinessArea" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={G_YELLOW} stopOpacity="0.4" />
            <stop offset="100%" stopColor={G_YELLOW} stopOpacity="0" />
          </linearGradient>
        </defs>
        {/* Grid lines */}
        {[2.5, 5, 7.5, 10].map((v) => {
          const y = padding + chartH - (v / maxScore) * chartH;
          return (
            <line
              key={v}
              x1={padding}
              y1={y}
              x2={width - padding}
              y2={y}
              stroke="currentColor"
              strokeOpacity="0.05"
              strokeWidth="1"
            />
          );
        })}
        {/* Area */}
        {areaD && <path d={areaD} fill="url(#happinessArea)" />}
        {/* Line */}
        <motion.path
          d={pathD}
          fill="none"
          stroke={G_YELLOW}
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          initial={{ pathLength: 0 }}
          animate={{ pathLength: 1 }}
          transition={{ duration: 0.8, ease: "easeInOut" }}
        />
        {/* Points */}
        {points.map((p, i) => (
          <motion.g
            key={p.id}
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: 0.4 + i * 0.05, type: "spring", stiffness: 300 }}
            style={{ transformOrigin: `${p.x}px ${p.y}px` }}
          >
            <circle cx={p.x} cy={p.y} r="3" fill={G_YELLOW} />
            <circle cx={p.x} cy={p.y} r="5" fill={G_YELLOW} fillOpacity="0.2" />
            <text
              x={p.x}
              y={p.y - 7}
              fontSize="8"
              fill="currentColor"
              textAnchor="middle"
              className="font-mono font-bold"
              style={{ fill: G_YELLOW }}
            >
              {p.score}
            </text>
          </motion.g>
        ))}
      </svg>
      <div className="flex justify-between text-[9px] text-muted-foreground mt-1 px-1">
        {logs.map((l) => (
          <span key={l.id}>{format(new Date(l.date), "EEE", { locale: ar })}</span>
        ))}
      </div>
    </div>
  );
}

// ============================================================
// PRODUCTIVITY TAB
// ============================================================
function ProductivityTab() {
  const [stats, setStats] = React.useState<StatsData | null>(null);
  const [insights, setInsights] = React.useState<AiInsightsData | null>(null);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    Promise.all([fetch("/api/stats?period=week"), fetch("/api/ai-insights")])
      .then(([s, i]) => Promise.all([s.json(), i.json()]))
      .then(([sJson, iJson]) => {
        if (sJson.success) setStats(sJson.data);
        if (iJson.success) setInsights(iJson.data);
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  if (loading || !stats) {
    return (
      <Card className="p-2 space-y-1.5" style={{ backgroundColor: "var(--surface-container)" }}>
        {Array.from({ length: 3 }).map((_, i) => (
          <Skeleton key={i} className="h-12 rounded-lg" />
        ))}
      </Card>
    );
  }

  // Peak hours from bestTimes
  const bestHours = (insights?.bestTimes || []).filter((b) => b.type === "hour");
  const maxHourCount = Math.max(...bestHours.map((h) => h.count), 1);

  // Heatmap colorscale based on tasks done
  const maxTasks = Math.max(...stats.dailyStats.map((d) => d.tasks), 1);

  return (
    <div className="space-y-1.5">
      {/* Quick stats */}
      <div className="grid grid-cols-3 gap-1.5">
        <StatCard
          icon="CheckCircle"
          color={G_GREEN}
          value={String(stats.tasksDoneThisWeek)}
          label="مهام منجزة"
          delay={0}
        />
        <StatCard
          icon="RefreshCw"
          color={G_TEAL}
          value={String(stats.habitsCompletedThisWeek)}
          label="عادات مكتملة"
          delay={0.05}
        />
        <StatCard
          icon="Phone"
          color={G_BLUE}
          value={String(stats.callsThisWeek)}
          label="مكالمات"
          delay={0.1}
        />
      </div>

      {/* Peak time bar chart */}
      <Card className="p-2" style={{ backgroundColor: "var(--surface-container)" }}>
        <div className="flex items-center gap-1.5 mb-1.5">
          <div
            className="flex h-6 w-6 items-center justify-center rounded-lg shrink-0"
            style={{ backgroundColor: `${G_GREEN}22`, color: G_GREEN }}
          >
            <DynamicIcon name="Clock" className="h-3.5 w-3.5" />
          </div>
          <h3 className="text-xs font-bold text-foreground">تحليل أوقات الذروة</h3>
        </div>
        {bestHours.length === 0 ? (
          <EmptyState icon="Clock" color={G_GREEN} title="لا بيانات كافية" hint="أنجز بعض المهام لاكتشاف أنماطك" />
        ) : (
          <div className="space-y-1">
            {bestHours.map((h, i) => {
              const pct = (h.count / maxHourCount) * 100;
              return (
                <motion.div
                  key={h.label}
                  initial={{ opacity: 0, x: 6 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.05 }}
                  className="flex items-center gap-1.5"
                >
                  <span className="text-[10px] font-mono text-muted-foreground w-16 shrink-0">
                    {h.label}
                  </span>
                  <div className="flex-1 h-3 rounded-full bg-white/5 overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${pct}%` }}
                      transition={{ delay: i * 0.05 + 0.1, type: "spring", stiffness: 200 }}
                      className="h-full rounded-full flex items-center justify-end px-1"
                      style={{
                        background: `linear-gradient(90deg, ${G_GREEN}, ${G_TEAL})`,
                      }}
                    >
                      <span className="text-[8px] text-white font-bold font-mono">{h.count}</span>
                    </motion.div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        )}
      </Card>

      {/* Productivity heatmap */}
      <Card className="p-2" style={{ backgroundColor: "var(--surface-container)" }}>
        <div className="flex items-center gap-1.5 mb-1.5">
          <div
            className="flex h-6 w-6 items-center justify-center rounded-lg shrink-0"
            style={{ backgroundColor: `${G_ORANGE}22`, color: G_ORANGE }}
          >
            <DynamicIcon name="BarChart3" className="h-3.5 w-3.5" />
          </div>
          <h3 className="text-xs font-bold text-foreground">خريطة الإنتاجية الأسبوعية</h3>
        </div>
        <div className="grid grid-cols-7 gap-1">
          {stats.dailyStats.map((d, i) => {
            const intensity = d.tasks / maxTasks;
            const bg =
              d.tasks === 0
                ? "rgba(255,255,255,0.04)"
                : `rgba(52, 168, 83, ${0.2 + intensity * 0.8})`;
            return (
              <motion.div
                key={i}
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ delay: i * 0.04, type: "spring", stiffness: 300, damping: 20 }}
                className="aspect-square rounded-md flex flex-col items-center justify-center"
                style={{ backgroundColor: bg, border: d.isToday ? `1px solid ${G_GREEN}` : "none" }}
                title={`${d.day}: ${d.tasks} مهمة`}
              >
                <span className="text-[10px] font-bold text-foreground font-mono leading-none">
                  {d.tasks}
                </span>
                <span className="text-[7px] text-muted-foreground leading-none mt-0.5">{d.day}</span>
              </motion.div>
            );
          })}
        </div>
        {/* Legend */}
        <div className="flex items-center justify-end gap-1 mt-1.5 text-[8px] text-muted-foreground">
          <span>أقل</span>
          {[0.2, 0.4, 0.6, 0.8, 1].map((v) => (
            <div
              key={v}
              className="h-2 w-2 rounded-sm"
              style={{ backgroundColor: `rgba(52, 168, 83, ${v})` }}
            />
          ))}
          <span>أكثر</span>
        </div>
      </Card>
    </div>
  );
}

// ============================================================
// SLEEP TAB
// ============================================================
function SleepTab() {
  const [logs, setLogs] = React.useState<SleepLog[]>([]);
  const [stats, setStats] = React.useState<StatsData | null>(null);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    Promise.all([fetch("/api/sleep"), fetch("/api/stats?period=week")])
      .then(([s, st]) => Promise.all([s.json(), st.json()]))
      .then(([sJson, stJson]) => {
        if (sJson.success) setLogs(sJson.data);
        if (stJson.success) setStats(stJson.data);
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <Card className="p-2 space-y-1.5" style={{ backgroundColor: "var(--surface-container)" }}>
        {Array.from({ length: 3 }).map((_, i) => (
          <Skeleton key={i} className="h-12 rounded-lg" />
        ))}
      </Card>
    );
  }

  // Compute duration per log (in hours)
  const recent = logs.slice(0, 7).reverse();
  const durations = recent.map((l) => {
    const bed = new Date(l.bedtime);
    const wake = new Date(l.wakeTime);
    return Math.max(0, differenceInHours(wake, bed));
  });
  const maxDur = Math.max(...durations, 8);
  const avgDur = durations.length
    ? durations.reduce((s, d) => s + d, 0) / durations.length
    : 0;
  const avgQuality = recent.length
    ? recent.reduce((s, l) => s + l.quality, 0) / recent.length
    : 0;

  // Correlation: compare tasks on the day after a good sleep vs bad
  const correlationHint = (() => {
    if (!stats?.dailyStats || recent.length === 0) return null;
    const good = recent.filter((l) => l.quality >= 4);
    const bad = recent.filter((l) => l.quality <= 2);
    if (good.length === 0 || bad.length === 0)
      return { label: "بحاجة لمزيد من البيانات", color: G_GRAY, value: 0 };
    // Rough productivity avg for next day
    return {
      label: "نوم أفضل ⇐ إنتاجية أعلى",
      color: G_GREEN,
      value: Math.round((good.length / (good.length + bad.length)) * 100),
    };
  })();

  const qualityLabels = ["سيء جداً", "سيء", "متوسط", "جيد", "ممتاز"];
  const qualityColors = [G_RED, G_ORANGE, G_YELLOW, G_TEAL, G_GREEN];

  return (
    <div className="space-y-1.5">
      {/* Summary cards */}
      <div className="grid grid-cols-2 gap-1.5">
        <StatCard
          icon="Moon"
          color={G_PURPLE}
          value={`${avgDur.toFixed(1)}س`}
          label="متوسط النوم"
          delay={0}
        />
        <StatCard
          icon="Sparkles"
          color={G_TEAL}
          value={avgQuality.toFixed(1)}
          label="متوسط الجودة /5"
          delay={0.05}
        />
      </div>

      {/* Sleep duration bar chart */}
      <Card className="p-2" style={{ backgroundColor: "var(--surface-container)" }}>
        <div className="flex items-center gap-1.5 mb-1.5">
          <div
            className="flex h-6 w-6 items-center justify-center rounded-lg shrink-0"
            style={{ backgroundColor: `${G_PURPLE}22`, color: G_PURPLE }}
          >
            <DynamicIcon name="Moon" className="h-3.5 w-3.5" />
          </div>
          <h3 className="text-xs font-bold text-foreground">مدة النوم (آخر 7 أيام)</h3>
        </div>
        {recent.length === 0 ? (
          <EmptyState icon="Moon" color={G_PURPLE} title="لا سجلات نوم" hint="أضف سجل نوم للبدء" />
        ) : (
          <div className="flex items-end justify-between gap-1 h-24">
            {recent.map((l, i) => {
              const dur = durations[i];
              const heightPct = (dur / maxDur) * 100;
              const color = dur >= 7 ? G_GREEN : dur >= 6 ? G_YELLOW : G_RED;
              return (
                <div key={l.id} className="flex-1 flex flex-col items-center gap-0.5 min-w-0">
                  <span className="text-[8px] font-mono text-muted-foreground">{dur}س</span>
                  <div className="w-full flex-1 flex items-end">
                    <motion.div
                      initial={{ height: 0 }}
                      animate={{ height: `${Math.max(heightPct, 4)}%` }}
                      transition={{
                        delay: i * 0.05,
                        type: "spring",
                        stiffness: 200,
                      }}
                      className="w-full rounded-t-sm"
                      style={{ backgroundColor: color }}
                    />
                  </div>
                  <span className="text-[8px] text-muted-foreground leading-tight">
                    {format(new Date(l.bedtime), "EEE", { locale: ar })}
                  </span>
                </div>
              );
            })}
          </div>
        )}
      </Card>

      {/* Quality trends */}
      <Card className="p-2" style={{ backgroundColor: "var(--surface-container)" }}>
        <div className="flex items-center gap-1.5 mb-1.5">
          <div
            className="flex h-6 w-6 items-center justify-center rounded-lg shrink-0"
            style={{ backgroundColor: `${G_TEAL}22`, color: G_TEAL }}
          >
            <DynamicIcon name="Activity" className="h-3.5 w-3.5" />
          </div>
          <h3 className="text-xs font-bold text-foreground">اتجاهات الجودة</h3>
        </div>
        {recent.length === 0 ? (
          <p className="text-[10px] text-muted-foreground">لا بيانات</p>
        ) : (
          <div className="space-y-1">
            {recent.slice(-5).map((l, i) => (
              <motion.div
                key={l.id}
                initial={{ opacity: 0, x: 6 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.04 }}
                className="flex items-center gap-1.5"
              >
                <span className="text-[10px] text-muted-foreground w-12 shrink-0">
                  {format(new Date(l.bedtime), "EEE", { locale: ar })}
                </span>
                <div className="flex-1 h-2 rounded-full bg-white/5 overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${(l.quality / 5) * 100}%` }}
                    transition={{ delay: i * 0.04 + 0.1, type: "spring", stiffness: 200 }}
                    className="h-full rounded-full"
                    style={{ backgroundColor: qualityColors[l.quality - 1] || G_GRAY }}
                  />
                </div>
                <span
                  className="text-[9px] font-medium w-12 text-left"
                  style={{ color: qualityColors[l.quality - 1] || G_GRAY }}
                >
                  {qualityLabels[l.quality - 1] || "—"}
                </span>
              </motion.div>
            ))}
          </div>
        )}
      </Card>

      {/* Correlation with productivity */}
      <Card className="p-2" style={{ backgroundColor: "var(--surface-container)" }}>
        <div className="flex items-center gap-1.5 mb-1">
          <div
            className="flex h-6 w-6 items-center justify-center rounded-lg shrink-0"
            style={{ backgroundColor: `${G_GREEN}22`, color: G_GREEN }}
          >
            <DynamicIcon name="TrendingUp" className="h-3.5 w-3.5" />
          </div>
          <h3 className="text-xs font-bold text-foreground">العلاقة مع الإنتاجية</h3>
        </div>
        {correlationHint ? (
          <div className="flex items-center gap-1.5">
            <div
              className="flex h-6 w-6 items-center justify-center rounded-full shrink-0"
              style={{
                backgroundColor: `${correlationHint.color}22`,
                color: correlationHint.color,
              }}
            >
              <DynamicIcon name="Sparkles" className="h-3 w-3" />
            </div>
            <p className="text-[10px] text-muted-foreground flex-1">{correlationHint.label}</p>
            {correlationHint.value > 0 && (
              <span
                className="text-[10px] font-mono font-bold"
                style={{ color: correlationHint.color }}
              >
                {correlationHint.value}%
              </span>
            )}
          </div>
        ) : (
          <p className="text-[10px] text-muted-foreground">
            سجّل المزيد من بيانات النوم لتحليل العلاقة.
          </p>
        )}
      </Card>
    </div>
  );
}

// ============================================================
// BEST DAY TAB
// ============================================================
function BestDayTab() {
  const [stats, setStats] = React.useState<StatsData | null>(null);
  const [insights, setInsights] = React.useState<AiInsightsData | null>(null);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    Promise.all([fetch("/api/stats?period=week"), fetch("/api/ai-insights")])
      .then(([s, i]) => Promise.all([s.json(), i.json()]))
      .then(([sJson, iJson]) => {
        if (sJson.success) setStats(sJson.data);
        if (iJson.success) setInsights(iJson.data);
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  if (loading || !stats) {
    return (
      <Card className="p-2 space-y-1.5" style={{ backgroundColor: "var(--surface-container)" }}>
        {Array.from({ length: 3 }).map((_, i) => (
          <Skeleton key={i} className="h-12 rounded-lg" />
        ))}
      </Card>
    );
  }

  // Find best day = max (tasks + habits)
  const bestDay: DailyStat & { score: number } = stats.dailyStats.reduce<
    DailyStat & { score: number }
  >(
    (best, d) => {
      const score = d.tasks + d.habits;
      return score > best.score ? { ...d, score } : best;
    },
    { ...stats.dailyStats[0], score: 0 }
  );

  const bestDaysFromInsights = (insights?.bestTimes || []).filter((b) => b.type === "day");
  const bestHourFromInsights = (insights?.bestTimes || []).find((b) => b.type === "hour");

  // Build recommendation list
  const recommendations: Array<{ icon: string; color: string; text: string }> = [];
  if (bestHourFromInsights) {
    recommendations.push({
      icon: "Clock",
      color: G_GREEN,
      text: `جدول مهمامك الصعبة في ${bestHourFromInsights.label} (ساعة الذروة)`,
    });
  }
  if (bestDaysFromInsights.length > 0) {
    recommendations.push({
      icon: "Calendar",
      color: G_BLUE,
      text: `${bestDaysFromInsights[0].label} هو أنسب يوم للمهام الكبيرة`,
    });
  }
  if (bestDay) {
    recommendations.push({
      icon: "Trophy",
      color: G_ORANGE,
      text: `كرّر نشاطات يوم ${bestDay.day} — حققت ${bestDay.tasks} مهمة`,
    });
  }
  if (recommendations.length === 0) {
    recommendations.push({
      icon: "Sparkles",
      color: G_PURPLE,
      text: "أنجز المزيد من المهام لتلقي توصيات مخصصة",
    });
  }

  // Best day comparison
  const maxScore = Math.max(...stats.dailyStats.map((d) => d.tasks + d.habits), 1);

  return (
    <div className="space-y-1.5">
      {/* Best day hero card */}
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ type: "spring", stiffness: 300, damping: 20 }}
      >
        <Card
          className="p-3 relative overflow-hidden"
          style={{ backgroundColor: "var(--surface-container)" }}
        >
          <div
            className="absolute -top-6 -left-6 h-20 w-20 rounded-full blur-3xl pointer-events-none"
            style={{ backgroundColor: `${G_ORANGE}33` }}
          />
          <div className="relative">
            <div className="flex items-center gap-2 mb-2">
              <motion.div
                animate={{ rotate: [0, -10, 10, 0] }}
                transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
                className="flex h-10 w-10 items-center justify-center rounded-full text-white shrink-0"
                style={{
                  background: `linear-gradient(135deg, ${G_ORANGE}, ${G_YELLOW})`,
                  boxShadow: `0 4px 12px ${G_ORANGE}55`,
                }}
              >
                <DynamicIcon name="Crown" className="h-5 w-5" />
              </motion.div>
              <div className="flex-1">
                <p className="text-[10px] text-muted-foreground">أفضل يوم هذا الأسبوع</p>
                <p className="text-sm font-bold text-foreground">{bestDay?.day || "—"}</p>
              </div>
              <div className="text-left">
                <p className="text-[10px] text-muted-foreground">النتيجة</p>
                <p className="text-sm font-bold font-mono" style={{ color: G_ORANGE }}>
                  {bestDay?.score ?? 0}
                </p>
              </div>
            </div>
            <p className="text-[10px] text-muted-foreground leading-snug">
              {bestDay
                ? `أنجزت ${bestDay.tasks} مهمة و ${bestDay.habits} عادة في ${bestDay.day}. ${
                    bestDay.isToday ? "هذا اليوم!" : "حافظ على هذا النمط."
                  }`
                : "لا توجد بيانات كافية لتحديد أفضل يوم."}
            </p>
          </div>
        </Card>
      </motion.div>

      {/* Daily comparison bars */}
      <Card className="p-2" style={{ backgroundColor: "var(--surface-container)" }}>
        <div className="flex items-center gap-1.5 mb-1.5">
          <div
            className="flex h-6 w-6 items-center justify-center rounded-lg shrink-0"
            style={{ backgroundColor: `${G_BLUE}22`, color: G_BLUE }}
          >
            <DynamicIcon name="BarChart3" className="h-3.5 w-3.5" />
          </div>
          <h3 className="text-xs font-bold text-foreground">مقارنة الأيام</h3>
        </div>
        <div className="space-y-1">
          {stats.dailyStats.map((d, i) => {
            const score = d.tasks + d.habits;
            const pct = (score / maxScore) * 100;
            const isBest = d.day === bestDay?.day;
            return (
              <motion.div
                key={i}
                initial={{ opacity: 0, x: 6 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.04 }}
                className="flex items-center gap-1.5"
              >
                <span
                  className={cn(
                    "text-[10px] w-10 shrink-0",
                    isBest ? "font-bold" : "text-muted-foreground"
                  )}
                  style={isBest ? { color: G_ORANGE } : {}}
                >
                  {d.day}
                </span>
                <div className="flex-1 h-2.5 rounded-full bg-white/5 overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${Math.max(pct, 2)}%` }}
                    transition={{ delay: i * 0.04 + 0.1, type: "spring", stiffness: 200 }}
                    className="h-full rounded-full"
                    style={{
                      backgroundColor: isBest ? G_ORANGE : G_BLUE,
                    }}
                  />
                </div>
                <span
                  className="text-[10px] font-mono font-bold w-6 text-left"
                  style={{ color: isBest ? G_ORANGE : "inherit" }}
                >
                  {score}
                </span>
              </motion.div>
            );
          })}
        </div>
      </Card>

      {/* Recommendations */}
      <Card className="p-2" style={{ backgroundColor: "var(--surface-container)" }}>
        <div className="flex items-center gap-1.5 mb-1.5">
          <div
            className="flex h-6 w-6 items-center justify-center rounded-lg shrink-0"
            style={{ backgroundColor: `${G_PURPLE}22`, color: G_PURPLE }}
          >
            <DynamicIcon name="Lightbulb" className="h-3.5 w-3.5" />
          </div>
          <h3 className="text-xs font-bold text-foreground">توصيات ذكية</h3>
        </div>
        <div className="space-y-1">
          {recommendations.map((r, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
              className="flex items-start gap-1.5 p-1.5 rounded-lg"
              style={{ backgroundColor: "var(--surface-container-high)" }}
            >
              <div
                className="flex h-5 w-5 items-center justify-center rounded-md shrink-0 mt-0.5"
                style={{ backgroundColor: `${r.color}22`, color: r.color }}
              >
                <DynamicIcon name={r.icon} className="h-3 w-3" />
              </div>
              <p className="text-[10px] text-foreground leading-snug flex-1">{r.text}</p>
            </motion.div>
          ))}
        </div>
      </Card>
    </div>
  );
}

// ============================================================
// SHARED COMPONENTS
// ============================================================
function StatCard({
  icon,
  color,
  value,
  label,
  delay = 0,
}: {
  icon: string;
  color: string;
  value: string;
  label: string;
  delay?: number;
}) {
  return (
    <motion.div initial={{ opacity: 0, y: 4 }} animate={{ opacity: 1, y: 0 }} transition={{ delay }}>
      <Card className="p-2" style={{ backgroundColor: "var(--surface-container)" }}>
        <div className="flex items-center gap-1.5">
          <div
            className="flex h-6 w-6 items-center justify-center rounded-lg shrink-0"
            style={{ backgroundColor: `${color}22`, color }}
          >
            <DynamicIcon name={icon} className="h-3.5 w-3.5" />
          </div>
          <div className="min-w-0">
            <p className="text-sm font-bold font-mono text-foreground">{value}</p>
            <p className="text-[10px] text-muted-foreground">{label}</p>
          </div>
        </div>
      </Card>
    </motion.div>
  );
}

function EmptyState({
  icon,
  color,
  title,
  hint,
}: {
  icon: string;
  color: string;
  title: string;
  hint?: string;
}) {
  return (
    <div className="flex flex-col items-center justify-center py-4 text-center">
      <div
        className="flex h-10 w-10 items-center justify-center rounded-full mb-1.5"
        style={{ backgroundColor: `${color}22`, color }}
      >
        <DynamicIcon name={icon} className="h-5 w-5" />
      </div>
      <p className="text-xs font-medium text-foreground">{title}</p>
      {hint && <p className="text-[10px] text-muted-foreground mt-0.5">{hint}</p>}
    </div>
  );
}

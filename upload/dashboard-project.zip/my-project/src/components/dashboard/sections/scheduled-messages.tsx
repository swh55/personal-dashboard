"use client";

import * as React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { DynamicIcon } from "../icon";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { format, isToday, isTomorrow, isPast } from "date-fns";
import { ar } from "date-fns/locale";
import { formatSyrianDate, SYRIAN_MONTHS } from "@/lib/syrian-date";

// Google brand colors
const G_BLUE = "#4285F4";
const G_RED = "#EA4335";
const G_YELLOW = "#FBBC04";
const G_GREEN = "#34A853";
const G_ORANGE = "#FF6D00";
const G_PURPLE = "#A142F4";
const G_TEAL = "#00897B";

interface ScheduledMessage {
  id: string;
  contactName: string;
  phone: string;
  message: string;
  type: string; // whatsapp | sms
  scheduledAt: string;
  sent: boolean;
  createdAt: string;
}

const typeMeta: Record<string, { label: string; icon: string; color: string }> = {
  whatsapp: { label: "واتساب", icon: "MessageCircle", color: G_GREEN },
  sms: { label: "SMS", icon: "MessageSquare", color: G_BLUE },
};

function normalizePhone(phone: string): string {
  let clean = phone.replace(/[^0-9]/g, "");
  if (clean.startsWith("0")) clean = "963" + clean.slice(1);
  else if (!clean.startsWith("963")) clean = "963" + clean;
  return clean;
}

export function ScheduledMessagesSection() {
  const { toast } = useToast();
  const [messages, setMessages] = React.useState<ScheduledMessage[]>([]);
  const [loading, setLoading] = React.useState(true);

  // New message form
  const [contactName, setContactName] = React.useState("");
  const [phone, setPhone] = React.useState("");
  const [message, setMessage] = React.useState("");
  const [type, setType] = React.useState<string>("whatsapp");
  const [scheduledAt, setScheduledAt] = React.useState("");
  const [creating, setCreating] = React.useState(false);

  const fetchMessages = React.useCallback(async () => {
    try {
      const res = await fetch("/api/scheduled-messages?includeSent=true");
      const json = await res.json();
      if (json.success) setMessages(json.data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, []);

  React.useEffect(() => {
    fetchMessages();
  }, [fetchMessages]);

  const handleAdd = async () => {
    if (!contactName || !phone || !message || !scheduledAt) {
      toast({ title: "جميع الحقول مطلوبة", variant: "destructive" });
      return;
    }
    setCreating(true);
    try {
      const res = await fetch("/api/scheduled-messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ contactName, phone, message, type, scheduledAt }),
      });
      const json = await res.json();
      if (json.success) {
        toast({ title: "تمت جدولة الرسالة ✓" });
        setContactName(""); setPhone(""); setMessage(""); setScheduledAt(""); setType("whatsapp");
        fetchMessages();
      } else {
        toast({ title: json.error || "فشل الجدولة", variant: "destructive" });
      }
    } catch {
      toast({ title: "فشل الجدولة", variant: "destructive" });
    } finally {
      setCreating(false);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await fetch(`/api/scheduled-messages?id=${id}`, { method: "DELETE" });
      toast({ title: "تم حذف الرسالة" });
      fetchMessages();
    } catch {
      toast({ title: "فشل الحذف", variant: "destructive" });
    }
  };

  const handleSendNow = async (msg: ScheduledMessage) => {
    const clean = normalizePhone(msg.phone);
    if (msg.type === "whatsapp") {
      const url = `https://wa.me/${clean}?text=${encodeURIComponent(msg.message)}`;
      window.open(url, "_blank");
    } else {
      window.location.href = `sms:${msg.phone}?body=${encodeURIComponent(msg.message)}`;
    }
    // mark as sent
    try {
      await fetch("/api/scheduled-messages", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: msg.id, sent: true }),
      });
      toast({ title: `تم الإرسال إلى ${msg.contactName} ✓` });
      fetchMessages();
    } catch {
      // ignore
    }
  };

  const pending = messages.filter((m) => !m.sent);
  const sent = messages.filter((m) => m.sent);
  const dueNow = pending.filter((m) => isPast(new Date(m.scheduledAt)));

  return (
    <div className="space-y-1.5">
      {/* Summary header */}
      <Card className="p-2" style={{ backgroundColor: "var(--surface-container)" }}>
        <div className="flex items-center gap-1.5">
          <div
            className="flex h-7 w-7 items-center justify-center rounded-lg"
            style={{ backgroundColor: `${G_BLUE}22`, color: G_BLUE }}
          >
            <DynamicIcon name="Send" className="h-4 w-4" />
          </div>
          <div className="flex-1">
            <p className="text-xs font-bold text-foreground">الرسائل المجدولة</p>
            <p className="text-[10px] text-muted-foreground">جدول رسائل واتساب و SMS لإرسالها لاحقاً</p>
          </div>
          <div className="flex gap-1">
            <span
              className="text-[10px] font-mono px-1.5 py-0.5 rounded-full"
              style={{ backgroundColor: `${G_ORANGE}22`, color: G_ORANGE }}
            >
              {dueNow.length} مستحقة
            </span>
            <span
              className="text-[10px] font-mono px-1.5 py-0.5 rounded-full"
              style={{ backgroundColor: `${G_GREEN}22`, color: G_GREEN }}
            >
              {pending.length} قيد الانتظار
            </span>
          </div>
        </div>
      </Card>

      {/* New message form */}
      <Card className="p-2" style={{ backgroundColor: "var(--surface-container)" }}>
        <div className="flex items-center gap-1.5 mb-1.5">
          <div
            className="flex h-6 w-6 items-center justify-center rounded-lg"
            style={{ backgroundColor: `${G_GREEN}22`, color: G_GREEN }}
          >
            <DynamicIcon name="Plus" className="h-3.5 w-3.5" />
          </div>
          <h3 className="text-xs font-bold text-foreground">جدولة رسالة جديدة</h3>
        </div>

        <div className="space-y-1.5">
          <div className="grid grid-cols-2 gap-1.5">
            <div>
              <Label className="text-[10px]">اسم جهة الاتصال</Label>
              <Input
                value={contactName}
                onChange={(e) => setContactName(e.target.value)}
                placeholder="منصور"
                className="mt-0.5"
              />
            </div>
            <div>
              <Label className="text-[10px]">رقم الهاتف</Label>
              <Input
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="09xxxxxxxx"
                className="mt-0.5"
                dir="ltr"
              />
            </div>
          </div>
          <div>
            <Label className="text-[10px]">نص الرسالة</Label>
            <Textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              rows={2}
              placeholder="اكتب رسالتك هنا..."
              className="mt-0.5"
            />
          </div>
          <div className="grid grid-cols-2 gap-1.5">
            <div>
              <Label className="text-[10px]">النوع</Label>
              <Select value={type} onValueChange={setType}>
                <SelectTrigger className="mt-0.5">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="whatsapp">واتساب</SelectItem>
                  <SelectItem value="sms">SMS</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-[10px]">وقت الإرسال</Label>
              <Input
                type="datetime-local"
                value={scheduledAt}
                onChange={(e) => setScheduledAt(e.target.value)}
                className="mt-0.5"
              />
            </div>
          </div>
          <Button
            size="sm"
            className="w-full"
            onClick={handleAdd}
            disabled={creating}
            style={{ backgroundColor: G_GREEN, color: "#fff" }}
          >
            {creating ? (
              <DynamicIcon name="Loader2" className="h-3.5 w-3.5 animate-spin" />
            ) : (
              <DynamicIcon name="Send" className="h-3.5 w-3.5" />
            )}
            جدولة الرسالة
          </Button>
        </div>
      </Card>

      {/* Pending list */}
      <Card className="p-2" style={{ backgroundColor: "var(--surface-container)" }}>
        <div className="flex items-center justify-between mb-1.5">
          <div className="flex items-center gap-1.5">
            <div
              className="flex h-6 w-6 items-center justify-center rounded-lg"
              style={{ backgroundColor: `${G_ORANGE}22`, color: G_ORANGE }}
            >
              <DynamicIcon name="Clock" className="h-3.5 w-3.5" />
            </div>
            <h3 className="text-xs font-bold text-foreground">في الانتظار</h3>
          </div>
          <span className="text-[10px] text-muted-foreground">{pending.length} رسالة</span>
        </div>

        {loading ? (
          <div className="space-y-1.5">
            {Array.from({ length: 3 }).map((_, i) => (
              <Skeleton key={i} className="h-16 rounded-lg" />
            ))}
          </div>
        ) : pending.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-4 text-center">
            <div
              className="flex h-10 w-10 items-center justify-center rounded-full mb-1.5"
              style={{ backgroundColor: `${G_BLUE}22`, color: G_BLUE }}
            >
              <DynamicIcon name="Send" className="h-5 w-5" />
            </div>
            <p className="text-xs font-medium text-foreground">لا رسائل مجدولة</p>
            <p className="text-[10px] text-muted-foreground mt-0.5">ابدأ بجدولة رسالتك الأولى</p>
          </div>
        ) : (
          <div className="space-y-1 max-h-96 overflow-y-auto custom-scroll">
            <AnimatePresence>
              {pending.map((msg, i) => {
                const meta = typeMeta[msg.type] || typeMeta.whatsapp;
                const date = new Date(msg.scheduledAt);
                const overdue = isPast(date);
                const isTodayM = isToday(date);
                const isTomorrowM = isTomorrow(date);
                return (
                  <motion.div
                    key={msg.id}
                    layout
                    initial={{ opacity: 0, y: 6 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, x: -10 }}
                    transition={{ delay: i * 0.03 }}
                    className="group rounded-lg p-1.5"
                    style={{ backgroundColor: "var(--surface-container-high)" }}
                  >
                    <div className="flex items-start gap-1.5">
                      <div
                        className="flex h-7 w-7 items-center justify-center rounded-full shrink-0 font-bold text-[11px]"
                        style={{ backgroundColor: `${meta.color}22`, color: meta.color }}
                      >
                        {msg.contactName[0]}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-1.5">
                          <p className="text-xs font-bold text-foreground truncate">{msg.contactName}</p>
                          <span
                            className="flex items-center gap-0.5 text-[9px] px-1 py-0.5 rounded-full shrink-0"
                            style={{ backgroundColor: `${meta.color}22`, color: meta.color }}
                          >
                            <DynamicIcon name={meta.icon} className="h-2.5 w-2.5" />
                            {meta.label}
                          </span>
                          {overdue && (
                            <span
                              className="text-[9px] px-1 py-0.5 rounded-full shrink-0"
                              style={{ backgroundColor: `${G_RED}22`, color: G_RED }}
                            >
                              مستحقة
                            </span>
                          )}
                          {isTodayM && !overdue && (
                            <span
                              className="text-[9px] px-1 py-0.5 rounded-full shrink-0"
                              style={{ backgroundColor: `${G_GREEN}22`, color: G_GREEN }}
                            >
                              اليوم
                            </span>
                          )}
                          {isTomorrowM && (
                            <span
                              className="text-[9px] px-1 py-0.5 rounded-full shrink-0"
                              style={{ backgroundColor: `${G_YELLOW}22`, color: G_YELLOW }}
                            >
                              غداً
                            </span>
                          )}
                        </div>
                        <p className="text-[10px] text-muted-foreground" dir="ltr">{msg.phone}</p>
                        <p className="text-[11px] text-foreground/80 mt-0.5 line-clamp-2">{msg.message}</p>
                        <p className="text-[9px] text-muted-foreground mt-0.5">
                          <DynamicIcon name="Clock" className="h-2 w-2 inline ml-0.5" />
                          {format(date, "EEEE d MMMM HH:mm", { locale: ar })}
                        </p>
                      </div>
                      <div className="flex flex-col gap-1 shrink-0">
                        <Button
                          size="sm"
                          className="h-6 px-2 text-[10px]"
                          onClick={() => handleSendNow(msg)}
                          style={{ backgroundColor: meta.color, color: "#fff" }}
                        >
                          <DynamicIcon name="Send" className="h-2.5 w-2.5" />
                          إرسال
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          className="h-6 w-6 p-0 opacity-0 group-hover:opacity-100 hover:text-red-400"
                          onClick={() => handleDelete(msg.id)}
                        >
                          <DynamicIcon name="Trash2" className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                  </motion.div>
                );
              })}
            </AnimatePresence>
          </div>
        )}
      </Card>

      {/* Sent list */}
      {sent.length > 0 && (
        <Card className="p-2" style={{ backgroundColor: "var(--surface-container)" }}>
          <div className="flex items-center gap-1.5 mb-1.5">
            <div
              className="flex h-6 w-6 items-center justify-center rounded-lg"
              style={{ backgroundColor: `${G_TEAL}22`, color: G_TEAL }}
            >
              <DynamicIcon name="CheckCircle" className="h-3.5 w-3.5" />
            </div>
            <h3 className="text-xs font-bold text-foreground">تم إرسالها</h3>
            <span className="text-[10px] text-muted-foreground mr-auto">{sent.length}</span>
          </div>
          <div className="space-y-1 max-h-48 overflow-y-auto custom-scroll">
            {sent.map((msg, i) => {
              const meta = typeMeta[msg.type] || typeMeta.whatsapp;
              return (
                <motion.div
                  key={msg.id}
                  initial={{ opacity: 0, y: 4 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.02 }}
                  className="group rounded-lg p-1.5 flex items-center gap-1.5"
                  style={{ backgroundColor: "var(--surface-container-high)", opacity: 0.7 }}
                >
                  <DynamicIcon name="CheckCircle" className="h-3 w-3 shrink-0" style={{ color: G_TEAL }} />
                  <div className="flex-1 min-w-0">
                    <p className="text-[11px] font-medium text-foreground truncate">
                      {msg.contactName} — <span className="text-muted-foreground">{msg.message.slice(0, 40)}</span>
                    </p>
                  </div>
                  <span
                    className="text-[9px] px-1 py-0.5 rounded-full shrink-0"
                    style={{ backgroundColor: `${meta.color}22`, color: meta.color }}
                  >
                    {meta.label}
                  </span>
                  <Button
                    size="sm"
                    variant="ghost"
                    className="h-5 w-5 p-0 opacity-0 group-hover:opacity-100 hover:text-red-400"
                    onClick={() => handleDelete(msg.id)}
                  >
                    <DynamicIcon name="Trash2" className="h-2.5 w-2.5" />
                  </Button>
                </motion.div>
              );
            })}
          </div>
        </Card>
      )}
    </div>
  );
}

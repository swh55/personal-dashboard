"use client";

import * as React from "react";
import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { DynamicIcon } from "../icon";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { format, differenceInHours, differenceInMinutes, isToday, subDays, isSameDay } from "date-fns";
import { ar } from "date-fns/locale";

interface SleepLog {
  id: string;
  bedtime: string;
  wakeTime: string;
  quality: number;
  note: string | null;
}

interface Medication {
  id: string;
  name: string;
  dosage: string;
  frequency: string;
  times: string;
  active: boolean;
  note: string | null;
  logs: Array<{ id: string; takenAt: string }>;
}

const qualityLabels = ["سيء جداً", "سيء", "متوسط", "جيد", "ممتاز"];
const qualityColors = ["text-rose-400", "text-amber-glow", "text-yellow-400", "text-emerald-glow", "text-teal-400"];

export function HealthSection() {
  const [tab, setTab] = React.useState<"sleep" | "medications">("sleep");

  return (
    <div className="space-y-2">
      <Card className="glass p-2">
        <div className="flex gap-1">
          {[
            { id: "sleep", label: "تتبع النوم", icon: "Moon" },
            { id: "medications", label: "تذكير الأدوية", icon: "Heart" },
          ].map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id as "sleep" | "medications")}
              className={cn(
                "flex-1 flex items-center justify-center gap-2 py-2.5 rounded-lg text-sm font-medium transition-all",
                tab === t.id ? "bg-emerald-glow/15 text-emerald-glow" : "text-muted-foreground"
              )}
            >
              <DynamicIcon name={t.icon} className="h-4 w-4" />
              {t.label}
            </button>
          ))}
        </div>
      </Card>

      {tab === "sleep" && <SleepTab />}
      {tab === "medications" && <MedicationsTab />}
    </div>
  );
}

function SleepTab() {
  const [logs, setLogs] = React.useState<SleepLog[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [bedtime, setBedtime] = React.useState("");
  const [wakeTime, setWakeTime] = React.useState("");
  const [quality, setQuality] = React.useState(3);
  const { toast } = useToast();

  const fetchLogs = React.useCallback(async () => {
    try {
      const res = await fetch("/api/sleep");
      const json = await res.json();
      if (json.success) setLogs(json.data);
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  }, []);

  React.useEffect(() => { fetchLogs(); }, [fetchLogs]);

  const handleAdd = async () => {
    if (!bedtime || !wakeTime) {
      toast({ title: "وقت النوم والاستيقاظ مطلوبان", variant: "destructive" });
      return;
    }
    try {
      await fetch("/api/sleep", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ bedtime, wakeTime, quality }),
      });
      toast({ title: "تم تسجيل النوم 😴" });
      setBedtime(""); setWakeTime(""); setQuality(3);
      fetchLogs();
    } catch {
      toast({ title: "فشل التسجيل", variant: "destructive" });
    }
  };

  const avgSleep = logs.length > 0
    ? logs.reduce((sum, l) => {
      const hours = differenceInHours(new Date(l.wakeTime), new Date(l.bedtime));
      const mins = differenceInMinutes(new Date(l.wakeTime), new Date(l.bedtime)) % 60;
      return sum + hours + mins / 60;
    }, 0) / logs.length
    : 0;

  const last7Days = Array.from({ length: 7 }, (_, i) => {
    const date = subDays(new Date(), 6 - i);
    const dayLog = logs.find(l => isSameDay(new Date(l.bedtime), date));
    return { date, label: format(date, "EEEEEE", { locale: ar }), hasLog: !!dayLog, log: dayLog };
  });

  return (
    <div className="space-y-2">
      {/* Stats */}
      <div className="grid grid-cols-3 gap-2">
        <Card className="glass p-2.5 text-center">
          <p className="text-2xl font-bold text-emerald-glow">{avgSleep.toFixed(1)}س</p>
          <p className="text-[11px] text-muted-foreground">متوسط النوم</p>
        </Card>
        <Card className="glass p-2.5 text-center">
          <p className="text-2xl font-bold text-amber-glow">{logs.length}</p>
          <p className="text-[11px] text-muted-foreground">سجلات</p>
        </Card>
        <Card className="glass p-2.5 text-center">
          <p className="text-2xl font-bold text-teal-400">
            {logs.length > 0 ? qualityLabels[logs[0].quality - 1] : "—"}
          </p>
          <p className="text-[11px] text-muted-foreground">آخر جودة</p>
        </Card>
      </div>

      {/* Add form */}
      <Card className="glass p-2">
        <h4 className="text-sm font-bold text-foreground mb-1.5">تسجيل نوم جديد</h4>
        <div className="grid grid-cols-2 gap-2 mb-1.5">
          <div>
            <Label className="text-[11px]">وقت النوم</Label>
            <Input type="datetime-local" value={bedtime} onChange={(e) => setBedtime(e.target.value)} />
          </div>
          <div>
            <Label className="text-[11px]">وقت الاستيقاظ</Label>
            <Input type="datetime-local" value={wakeTime} onChange={(e) => setWakeTime(e.target.value)} />
          </div>
        </div>
        <div className="mb-1.5">
          <Label className="text-[11px]">جودة النوم</Label>
          <div className="flex gap-2 mt-1">
            {[1, 2, 3, 4, 5].map((q) => (
              <button
                key={q}
                onClick={() => setQuality(q)}
                className={cn(
                  "flex-1 py-2 rounded-lg border text-xs font-medium transition-all",
                  quality === q
                    ? cn("border-current", qualityColors[q - 1])
                    : "border-border/40 text-muted-foreground"
                )}
              >
                {qualityLabels[q - 1]}
              </button>
            ))}
          </div>
        </div>
        <Button onClick={handleAdd} className="w-full bg-emerald-glow hover:bg-emerald-glow/90 text-background">
          <DynamicIcon name="Plus" className="h-4 w-4" />
          تسجيل
        </Button>
      </Card>

      {/* Last 7 days chart */}
      <Card className="glass p-2">
        <h4 className="text-sm font-bold text-foreground mb-1.5">آخر 7 أيام</h4>
        <div className="flex items-end justify-between gap-2 h-32">
          {last7Days.map((day, i) => {
            const hours = day.log ? differenceInHours(new Date(day.log.wakeTime), new Date(day.log.bedtime)) : 0;
            const heightPercent = Math.min((hours / 10) * 100, 100);
            return (
              <div key={i} className="flex-1 flex flex-col items-center gap-1">
                <div className="w-full flex-1 flex items-end">
                  <motion.div
                    initial={{ height: 0 }}
                    animate={{ height: `${Math.max(heightPercent, 4)}%` }}
                    transition={{ delay: i * 0.05 }}
                    className={cn(
                      "w-full rounded-t-md",
                      day.hasLog ? "bg-gradient-to-t from-emerald-glow to-amber-glow" : "bg-muted/20"
                    )}
                  />
                </div>
                <span className="text-[9px] text-muted-foreground">{day.label}</span>
                {day.hasLog && <span className="text-[9px] text-emerald-glow font-bold">{hours}س</span>}
              </div>
            );
          })}
        </div>
      </Card>

      {/* History */}
      <Card className="glass p-2">
        <h4 className="text-sm font-bold text-foreground mb-1.5">السجل</h4>
        {loading ? (
          <Skeleton className="h-8 rounded-lg" />
        ) : logs.length === 0 ? (
          <p className="text-sm text-muted-foreground text-center py-2">لا سجلات بعد</p>
        ) : (
          <div className="space-y-2 max-h-60 overflow-y-auto custom-scroll">
            {logs.slice(0, 10).map((log) => {
              const hours = differenceInHours(new Date(log.wakeTime), new Date(log.bedtime));
              const mins = differenceInMinutes(new Date(log.wakeTime), new Date(log.bedtime)) % 60;
              return (
                <div key={log.id} className="flex items-center gap-2 rounded-xl border border-border/40 bg-background/30 p-2">
                  <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-purple-500/15 text-purple-400 shrink-0">
                    <DynamicIcon name="Moon" className="h-4 w-4" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-foreground">{hours}س {mins}د</p>
                    <p className="text-[10px] text-muted-foreground">
                      {format(new Date(log.bedtime), "d MMM HH:mm", { locale: ar })} → {format(new Date(log.wakeTime), "HH:mm")}
                    </p>
                  </div>
                  <span className={cn("text-[10px] px-2 py-0.5 rounded-full", qualityColors[log.quality - 1])}>
                    {qualityLabels[log.quality - 1]}
                  </span>
                </div>
              );
            })}
          </div>
        )}
      </Card>
    </div>
  );
}

function MedicationsTab() {
  const [meds, setMeds] = React.useState<Medication[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [name, setName] = React.useState("");
  const [dosage, setDosage] = React.useState("");
  const [frequency, setFrequency] = React.useState("daily");
  const [times, setTimes] = React.useState("08:00");
  const { toast } = useToast();

  const fetchMeds = React.useCallback(async () => {
    try {
      const res = await fetch("/api/medications");
      const json = await res.json();
      if (json.success) setMeds(json.data);
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  }, []);

  React.useEffect(() => { fetchMeds(); }, [fetchMeds]);

  const handleAdd = async () => {
    if (!name) { toast({ title: "اسم الدواء مطلوب", variant: "destructive" }); return; }
    try {
      await fetch("/api/medications", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, dosage, frequency, times: times.split(",").map(t => t.trim()) }),
      });
      toast({ title: "تم إضافة الدواء 💊" });
      setName(""); setDosage(""); setTimes("08:00");
      fetchMeds();
    } catch { toast({ title: "فشل الإضافة", variant: "destructive" }); }
  };

  const handleTaken = async (id: string) => {
    try {
      await fetch("/api/medications", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id, action: "log" }),
      });
      toast({ title: "تم تسجيل تناول الدواء ✓" });
      fetchMeds();
    } catch { toast({ title: "فشل التسجيل", variant: "destructive" }); }
  };

  const handleDelete = async (id: string) => {
    await fetch(`/api/medications?id=${id}`, { method: "DELETE" });
    fetchMeds();
  };

  const isTakenToday = (med: Medication) => {
    return med.logs.some(l => isToday(new Date(l.takenAt)));
  };

  return (
    <div className="space-y-2">
      {/* Add form */}
      <Card className="glass p-2">
        <h4 className="text-sm font-bold text-foreground mb-1.5">إضافة دواء جديد</h4>
        <div className="grid grid-cols-2 gap-2 mb-1.5">
          <div>
            <Label className="text-[11px]">اسم الدواء</Label>
            <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="مثلاً: فيتامين د" />
          </div>
          <div>
            <Label className="text-[11px]">الجرعة</Label>
            <Input value={dosage} onChange={(e) => setDosage(e.target.value)} placeholder="مثلاً: حبة واحدة" />
          </div>
          <div>
            <Label className="text-[11px]">التكرار</Label>
            <select value={frequency} onChange={(e) => setFrequency(e.target.value)} className="w-full h-9 rounded-md border border-border bg-background/50 px-3 text-sm">
              <option value="daily">يومياً</option>
              <option value="twice">مرتين يومياً</option>
              <option value="thrice">3 مرات يومياً</option>
              <option value="weekly">أسبوعياً</option>
              <option value="asNeeded">عند الحاجة</option>
            </select>
          </div>
          <div>
            <Label className="text-[11px]">المواعيد (افصل بفاصلة)</Label>
            <Input value={times} onChange={(e) => setTimes(e.target.value)} placeholder="08:00, 20:00" dir="ltr" />
          </div>
        </div>
        <Button onClick={handleAdd} className="w-full bg-emerald-glow hover:bg-emerald-glow/90 text-background">
          <DynamicIcon name="Plus" className="h-4 w-4" />
          إضافة الدواء
        </Button>
      </Card>

      {/* List */}
      {loading ? (
        <Skeleton className="h-10 rounded-lg" />
      ) : meds.length === 0 ? (
        <Card className="glass p-10 text-center">
          <DynamicIcon name="Heart" className="h-7 w-7 text-muted-foreground/50 mx-auto mb-2" />
          <p className="text-sm text-muted-foreground">لا أدوية مسجلة</p>
        </Card>
      ) : (
        <div className="space-y-2">
          {meds.map((med, i) => {
            const taken = isTakenToday(med);
            const timesArray = JSON.parse(med.times || "[]");
            return (
              <motion.div key={med.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}>
                <Card className={cn("glass p-2.5 transition-all", taken && "border-emerald-glow/30 bg-emerald-glow/5")}>
                  <div className="flex items-center gap-2">
                    <div className={cn(
                      "flex h-7 w-7 items-center justify-center rounded-xl shrink-0",
                      taken ? "bg-emerald-glow/15 text-emerald-glow" : "bg-rose-500/15 text-rose-400"
                    )}>
                      <DynamicIcon name={taken ? "CheckCircle" : "Heart"} className="h-5 w-5" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-bold text-foreground">{med.name}</p>
                      <p className="text-[11px] text-muted-foreground">
                        {med.dosage && `${med.dosage} • `}
                        {timesArray.join("، ")}
                      </p>
                    </div>
                    {!taken && (
                      <Button size="sm" onClick={() => handleTaken(med.id)} className="bg-emerald-glow hover:bg-emerald-glow/90 text-background h-8">
                        تناولت
                      </Button>
                    )}
                    {taken && <span className="text-[10px] text-emerald-glow font-medium">✓ تم اليوم</span>}
                    <Button variant="ghost" size="icon" className="h-8 w-8 hover:text-rose-400" onClick={() => handleDelete(med.id)}>
                      <DynamicIcon name="Trash2" className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                </Card>
              </motion.div>
            );
          })}
        </div>
      )}
    </div>
  );
}

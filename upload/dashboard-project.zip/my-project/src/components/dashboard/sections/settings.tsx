"use client";

import * as React from "react";
import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { DynamicIcon } from "../icon";
import { ColorCustomizer } from "../color-customizer";
import { useToast } from "@/hooks/use-toast";
import { useTheme } from "next-themes";
import { cn } from "@/lib/utils";

export function SettingsSection() {
  const { theme, setTheme } = useTheme();
  const { toast } = useToast();
  const [settings, setSettings] = React.useState<Record<string, string>>({});
  const [loading, setLoading] = React.useState(true);
  const [pinInput, setPinInput] = React.useState("");
  const [pinConfirm, setPinConfirm] = React.useState("");
  const [exporting, setExporting] = React.useState(false);

  React.useEffect(() => {
    fetch("/api/settings")
      .then((r) => r.json())
      .then((json) => {
        if (json.success) setSettings(json.data);
      })
      .finally(() => setLoading(false));
  }, []);

  const updateSetting = async (key: string, value: string) => {
    setSettings((prev) => ({ ...prev, [key]: value }));
    try {
      await fetch("/api/settings", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ key, value }),
      });
    } catch {
      toast({ title: "فشل حفظ الإعداد", variant: "destructive" });
    }
  };

  const handleExport = async (format: "json" | "csv") => {
    setExporting(true);
    try {
      const res = await fetch(`/api/export?format=${format}&type=all`);
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `dashboard-export-${new Date().toISOString().split("T")[0]}.${format}`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      toast({ title: `تم تصدير البيانات (${format.toUpperCase()})` });
    } catch {
      toast({ title: "فشل التصدير", variant: "destructive" });
    } finally {
      setExporting(false);
    }
  };

  const handleGenerateReport = async () => {
    setExporting(true);
    try {
      // فتح التقرير في نافذة جديدة (قابل للطباعة كـ PDF)
      window.open("/api/report", "_blank");
      toast({ title: "تم فتح التقرير — استخدم طباعة → حفظ كـ PDF" });
    } catch {
      toast({ title: "فشل إنشاء التقرير", variant: "destructive" });
    } finally {
      setExporting(false);
    }
  };

  const handleSavePin = async () => {
    if (pinInput.length !== 4 || !/^\d{4}$/.test(pinInput)) {
      toast({ title: "الرمز يجب أن يكون 4 أرقام", variant: "destructive" });
      return;
    }
    if (pinInput !== pinConfirm) {
      toast({ title: "الرمزان غير متطابقين", variant: "destructive" });
      return;
    }
    await updateSetting("pinCode", pinInput);
    await updateSetting("pinEnabled", "true");
    setPinInput("");
    setPinConfirm("");
    toast({ title: "تم تفعيل قفل الرمز بنجاح 🔒" });
  };

  const handleDisablePin = async () => {
    await updateSetting("pinEnabled", "false");
    await updateSetting("pinCode", "");
    toast({ title: "تم إلغاء قفل الرمز" });
  };

  return (
    <div className="space-y-2">
      {/* Appearance */}
      <Card className="glass p-2">
        <div className="flex items-center gap-2 mb-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-emerald-glow/15 text-emerald-glow">
            <DynamicIcon name="Palette" className="h-4 w-4" />
          </div>
          <h3 className="text-sm font-bold text-foreground">المظهر</h3>
        </div>

        <div className="space-y-2">
          {/* Theme */}
          <div className="flex items-center justify-between rounded-xl border border-border/40 bg-background/30 p-2">
            <div className="flex items-center gap-2">
              <DynamicIcon name={theme === "dark" ? "Moon" : "Sun"} className="h-5 w-5 text-emerald-glow" />
              <div>
                <p className="text-sm font-medium text-foreground">الوضع الليلي</p>
                <p className="text-[11px] text-muted-foreground">تبديل بين الوضع الداكن والنهاري</p>
              </div>
            </div>
            <Switch
              checked={theme === "dark"}
              onCheckedChange={(checked) => {
                setTheme(checked ? "dark" : "light");
                toast({ title: checked ? "الوضع الليلي مفعل" : "الوضع النهاري مفعل" });
              }}
            />
          </div>

          {/* Auto night mode */}
          <div className="flex items-center justify-between rounded-xl border border-border/40 bg-background/30 p-2">
            <div className="flex items-center gap-2">
              <DynamicIcon name="Clock" className="h-5 w-5 text-amber-glow" />
              <div>
                <p className="text-sm font-medium text-foreground">الوضع الليلي التلقائي</p>
                <p className="text-[11px] text-muted-foreground">تبديل تلقائي حسب الوقت (8م - 6ص)</p>
              </div>
            </div>
            <Switch
              checked={settings.autoNightMode === "true"}
              disabled={loading}
              onCheckedChange={(checked) => updateSetting("autoNightMode", checked ? "true" : "false")}
            />
          </div>

          {/* Week start */}
          <div className="flex items-center justify-between rounded-xl border border-border/40 bg-background/30 p-2">
            <div className="flex items-center gap-2">
              <DynamicIcon name="Calendar" className="h-5 w-5 text-teal-400" />
              <div>
                <p className="text-sm font-medium text-foreground">بداية الأسبوع</p>
                <p className="text-[11px] text-muted-foreground">اليوم الأول للأسبوع في التقويم</p>
              </div>
            </div>
            <Select
              value={settings.weekStartDay || "6"}
              onValueChange={(v) => updateSetting("weekStartDay", v)}
            >
              <SelectTrigger className="w-28"><SelectValue /></SelectTrigger>
              <SelectContent className="glass-strong">
                <SelectItem value="6">السبت</SelectItem>
                <SelectItem value="0">الأحد</SelectItem>
                <SelectItem value="1">الإثنين</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Color Customization */}
          <div className="rounded-xl border border-border/40 bg-background/30 p-2">
            <ColorCustomizer />
          </div>
        </div>
      </Card>

      {/* Security - PIN Lock */}
      <Card className="glass p-2">
        <div className="flex items-center gap-2 mb-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-rose-500/15 text-rose-400">
            <DynamicIcon name="Shield" className="h-4 w-4" />
          </div>
          <h3 className="text-sm font-bold text-foreground">الأمان</h3>
        </div>

        <div className="space-y-2">
          <div className="rounded-xl border border-border/40 bg-background/30 p-2">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <DynamicIcon name="Lock" className="h-5 w-5 text-rose-400" />
                <div>
                  <p className="text-sm font-medium text-foreground">قفل الرمز (PIN)</p>
                  <p className="text-[11px] text-muted-foreground">حماية لوحة التحكم برمز 4 أرقام</p>
                </div>
              </div>
              <Switch
                checked={settings.pinEnabled === "true"}
                disabled={loading}
                onCheckedChange={(checked) => {
                  if (!checked) handleDisablePin();
                }}
              />
            </div>

            {settings.pinEnabled !== "true" && (
              <div className="grid grid-cols-2 gap-2 mt-1.5 pt-3 border-t border-border/30">
                <div>
                  <Label htmlFor="pin1" className="text-[11px]">الرمز (4 أرقام)</Label>
                  <Input
                    id="pin1"
                    type="password"
                    inputMode="numeric"
                    maxLength={4}
                    value={pinInput}
                    onChange={(e) => setPinInput(e.target.value.replace(/\D/g, ""))}
                    placeholder="••••"
                    dir="ltr"
                    className="text-center font-mono text-lg tracking-widest"
                  />
                </div>
                <div>
                  <Label htmlFor="pin2" className="text-[11px]">تأكيد الرمز</Label>
                  <Input
                    id="pin2"
                    type="password"
                    inputMode="numeric"
                    maxLength={4}
                    value={pinConfirm}
                    onChange={(e) => setPinConfirm(e.target.value.replace(/\D/g, ""))}
                    placeholder="••••"
                    dir="ltr"
                    className="text-center font-mono text-lg tracking-widest"
                  />
                </div>
                <div className="col-span-2">
                  <Button
                    onClick={handleSavePin}
                    className="w-full bg-emerald-glow hover:bg-emerald-glow/90 text-background"
                    disabled={pinInput.length !== 4 || pinInput !== pinConfirm}
                  >
                    <DynamicIcon name="ShieldCheck" className="h-4 w-4" />
                    تفعيل القفل
                  </Button>
                </div>
              </div>
            )}

            {settings.pinEnabled === "true" && (
              <div className="flex items-center gap-2 mt-1.5 pt-3 border-t border-border/30 text-emerald-glow">
                <DynamicIcon name="ShieldCheck" className="h-4 w-4" />
                <p className="text-xs">القفل مفعّل — سيُطلب الرمز عند فتح اللوحة</p>
              </div>
            )}
          </div>
        </div>
      </Card>

      {/* Google OAuth Configuration */}
      <GoogleOAuthCard />

      {/* Data Management */}
      <Card className="glass p-2">
        <div className="flex items-center gap-2 mb-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-teal-500/15 text-teal-400">
            <DynamicIcon name="Database" className="h-4 w-4" />
          </div>
          <h3 className="text-sm font-bold text-foreground">إدارة البيانات</h3>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
          <button
            onClick={() => handleExport("json")}
            disabled={exporting}
            className="flex items-center gap-2 rounded-xl border border-border/40 bg-background/30 p-2 hover:border-emerald-glow/30 transition-all text-right disabled:opacity-50"
          >
            <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-emerald-glow/15 text-emerald-glow shrink-0">
              <DynamicIcon name={exporting ? "Loader2" : "Download"} className={cn("h-5 w-5", exporting && "animate-spin")} />
            </div>
            <div className="flex-1">
              <p className="text-sm font-medium text-foreground">تصدير JSON</p>
              <p className="text-[11px] text-muted-foreground">كل البيانات</p>
            </div>
          </button>

          <button
            onClick={() => handleExport("csv")}
            disabled={exporting}
            className="flex items-center gap-2 rounded-xl border border-border/40 bg-background/30 p-2 hover:border-amber-glow/30 transition-all text-right disabled:opacity-50"
          >
            <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-amber-glow/15 text-amber-glow shrink-0">
              <DynamicIcon name={exporting ? "Loader2" : "Download"} className={cn("h-5 w-5", exporting && "animate-spin")} />
            </div>
            <div className="flex-1">
              <p className="text-sm font-medium text-foreground">تصدير CSV</p>
              <p className="text-[11px] text-muted-foreground">جدول المهام</p>
            </div>
          </button>

          <button
            onClick={handleGenerateReport}
            disabled={exporting}
            className="flex items-center gap-2 rounded-xl border border-border/40 bg-background/30 p-2 hover:border-purple-500/30 transition-all text-right disabled:opacity-50"
          >
            <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-purple-500/15 text-purple-400 shrink-0">
              <DynamicIcon name={exporting ? "Loader2" : "FileText"} className={cn("h-5 w-5", exporting && "animate-spin")} />
            </div>
            <div className="flex-1">
              <p className="text-sm font-medium text-foreground">تقرير PDF</p>
              <p className="text-[11px] text-muted-foreground">ملخص شامل قابل للطباعة</p>
            </div>
          </button>
        </div>

        <div className="mt-1.5 rounded-xl border border-amber-glow/20 bg-amber-glow/5 p-2">
          <div className="flex items-start gap-2">
            <DynamicIcon name="AlertCircle" className="h-4 w-4 text-amber-glow shrink-0 mt-0.5" />
            <div>
              <p className="text-xs font-medium text-foreground">نسخة احتياطية</p>
              <p className="text-[11px] text-muted-foreground mt-0.5">
                يُنصح بتصدير بياناتك أسبوعياً كنسخة احتياطية. البيانات تُخزن محلياً على جهازك.
              </p>
            </div>
          </div>
        </div>
      </Card>

      {/* About */}
      <Card className="glass p-2">
        <div className="flex items-center gap-2 mb-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-purple-500/15 text-purple-400">
            <DynamicIcon name="Sparkles" className="h-4 w-4" />
          </div>
          <h3 className="text-sm font-bold text-foreground">حول التطبيق</h3>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          {[
            { label: "الإصدار", value: "1.4.0", icon: "Tag" },
            { label: "الأقسام", value: "14 قسم", icon: "LayoutDashboard" },
            { label: "APIs", value: "15+ route", icon: "Database" },
            { label: "الميزات", value: "20+ ميزة", icon: "Sparkles" },
          ].map((item) => (
            <div key={item.label} className="rounded-xl border border-border/40 bg-background/30 p-2 text-center">
              <DynamicIcon name={item.icon} className="h-4 w-4 mx-auto mb-1 text-emerald-glow" />
              <p className="text-sm font-bold text-foreground">{item.value}</p>
              <p className="text-[10px] text-muted-foreground">{item.label}</p>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}

// ===== Google OAuth Configuration Card =====
function GoogleOAuthCard() {
  const [config, setConfig] = React.useState({
    google_client_id: "",
    google_client_secret: "",
    google_redirect_uri: "",
    nextauth_secret: "",
    is_configured: false,
  });
  const [loading, setLoading] = React.useState(true);
  const [saving, setSaving] = React.useState(false);
  const [showSecrets, setShowSecrets] = React.useState(false);
  const { toast } = useToast();

  React.useEffect(() => {
    fetch("/api/settings/google")
      .then((r) => r.json())
      .then((json) => {
        if (json.success) setConfig(json.data);
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  const handleSave = async () => {
    setSaving(true);
    try {
      await fetch("/api/settings/google", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          google_client_id: config.google_client_id,
          google_client_secret: config.google_client_secret,
          google_redirect_uri: config.google_redirect_uri || "http://localhost:3000/api/auth/callback",
          nextauth_secret: config.nextauth_secret,
        }),
      });
      toast({ title: "تم حفظ بيانات Google ✓" });
      // إعادة تحميل
      const res = await fetch("/api/settings/google");
      const json = await res.json();
      if (json.success) setConfig(json.data);
    } catch {
      toast({ title: "فشل الحفظ", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  const handleConnect = () => {
    window.open("/api/auth/google", "_self");
  };

  return (
    <Card className="glass p-2">
      <div className="flex items-center gap-2 mb-2">
        <div className="flex h-8 w-8 items-center justify-center rounded-lg" style={{ backgroundColor: "#4285F4" + "22" }}>
          <DynamicIcon name="Globe" className="h-4 w-4" style={{ color: "#4285F4" }} />
        </div>
        <h3 className="text-sm font-bold text-foreground">تكامل Google</h3>
        {config.is_configured && (
          <span className="text-[10px] px-1.5 py-0.5 rounded-full text-white font-bold" style={{ backgroundColor: "#34A853" }}>
            مُعد
          </span>
        )}
      </div>

      {loading ? (
        <div className="text-xs text-muted-foreground py-4 text-center">جاري التحميل...</div>
      ) : (
        <div className="space-y-2">
          {/* Instructions */}
          <div className="rounded-xl p-2 text-[10px] leading-relaxed" style={{ backgroundColor: "#4285F4" + "10" }}>
            <p className="font-bold text-foreground mb-1">طريقة الإعداد:</p>
            <ol className="text-muted-foreground space-y-0.5 list-decimal list-inside">
              <li>اذهب إلى <a href="https://console.cloud.google.com/" target="_blank" className="text-blue-400 underline">Google Cloud Console</a></li>
              <li>أنشئ مشروع جديد</li>
              <li>فعّل APIs: Calendar, Drive, Contacts</li>
              <li>أنشئ OAuth 2.0 Client ID</li>
              <li>أضف Redirect URI أدناه في إعدادات Google</li>
              <li>انسخ Client ID و Client Secret وأدخلهما هنا</li>
            </ol>
          </div>

          {/* Client ID */}
          <div>
            <Label className="text-[11px]">Google Client ID</Label>
            <Input
              value={config.google_client_id}
              onChange={(e) => setConfig({ ...config, google_client_id: e.target.value })}
              placeholder="xxxxxxxxx.apps.googleusercontent.com"
              dir="ltr"
              className="text-xs"
            />
          </div>

          {/* Client Secret */}
          <div>
            <Label className="text-[11px]">Google Client Secret</Label>
            <div className="flex gap-1">
              <Input
                type={showSecrets ? "text" : "password"}
                value={config.google_client_secret}
                onChange={(e) => setConfig({ ...config, google_client_secret: e.target.value })}
                placeholder="GOCSPX-xxxxxxxxxxxx"
                dir="ltr"
                className="text-xs flex-1"
              />
              <Button
                size="icon"
                variant="outline"
                onClick={() => setShowSecrets(!showSecrets)}
                className="shrink-0"
              >
                <DynamicIcon name={showSecrets ? "EyeOff" : "Eye"} className="h-3.5 w-3.5" />
              </Button>
            </div>
          </div>

          {/* Redirect URI */}
          <div>
            <Label className="text-[11px]">Redirect URI</Label>
            <Input
              value={config.google_redirect_uri || "http://localhost:3000/api/auth/callback"}
              onChange={(e) => setConfig({ ...config, google_redirect_uri: e.target.value })}
              dir="ltr"
              className="text-xs"
            />
            <p className="text-[9px] text-muted-foreground mt-0.5">
              أضف هذا الرابط في إعدادات Google OAuth
            </p>
          </div>

          {/* NextAuth Secret */}
          <div>
            <Label className="text-[11px]">NextAuth Secret (لتشفير الجلسة)</Label>
            <Input
              type={showSecrets ? "text" : "password"}
              value={config.nextauth_secret}
              onChange={(e) => setConfig({ ...config, nextauth_secret: e.target.value })}
              placeholder="أي نص عشوائي طويل"
              dir="ltr"
              className="text-xs"
            />
          </div>

          {/* Actions */}
          <div className="flex gap-1.5 pt-1">
            <Button
              onClick={handleSave}
              disabled={saving}
              className="flex-1"
              style={{ backgroundColor: "#4285F4", color: "white" }}
            >
              <DynamicIcon name={saving ? "Loader2" : "Save"} className={cn("h-3.5 w-3.5", saving && "animate-spin")} />
              حفظ
            </Button>
            {config.is_configured && (
              <Button
                onClick={handleConnect}
                variant="outline"
                className="flex-1"
                style={{ borderColor: "#34A853", color: "#34A853" }}
              >
                <DynamicIcon name="ExternalLink" className="h-3.5 w-3.5" />
                ربط Google
              </Button>
            )}
          </div>
        </div>
      )}
    </Card>
  );
}

"use client";

import * as React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger } from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { DynamicIcon } from "../icon";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

interface ProjectTask {
  id: string;
  title: string;
  status: string;
}

interface Project {
  id: string;
  name: string;
  description: string | null;
  status: string;
  progress: number;
  startDate: string | null;
  endDate: string | null;
  color: string;
  tasks: ProjectTask[];
}

const statusConfig: Record<string, { label: string; color: string }> = {
  planning: { label: "تخطيط", color: "text-amber-glow bg-amber-glow/10" },
  active: { label: "نشط", color: "text-emerald-glow bg-emerald-glow/10" },
  paused: { label: "متوقف", color: "text-muted-foreground bg-muted/20" },
  completed: { label: "مكتمل", color: "text-teal-400 bg-teal-500/10" },
};

export function ProjectsSection() {
  const [projects, setProjects] = React.useState<Project[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [dialogOpen, setDialogOpen] = React.useState(false);
  const [name, setName] = React.useState("");
  const [description, setDescription] = React.useState("");
  const [newTasks, setNewTasks] = React.useState<Record<string, string>>({});
  const { toast } = useToast();

  const fetchData = React.useCallback(async () => {
    try {
      const res = await fetch("/api/projects");
      const json = await res.json();
      if (json.success) setProjects(json.data);
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  }, []);

  React.useEffect(() => { fetchData(); }, [fetchData]);

  const handleAdd = async () => {
    if (!name) { toast({ title: "الاسم مطلوب", variant: "destructive" }); return; }
    try {
      await fetch("/api/projects", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, description }),
      });
      toast({ title: "تم إضافة المشروع" });
      setName(""); setDescription(""); setDialogOpen(false);
      fetchData();
    } catch { toast({ title: "فشل الإضافة", variant: "destructive" }); }
  };

  const handleAddTask = async (projectId: string) => {
    const title = newTasks[projectId];
    if (!title) return;
    try {
      await fetch("/api/projects", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: projectId, action: "addTask", taskTitle: title }),
      });
      setNewTasks((prev) => ({ ...prev, [projectId]: "" }));
      fetchData();
    } catch { toast({ title: "فشل الإضافة", variant: "destructive" }); }
  };

  const handleToggleTask = async (projectId: string, taskId: string) => {
    await fetch("/api/projects", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: projectId, action: "toggleTask", taskId }),
    });
    fetchData();
  };

  const handleDelete = async (id: string) => {
    await fetch(`/api/projects?id=${id}`, { method: "DELETE" });
    fetchData();
  };

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="flex h-7 w-7 items-center justify-center rounded-xl bg-emerald-glow/15 text-emerald-glow">
            <DynamicIcon name="Briefcase" className="h-5 w-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-foreground">إدارة المشاريع</h2>
            <p className="text-xs text-muted-foreground">{projects.length} مشروع</p>
          </div>
        </div>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-emerald-glow hover:bg-emerald-glow/90 text-background">
              <DynamicIcon name="Plus" className="h-4 w-4" />
              مشروع جديد
            </Button>
          </DialogTrigger>
          <DialogContent className="glass-strong max-w-md">
            <DialogHeader><DialogTitle>مشروع جديد</DialogTitle></DialogHeader>
            <div className="space-y-1.5">
              <div><Label>اسم المشروع</Label><Input value={name} onChange={(e) => setName(e.target.value)} /></div>
              <div><Label>الوصف</Label><Input value={description} onChange={(e) => setDescription(e.target.value)} /></div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setDialogOpen(false)}>إلغاء</Button>
              <Button onClick={handleAdd} className="bg-emerald-glow hover:bg-emerald-glow/90 text-background">إضافة</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {loading ? (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-2">
          {Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-12 rounded-lg" />)}
        </div>
      ) : projects.length === 0 ? (
        <Card className="glass p-12 text-center">
          <DynamicIcon name="Briefcase" className="h-8 w-8 text-muted-foreground/50 mx-auto mb-1.5" />
          <p className="text-sm font-medium text-foreground">لا مشاريع بعد</p>
          <p className="text-xs text-muted-foreground mt-1">ابدأ بإنشاء مشروعك الأول</p>
        </Card>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-2">
          <AnimatePresence>
            {projects.map((project, i) => {
              const status = statusConfig[project.status] || statusConfig.planning;
              const doneTasks = project.tasks.filter(t => t.status === "done").length;
              return (
                <motion.div
                  key={project.id}
                  layout
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  transition={{ delay: i * 0.05 }}
                >
                  <Card className="glass p-2 group">
                    <div className="flex items-start justify-between mb-1.5">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <h3 className="text-sm font-bold text-foreground">{project.name}</h3>
                          <span className={cn("text-[10px] px-2 py-0.5 rounded-full", status.color)}>{status.label}</span>
                        </div>
                        {project.description && <p className="text-xs text-muted-foreground">{project.description}</p>}
                      </div>
                      <Button variant="ghost" size="icon" className="h-8 w-8 opacity-0 group-hover:opacity-100 hover:text-rose-400" onClick={() => handleDelete(project.id)}>
                        <DynamicIcon name="Trash2" className="h-3.5 w-3.5" />
                      </Button>
                    </div>

                    {/* Progress */}
                    <div className="mb-1.5">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-[10px] text-muted-foreground">التقدم</span>
                        <span className="text-xs font-bold text-emerald-glow">{project.progress}%</span>
                      </div>
                      <div className="h-2 rounded-full bg-muted/20 overflow-hidden">
                        <motion.div
                          initial={{ width: 0 }}
                          animate={{ width: `${project.progress}%` }}
                          className="h-full rounded-full bg-gradient-to-l from-emerald-glow to-amber-glow"
                        />
                      </div>
                      <p className="text-[10px] text-muted-foreground mt-1">{doneTasks}/{project.tasks.length} مهمة منجزة</p>
                    </div>

                    {/* Tasks */}
                    <div className="space-y-1.5 mb-1.5 max-h-16 overflow-y-auto custom-scroll">
                      {project.tasks.map((task) => (
                        <button
                          key={task.id}
                          onClick={() => handleToggleTask(project.id, task.id)}
                          className="flex items-center gap-2 w-full rounded-lg p-1.5 hover:bg-accent/30 text-right"
                        >
                          <div className={cn(
                            "flex h-4 w-4 items-center justify-center rounded border-2 shrink-0",
                            task.status === "done" ? "bg-emerald-glow border-emerald-glow text-background" : "border-border/40"
                          )}>
                            {task.status === "done" && <DynamicIcon name="Check" className="h-2.5 w-2.5" />}
                          </div>
                          <span className={cn("text-xs", task.status === "done" ? "line-through text-muted-foreground" : "text-foreground")}>
                            {task.title}
                          </span>
                        </button>
                      ))}
                    </div>

                    {/* Add task */}
                    <div className="flex gap-2">
                      <Input
                        value={newTasks[project.id] || ""}
                        onChange={(e) => setNewTasks((prev) => ({ ...prev, [project.id]: e.target.value }))}
                        onKeyDown={(e) => { if (e.key === "Enter") handleAddTask(project.id); }}
                        placeholder="إضافة مهمة..."
                        className="h-8 text-xs bg-background/50"
                      />
                      <Button size="icon" className="h-8 w-8 bg-emerald-glow hover:bg-emerald-glow/90 text-background" onClick={() => handleAddTask(project.id)}>
                        <DynamicIcon name="Plus" className="h-3.5 w-3.5" />
                      </Button>
                    </div>
                  </Card>
                </motion.div>
              );
            })}
          </AnimatePresence>
        </div>
      )}
    </div>
  );
}

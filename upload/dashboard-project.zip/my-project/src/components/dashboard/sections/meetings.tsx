"use client";

import * as React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger } from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { DynamicIcon } from "../icon";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { format, isToday, isTomorrow, isPast } from "date-fns";
import { ar } from "date-fns/locale";
import { formatSyrianDate, SYRIAN_MONTHS } from "@/lib/syrian-date";

// Recurring marker stored at the end of the description field
const RECURRING_NONE = "none";
const RECURRING_WEEKLY = "weekly";
const RECURRING_MONTHLY = "monthly";
const RECURRING_REGEX = /\s*\[recurring:(weekly|monthly)\]\s*$/;

function getRecurringKind(desc: string | null): "weekly" | "monthly" | null {
  if (!desc) return null;
  const m = desc.match(RECURRING_REGEX);
  return m ? (m[1] as "weekly" | "monthly") : null;
}

function stripRecurringMarker(desc: string | null): string {
  if (!desc) return "";
  return desc.replace(RECURRING_REGEX, "").trim();
}

function shiftDate(iso: string, kind: "weekly" | "monthly", count: number): string {
  const d = new Date(iso);
  if (kind === "weekly") d.setDate(d.getDate() + 7 * count);
  else d.setMonth(d.getMonth() + count);
  return d.toISOString();
}

interface Meeting {
  id: string;
  title: string;
  description: string | null;
  startTime: string;
  endTime: string | null;
  location: string | null;
  attendees: string | null;
  notes: string | null;
  status: string;
}

export function MeetingsSection() {
  const [meetings, setMeetings] = React.useState<Meeting[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [dialogOpen, setDialogOpen] = React.useState(false);
  const [title, setTitle] = React.useState("");
  const [description, setDescription] = React.useState("");
  const [startTime, setStartTime] = React.useState("");
  const [endTime, setEndTime] = React.useState("");
  const [location, setLocation] = React.useState("");
  const [attendees, setAttendees] = React.useState("");
  const [recurring, setRecurring] = React.useState<string>(RECURRING_NONE);
  const [adding, setAdding] = React.useState(false);
  const { toast } = useToast();

  const fetchData = React.useCallback(async () => {
    try {
      const res = await fetch("/api/meetings");
      const json = await res.json();
      if (json.success) setMeetings(json.data);
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  }, []);

  React.useEffect(() => { fetchData(); }, [fetchData]);

  const handleAdd = async () => {
    if (!title || !startTime) { toast({ title: "العنوان والوقت مطلوبان", variant: "destructive" }); return; }
    setAdding(true);
    try {
      const attendeesList = attendees.split(",").map(a => a.trim()).filter(Boolean);
      // Append recurring marker to the description so copies can be identified
      const baseDesc = description.trim();
      const isRecurring = recurring === RECURRING_WEEKLY || recurring === RECURRING_MONTHLY;
      const markedDesc = isRecurring ? `${baseDesc} [recurring:${recurring}]`.trim() : baseDesc;

      await fetch("/api/meetings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title,
          description: markedDesc,
          startTime,
          endTime: endTime || undefined,
          location,
          attendees: attendeesList,
        }),
      });

      // Create the next 4 copies for recurring meetings
      if (isRecurring) {
        for (let i = 1; i <= 4; i++) {
          const shiftedStart = shiftDate(startTime, recurring as "weekly" | "monthly", i);
          const shiftedEnd = endTime ? shiftDate(endTime, recurring as "weekly" | "monthly", i) : undefined;
          try {
            await fetch("/api/meetings", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                title,
                description: markedDesc,
                startTime: shiftedStart,
                endTime: shiftedEnd,
                location,
                attendees: attendeesList,
              }),
            });
          } catch (e) {
            console.error("Failed to create recurring copy", e);
          }
        }
        toast({ title: `تم إضافة الاجتماع + 4 نسخ ${recurring === "weekly" ? "أسبوعية" : "شهرية"}` });
      } else {
        toast({ title: "تم إضافة الاجتماع" });
      }

      setTitle(""); setDescription(""); setStartTime(""); setEndTime(""); setLocation(""); setAttendees("");
      setRecurring(RECURRING_NONE);
      setDialogOpen(false);
      fetchData();
    } catch { toast({ title: "فشل الإضافة", variant: "destructive" }); }
    finally { setAdding(false); }
  };

  const handleDelete = async (id: string) => {
    await fetch(`/api/meetings?id=${id}`, { method: "DELETE" });
    fetchData();
  };

  const handleComplete = async (id: string) => {
    await fetch("/api/meetings", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id, status: "completed" }),
    });
    toast({ title: "تم تأكيد الاجتماع ✓" });
    fetchData();
  };

  const upcoming = meetings.filter(m => m.status === "upcoming" && !isPast(new Date(m.startTime)));
  const todayMeetings = upcoming.filter(m => isToday(new Date(m.startTime)));
  const past = meetings.filter(m => m.status === "completed" || isPast(new Date(m.startTime)));

  return (
    <div className="space-y-2">
      {/* Stats */}
      <div className="grid grid-cols-3 gap-2">
        <Card className="glass p-2.5"><div className="flex items-center gap-2">
          <div className="flex h-7 w-7 items-center justify-center rounded-xl bg-emerald-glow/15 text-emerald-glow"><DynamicIcon name="Calendar" className="h-5 w-5" /></div>
          <div><p className="text-xl font-bold text-emerald-glow">{todayMeetings.length}</p><p className="text-[11px] text-muted-foreground">اجتماعات اليوم</p></div>
        </div></Card>
        <Card className="glass p-2.5"><div className="flex items-center gap-2">
          <div className="flex h-7 w-7 items-center justify-center rounded-xl bg-amber-glow/15 text-amber-glow"><DynamicIcon name="Clock" className="h-5 w-5" /></div>
          <div><p className="text-xl font-bold text-amber-glow">{upcoming.length}</p><p className="text-[11px] text-muted-foreground">قادمة</p></div>
        </div></Card>
        <Card className="glass p-2.5"><div className="flex items-center gap-2">
          <div className="flex h-7 w-7 items-center justify-center rounded-xl bg-teal-500/15 text-teal-400"><DynamicIcon name="CheckCircle" className="h-5 w-5" /></div>
          <div><p className="text-xl font-bold text-teal-400">{past.length}</p><p className="text-[11px] text-muted-foreground">منجزة</p></div>
        </div></Card>
      </div>

      {/* Add */}
      <div className="flex justify-end">
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-emerald-glow hover:bg-emerald-glow/90 text-background"><DynamicIcon name="Plus" className="h-4 w-4" />اجتماع جديد</Button>
          </DialogTrigger>
          <DialogContent className="glass-strong max-w-md">
            <DialogHeader><DialogTitle>اجتماع جديد</DialogTitle></DialogHeader>
            <div className="space-y-1.5">
              <div><Label>العنوان</Label><Input value={title} onChange={(e) => setTitle(e.target.value)} /></div>
              <div className="grid grid-cols-2 gap-2">
                <div><Label>البداية</Label><Input type="datetime-local" value={startTime} onChange={(e) => setStartTime(e.target.value)} /></div>
                <div><Label>النهاية (اختياري)</Label><Input type="datetime-local" value={endTime} onChange={(e) => setEndTime(e.target.value)} /></div>
              </div>
              <div><Label>المكان</Label><Input value={location} onChange={(e) => setLocation(e.target.value)} /></div>
              <div><Label>الحضور (افصل بفاصلة)</Label><Input value={attendees} onChange={(e) => setAttendees(e.target.value)} placeholder="منصور، باسل" /></div>
              <div><Label>الوصف</Label><Textarea value={description} onChange={(e) => setDescription(e.target.value)} rows={2} /></div>
              {/* Recurring options */}
              <div className="rounded-lg border border-border/40 p-2">
                <Label className="mb-1.5 block">التكرار</Label>
                <div className="flex gap-1.5">
                  {[
                    { id: RECURRING_NONE, label: "بدون", icon: "X" },
                    { id: RECURRING_WEEKLY, label: "أسبوعي", icon: "RefreshCw" },
                    { id: RECURRING_MONTHLY, label: "شهري", icon: "RefreshCw" },
                  ].map((opt) => (
                    <button
                      key={opt.id}
                      onClick={() => setRecurring(opt.id)}
                      className={cn(
                        "flex-1 h-8 rounded-md text-[11px] font-medium transition-all flex items-center justify-center gap-1",
                        recurring === opt.id
                          ? "bg-emerald-glow/15 text-emerald-glow"
                          : "text-muted-foreground hover:bg-muted/40"
                      )}
                    >
                      <DynamicIcon name={opt.icon} className="h-3 w-3" />
                      {opt.label}
                    </button>
                  ))}
                </div>
                {recurring !== RECURRING_NONE && (
                  <p className="text-[10px] text-muted-foreground mt-1.5">
                    🔄 سيتم إنشاء 4 نسخ إضافية ({recurring === "weekly" ? "أسبوعية" : "شهرية"}) تلقائياً.
                  </p>
                )}
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setDialogOpen(false)}>إلغاء</Button>
              <Button onClick={handleAdd} disabled={adding} className="bg-emerald-glow hover:bg-emerald-glow/90 text-background">
                {adding ? <DynamicIcon name="Loader2" className="h-4 w-4 animate-spin" /> : null}
                إضافة
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {/* Upcoming */}
      {loading ? (
        <Skeleton className="h-10 rounded-lg" />
      ) : upcoming.length === 0 && past.length === 0 ? (
        <Card className="glass p-12 text-center">
          <DynamicIcon name="Users" className="h-8 w-8 text-muted-foreground/50 mx-auto mb-1.5" />
          <p className="text-sm font-medium text-foreground">لا اجتماعات</p>
        </Card>
      ) : (
        <div className="space-y-2">
          {upcoming.length > 0 && (
            <div>
              <h3 className="text-sm font-bold text-foreground mb-2">القادمة</h3>
              <div className="space-y-2">
                <AnimatePresence>
                  {upcoming.map((m, i) => {
                    const date = new Date(m.startTime);
                    const isTodayM = isToday(date);
                    const isTomorrowM = isTomorrow(date);
                    const attendeesList = m.attendees ? JSON.parse(m.attendees) : [];
                    const recurringKind = getRecurringKind(m.description);
                    const cleanDesc = stripRecurringMarker(m.description);
                    return (
                      <motion.div key={m.id} layout initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, x: -20 }} transition={{ delay: i * 0.03 }}>
                        <Card className={cn("glass p-2.5 group", isTodayM && "border-emerald-glow/30 bg-emerald-glow/5")}>
                          <div className="flex items-start gap-2">
                            <div className={cn("flex flex-col items-center justify-center w-14 h-8 rounded-lg shrink-0", isTodayM ? "bg-emerald-glow/15 text-emerald-glow" : "bg-muted/30 text-muted-foreground")}>
                              <span className="text-lg font-bold leading-none">{format(date, "d")}</span>
                              <span className="text-[10px] leading-none mt-0.5">{SYRIAN_MONTHS[date.getMonth()].slice(0, 4)}</span>
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-2 flex-wrap">
                                <h4 className="text-sm font-bold text-foreground">{m.title}</h4>
                                {recurringKind && (
                                  <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-purple-500/15 text-purple-400 flex items-center gap-0.5" title={`اجتماع متكرر (${recurringKind === "weekly" ? "أسبوعي" : "شهري"})`}>
                                    🔄 {recurringKind === "weekly" ? "أسبوعي" : "شهري"}
                                  </span>
                                )}
                                {isTodayM && <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-glow/15 text-emerald-glow">اليوم</span>}
                                {isTomorrowM && <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-glow/15 text-amber-glow">غداً</span>}
                              </div>
                              <p className="text-[11px] text-muted-foreground mt-0.5">
                                {format(date, "HH:mm", { locale: ar })}
                                {m.endTime && ` - ${format(new Date(m.endTime), "HH:mm")}`}
                                {m.location && ` • ${m.location}`}
                              </p>
                              {attendeesList.length > 0 && (
                                <p className="text-[10px] text-muted-foreground mt-0.5">👤 {attendeesList.join("، ")}</p>
                              )}
                              {cleanDesc && <p className="text-[11px] text-foreground/70 mt-1 line-clamp-1">{cleanDesc}</p>}
                            </div>
                            <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                              <Button size="sm" variant="outline" className="h-8 text-xs" onClick={() => handleComplete(m.id)}>إنهاء</Button>
                              <Button variant="ghost" size="icon" className="h-8 w-8 hover:text-rose-400" onClick={() => handleDelete(m.id)}>
                                <DynamicIcon name="Trash2" className="h-3.5 w-3.5" />
                              </Button>
                            </div>
                          </div>
                        </Card>
                      </motion.div>
                    );
                  })}
                </AnimatePresence>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

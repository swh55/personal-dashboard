"use client";

import * as React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger } from "@/components/ui/dialog";
import { Switch } from "@/components/ui/switch";
import { Skeleton } from "@/components/ui/skeleton";
import { DynamicIcon } from "../icon";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

interface Contact {
  id: string;
  name: string;
  phone: string;
  whatsapp?: string | null;
  email?: string | null;
  relation: string;
  category?: string | null;
  note?: string | null;
  favorite: boolean;
}

const relationConfig: Record<string, { label: string; color: string; bg: string }> = {
  family: { label: "العائلة", color: "text-rose-400", bg: "bg-rose-500/15" },
  work: { label: "العمل", color: "text-emerald-glow", bg: "bg-emerald-glow/15" },
  friend: { label: "صديق", color: "text-amber-glow", bg: "bg-amber-glow/15" },
  other: { label: "أخرى", color: "text-teal-400", bg: "bg-teal-500/15" },
};

export function ContactsSection() {
  const [contacts, setContacts] = React.useState<Contact[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [search, setSearch] = React.useState("");
  const [filter, setFilter] = React.useState<string>("all");
  const [dialogOpen, setDialogOpen] = React.useState(false);
  const [editingContact, setEditingContact] = React.useState<Contact | null>(null);
  const { toast } = useToast();

  const fetchContacts = React.useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/contacts");
      const json = await res.json();
      if (json.success) setContacts(json.data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, []);

  React.useEffect(() => {
    fetchContacts();
  }, [fetchContacts]);

  const filteredContacts = contacts
    .filter((c) => filter === "all" || c.relation === filter)
    .filter((c) => !search || c.name.includes(search) || c.phone.includes(search));

  const handleDelete = async (id: string) => {
    try {
      await fetch(`/api/contacts?id=${id}`, { method: "DELETE" });
      toast({ title: "تم حذف جهة الاتصال" });
      fetchContacts();
    } catch {
      toast({ title: "فشل الحذف", variant: "destructive" });
    }
  };

  const handleToggleFavorite = async (contact: Contact) => {
    await fetch("/api/contacts", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: contact.id, favorite: !contact.favorite }),
    });
    fetchContacts();
  };

  const handleCall = (phone: string, name: string) => {
    if (!phone || phone === "—") {
      toast({ title: "لا يوجد رقم", variant: "destructive" });
      return;
    }
    window.location.href = `tel:${phone.replace(/[^0-9+]/g, "")}`;
    toast({ title: `الاتصال بـ ${name}` });
  };

  const handleWhatsApp = (phone: string, name: string) => {
    if (!phone || phone === "—") {
      toast({ title: "لا يوجد رقم", variant: "destructive" });
      return;
    }
    let clean = phone.replace(/[^0-9]/g, "");
    if (clean.startsWith("0")) clean = "963" + clean.slice(1);
    else if (!clean.startsWith("963")) clean = "963" + clean;
    window.open(`https://wa.me/${clean}`, "_blank");
    toast({ title: `مراسلة ${name} على واتساب` });
  };

  const handleCreateReminder = async (contact: Contact) => {
    try {
      const res = await fetch("/api/contact-reminders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contactId: contact.id,
          contactName: contact.name,
          frequency: "weekly",
        }),
      });
      const json = await res.json();
      if (json.success) {
        toast({ title: `تم إنشاء تذكير تواصل لـ ${contact.name} ✓` });
      } else {
        toast({ title: json.error || "فشل إنشاء التذكير", variant: "destructive" });
      }
    } catch {
      toast({ title: "فشل إنشاء التذكير", variant: "destructive" });
    }
  };

  const stats = {
    total: contacts.length,
    family: contacts.filter((c) => c.relation === "family").length,
    work: contacts.filter((c) => c.relation === "work").length,
    favorites: contacts.filter((c) => c.favorite).length,
  };

  return (
    <div className="space-y-2">
      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-2">
        {[
          { label: "إجمالي", value: stats.total, icon: "Users", color: "emerald" },
          { label: "العائلة", value: stats.family, icon: "Heart", color: "rose" },
          { label: "العمل", value: stats.work, icon: "Briefcase", color: "amber" },
          { label: "المفضلة", value: stats.favorites, icon: "Star", color: "teal" },
        ].map((s, i) => {
          const colorMap: Record<string, string> = {
            emerald: "bg-emerald-glow/10 text-emerald-glow",
            rose: "bg-rose-500/10 text-rose-400",
            amber: "bg-amber-glow/10 text-amber-glow",
            teal: "bg-teal-500/10 text-teal-400",
          };
          return (
            <motion.div key={s.label} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}>
              <Card className="glass p-2.5">
                <div className="flex items-center gap-2">
                  <div className={cn("flex h-9 w-9 items-center justify-center rounded-lg", colorMap[s.color])}>
                    <DynamicIcon name={s.icon} className="h-4 w-4" />
                  </div>
                  <div>
                    <p className="text-xl font-bold text-foreground">{s.value}</p>
                    <p className="text-[11px] text-muted-foreground">{s.label}</p>
                  </div>
                </div>
              </Card>
            </motion.div>
          );
        })}
      </div>

      {/* Toolbar */}
      <Card className="glass p-2.5">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="بحث بالاسم أو الرقم..."
            className="bg-background/50 sm:max-w-xs"
          />
          <div className="flex rounded-lg bg-muted/30 p-0.5">
            {[
              { id: "all", label: "الكل" },
              { id: "family", label: "العائلة" },
              { id: "work", label: "العمل" },
              { id: "friend", label: "أصدقاء" },
              { id: "other", label: "أخرى" },
            ].map((f) => (
              <button
                key={f.id}
                onClick={() => setFilter(f.id)}
                className={cn(
                  "px-3 py-1.5 text-xs rounded-md transition-all",
                  filter === f.id ? "bg-emerald-glow/15 text-emerald-glow" : "text-muted-foreground"
                )}
              >
                {f.label}
              </button>
            ))}
          </div>
          <div className="flex-1" />
          <ContactDialog
            open={dialogOpen}
            onOpenChange={setDialogOpen}
            editingContact={editingContact}
            onSaved={() => {
              setDialogOpen(false);
              setEditingContact(null);
              fetchContacts();
            }}
          >
            <Button className="bg-emerald-glow hover:bg-emerald-glow/90 text-background">
              <DynamicIcon name="UserPlus" className="h-4 w-4" />
              إضافة جهة
            </Button>
          </ContactDialog>
        </div>
      </Card>

      {/* Contacts grid */}
      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
          {Array.from({ length: 6 }).map((_, i) => (
            <Skeleton key={i} className="h-12 rounded-lg" />
          ))}
        </div>
      ) : filteredContacts.length === 0 ? (
        <Card className="glass p-10">
          <div className="flex flex-col items-center justify-center text-center">
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-muted/30 mb-1.5">
              <DynamicIcon name="Users" className="h-6 w-6 text-muted-foreground" />
            </div>
            <p className="text-sm font-medium text-foreground">لا جهات اتصال</p>
            <p className="text-xs text-muted-foreground mt-1">أضف جهة اتصال جديدة للبدء</p>
          </div>
        </Card>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
          <AnimatePresence>
            {filteredContacts.map((contact, i) => {
              const rel = relationConfig[contact.relation] || relationConfig.other;
              return (
                <motion.div
                  key={contact.id}
                  layout
                  initial={{ opacity: 0, scale: 0.96 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  transition={{ delay: i * 0.03 }}
                >
                  <Card className="glass p-2.5 hover:border-emerald-glow/30 transition-all group">
                    <div className="flex items-start gap-2 mb-1.5">
                      <div className={cn("flex h-8 w-8 items-center justify-center rounded-full font-bold shrink-0", rel.bg, rel.color)}>
                        {contact.name[0]}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <p className="text-sm font-bold text-foreground truncate">{contact.name}</p>
                          {contact.favorite && (
                            <DynamicIcon name="Star" className="h-3.5 w-3.5 text-amber-glow fill-amber-glow" />
                          )}
                        </div>
                        <p className="text-[11px] text-muted-foreground" dir="ltr">{contact.phone}</p>
                        <span className={cn("inline-block text-[10px] px-1.5 py-0.5 rounded-full mt-1", rel.bg, rel.color)}>
                          {rel.label}
                        </span>
                      </div>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-7 w-7 opacity-0 group-hover:opacity-100"
                        onClick={() => handleToggleFavorite(contact)}
                      >
                        <DynamicIcon
                          name="Star"
                          className={cn("h-3.5 w-3.5", contact.favorite ? "text-amber-glow fill-amber-glow" : "text-muted-foreground")}
                        />
                      </Button>
                    </div>

                    {contact.note && (
                      <p className="text-[11px] text-muted-foreground mb-1.5 line-clamp-1">{contact.note}</p>
                    )}

                    <div className="flex gap-1.5">
                      <Button
                        size="sm"
                        variant="outline"
                        className="flex-1 h-8 bg-emerald-glow/5 border-emerald-glow/20 hover:bg-emerald-glow/15 text-emerald-glow"
                        onClick={() => handleCall(contact.phone, contact.name)}
                      >
                        <DynamicIcon name="Phone" className="h-3.5 w-3.5" />
                        اتصال
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        className="flex-1 h-8 bg-green-600/5 border-green-600/20 hover:bg-green-600/15 text-green-500"
                        onClick={() => handleWhatsApp(contact.whatsapp || contact.phone, contact.name)}
                      >
                        <DynamicIcon name="MessageCircle" className="h-3.5 w-3.5" />
                        واتساب
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        className="flex-1 h-8 bg-amber-glow/5 border-amber-glow/20 hover:bg-amber-glow/15 text-amber-glow"
                        onClick={() => handleCreateReminder(contact)}
                        title="إنشاء تذكير بالتواصل"
                      >
                        <DynamicIcon name="BellRing" className="h-3.5 w-3.5" />
                        تذكير
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        className="h-8 px-2"
                        onClick={() => { setEditingContact(contact); setDialogOpen(true); }}
                      >
                        <DynamicIcon name="Pencil" className="h-3.5 w-3.5" />
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        className="h-8 px-2 hover:text-rose-400"
                        onClick={() => handleDelete(contact.id)}
                      >
                        <DynamicIcon name="Trash2" className="h-3.5 w-3.5" />
                      </Button>
                    </div>
                  </Card>
                </motion.div>
              );
            })}
          </AnimatePresence>
        </div>
      )}
    </div>
  );
}

function ContactDialog({
  open, onOpenChange, editingContact, onSaved, children,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  editingContact: Contact | null;
  onSaved: () => void;
  children: React.ReactNode;
}) {
  const [name, setName] = React.useState("");
  const [phone, setPhone] = React.useState("");
  const [whatsapp, setWhatsapp] = React.useState("");
  const [email, setEmail] = React.useState("");
  const [relation, setRelation] = React.useState("other");
  const [category, setCategory] = React.useState("");
  const [note, setNote] = React.useState("");
  const [favorite, setFavorite] = React.useState(false);
  const { toast } = useToast();

  React.useEffect(() => {
    if (editingContact) {
      setName(editingContact.name);
      setPhone(editingContact.phone);
      setWhatsapp(editingContact.whatsapp || "");
      setEmail(editingContact.email || "");
      setRelation(editingContact.relation);
      setCategory(editingContact.category || "");
      setNote(editingContact.note || "");
      setFavorite(editingContact.favorite);
    } else {
      setName(""); setPhone(""); setWhatsapp(""); setEmail("");
      setRelation("other"); setCategory(""); setNote(""); setFavorite(false);
    }
  }, [editingContact, open]);

  const handleSave = async () => {
    if (!name || !phone) {
      toast({ title: "الاسم والهاتف مطلوبان", variant: "destructive" });
      return;
    }
    const payload = { name, phone, whatsapp, email, relation, category, note, favorite };
    try {
      if (editingContact) {
        await fetch("/api/contacts", {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ id: editingContact.id, ...payload }),
        });
        toast({ title: "تم تحديث جهة الاتصال" });
      } else {
        await fetch("/api/contacts", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
        toast({ title: "تم إضافة جهة الاتصال" });
      }
      onSaved();
    } catch {
      toast({ title: "فشل الحفظ", variant: "destructive" });
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogTrigger asChild>{children}</DialogTrigger>
      <DialogContent className="glass-strong max-w-md">
        <DialogHeader>
          <DialogTitle>{editingContact ? "تعديل جهة اتصال" : "إضافة جهة اتصال"}</DialogTitle>
        </DialogHeader>
        <div className="space-y-1.5">
          <div>
            <Label htmlFor="c-name">الاسم</Label>
            <Input id="c-name" value={name} onChange={(e) => setName(e.target.value)} placeholder="الاسم الكامل" />
          </div>
          <div className="grid grid-cols-2 gap-2">
            <div>
              <Label htmlFor="c-phone">رقم الهاتف</Label>
              <Input id="c-phone" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="09xxxxxxxx" dir="ltr" />
            </div>
            <div>
              <Label htmlFor="c-wa">واتساب (إن اختلفت)</Label>
              <Input id="c-wa" value={whatsapp} onChange={(e) => setWhatsapp(e.target.value)} placeholder="اختياري" dir="ltr" />
            </div>
          </div>
          <div>
            <Label htmlFor="c-email">البريد الإلكتروني</Label>
            <Input id="c-email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="اختياري" dir="ltr" />
          </div>
          <div className="grid grid-cols-2 gap-2">
            <div>
              <Label htmlFor="c-rel">العلاقة</Label>
              <Select value={relation} onValueChange={setRelation}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="family">عائلة</SelectItem>
                  <SelectItem value="work">عمل</SelectItem>
                  <SelectItem value="friend">صديق</SelectItem>
                  <SelectItem value="other">أخرى</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="c-cat">الفئة</Label>
              <Input id="c-cat" value={category} onChange={(e) => setCategory(e.target.value)} placeholder="مثلاً: أصدقاء العمل" />
            </div>
          </div>
          <div>
            <Label htmlFor="c-note">ملاحظة</Label>
            <Textarea id="c-note" value={note} onChange={(e) => setNote(e.target.value)} rows={2} placeholder="ملاحظات إضافية" />
          </div>
          <div className="flex items-center justify-between rounded-lg border border-border/40 p-2">
            <Label htmlFor="c-fav" className="cursor-pointer">إضافة للمفضلة</Label>
            <Switch id="c-fav" checked={favorite} onCheckedChange={setFavorite} />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>إلغاء</Button>
          <Button onClick={handleSave} className="bg-emerald-glow hover:bg-emerald-glow/90 text-background">
            {editingContact ? "حفظ" : "إضافة"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

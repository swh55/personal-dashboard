"use client";

import * as React from "react";
import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { DynamicIcon } from "../icon";
import { cn } from "@/lib/utils";

interface Suggestion {
  id: number;
  title: string;
  description: string;
  icon: string;
  category: string;
}

const CATEGORIES = [
  { id: "productivity", label: "الإنتاجية", color: "emerald" },
  { id: "business", label: "الأعمال", color: "amber" },
  { id: "finance", label: "المالية", color: "teal" },
  { id: "health", label: "الصحة", color: "rose" },
  { id: "social", label: "الاجتماعي", color: "purple" },
  { id: "smart", label: "ذكاء اصطناعي", color: "emerald" },
  { id: "security", label: "الأمان", color: "amber" },
  { id: "lifestyle", label: "نمط الحياة", color: "rose" },
];

const colorMap: Record<string, string> = {
  emerald: "bg-emerald-glow/10 text-emerald-glow border-emerald-glow/20",
  amber: "bg-amber-glow/10 text-amber-glow border-amber-glow/20",
  rose: "bg-rose-500/10 text-rose-400 border-rose-500/20",
  teal: "bg-teal-500/10 text-teal-400 border-teal-500/20",
  purple: "bg-purple-500/10 text-purple-400 border-purple-500/20",
};

const SUGGESTIONS: Suggestion[] = [
  // الإنتاجية
  { id: 1, title: "مساعد ذكي بالذكاء الاصطناعي", description: "محادثة صوتية لتنظيم المهام والإجابة على الأسئلة", icon: "Sparkles", category: "smart" },
  { id: 2, title: "تقنية بومودورو", description: "مؤقت للتركيز 25 دقيقة عمل و5 دقائق راحة", icon: "Clock", category: "productivity" },
  { id: 3, title: "تحليل الوقت", description: "تتبع الوقت المستغرق في كل مهمة يومياً", icon: "ChartBar", category: "productivity" },
  { id: 4, title: "أهداف سنوية وربعية", description: "وضع أهداف طويلة المدى مع تتبع التقدم", icon: "Target", category: "productivity" },
  { id: 5, title: "قوائم مرجعية", description: "حفظ القوائم المتكررة (سفر، تسوق، اجتماعات)", icon: "List", category: "productivity" },
  { id: 6, title: "تذكيرات ذكية", description: "إشعارات بناءً على الموقع والوقت", icon: "Bell", category: "productivity" },
  { id: 7, title: "وضع التركيز العميق", description: "حجب الإشعارات لفترات تركيز طويلة", icon: "Coffee", category: "productivity" },
  { id: 8, title: "تتبع العادات", description: "بناء عادات يومية مع تتبع الالتزام", icon: "RefreshCw", category: "productivity" },
  { id: 9, title: "تقارير أسبوعية", description: "ملخص آلي لإنجازات الأسبوع", icon: "FileText", category: "productivity" },
  { id: 10, title: "إدارة المشاريع", description: "مشاريع متعددة المراحل مع تتبع التقدم", icon: "Briefcase", category: "business" },
  { id: 11, title: "إدارة الفريق", description: "توزيع المهام على الموظفين وتتبعها", icon: "Users", category: "business" },
  { id: 12, title: "نظام CRM مصغر", description: "إدارة العملاء والمبيعات والاجتماعات", icon: "Building2", category: "business" },
  { id: 13, title: "تتبع المخزون", description: "مراقبة كميات البضائع في المتاجر", icon: "Package", category: "business" },
  { id: 14, title: "فواتير وعروض أسعار", description: "إنشاء فواتير PDF وعرض أسعار للعملاء", icon: "FileText", category: "business" },
  { id: 15, title: "متابعة الديون", description: "تتبع الديون المستحقة لك وعليك", icon: "Wallet", category: "finance" },
  { id: 16, title: "ميزانية شهرية", description: "وضع ميزانية وتتبع المصروفات", icon: "Banknote", category: "finance" },
  { id: 17, title: "تتبع المصروفات", description: "تسجيل المصروفات اليومية بالتصنيفات", icon: "Coins", category: "finance" },
  { id: 18, title: "تنبيهات الأسعار", description: "إشعار عند تغير سعر الذهب أو الدولار", icon: "TrendingUp", category: "finance" },
  { id: 19, title: "محفظة استثمارية", description: "تتبع الأسهم والاستثمارات", icon: "Briefcase", category: "finance" },
  { id: 20, title: "حاسبة الضرائب", description: "حساب الضرائب المستحقة بدقة", icon: "Calculator", category: "finance" },
  { id: 21, title: "تذكير الأدوية", description: "تذكير بمواعيد الأدوية والفيتامينات", icon: "Heart", category: "health" },
  { id: 22, title: "تتبع الوزن", description: "تسجيل الوزن وعرض التغيرات", icon: "TrendingDown", category: "health" },
  { id: 23, title: "تتبع النوم", description: "تسجيل ساعات النوم وجودتها", icon: "Moon", category: "health" },
  { id: 24, title: "تتبع شرب الماء", description: "تذكير بشرب الماء وتسجيل الكمية", icon: "Droplets", category: "health" },
  { id: 25, title: "مذكرات طبية", description: "حفظ نتائج التحاليل والزيارات الطبية", icon: "FileText", category: "health" },
  { id: 26, title: "مواعيد طبية", description: "جدولة المواعيد الطبية للعائلة", icon: "Calendar", category: "health" },
  { id: 27, title: "بطاقات أعمال رقمية", description: "مشاركة بطاقة العمل عبر QR Code", icon: "QrCode", category: "social" },
  { id: 28, title: "تكامل واتساب", description: "إرسال رسائل جماعية للعملاء", icon: "MessageCircle", category: "social" },
  { id: 29, title: "تكامل البريد", description: "قراءة وعرض الإيميلات داخل اللوحة", icon: "Mail", category: "social" },
  { id: 30, title: "تذكير بالتواصل", description: "تذكير بمراسلة الأصدقاء دورياً", icon: "Users", category: "social" },
  { id: 31, title: "خريطة العلاقات", description: "عرض شبكة العلاقات بصرياً", icon: "Share2", category: "social" },
  { id: 32, title: "تقويم هجري كامل", description: "عرض التقويم الهجري بجانب الميلادي", icon: "Moon", category: "lifestyle" },
  { id: 33, title: "أذكار الصباح والمساء", description: "تذكير بالأذكار وعرضها", icon: "Sparkles", category: "lifestyle" },
  { id: 34, title: "ختمة القرآن", description: "تتبع تلاوة القرآن ووضع ختمة", icon: "Book", category: "lifestyle" },
  { id: 35, title: "تتبع الصيام", description: "تسجيل أيام الصيام التطوع", icon: "Sunrise", category: "lifestyle" },
  { id: 36, title: "موقع القبلة", description: "تحديد اتجاه القبلة في أي مكان", icon: "Compass", category: "lifestyle" },
  { id: 37, title: "مكتبة كتب", description: "قائمة كتب للقراءة مع التقييم", icon: "Book", category: "lifestyle" },
  { id: 38, title: "تتبع السفر", description: "تخطيط الرحلات وحجز التذاكر", icon: "Plane", category: "lifestyle" },
  { id: 39, title: "مذكرات شخصية", description: "كتابة يوميات مع تأمين بالبصمة", icon: "StickyNote", category: "lifestyle" },
  { id: 40, title: "تخطيط الوجبات", description: "قائمة وجبات أسبوعية مع المكونات", icon: "Coffee", category: "lifestyle" },
  { id: 41, title: "قائمة الأمنيات", description: "حفظ الأشياء التي ترغب بشرائها", icon: "Star", category: "lifestyle" },
  { id: 42, title: "مولد تقارير PDF", description: "تصدير أي بيانات إلى PDF", icon: "FileText", category: "productivity" },
  { id: 43, title: "تكامل Google Calendar", description: "مزامنة مع تقويم جوجل", icon: "Calendar", category: "productivity" },
  { id: 44, title: "وضع عدم الإزعاج", description: "كتم الإشعارات في أوقات محددة", icon: "Bell", category: "productivity" },
  { id: 45, title: "اختصارات لوحة المفاتيح", description: "تنقل سريع عبر اختصارات", icon: "Keyboard", category: "productivity" },
  { id: 46, title: "سلة المحذوفات", description: "استعادة العناصر المحذوفة", icon: "Trash2", category: "productivity" },
  { id: 47, title: "بحث شامل", description: "بحث في كل البيانات دفعة واحدة", icon: "Search", category: "productivity" },
  { id: 48, title: "تكامل WhatsApp Business", description: "إدارة محادثات واتساب للأعمال", icon: "MessageCircle", category: "business" },
  { id: 49, title: "نظام نقاط ولاء", description: "نقاط للعملاء المتكررين", icon: "Star", category: "business" },
  { id: 50, title: "تحليلات المبيعات", description: "رسوم بيانية للمبيعات والأرباح", icon: "ChartBar", category: "business" },
  { id: 51, title: "إدارة العقود", description: "حفظ وتذكير بانتهاء العقود", icon: "FileText", category: "business" },
  { id: 52, title: "تتبع الشحنات", description: "متابعة الطلبات والشحنات", icon: "Package", category: "business" },
  { id: 53, title: "نظام طلبات", description: "استقبال وإدارة طلبات العملاء", icon: "ShoppingCart", category: "business" },
  { id: 54, title: "مؤشرات أداء KPIs", description: "عرض مؤشرات الأداء الرئيسية", icon: "TrendingUp", category: "business" },
  { id: 55, title: "مخطط زمني للمشاريع", description: "Gantt chart للمشاريع", icon: "Calendar", category: "business" },
  { id: 56, title: "تسجيل الدخول بالبصمة", description: "حماية إضافية بالبصمة/PIN", icon: "Lock", category: "security" },
  { id: 57, title: "تشفير البيانات", description: "تشفير المعلومات الحساسة", icon: "Lock", category: "security" },
  { id: 58, title: "نسخ احتياطي تلقائي", description: "حفظ نسخة من البيانات يومياً", icon: "Download", category: "security" },
  { id: 59, title: "سجل النشاط", description: "تتبع كل التغييرات في النظام", icon: "Eye", category: "security" },
  { id: 60, title: "وضع الضيف", description: "وصول محدود بدون بيانات حساسة", icon: "User", category: "security" },
  { id: 61, title: "تكامل AI لتحليل البيانات", description: "تحليل ذكي للأنماط والتنبؤ", icon: "Sparkles", category: "smart" },
  { id: 62, title: "تلخيص ذكي للرسائل", description: "تلخيص الإيميلات والمحادثات", icon: "Sparkles", category: "smart" },
  { id: 63, title: "اقتراحات ذكية للمهام", description: "اقتراح مهام بناءً على نمط حياتك", icon: "Sparkles", category: "smart" },
  { id: 64, title: "ترجمة فورية", description: "ترجمة النصوص بين اللغات", icon: "Languages", category: "smart" },
  { id: 65, title: "تحويل الصوت لنص", description: "كتابة الملاحظات صوتياً", icon: "Mic", category: "smart" },
  { id: 66, title: "تحويل النص لصوت", description: "قراءة الملاحظات والمهام", icon: "Volume2", category: "smart" },
  { id: 67, title: "تحليل الصور", description: "استخراج نص من الصور OCR", icon: "Camera", category: "smart" },
  { id: 68, title: "مساعد محادثة Chatbot", description: "محادثة ذكية للأسئلة الشائعة", icon: "MessageSquare", category: "smart" },
  { id: 69, title: "توليد أفكار", description: "اقتراح أفكار للمشاريع الجديدة", icon: "Lightbulb", category: "smart" },
  { id: 70, title: "تنبيهات ذكية للطقس", description: "إشعارات عند العواصف أو الحرارة", icon: "Cloud", category: "lifestyle" },
  { id: 71, title: "تتبع الأسعار", description: "مراقبة أسعار منتجات محددة", icon: "Tag", category: "finance" },
  { id: 72, title: "ميزة الوضع الليلي التلقائي", description: "تبديل تلقائي حسب الوقت", icon: "Moon", category: "lifestyle" },
  { id: 73, title: "واجهة قابلة للتخصيص", description: "تغيير الألوان والتخطيط", icon: "Palette", category: "lifestyle" },
  { id: 74, title: "اختصارات سريعة", description: "أزرار عائمة للأجراءات الشائعة", icon: "Zap", category: "productivity" },
  { id: 75, title: "تكامل Slack", description: "إشعارات الفريق", icon: "MessageSquare", category: "business" },
  { id: 76, title: "تكامل Telegram", description: "بوت تيليجرام للإشعارات", icon: "Send", category: "social" },
  { id: 77, title: "تقويم موسمي", description: "عرض المواسم والأحداث الموسمية", icon: "Calendar", category: "lifestyle" },
  { id: 78, title: "مؤشر الإنتاجية", description: "درجة يومية للإنتاجية", icon: "TrendingUp", category: "productivity" },
  { id: 79, title: "تتبع المواعيد النهائية", description: "تحذيرات قبل المواعيد الحرجة", icon: "AlertCircle", category: "productivity" },
  { id: 80, title: "إدارة الاجتماعات", description: "جدولة ومحاضر الاجتماعات", icon: "Users", category: "business" },
  { id: 81, title: "تسجيل صوتي للمحاضرات", description: "تسجيل وتخزين المحاضرات", icon: "Mic", category: "lifestyle" },
  { id: 82, title: "خرائط ذهنية", description: "إنشاء خرائط ذهنية للأفكار", icon: "Share2", category: "productivity" },
  { id: 83, title: "قوالب جاهزة", description: "قوالب للمهام والاجتماعات", icon: "Layout", category: "productivity" },
  { id: 84, title: "مزامنة سحابية", description: "مزامنة البيانات عبر الأجهزة", icon: "Cloud", category: "security" },
  { id: 85, title: "وضع القراءة", description: "واجهة مريحة للقراءة الطويلة", icon: "Book", category: "lifestyle" },
  { id: 86, title: "تكامل Zapier", description: "أتمتة المهام مع خدمات أخرى", icon: "Zap", category: "productivity" },
  { id: 87, title: "كشف المعادلات", description: "تحويل الصور لمعادلات", icon: "Calculator", category: "smart" },
  { id: 88, title: "مذكّر بالمناسبات الدينية", description: "تنبيهات بالمناسبات الإسلامية", icon: "Moon", category: "lifestyle" },
  { id: 89, title: "ميزة العثور على الجهاز", description: "تحديد موقع الجهاز المفقود", icon: "MapPin", category: "security" },
  { id: 90, title: "قفل التطبيقات", description: "حماية التطبيقات الحساسة", icon: "Lock", category: "security" },
  { id: 91, title: "تتبع المصاريف المشتركة", description: "تقسيم الفواتير بين الأشخاص", icon: "Users", category: "finance" },
  { id: 92, title: "حاسبة العملات الرقمية", description: "تتبع الكريبتو", icon: "Coins", category: "finance" },
  { id: 93, title: "تنظيم الملفات", description: "تصنيف المستندات والملفات", icon: "Folder", category: "productivity" },
  { id: 94, title: "تكامل مع Google Drive", description: "الوصول للملفات السحابية", icon: "Cloud", category: "productivity" },
  { id: 95, title: "مؤقت متعدد", description: "عدة مؤقتات تعمل معاً", icon: "Clock", category: "productivity" },
  { id: 96, title: "تتبع العادات السيئة", description: "مراقبة وتقليل العادات السلبية", icon: "AlertCircle", category: "health" },
  { id: 97, title: "مكافآت الإنجاز", description: "نقاط ومكافآت عند إكمال المهام", icon: "Trophy", category: "productivity" },
  { id: 98, title: "تقويم أسري مشترك", description: "مشاركة المهام مع العائلة", icon: "Users", category: "social" },
  { id: 99, title: "تحليل المزاج", description: "تتبع الحالة المزاجية يومياً", icon: "Heart", category: "health" },
  { id: 100, title: "وضع الطوارئ", description: "وصول سريع لأرقام الطوارئ والمعلومات الحيوية", icon: "AlertCircle", category: "security" },
];

export function SuggestionsSection() {
  const [search, setSearch] = React.useState("");
  const [activeCategory, setActiveCategory] = React.useState<string>("all");

  const filtered = SUGGESTIONS.filter((s) => {
    const matchSearch = !search || s.title.includes(search) || s.description.includes(search);
    const matchCat = activeCategory === "all" || s.category === activeCategory;
    return matchSearch && matchCat;
  });

  return (
    <div className="space-y-2">
      {/* Header */}
      <Card className="glass-strong p-2 relative overflow-hidden">
        <div className="absolute -top-12 -left-12 h-20 w-20 rounded-full bg-emerald-glow/10 blur-3xl" />
        <div className="relative flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-gradient-to-br from-emerald-glow to-amber-glow text-background">
            <DynamicIcon name="Sparkles" className="h-6 w-6" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-foreground">100 ميزة إضافية مقترحة</h2>
            <p className="text-xs text-muted-foreground">
              أفكار لتطوير لوحة التحكم وجعلها أكثر قوة وذكاءً
            </p>
          </div>
        </div>
      </Card>

      {/* Search + filters */}
      <Card className="glass p-2.5">
        <Input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="ابحث في الاقتراحات..."
          className="bg-background/50 mb-1.5"
        />
        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => setActiveCategory("all")}
            className={cn(
              "px-3 py-1.5 text-xs rounded-lg border transition-all",
              activeCategory === "all"
                ? "bg-emerald-glow/15 text-emerald-glow border-emerald-glow/30"
                : "bg-background/40 text-muted-foreground border-border/40"
            )}
          >
            الكل ({SUGGESTIONS.length})
          </button>
          {CATEGORIES.map((cat) => {
            const count = SUGGESTIONS.filter((s) => s.category === cat.id).length;
            return (
              <button
                key={cat.id}
                onClick={() => setActiveCategory(cat.id)}
                className={cn(
                  "px-3 py-1.5 text-xs rounded-lg border transition-all",
                  activeCategory === cat.id
                    ? cn(colorMap[cat.color], "border-current/30")
                    : "bg-background/40 text-muted-foreground border-border/40"
                )}
              >
                {cat.label} ({count})
              </button>
            );
          })}
        </div>
      </Card>

      {/* Suggestions grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
        {filtered.map((suggestion, i) => {
          const cat = CATEGORIES.find((c) => c.id === suggestion.category) || CATEGORIES[0];
          return (
            <motion.div
              key={suggestion.id}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: Math.min(i * 0.02, 0.5) }}
            >
              <Card className="glass p-2.5 hover:border-emerald-glow/30 transition-all group h-full">
                <div className="flex items-start gap-2">
                  <div className={cn(
                    "flex h-7 w-7 items-center justify-center rounded-xl shrink-0 border",
                    colorMap[cat.color]
                  )}>
                    <DynamicIcon name={suggestion.icon} className="h-5 w-5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2">
                      <h3 className="text-sm font-bold text-foreground">{suggestion.title}</h3>
                      <span className="text-[10px] text-muted-foreground/60 font-mono shrink-0">
                        #{suggestion.id}
                      </span>
                    </div>
                    <p className="text-xs text-muted-foreground mt-1 line-clamp-2">
                      {suggestion.description}
                    </p>
                    <span className={cn(
                      "inline-block mt-2 text-[10px] px-2 py-0.5 rounded-full",
                      colorMap[cat.color]
                    )}>
                      {cat.label}
                    </span>
                  </div>
                </div>
              </Card>
            </motion.div>
          );
        })}
      </div>

      {filtered.length === 0 && (
        <Card className="glass p-12">
          <div className="flex flex-col items-center justify-center text-center">
            <DynamicIcon name="Search" className="h-8 w-8 text-muted-foreground mb-2" />
            <p className="text-sm text-muted-foreground">لا نتائج مطابقة</p>
          </div>
        </Card>
      )}
    </div>
  );
}

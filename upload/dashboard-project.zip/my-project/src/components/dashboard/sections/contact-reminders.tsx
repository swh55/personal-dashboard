"use client";

import * as React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { DynamicIcon } from "../icon";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { format } from "date-fns";
import { ar } from "date-fns/locale";
import { formatSyrianDate, SYRIAN_MONTHS } from "@/lib/syrian-date";

// Google brand colors
const G_BLUE = "#4285F4";
const G_RED = "#EA4335";
const G_YELLOW = "#FBBC04";
const G_GREEN = "#34A853";
const G_ORANGE = "#FF6D00";
const G_PURPLE = "#A142F4";
const G_TEAL = "#00897B";

interface Contact {
  id: string;
  name: string;
  phone: string;
  relation: string;
}

interface ContactReminder {
  id: string;
  contactId: string | null;
  contactName: string;
  frequency: string; // daily | weekly | monthly
  lastContacted: string | null;
  nextReminder: string | null;
  active: boolean;
  overdue: boolean;
  daysUntilDue: number | null;
}

const freqMeta: Record<string, { label: string; icon: string; color: string }> = {
  daily: { label: "يومياً", icon: "Clock", color: G_RED },
  weekly: { label: "أسبوعياً", icon: "Calendar", color: G_BLUE },
  monthly: { label: "شهرياً", icon: "CalendarDays", color: G_PURPLE },
};

// Group colors by relation
const relationColors: Record<string, string> = {
  family: G_RED,
  work: G_BLUE,
  friend: G_YELLOW,
  other: G_TEAL,
};

function daysColor(days: number | null): string {
  if (days === null) return "#9AA0A6";
  if (days < 0) return G_RED; // overdue
  if (days < 3) return G_RED;
  if (days <= 7) return G_YELLOW;
  return G_GREEN;
}

function daysLabel(days: number | null): string {
  if (days === null) return "—";
  if (days < 0) return `متأخر ${Math.abs(days)} يوم`;
  if (days === 0) return "اليوم";
  if (days === 1) return "غداً";
  return `بعد ${days} يوم`;
}

export function ContactRemindersSection() {
  const { toast } = useToast();
  const [reminders, setReminders] = React.useState<ContactReminder[]>([]);
  const [contacts, setContacts] = React.useState<Contact[]>([]);
  const [loading, setLoading] = React.useState(true);

  // New reminder form
  const [selectedContactId, setSelectedContactId] = React.useState<string>("");
  const [selectedContactName, setSelectedContactName] = React.useState<string>("");
  const [frequency, setFrequency] = React.useState<string>("weekly");
  const [creating, setCreating] = React.useState(false);
  const [callingId, setCallingId] = React.useState<string | null>(null);

  const fetchReminders = React.useCallback(async () => {
    try {
      const res = await fetch("/api/contact-reminders");
      const json = await res.json();
      if (json.success) setReminders(json.data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, []);

  const fetchContacts = React.useCallback(async () => {
    try {
      const res = await fetch("/api/contacts");
      const json = await res.json();
      if (json.success) setContacts(json.data);
    } catch (e) {
      console.error(e);
    }
  }, []);

  React.useEffect(() => {
    fetchReminders();
    fetchContacts();
  }, [fetchReminders, fetchContacts]);

  const handleAdd = async () => {
    if (!selectedContactName) {
      toast({ title: "اختر جهة اتصال", variant: "destructive" });
      return;
    }
    setCreating(true);
    try {
      const res = await fetch("/api/contact-reminders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contactId: selectedContactId || null,
          contactName: selectedContactName,
          frequency,
        }),
      });
      const json = await res.json();
      if (json.success) {
        toast({ title: "تم إضافة التذكير ✓" });
        setSelectedContactId(""); setSelectedContactName(""); setFrequency("weekly");
        fetchReminders();
      } else {
        toast({ title: json.error || "فشل الإضافة", variant: "destructive" });
      }
    } catch {
      toast({ title: "فشل الإضافة", variant: "destructive" });
    } finally {
      setCreating(false);
    }
  };

  const handleCalled = async (r: ContactReminder) => {
    setCallingId(r.id);
    try {
      await fetch("/api/contact-reminders", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: r.id, lastContacted: new Date().toISOString() }),
      });
      toast({ title: `تم تسجيل التواصل مع ${r.contactName} ✓` });
      fetchReminders();
    } catch {
      toast({ title: "فشل التحديث", variant: "destructive" });
    } finally {
      setCallingId(null);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await fetch(`/api/contact-reminders?id=${id}`, { method: "DELETE" });
      toast({ title: "تم حذف التذكير" });
      fetchReminders();
    } catch {
      toast({ title: "فشل الحذف", variant: "destructive" });
    }
  };

  const overdueCount = reminders.filter((r) => r.overdue).length;
  const dueSoonCount = reminders.filter(
    (r) => !r.overdue && r.daysUntilDue !== null && r.daysUntilDue <= 3
  ).length;

  // Build a relation map: contacts grouped by relation for the visual map
  const relationGroups = React.useMemo(() => {
    const groups: Record<string, Contact[]> = { family: [], work: [], friend: [], other: [] };
    contacts.forEach((c) => {
      const key = c.relation in groups ? c.relation : "other";
      groups[key].push(c);
    });
    return groups;
  }, [contacts]);

  return (
    <div className="space-y-1.5">
      {/* Summary header */}
      <Card className="p-2" style={{ backgroundColor: "var(--surface-container)" }}>
        <div className="flex items-center gap-1.5">
          <div
            className="flex h-7 w-7 items-center justify-center rounded-lg"
            style={{ backgroundColor: `${G_RED}22`, color: G_RED }}
          >
            <DynamicIcon name="BellRing" className="h-4 w-4" />
          </div>
          <div className="flex-1">
            <p className="text-xs font-bold text-foreground">تذكيرات التواصل</p>
            <p className="text-[10px] text-muted-foreground">حافظ على تواصلك الدوري مع الجميع</p>
          </div>
          <div className="flex gap-1">
            {overdueCount > 0 && (
              <span
                className="text-[10px] font-mono px-1.5 py-0.5 rounded-full"
                style={{ backgroundColor: `${G_RED}22`, color: G_RED }}
              >
                {overdueCount} متأخر
              </span>
            )}
            <span
              className="text-[10px] font-mono px-1.5 py-0.5 rounded-full"
              style={{ backgroundColor: `${G_YELLOW}22`, color: G_YELLOW }}
            >
              {dueSoonCount} قريبة
            </span>
          </div>
        </div>
      </Card>

      {/* Visual relationship map */}
      <Card className="p-2" style={{ backgroundColor: "var(--surface-container)" }}>
        <div className="flex items-center gap-1.5 mb-1.5">
          <div
            className="flex h-6 w-6 items-center justify-center rounded-lg"
            style={{ backgroundColor: `${G_PURPLE}22`, color: G_PURPLE }}
          >
            <DynamicIcon name="Users" className="h-3.5 w-3.5" />
          </div>
          <h3 className="text-xs font-bold text-foreground">خريطة العلاقات</h3>
        </div>
        <RelationshipMap groups={relationGroups} />
      </Card>

      {/* New reminder form */}
      <Card className="p-2" style={{ backgroundColor: "var(--surface-container)" }}>
        <div className="flex items-center gap-1.5 mb-1.5">
          <div
            className="flex h-6 w-6 items-center justify-center rounded-lg"
            style={{ backgroundColor: `${G_GREEN}22`, color: G_GREEN }}
          >
            <DynamicIcon name="Plus" className="h-3.5 w-3.5" />
          </div>
          <h3 className="text-xs font-bold text-foreground">إضافة تذكير جديد</h3>
        </div>

        <div className="space-y-1.5">
          <div>
            <label className="text-[10px]">اختر جهة الاتصال</label>
            <Select
              value={selectedContactId}
              onValueChange={(v) => {
                setSelectedContactId(v);
                const c = contacts.find((c) => c.id === v);
                if (c) setSelectedContactName(c.name);
              }}
            >
              <SelectTrigger className="mt-0.5">
                <SelectValue placeholder="اختر جهة اتصال..." />
              </SelectTrigger>
              <SelectContent>
                {contacts.length === 0 ? (
                  <SelectItem value="_none" disabled>لا جهات اتصال</SelectItem>
                ) : (
                  contacts.map((c) => (
                    <SelectItem key={c.id} value={c.id}>
                      <div className="flex items-center gap-1.5">
                        <span
                          className="h-1.5 w-1.5 rounded-full"
                          style={{ backgroundColor: relationColors[c.relation] || G_TEAL }}
                        />
                        {c.name}
                      </div>
                    </SelectItem>
                  ))
                )}
              </SelectContent>
            </Select>
          </div>
          <div>
            <label className="text-[10px]">تكرار التذكير</label>
            <div className="flex gap-1 mt-0.5">
              {Object.entries(freqMeta).map(([id, meta]) => (
                <button
                  key={id}
                  onClick={() => setFrequency(id)}
                  className={cn(
                    "flex-1 h-7 rounded-md text-[10px] font-medium transition-all flex items-center justify-center gap-1",
                    frequency === id ? "scale-105" : "opacity-70 hover:opacity-100"
                  )}
                  style={{
                    backgroundColor: frequency === id ? meta.color : `${meta.color}22`,
                    color: frequency === id ? "#fff" : meta.color,
                  }}
                >
                  <DynamicIcon name={meta.icon} className="h-3 w-3" />
                  {meta.label}
                </button>
              ))}
            </div>
          </div>
          <Button
            size="sm"
            className="w-full"
            onClick={handleAdd}
            disabled={creating}
            style={{ backgroundColor: G_GREEN, color: "#fff" }}
          >
            {creating ? (
              <DynamicIcon name="Loader2" className="h-3.5 w-3.5 animate-spin" />
            ) : (
              <DynamicIcon name="Plus" className="h-3.5 w-3.5" />
            )}
            إضافة التذكير
          </Button>
        </div>
      </Card>

      {/* Reminders list */}
      <Card className="p-2" style={{ backgroundColor: "var(--surface-container)" }}>
        <div className="flex items-center justify-between mb-1.5">
          <div className="flex items-center gap-1.5">
            <div
              className="flex h-6 w-6 items-center justify-center rounded-lg"
              style={{ backgroundColor: `${G_BLUE}22`, color: G_BLUE }}
            >
              <DynamicIcon name="BellRing" className="h-3.5 w-3.5" />
            </div>
            <h3 className="text-xs font-bold text-foreground">التذكيرات النشطة</h3>
          </div>
          <span className="text-[10px] text-muted-foreground">{reminders.length} تذكير</span>
        </div>

        {loading ? (
          <div className="space-y-1.5">
            {Array.from({ length: 3 }).map((_, i) => (
              <Skeleton key={i} className="h-14 rounded-lg" />
            ))}
          </div>
        ) : reminders.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-4 text-center">
            <div
              className="flex h-10 w-10 items-center justify-center rounded-full mb-1.5"
              style={{ backgroundColor: `${G_RED}22`, color: G_RED }}
            >
              <DynamicIcon name="BellRing" className="h-5 w-5" />
            </div>
            <p className="text-xs font-medium text-foreground">لا تذكيرات تواصل</p>
            <p className="text-[10px] text-muted-foreground mt-0.5">أضف تذكيراً للتواصل الدوري</p>
          </div>
        ) : (
          <div className="space-y-1 max-h-96 overflow-y-auto custom-scroll">
            <AnimatePresence>
              {reminders.map((r, i) => {
                const meta = freqMeta[r.frequency] || freqMeta.weekly;
                const dColor = daysColor(r.daysUntilDue);
                // try to find contact relation color
                const linkedContact = contacts.find((c) => c.id === r.contactId);
                const dotColor = linkedContact
                  ? relationColors[linkedContact.relation] || G_TEAL
                  : G_BLUE;
                return (
                  <motion.div
                    key={r.id}
                    layout
                    initial={{ opacity: 0, y: 6 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, x: -10 }}
                    transition={{ delay: i * 0.03 }}
                    className="group rounded-lg p-1.5"
                    style={{
                      backgroundColor: r.overdue ? `${G_RED}10` : "var(--surface-container-high)",
                      borderRight: `3px solid ${dColor}`,
                    }}
                  >
                    <div className="flex items-start gap-1.5">
                      <div
                        className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full font-bold text-[11px]"
                        style={{ backgroundColor: `${dotColor}22`, color: dotColor }}
                      >
                        {r.contactName[0]}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <p className="text-xs font-bold text-foreground truncate">{r.contactName}</p>
                          <span
                            className="flex items-center gap-0.5 text-[9px] px-1 py-0.5 rounded-full shrink-0"
                            style={{ backgroundColor: `${meta.color}22`, color: meta.color }}
                          >
                            <DynamicIcon name={meta.icon} className="h-2.5 w-2.5" />
                            {meta.label}
                          </span>
                        </div>
                        <div className="flex items-center gap-1.5 mt-0.5">
                          <span
                            className="text-[10px] font-bold"
                            style={{ color: dColor }}
                          >
                            <DynamicIcon name="Clock" className="h-2.5 w-2.5 inline ml-0.5" />
                            {daysLabel(r.daysUntilDue)}
                          </span>
                          {r.lastContacted && (
                            <span className="text-[9px] text-muted-foreground">
                              آخر تواصل: {format(new Date(r.lastContacted), "d MMM", { locale: ar })}
                            </span>
                          )}
                        </div>
                        {r.nextReminder && (
                          <p className="text-[9px] text-muted-foreground mt-0.5">
                            التذكير القادم: {formatSyrianDate(new Date(r.nextReminder), "EEEE d MMMM")}
                          </p>
                        )}
                      </div>
                      <div className="flex flex-col gap-1 shrink-0">
                        <Button
                          size="sm"
                          className="h-6 px-2 text-[10px]"
                          disabled={callingId === r.id}
                          onClick={() => handleCalled(r)}
                          style={{ backgroundColor: G_GREEN, color: "#fff" }}
                        >
                          {callingId === r.id ? (
                            <DynamicIcon name="Loader2" className="h-2.5 w-2.5 animate-spin" />
                          ) : (
                            <DynamicIcon name="Phone" className="h-2.5 w-2.5" />
                          )}
                          اتصلت
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          className="h-6 w-6 p-0 opacity-0 group-hover:opacity-100 hover:text-red-400"
                          onClick={() => handleDelete(r.id)}
                        >
                          <DynamicIcon name="Trash2" className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                  </motion.div>
                );
              })}
            </AnimatePresence>
          </div>
        )}
      </Card>
    </div>
  );
}

/* ---------------- Visual relationship map (SVG) ---------------- */
function RelationshipMap({ groups }: { groups: Record<string, Contact[]> }) {
  const W = 320;
  const H = 140;
  const cx = W / 2;
  const cy = H / 2;

  const groupKeys = ["family", "work", "friend", "other"];
  const groupLabels: Record<string, string> = {
    family: "العائلة",
    work: "العمل",
    friend: "أصدقاء",
    other: "أخرى",
  };

  // Position each group around a circle
  const angleFor: Record<string, number> = {
    family: -Math.PI / 2,      // top
    work: 0,                   // right
    friend: Math.PI / 2,       // bottom
    other: Math.PI,            // left
  };

  const R = 50; // radius from center

  return (
    <div className="w-full overflow-x-auto">
      <svg viewBox={`0 0 ${W} ${H}`} className="w-full" style={{ minWidth: 260, maxHeight: 160 }}>
        {/* Center "me" node */}
        <circle cx={cx} cy={cy} r={12} fill={G_BLUE} opacity={0.85} />
        <text x={cx} y={cy + 3} textAnchor="middle" fontSize={8} fill="#fff" fontWeight="bold">أنا</text>

        {/* For each group, draw the cluster + lines */}
        {groupKeys.map((key) => {
          const arr = groups[key] || [];
          if (arr.length === 0) return null;
          const baseAngle = angleFor[key];
          const clusterX = cx + R * Math.cos(baseAngle);
          const clusterY = cy + R * Math.sin(baseAngle);
          const color = relationColors[key];
          return (
            <g key={key}>
              {/* Line from center to cluster */}
              <line
                x1={cx}
                y1={cy}
                x2={clusterX}
                y2={clusterY}
                stroke={color}
                strokeWidth={1.5}
                strokeDasharray="3 2"
                opacity={0.55}
              />
              {/* Group center node */}
              <circle cx={clusterX} cy={clusterY} r={9} fill={color} opacity={0.9} />
              <text
                x={clusterX}
                y={clusterY + 2}
                textAnchor="middle"
                fontSize={7}
                fill="#fff"
                fontWeight="bold"
              >
                {arr.length}
              </text>
              <text
                x={clusterX}
                y={clusterY + (baseAngle > 0 ? 18 : -12)}
                textAnchor="middle"
                fontSize={7}
                fill={color}
                fontWeight="bold"
              >
                {groupLabels[key]}
              </text>

              {/* Mini contacts around the cluster */}
              {arr.slice(0, 6).map((c, i) => {
                const a = baseAngle + (i - (Math.min(arr.length, 6) - 1) / 2) * 0.35;
                const r2 = 22;
                const px = clusterX + r2 * Math.cos(a);
                const py = clusterY + r2 * Math.sin(a);
                return (
                  <g key={c.id}>
                    <line x1={clusterX} y1={clusterY} x2={px} y2={py} stroke={color} strokeWidth={0.5} opacity={0.4} />
                    <circle cx={px} cy={py} r={4} fill={color} opacity={0.75} />
                    <text x={px} y={py - 6} textAnchor="middle" fontSize={5} fill="currentColor" opacity={0.7}>
                      {c.name.slice(0, 6)}
                    </text>
                  </g>
                );
              })}
              {arr.length > 6 && (
                <text
                  x={clusterX + 22 * Math.cos(baseAngle)}
                  y={clusterY + 22 * Math.sin(baseAngle) + 2}
                  textAnchor="middle"
                  fontSize={6}
                  fill={color}
                  opacity={0.7}
                >
                  +{arr.length - 6}
                </text>
              )}
            </g>
          );
        })}
      </svg>
      {/* Legend */}
      <div className="flex flex-wrap items-center justify-center gap-1 mt-1">
        {groupKeys.map((k) => (
          <span key={k} className="flex items-center gap-0.5 text-[9px] text-muted-foreground">
            <span
              className="h-1.5 w-1.5 rounded-full inline-block"
              style={{ backgroundColor: relationColors[k] }}
            />
            {groupLabels[k]} ({(groups[k] || []).length})
          </span>
        ))}
      </div>
    </div>
  );
}

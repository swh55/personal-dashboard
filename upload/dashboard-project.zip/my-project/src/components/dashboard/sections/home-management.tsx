"use client";

import * as React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { DynamicIcon } from "../icon";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { format, differenceInCalendarDays, isPast, isToday } from "date-fns";
import { ar } from "date-fns/locale";

// Google brand colors
const G_BLUE = "#4285F4";
const G_RED = "#EA4335";
const G_YELLOW = "#FBBC04";
const G_GREEN = "#34A853";
const G_ORANGE = "#FF6D00";
const G_PURPLE = "#A142F4";
const G_TEAL = "#00897B";
const G_GRAY = "#5F6368";

type Tab = "bills" | "maintenance" | "pantry" | "subscriptions";

const TABS: Array<{ id: Tab; label: string; icon: string; color: string }> = [
  { id: "bills", label: "الفواتير", icon: "Receipt", color: G_RED },
  { id: "maintenance", label: "الصيانة", icon: "Wrench", color: G_ORANGE },
  { id: "pantry", label: "المخزون", icon: "Package", color: G_GREEN },
  { id: "subscriptions", label: "الاشتراكات", icon: "RefreshCw", color: G_BLUE },
];

export function HomeManagementSection() {
  const [tab, setTab] = React.useState<Tab>("bills");

  return (
    <div className="space-y-1.5">
      {/* Header */}
      <Card className="p-2" style={{ backgroundColor: "var(--surface-container)" }}>
        <div className="flex items-center gap-1.5">
          <div
            className="flex h-7 w-7 items-center justify-center rounded-lg"
            style={{ backgroundColor: `${G_TEAL}22`, color: G_TEAL }}
          >
            <DynamicIcon name="Home" className="h-4 w-4" />
          </div>
          <div className="flex-1">
            <p className="text-xs font-bold text-foreground">إدارة المنزل</p>
            <p className="text-[10px] text-muted-foreground">
              الفواتير · الصيانة · المخزون · الاشتراكات
            </p>
          </div>
        </div>
      </Card>

      {/* Tabs */}
      <Card className="p-1" style={{ backgroundColor: "var(--surface-container)" }}>
        <div className="grid grid-cols-4 gap-0.5">
          {TABS.map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={cn(
                "flex flex-col items-center gap-0.5 py-1.5 rounded-lg transition-all text-[10px] font-medium",
                tab === t.id ? "text-foreground" : "text-muted-foreground hover:text-foreground"
              )}
              style={tab === t.id ? { backgroundColor: `${t.color}22`, color: t.color } : {}}
            >
              <DynamicIcon name={t.icon} className="h-3.5 w-3.5" />
              <span className="leading-tight text-center">{t.label}</span>
            </button>
          ))}
        </div>
      </Card>

      {/* Tab content */}
      <AnimatePresence mode="wait">
        <motion.div
          key={tab}
          initial={{ opacity: 0, y: 6 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -6 }}
          transition={{ duration: 0.15 }}
        >
          {tab === "bills" && <BillsTab />}
          {tab === "maintenance" && <MaintenanceTab />}
          {tab === "pantry" && <PantryTab />}
          {tab === "subscriptions" && <SubscriptionsTab />}
        </motion.div>
      </AnimatePresence>
    </div>
  );
}

// ============================================================
// 1) BILLS TAB
// ============================================================
interface Bill {
  id: string;
  type: string;
  amount: number;
  dueDate: string;
  paid: boolean;
  paidAt: string | null;
  note: string | null;
}

const BILL_TYPES: Array<{ value: string; label: string; icon: string; color: string }> = [
  { value: "electricity", label: "كهرباء", icon: "Zap", color: G_YELLOW },
  { value: "water", label: "مياه", icon: "Droplets", color: G_BLUE },
  { value: "internet", label: "إنترنت", icon: "Globe", color: G_TEAL },
  { value: "phone", label: "هاتف", icon: "Phone", color: G_GREEN },
  { value: "gas", label: "غاز", icon: "Flame", color: G_RED },
  { value: "other", label: "أخرى", icon: "Receipt", color: G_GRAY },
];

function billMeta(type: string) {
  return BILL_TYPES.find((b) => b.value === type) || BILL_TYPES[BILL_TYPES.length - 1];
}

function formatAmount(n: number) {
  if (Math.abs(n) >= 1_000_000) return (n / 1_000_000).toFixed(1) + "M";
  if (Math.abs(n) >= 1000) return (n / 1000).toFixed(1) + "K";
  return Math.round(n).toLocaleString("en-US");
}

function billStatus(bill: Bill): { color: string; label: string; bg: string } {
  if (bill.paid) return { color: G_GREEN, label: "مدفوع", bg: `${G_GREEN}22` };
  const due = new Date(bill.dueDate);
  if (isPast(due) && !isToday(due))
    return { color: G_RED, label: "متأخرة", bg: `${G_RED}22` };
  const days = differenceInCalendarDays(due, new Date());
  if (days <= 3) return { color: G_YELLOW, label: "قريبة", bg: `${G_YELLOW}22` };
  return { color: G_BLUE, label: "قادمة", bg: `${G_BLUE}22` };
}

function BillsTab() {
  const { toast } = useToast();
  const [bills, setBills] = React.useState<Bill[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [dialogOpen, setDialogOpen] = React.useState(false);
  const [editing, setEditing] = React.useState<Bill | null>(null);

  const fetchBills = React.useCallback(async () => {
    try {
      const res = await fetch("/api/utility-bills");
      const json = await res.json();
      if (json.success) setBills(json.data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, []);

  React.useEffect(() => {
    fetchBills();
  }, [fetchBills]);

  const totalUnpaid = bills.filter((b) => !b.paid).reduce((s, b) => s + b.amount, 0);
  const overdueCount = bills.filter(
    (b) => !b.paid && isPast(new Date(b.dueDate)) && !isToday(new Date(b.dueDate))
  ).length;

  const handleTogglePaid = async (bill: Bill) => {
    await fetch("/api/utility-bills", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: bill.id, paid: !bill.paid }),
    });
    toast({ title: bill.paid ? "تم إلغاء الدفع" : "تم تسجيل الدفع ✓" });
    fetchBills();
  };

  const handleDelete = async (id: string) => {
    await fetch(`/api/utility-bills?id=${id}`, { method: "DELETE" });
    toast({ title: "تم حذف الفاتورة" });
    fetchBills();
  };

  return (
    <div className="space-y-1.5">
      {/* Total unpaid summary */}
      <div className="grid grid-cols-2 gap-1.5">
        <motion.div initial={{ opacity: 0, y: 4 }} animate={{ opacity: 1, y: 0 }}>
          <Card className="p-2" style={{ backgroundColor: "var(--surface-container)" }}>
            <div className="flex items-center gap-1.5">
              <div
                className="flex h-6 w-6 items-center justify-center rounded-lg shrink-0"
                style={{ backgroundColor: `${G_RED}22`, color: G_RED }}
              >
                <DynamicIcon name="Receipt" className="h-3.5 w-3.5" />
              </div>
              <div className="min-w-0">
                <p className="text-sm font-bold text-foreground font-mono">
                  {formatAmount(totalUnpaid)}
                </p>
                <p className="text-[10px] text-muted-foreground">إجمالي غير مدفوع (ل.س)</p>
              </div>
            </div>
          </Card>
        </motion.div>
        <motion.div initial={{ opacity: 0, y: 4 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.05 }}>
          <Card className="p-2" style={{ backgroundColor: "var(--surface-container)" }}>
            <div className="flex items-center gap-1.5">
              <div
                className="flex h-6 w-6 items-center justify-center rounded-lg shrink-0"
                style={{
                  backgroundColor: `${overdueCount > 0 ? G_RED : G_GREEN}22`,
                  color: overdueCount > 0 ? G_RED : G_GREEN,
                }}
              >
                <DynamicIcon name="AlertCircle" className="h-3.5 w-3.5" />
              </div>
              <div className="min-w-0">
                <p className="text-sm font-bold text-foreground font-mono">{overdueCount}</p>
                <p className="text-[10px] text-muted-foreground">فاتورة متأخرة</p>
              </div>
            </div>
          </Card>
        </motion.div>
      </div>

      {/* Bills list */}
      <Card className="p-2" style={{ backgroundColor: "var(--surface-container)" }}>
        <div className="flex items-center justify-between mb-1.5">
          <div className="flex items-center gap-1.5">
            <div
              className="flex h-6 w-6 items-center justify-center rounded-lg"
              style={{ backgroundColor: `${G_YELLOW}22`, color: G_YELLOW }}
            >
              <DynamicIcon name="Receipt" className="h-3.5 w-3.5" />
            </div>
            <h3 className="text-xs font-bold text-foreground">الفواتير</h3>
          </div>
          <BillDialog
            open={dialogOpen}
            onOpenChange={setDialogOpen}
            editing={editing}
            onSaved={() => {
              setDialogOpen(false);
              setEditing(null);
              fetchBills();
            }}
          >
            <Button
              size="sm"
              className="h-6 gap-1"
              style={{ backgroundColor: G_GREEN, color: "#fff" }}
              onClick={() => {
                setEditing(null);
                setDialogOpen(true);
              }}
            >
              <DynamicIcon name="Plus" className="h-3.5 w-3.5" />
              إضافة
            </Button>
          </BillDialog>
        </div>

        {loading ? (
          <div className="space-y-1.5">
            {Array.from({ length: 3 }).map((_, i) => (
              <Skeleton key={i} className="h-12 rounded-lg" />
            ))}
          </div>
        ) : bills.length === 0 ? (
          <EmptyState
            icon="Receipt"
            color={G_YELLOW}
            title="لا فواتير مسجّلة"
            hint="أضف فاتورة جديدة لتتبعها"
          />
        ) : (
          <div className="space-y-1 max-h-96 overflow-y-auto custom-scroll">
            <AnimatePresence>
              {bills.map((bill, i) => {
                const meta = billMeta(bill.type);
                const status = billStatus(bill);
                return (
                  <motion.div
                    key={bill.id}
                    layout
                    initial={{ opacity: 0, y: 6 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, x: -10 }}
                    transition={{ delay: i * 0.03 }}
                    className="group rounded-lg p-1.5 transition-all hover:bg-white/5"
                    style={{ backgroundColor: "var(--surface-container-high)" }}
                  >
                    <div className="flex items-center gap-1.5">
                      <div
                        className="flex h-6 w-6 items-center justify-center rounded-lg shrink-0"
                        style={{ backgroundColor: `${meta.color}22`, color: meta.color }}
                      >
                        <DynamicIcon name={meta.icon} className="h-3.5 w-3.5" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-1">
                          <span className="text-xs font-medium text-foreground truncate">
                            {meta.label}
                          </span>
                          <span
                            className="text-[9px] px-1 py-0.5 rounded-full"
                            style={{ backgroundColor: status.bg, color: status.color }}
                          >
                            {status.label}
                          </span>
                        </div>
                        <p className="text-[10px] text-muted-foreground">
                          {format(new Date(bill.dueDate), "d MMM", { locale: ar })}
                          {bill.note ? ` · ${bill.note}` : ""}
                        </p>
                      </div>
                      <span className="text-xs font-mono font-bold text-foreground">
                        {formatAmount(bill.amount)}
                      </span>
                      <div className="flex gap-0.5">
                        <Button
                          size="sm"
                          variant="ghost"
                          className="h-6 w-6 p-0"
                          onClick={() => handleTogglePaid(bill)}
                          style={bill.paid ? { color: G_GREEN } : {}}
                          title={bill.paid ? "مدفوع" : "تعليم كمدفوع"}
                        >
                          <DynamicIcon name="CheckCircle" className="h-3.5 w-3.5" />
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          className="h-6 w-6 p-0 opacity-0 group-hover:opacity-100 transition-opacity"
                          onClick={() => {
                            setEditing(bill);
                            setDialogOpen(true);
                          }}
                        >
                          <DynamicIcon name="Pencil" className="h-3 w-3" />
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          className="h-6 w-6 p-0 opacity-0 group-hover:opacity-100 transition-opacity hover:text-red-400"
                          onClick={() => handleDelete(bill.id)}
                        >
                          <DynamicIcon name="Trash2" className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                  </motion.div>
                );
              })}
            </AnimatePresence>
          </div>
        )}
      </Card>
    </div>
  );
}

function BillDialog({
  open,
  onOpenChange,
  editing,
  onSaved,
  children,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  editing: Bill | null;
  onSaved: () => void;
  children: React.ReactNode;
}) {
  const { toast } = useToast();
  const [type, setType] = React.useState("electricity");
  const [amount, setAmount] = React.useState("");
  const [dueDate, setDueDate] = React.useState("");
  const [note, setNote] = React.useState("");
  const [saving, setSaving] = React.useState(false);

  React.useEffect(() => {
    if (open) {
      if (editing) {
        setType(editing.type);
        setAmount(String(editing.amount));
        setDueDate(new Date(editing.dueDate).toISOString().split("T")[0]);
        setNote(editing.note || "");
      } else {
        setType("electricity");
        setAmount("");
        setDueDate(new Date().toISOString().split("T")[0]);
        setNote("");
      }
    }
  }, [editing, open]);

  const handleSave = async () => {
    const amt = parseFloat(amount);
    if (!amt || amt <= 0) {
      toast({ title: "أدخل مبلغاً صحيحاً", variant: "destructive" });
      return;
    }
    if (!dueDate) {
      toast({ title: "تاريخ الاستحقاق مطلوب", variant: "destructive" });
      return;
    }
    setSaving(true);
    try {
      const payload: Record<string, unknown> = {
        type,
        amount: amt,
        dueDate: new Date(dueDate).toISOString(),
        note: note || undefined,
      };
      if (editing) payload.id = editing.id;
      await fetch("/api/utility-bills", {
        method: editing ? "PUT" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      toast({ title: editing ? "تم تحديث الفاتورة" : "تمت إضافة الفاتورة ✓" });
      onSaved();
    } catch {
      toast({ title: "فشل الحفظ", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogTrigger asChild>{children}</DialogTrigger>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>{editing ? "تعديل فاتورة" : "إضافة فاتورة جديدة"}</DialogTitle>
        </DialogHeader>
        <div className="space-y-1.5">
          <div>
            <Label>النوع</Label>
            <div className="grid grid-cols-3 gap-1 mt-1">
              {BILL_TYPES.map((t) => {
                const selected = type === t.value;
                return (
                  <button
                    key={t.value}
                    onClick={() => setType(t.value)}
                    className={cn(
                      "flex flex-col items-center gap-0.5 p-1.5 rounded-lg border transition-all",
                      selected
                        ? "border-transparent"
                        : "border-border/40 text-muted-foreground hover:border-primary/30"
                    )}
                    style={selected ? { backgroundColor: `${t.color}22`, color: t.color } : {}}
                  >
                    <DynamicIcon name={t.icon} className="h-3.5 w-3.5" />
                    <span className="text-[9px]">{t.label}</span>
                  </button>
                );
              })}
            </div>
          </div>
          <div>
            <Label htmlFor="bill-amount">المبلغ (ل.س)</Label>
            <Input
              id="bill-amount"
              type="number"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="0"
              dir="ltr"
              className="font-bold"
              autoFocus
            />
          </div>
          <div>
            <Label htmlFor="bill-due">تاريخ الاستحقاق</Label>
            <Input
              id="bill-due"
              type="date"
              value={dueDate}
              onChange={(e) => setDueDate(e.target.value)}
              dir="ltr"
            />
          </div>
          <div>
            <Label htmlFor="bill-note">ملاحظة (اختياري)</Label>
            <Input
              id="bill-note"
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="مثال: فاتورة شباط"
            />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            إلغاء
          </Button>
          <Button
            onClick={handleSave}
            disabled={saving}
            style={{ backgroundColor: G_GREEN, color: "#fff" }}
          >
            <DynamicIcon
              name={saving ? "Loader2" : "Save"}
              className={cn("h-3.5 w-3.5", saving && "animate-spin")}
            />
            {editing ? "حفظ" : "إضافة"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ============================================================
// 2) MAINTENANCE TAB
// ============================================================
interface MaintenanceItem {
  id: string;
  item: string;
  task: string;
  lastDone: string | null;
  nextDue: string | null;
  intervalDays: number;
  note: string | null;
}

const MAINTENANCE_ICONS: Record<string, { icon: string; color: string }> = {
  AC: { icon: "Wind", color: G_BLUE },
  Car: { icon: "Car", color: G_RED },
  Heater: { icon: "Flame", color: G_ORANGE },
  Filter: { icon: "Filter", color: G_TEAL },
  Other: { icon: "Wrench", color: G_GRAY },
};

function maintenanceMeta(item: string) {
  const key = Object.keys(MAINTENANCE_ICONS).find((k) =>
    item.toLowerCase().includes(k.toLowerCase())
  );
  return key ? MAINTENANCE_ICONS[key] : MAINTENANCE_ICONS.Other;
}

function MaintenanceTab() {
  const { toast } = useToast();
  const [items, setItems] = React.useState<MaintenanceItem[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [dialogOpen, setDialogOpen] = React.useState(false);

  const fetchItems = React.useCallback(async () => {
    try {
      const res = await fetch("/api/home-maintenance");
      const json = await res.json();
      if (json.success) setItems(json.data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, []);

  React.useEffect(() => {
    fetchItems();
  }, [fetchItems]);

  const overdueCount = items.filter(
    (i) => i.nextDue && isPast(new Date(i.nextDue)) && !isToday(new Date(i.nextDue))
  ).length;

  const handleDone = async (item: MaintenanceItem) => {
    await fetch("/api/home-maintenance", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: item.id, done: true }),
    });
    toast({ title: "تم تسجيل الإنجاز ✓", description: `${item.item} — ${item.task}` });
    fetchItems();
  };

  const handleDelete = async (id: string) => {
    await fetch(`/api/home-maintenance?id=${id}`, { method: "DELETE" });
    toast({ title: "تم حذف العنصر" });
    fetchItems();
  };

  return (
    <div className="space-y-1.5">
      {/* Summary */}
      <Card className="p-2" style={{ backgroundColor: "var(--surface-container)" }}>
        <div className="flex items-center gap-1.5">
          <div
            className="flex h-6 w-6 items-center justify-center rounded-lg shrink-0"
            style={{
              backgroundColor: `${overdueCount > 0 ? G_RED : G_GREEN}22`,
              color: overdueCount > 0 ? G_RED : G_GREEN,
            }}
          >
            <DynamicIcon name="AlertCircle" className="h-3.5 w-3.5" />
          </div>
          <div className="flex-1">
            <p className="text-xs font-bold text-foreground">
              {overdueCount > 0
                ? `${overdueCount} مهمة صيانة متأخرة`
                : "كل مهام الصيانة في موعدها ✓"}
            </p>
            <p className="text-[10px] text-muted-foreground">
              إجمالي {items.length} عنصر صيانة
            </p>
          </div>
        </div>
      </Card>

      <Card className="p-2" style={{ backgroundColor: "var(--surface-container)" }}>
        <div className="flex items-center justify-between mb-1.5">
          <div className="flex items-center gap-1.5">
            <div
              className="flex h-6 w-6 items-center justify-center rounded-lg"
              style={{ backgroundColor: `${G_ORANGE}22`, color: G_ORANGE }}
            >
              <DynamicIcon name="Wrench" className="h-3.5 w-3.5" />
            </div>
            <h3 className="text-xs font-bold text-foreground">مهام الصيانة</h3>
          </div>
          <MaintenanceDialog
            open={dialogOpen}
            onOpenChange={setDialogOpen}
            onSaved={() => {
              setDialogOpen(false);
              fetchItems();
            }}
          >
            <Button
              size="sm"
              className="h-6 gap-1"
              style={{ backgroundColor: G_GREEN, color: "#fff" }}
              onClick={() => setDialogOpen(true)}
            >
              <DynamicIcon name="Plus" className="h-3.5 w-3.5" />
              إضافة
            </Button>
          </MaintenanceDialog>
        </div>

        {loading ? (
          <div className="space-y-1.5">
            {Array.from({ length: 3 }).map((_, i) => (
              <Skeleton key={i} className="h-14 rounded-lg" />
            ))}
          </div>
        ) : items.length === 0 ? (
          <EmptyState
            icon="Wrench"
            color={G_ORANGE}
            title="لا مهام صيانة"
            hint="أضف مهمة لتتبع مواعيدها"
          />
        ) : (
          <div className="space-y-1 max-h-96 overflow-y-auto custom-scroll">
            <AnimatePresence>
              {items.map((item, i) => {
                const meta = maintenanceMeta(item.item);
                const nextDue = item.nextDue ? new Date(item.nextDue) : null;
                const isOverdue =
                  nextDue && isPast(nextDue) && !isToday(nextDue);
                const isDueToday = nextDue && isToday(nextDue);
                const daysUntil = nextDue
                  ? differenceInCalendarDays(nextDue, new Date())
                  : null;
                const statusColor = isOverdue
                  ? G_RED
                  : isDueToday
                  ? G_YELLOW
                  : (daysUntil ?? 0) <= 7
                  ? G_YELLOW
                  : G_GREEN;
                return (
                  <motion.div
                    key={item.id}
                    layout
                    initial={{ opacity: 0, y: 6 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, x: -10 }}
                    transition={{ delay: i * 0.03 }}
                    className="group rounded-lg p-1.5 transition-all hover:bg-white/5"
                    style={{
                      backgroundColor: "var(--surface-container-high)",
                      borderColor: isOverdue ? `${G_RED}33` : "transparent",
                      borderWidth: isOverdue ? 1 : 0,
                      borderStyle: "solid",
                    }}
                  >
                    <div className="flex items-center gap-1.5">
                      <div
                        className="flex h-6 w-6 items-center justify-center rounded-lg shrink-0"
                        style={{ backgroundColor: `${meta.color}22`, color: meta.color }}
                      >
                        <DynamicIcon name={meta.icon} className="h-3.5 w-3.5" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-1">
                          <span className="text-xs font-medium text-foreground truncate">
                            {item.item}
                          </span>
                          <span
                            className="text-[9px] px-1 py-0.5 rounded-full"
                            style={{ backgroundColor: `${statusColor}22`, color: statusColor }}
                          >
                            {isOverdue
                              ? "متأخرة"
                              : isDueToday
                              ? "اليوم"
                              : daysUntil !== null
                              ? `بعد ${daysUntil} يوم`
                              : "—"}
                          </span>
                        </div>
                        <p className="text-[10px] text-muted-foreground truncate">
                          {item.task} · كل {item.intervalDays} يوم
                        </p>
                        {item.lastDone && (
                          <p className="text-[9px] text-muted-foreground">
                            آخر صيانة: {format(new Date(item.lastDone), "d MMM yyyy", { locale: ar })}
                          </p>
                        )}
                      </div>
                      <div className="flex flex-col gap-0.5 items-end">
                        <Button
                          size="sm"
                          className="h-5 px-1.5 text-[9px] gap-0.5"
                          style={{ backgroundColor: G_GREEN, color: "#fff" }}
                          onClick={() => handleDone(item)}
                        >
                          <DynamicIcon name="Check" className="h-2.5 w-2.5" />
                          تم
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          className="h-5 w-5 p-0 opacity-0 group-hover:opacity-100 transition-opacity hover:text-red-400"
                          onClick={() => handleDelete(item.id)}
                        >
                          <DynamicIcon name="Trash2" className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                  </motion.div>
                );
              })}
            </AnimatePresence>
          </div>
        )}
      </Card>
    </div>
  );
}

function MaintenanceDialog({
  open,
  onOpenChange,
  onSaved,
  children,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSaved: () => void;
  children: React.ReactNode;
}) {
  const { toast } = useToast();
  const [item, setItem] = React.useState("");
  const [task, setTask] = React.useState("");
  const [intervalDays, setIntervalDays] = React.useState("90");
  const [lastDone, setLastDone] = React.useState("");
  const [saving, setSaving] = React.useState(false);

  React.useEffect(() => {
    if (open) {
      setItem("");
      setTask("");
      setIntervalDays("90");
      setLastDone(new Date().toISOString().split("T")[0]);
    }
  }, [open]);

  const handleSave = async () => {
    if (!item || !task) {
      toast({ title: "البند والمهمة مطلوبان", variant: "destructive" });
      return;
    }
    setSaving(true);
    try {
      await fetch("/api/home-maintenance", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          item,
          task,
          intervalDays: parseInt(intervalDays) || 90,
          lastDone: lastDone ? new Date(lastDone).toISOString() : undefined,
        }),
      });
      toast({ title: "تمت إضافة مهمة الصيانة ✓" });
      onSaved();
    } catch {
      toast({ title: "فشل الحفظ", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogTrigger asChild>{children}</DialogTrigger>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>إضافة مهمة صيانة</DialogTitle>
        </DialogHeader>
        <div className="space-y-1.5">
          <div>
            <Label htmlFor="m-item">البند (مثال: مكيف، سيارة)</Label>
            <Input
              id="m-item"
              value={item}
              onChange={(e) => setItem(e.target.value)}
              placeholder="مكيف غرفة الجلوس"
              autoFocus
            />
          </div>
          <div>
            <Label htmlFor="m-task">المهمة</Label>
            <Input
              id="m-task"
              value={task}
              onChange={(e) => setTask(e.target.value)}
              placeholder="تنظيف الفلاتر"
            />
          </div>
          <div className="grid grid-cols-2 gap-1.5">
            <div>
              <Label htmlFor="m-interval">الفترة (يوم)</Label>
              <Input
                id="m-interval"
                type="number"
                value={intervalDays}
                onChange={(e) => setIntervalDays(e.target.value)}
                dir="ltr"
              />
            </div>
            <div>
              <Label htmlFor="m-last">آخر صيانة</Label>
              <Input
                id="m-last"
                type="date"
                value={lastDone}
                onChange={(e) => setLastDone(e.target.value)}
                dir="ltr"
              />
            </div>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            إلغاء
          </Button>
          <Button
            onClick={handleSave}
            disabled={saving}
            style={{ backgroundColor: G_GREEN, color: "#fff" }}
          >
            <DynamicIcon
              name={saving ? "Loader2" : "Save"}
              className={cn("h-3.5 w-3.5", saving && "animate-spin")}
            />
            إضافة
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ============================================================
// 3) PANTRY TAB
// ============================================================
interface PantryItem {
  id: string;
  name: string;
  quantity: number;
  unit: string;
  lowStock: number;
  category: string;
}

const PANTRY_UNITS = ["piece", "kg", "g", "liter", "ml", "pack"];
const UNIT_LABELS: Record<string, string> = {
  piece: "قطعة",
  kg: "كغ",
  g: "غ",
  liter: "لتر",
  ml: "مل",
  pack: "علبة",
};
const PANTRY_CATEGORIES: Array<{ value: string; label: string; icon: string; color: string }> = [
  { value: "grains", label: "حبوب", icon: "Package", color: G_YELLOW },
  { value: "dairy", label: "ألبان", icon: "Coffee", color: G_BLUE },
  { value: "vegetables", label: "خضار", icon: "Leaf", color: G_GREEN },
  { value: "fruits", label: "فواكه", icon: "Apple", color: G_RED },
  { value: "meat", label: "لحوم", icon: "Beef", color: G_RED },
  { value: "other", label: "أخرى", icon: "Package", color: G_GRAY },
];

function pantryMeta(category: string) {
  return (
    PANTRY_CATEGORIES.find((c) => c.value === category) || PANTRY_CATEGORIES[PANTRY_CATEGORIES.length - 1]
  );
}

function PantryTab() {
  const { toast } = useToast();
  const [items, setItems] = React.useState<PantryItem[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [dialogOpen, setDialogOpen] = React.useState(false);

  const fetchItems = React.useCallback(async () => {
    try {
      const res = await fetch("/api/pantry");
      const json = await res.json();
      if (json.success) setItems(json.data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, []);

  React.useEffect(() => {
    fetchItems();
  }, [fetchItems]);

  const lowStockCount = items.filter((i) => i.quantity <= i.lowStock).length;

  const handleAddToShopping = async (item: PantryItem) => {
    await fetch("/api/shopping", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        name: item.name,
        quantity: Math.max(1, item.lowStock * 2 - item.quantity),
        category: "pantry",
        autoAdded: true,
      }),
    });
    toast({ title: `أُضيف ${item.name} لقائمة التسوق ✓` });
  };

  const handleAdjustQty = async (item: PantryItem, delta: number) => {
    const newQty = Math.max(0, item.quantity + delta);
    await fetch("/api/pantry", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: item.id, quantity: newQty }),
    });
    fetchItems();
  };

  const handleDelete = async (id: string) => {
    await fetch(`/api/pantry?id=${id}`, { method: "DELETE" });
    toast({ title: "تم حذف العنصر" });
    fetchItems();
  };

  return (
    <div className="space-y-1.5">
      {/* Summary */}
      <Card className="p-2" style={{ backgroundColor: "var(--surface-container)" }}>
        <div className="flex items-center gap-1.5">
          <div
            className="flex h-6 w-6 items-center justify-center rounded-lg shrink-0"
            style={{
              backgroundColor: `${lowStockCount > 0 ? G_YELLOW : G_GREEN}22`,
              color: lowStockCount > 0 ? G_YELLOW : G_GREEN,
            }}
          >
            <DynamicIcon name="Package" className="h-3.5 w-3.5" />
          </div>
          <div className="flex-1">
            <p className="text-xs font-bold text-foreground">
              {lowStockCount > 0
                ? `${lowStockCount} عنصر منخفض المخزون`
                : "المخزون بحالة جيدة ✓"}
            </p>
            <p className="text-[10px] text-muted-foreground">إجمالي {items.length} عنصر</p>
          </div>
        </div>
      </Card>

      <Card className="p-2" style={{ backgroundColor: "var(--surface-container)" }}>
        <div className="flex items-center justify-between mb-1.5">
          <div className="flex items-center gap-1.5">
            <div
              className="flex h-6 w-6 items-center justify-center rounded-lg"
              style={{ backgroundColor: `${G_GREEN}22`, color: G_GREEN }}
            >
              <DynamicIcon name="Package" className="h-3.5 w-3.5" />
            </div>
            <h3 className="text-xs font-bold text-foreground">مخزون المطبخ</h3>
          </div>
          <PantryDialog
            open={dialogOpen}
            onOpenChange={setDialogOpen}
            onSaved={() => {
              setDialogOpen(false);
              fetchItems();
            }}
          >
            <Button
              size="sm"
              className="h-6 gap-1"
              style={{ backgroundColor: G_GREEN, color: "#fff" }}
              onClick={() => setDialogOpen(true)}
            >
              <DynamicIcon name="Plus" className="h-3.5 w-3.5" />
              إضافة
            </Button>
          </PantryDialog>
        </div>

        {loading ? (
          <div className="space-y-1.5">
            {Array.from({ length: 3 }).map((_, i) => (
              <Skeleton key={i} className="h-12 rounded-lg" />
            ))}
          </div>
        ) : items.length === 0 ? (
          <EmptyState
            icon="Package"
            color={G_GREEN}
            title="المخزون فارغ"
            hint="أضف عناصر لتتبع مخزونك"
          />
        ) : (
          <div className="space-y-1 max-h-96 overflow-y-auto custom-scroll">
            <AnimatePresence>
              {items.map((item, i) => {
                const meta = pantryMeta(item.category);
                const isLow = item.quantity <= item.lowStock;
                return (
                  <motion.div
                    key={item.id}
                    layout
                    initial={{ opacity: 0, y: 6 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, x: -10 }}
                    transition={{ delay: i * 0.03 }}
                    className="group rounded-lg p-1.5 transition-all hover:bg-white/5"
                    style={{
                      backgroundColor: "var(--surface-container-high)",
                      borderColor: isLow ? `${G_YELLOW}33` : "transparent",
                      borderWidth: isLow ? 1 : 0,
                      borderStyle: "solid",
                    }}
                  >
                    <div className="flex items-center gap-1.5">
                      <div
                        className="flex h-6 w-6 items-center justify-center rounded-lg shrink-0"
                        style={{
                          backgroundColor: `${isLow ? G_YELLOW : meta.color}22`,
                          color: isLow ? G_YELLOW : meta.color,
                        }}
                      >
                        <DynamicIcon name={meta.icon} className="h-3.5 w-3.5" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-1">
                          <span className="text-xs font-medium text-foreground truncate">
                            {item.name}
                          </span>
                          {isLow && (
                            <span
                              className="text-[9px] px-1 py-0.5 rounded-full"
                              style={{ backgroundColor: `${G_YELLOW}22`, color: G_YELLOW }}
                            >
                              منخفض
                            </span>
                          )}
                        </div>
                        <p className="text-[10px] text-muted-foreground">
                          الحد الأدنى: {item.lowStock} {UNIT_LABELS[item.unit] || item.unit}
                        </p>
                      </div>
                      <div className="flex items-center gap-0.5">
                        <Button
                          size="sm"
                          variant="ghost"
                          className="h-5 w-5 p-0"
                          onClick={() => handleAdjustQty(item, -1)}
                        >
                          <DynamicIcon name="ChevronDown" className="h-3 w-3" />
                        </Button>
                        <span
                          className="text-xs font-mono font-bold min-w-[2.5rem] text-center"
                          style={{ color: isLow ? G_YELLOW : "inherit" }}
                        >
                          {item.quantity} {UNIT_LABELS[item.unit] || item.unit}
                        </span>
                        <Button
                          size="sm"
                          variant="ghost"
                          className="h-5 w-5 p-0"
                          onClick={() => handleAdjustQty(item, 1)}
                        >
                          <DynamicIcon name="ChevronUp" className="h-3 w-3" />
                        </Button>
                      </div>
                      <div className="flex gap-0.5">
                        {isLow && (
                          <Button
                            size="sm"
                            variant="ghost"
                            className="h-5 px-1 text-[9px] gap-0.5"
                            style={{ color: G_BLUE }}
                            onClick={() => handleAddToShopping(item)}
                            title="إضافة لقائمة التسوق"
                          >
                            <DynamicIcon name="ShoppingCart" className="h-3 w-3" />
                          </Button>
                        )}
                        <Button
                          size="sm"
                          variant="ghost"
                          className="h-5 w-5 p-0 opacity-0 group-hover:opacity-100 transition-opacity hover:text-red-400"
                          onClick={() => handleDelete(item.id)}
                        >
                          <DynamicIcon name="Trash2" className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                  </motion.div>
                );
              })}
            </AnimatePresence>
          </div>
        )}
      </Card>
    </div>
  );
}

function PantryDialog({
  open,
  onOpenChange,
  onSaved,
  children,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSaved: () => void;
  children: React.ReactNode;
}) {
  const { toast } = useToast();
  const [name, setName] = React.useState("");
  const [quantity, setQuantity] = React.useState("1");
  const [unit, setUnit] = React.useState("piece");
  const [lowStock, setLowStock] = React.useState("1");
  const [category, setCategory] = React.useState("other");
  const [saving, setSaving] = React.useState(false);

  React.useEffect(() => {
    if (open) {
      setName("");
      setQuantity("1");
      setUnit("piece");
      setLowStock("1");
      setCategory("other");
    }
  }, [open]);

  const handleSave = async () => {
    if (!name) {
      toast({ title: "الاسم مطلوب", variant: "destructive" });
      return;
    }
    setSaving(true);
    try {
      await fetch("/api/pantry", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name,
          quantity: parseFloat(quantity) || 1,
          unit,
          lowStock: parseFloat(lowStock) || 1,
          category,
        }),
      });
      toast({ title: "تمت إضافة العنصر ✓" });
      onSaved();
    } catch {
      toast({ title: "فشل الحفظ", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogTrigger asChild>{children}</DialogTrigger>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>إضافة عنصر للمخزون</DialogTitle>
        </DialogHeader>
        <div className="space-y-1.5">
          <div>
            <Label htmlFor="p-name">الاسم</Label>
            <Input
              id="p-name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="أرز"
              autoFocus
            />
          </div>
          <div className="grid grid-cols-2 gap-1.5">
            <div>
              <Label htmlFor="p-qty">الكمية</Label>
              <Input
                id="p-qty"
                type="number"
                value={quantity}
                onChange={(e) => setQuantity(e.target.value)}
                dir="ltr"
              />
            </div>
            <div>
              <Label htmlFor="p-low">الحد الأدنى</Label>
              <Input
                id="p-low"
                type="number"
                value={lowStock}
                onChange={(e) => setLowStock(e.target.value)}
                dir="ltr"
              />
            </div>
          </div>
          <div>
            <Label>الوحدة</Label>
            <div className="grid grid-cols-6 gap-0.5 mt-1">
              {PANTRY_UNITS.map((u) => {
                const selected = unit === u;
                return (
                  <button
                    key={u}
                    onClick={() => setUnit(u)}
                    className={cn(
                      "py-1 rounded-md text-[10px] transition-all",
                      selected
                        ? "text-white"
                        : "text-muted-foreground hover:text-foreground bg-white/5"
                    )}
                    style={selected ? { backgroundColor: G_GREEN } : {}}
                  >
                    {UNIT_LABELS[u]}
                  </button>
                );
              })}
            </div>
          </div>
          <div>
            <Label>الفئة</Label>
            <div className="grid grid-cols-3 gap-1 mt-1">
              {PANTRY_CATEGORIES.map((c) => {
                const selected = category === c.value;
                return (
                  <button
                    key={c.value}
                    onClick={() => setCategory(c.value)}
                    className={cn(
                      "flex items-center gap-1 p-1.5 rounded-lg border transition-all text-[10px]",
                      selected
                        ? "border-transparent"
                        : "border-border/40 text-muted-foreground hover:border-primary/30"
                    )}
                    style={selected ? { backgroundColor: `${c.color}22`, color: c.color } : {}}
                  >
                    <DynamicIcon name={c.icon} className="h-3 w-3" />
                    {c.label}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            إلغاء
          </Button>
          <Button
            onClick={handleSave}
            disabled={saving}
            style={{ backgroundColor: G_GREEN, color: "#fff" }}
          >
            <DynamicIcon
              name={saving ? "Loader2" : "Save"}
              className={cn("h-3.5 w-3.5", saving && "animate-spin")}
            />
            إضافة
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ============================================================
// 4) SUBSCRIPTIONS TAB
// ============================================================
interface Subscription {
  id: string;
  name: string;
  cost: number;
  currency: string;
  billingCycle: string;
  nextBilling: string | null;
  active: boolean;
  note: string | null;
}

const SUB_ICONS: Record<string, { icon: string; color: string }> = {
  netflix: { icon: "Play", color: G_RED },
  spotify: { icon: "Music", color: G_GREEN },
  internet: { icon: "Globe", color: G_BLUE },
  phone: { icon: "Phone", color: G_TEAL },
  gym: { icon: "Activity", color: G_PURPLE },
  other: { icon: "RefreshCw", color: G_GRAY },
};

function subMeta(name: string) {
  const lower = name.toLowerCase();
  const key = Object.keys(SUB_ICONS).find((k) => lower.includes(k));
  return key ? SUB_ICONS[key] : SUB_ICONS.other;
}

const CYCLE_LABELS: Record<string, string> = {
  monthly: "شهري",
  yearly: "سنوي",
  weekly: "أسبوعي",
  quarterly: "ربع سنوي",
};

function SubscriptionsTab() {
  const { toast } = useToast();
  const [subs, setSubs] = React.useState<Subscription[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [dialogOpen, setDialogOpen] = React.useState(false);

  const fetchSubs = React.useCallback(async () => {
    try {
      const res = await fetch("/api/subscriptions");
      const json = await res.json();
      if (json.success) setSubs(json.data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, []);

  React.useEffect(() => {
    fetchSubs();
  }, [fetchSubs]);

  const monthlyTotal = subs
    .filter((s) => s.active)
    .reduce((sum, s) => {
      if (s.billingCycle === "yearly") return sum + s.cost / 12;
      if (s.billingCycle === "quarterly") return sum + s.cost / 3;
      if (s.billingCycle === "weekly") return sum + s.cost * 4.33;
      return sum + s.cost; // monthly
    }, 0);

  const handleToggle = async (sub: Subscription) => {
    await fetch("/api/subscriptions", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: sub.id, toggleActive: true }),
    });
    toast({ title: sub.active ? "تم تعطيل الاشتراك" : "تم تفعيل الاشتراك ✓" });
    fetchSubs();
  };

  const handleDelete = async (id: string) => {
    await fetch(`/api/subscriptions?id=${id}`, { method: "DELETE" });
    toast({ title: "تم حذف الاشتراك" });
    fetchSubs();
  };

  return (
    <div className="space-y-1.5">
      {/* Summary */}
      <Card className="p-2" style={{ backgroundColor: "var(--surface-container)" }}>
        <div className="flex items-center gap-1.5">
          <div
            className="flex h-6 w-6 items-center justify-center rounded-lg shrink-0"
            style={{ backgroundColor: `${G_BLUE}22`, color: G_BLUE }}
          >
            <DynamicIcon name="Wallet" className="h-3.5 w-3.5" />
          </div>
          <div className="flex-1">
            <p className="text-sm font-bold text-foreground font-mono">
              {formatAmount(monthlyTotal)}{" "}
              <span className="text-[10px] text-muted-foreground font-normal">ل.س/شهر</span>
            </p>
            <p className="text-[10px] text-muted-foreground">
              إجمالي الاشتراكات النشطة ({subs.filter((s) => s.active).length})
            </p>
          </div>
        </div>
      </Card>

      <Card className="p-2" style={{ backgroundColor: "var(--surface-container)" }}>
        <div className="flex items-center justify-between mb-1.5">
          <div className="flex items-center gap-1.5">
            <div
              className="flex h-6 w-6 items-center justify-center rounded-lg"
              style={{ backgroundColor: `${G_BLUE}22`, color: G_BLUE }}
            >
              <DynamicIcon name="RefreshCw" className="h-3.5 w-3.5" />
            </div>
            <h3 className="text-xs font-bold text-foreground">الاشتراكات</h3>
          </div>
          <SubscriptionDialog
            open={dialogOpen}
            onOpenChange={setDialogOpen}
            onSaved={() => {
              setDialogOpen(false);
              fetchSubs();
            }}
          >
            <Button
              size="sm"
              className="h-6 gap-1"
              style={{ backgroundColor: G_GREEN, color: "#fff" }}
              onClick={() => setDialogOpen(true)}
            >
              <DynamicIcon name="Plus" className="h-3.5 w-3.5" />
              إضافة
            </Button>
          </SubscriptionDialog>
        </div>

        {loading ? (
          <div className="space-y-1.5">
            {Array.from({ length: 3 }).map((_, i) => (
              <Skeleton key={i} className="h-12 rounded-lg" />
            ))}
          </div>
        ) : subs.length === 0 ? (
          <EmptyState
            icon="RefreshCw"
            color={G_BLUE}
            title="لا اشتراكات مسجّلة"
            hint="أضف اشتراكاً لتتبع تكاليفه"
          />
        ) : (
          <div className="space-y-1 max-h-96 overflow-y-auto custom-scroll">
            <AnimatePresence>
              {subs.map((sub, i) => {
                const meta = subMeta(sub.name);
                return (
                  <motion.div
                    key={sub.id}
                    layout
                    initial={{ opacity: 0, y: 6 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, x: -10 }}
                    transition={{ delay: i * 0.03 }}
                    className={cn(
                      "group rounded-lg p-1.5 transition-all hover:bg-white/5",
                      !sub.active && "opacity-60"
                    )}
                    style={{ backgroundColor: "var(--surface-container-high)" }}
                  >
                    <div className="flex items-center gap-1.5">
                      <div
                        className="flex h-6 w-6 items-center justify-center rounded-lg shrink-0"
                        style={{ backgroundColor: `${meta.color}22`, color: meta.color }}
                      >
                        <DynamicIcon name={meta.icon} className="h-3.5 w-3.5" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-1">
                          <span className="text-xs font-medium text-foreground truncate">
                            {sub.name}
                          </span>
                          <span
                            className="text-[9px] px-1 py-0.5 rounded-full"
                            style={{
                              backgroundColor: sub.active ? `${G_GREEN}22` : `${G_GRAY}22`,
                              color: sub.active ? G_GREEN : G_GRAY,
                            }}
                          >
                            {CYCLE_LABELS[sub.billingCycle] || sub.billingCycle}
                          </span>
                        </div>
                        <p className="text-[10px] text-muted-foreground">
                          {sub.nextBilling
                            ? `الفاتورة القادمة: ${format(new Date(sub.nextBilling), "d MMM", { locale: ar })}`
                            : "—"}
                        </p>
                      </div>
                      <span className="text-xs font-mono font-bold text-foreground">
                        {formatAmount(sub.cost)}
                      </span>
                      <Switch checked={sub.active} onCheckedChange={() => handleToggle(sub)} />
                      <Button
                        size="sm"
                        variant="ghost"
                        className="h-5 w-5 p-0 opacity-0 group-hover:opacity-100 transition-opacity hover:text-red-400"
                        onClick={() => handleDelete(sub.id)}
                      >
                        <DynamicIcon name="Trash2" className="h-3 w-3" />
                      </Button>
                    </div>
                  </motion.div>
                );
              })}
            </AnimatePresence>
          </div>
        )}
      </Card>
    </div>
  );
}

function SubscriptionDialog({
  open,
  onOpenChange,
  onSaved,
  children,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSaved: () => void;
  children: React.ReactNode;
}) {
  const { toast } = useToast();
  const [name, setName] = React.useState("");
  const [cost, setCost] = React.useState("");
  const [billingCycle, setBillingCycle] = React.useState("monthly");
  const [nextBilling, setNextBilling] = React.useState("");
  const [saving, setSaving] = React.useState(false);

  React.useEffect(() => {
    if (open) {
      setName("");
      setCost("");
      setBillingCycle("monthly");
      setNextBilling(new Date().toISOString().split("T")[0]);
    }
  }, [open]);

  const handleSave = async () => {
    if (!name || !cost) {
      toast({ title: "الاسم والتكلفة مطلوبان", variant: "destructive" });
      return;
    }
    setSaving(true);
    try {
      await fetch("/api/subscriptions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name,
          cost: parseFloat(cost),
          billingCycle,
          nextBilling: nextBilling ? new Date(nextBilling).toISOString() : undefined,
          currency: "syp",
        }),
      });
      toast({ title: "تمت إضافة الاشتراك ✓" });
      onSaved();
    } catch {
      toast({ title: "فشل الحفظ", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogTrigger asChild>{children}</DialogTrigger>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>إضافة اشتراك</DialogTitle>
        </DialogHeader>
        <div className="space-y-1.5">
          <div>
            <Label htmlFor="s-name">الاسم</Label>
            <Input
              id="s-name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Netflix"
              autoFocus
            />
          </div>
          <div className="grid grid-cols-2 gap-1.5">
            <div>
              <Label htmlFor="s-cost">التكلفة (ل.س)</Label>
              <Input
                id="s-cost"
                type="number"
                value={cost}
                onChange={(e) => setCost(e.target.value)}
                dir="ltr"
              />
            </div>
            <div>
              <Label htmlFor="s-cycle">دورة الفوترة</Label>
              <div className="grid grid-cols-2 gap-0.5 mt-1">
                {Object.entries(CYCLE_LABELS).map(([value, label]) => {
                  const selected = billingCycle === value;
                  return (
                    <button
                      key={value}
                      onClick={() => setBillingCycle(value)}
                      className={cn(
                        "py-1 rounded-md text-[10px] transition-all",
                        selected
                          ? "text-white"
                          : "text-muted-foreground hover:text-foreground bg-white/5"
                      )}
                      style={selected ? { backgroundColor: G_BLUE } : {}}
                    >
                      {label}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
          <div>
            <Label htmlFor="s-next">الفاتورة القادمة</Label>
            <Input
              id="s-next"
              type="date"
              value={nextBilling}
              onChange={(e) => setNextBilling(e.target.value)}
              dir="ltr"
            />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            إلغاء
          </Button>
          <Button
            onClick={handleSave}
            disabled={saving}
            style={{ backgroundColor: G_GREEN, color: "#fff" }}
          >
            <DynamicIcon
              name={saving ? "Loader2" : "Save"}
              className={cn("h-3.5 w-3.5", saving && "animate-spin")}
            />
            إضافة
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ============================================================
// Shared
// ============================================================
function EmptyState({
  icon,
  color,
  title,
  hint,
}: {
  icon: string;
  color: string;
  title: string;
  hint?: string;
}) {
  return (
    <div className="flex flex-col items-center justify-center py-4 text-center">
      <div
        className="flex h-10 w-10 items-center justify-center rounded-full mb-1.5"
        style={{ backgroundColor: `${color}22`, color }}
      >
        <DynamicIcon name={icon} className="h-5 w-5" />
      </div>
      <p className="text-xs font-medium text-foreground">{title}</p>
      {hint && <p className="text-[10px] text-muted-foreground mt-0.5">{hint}</p>}
    </div>
  );
}

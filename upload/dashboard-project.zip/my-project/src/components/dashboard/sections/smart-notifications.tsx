"use client";

import * as React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Skeleton } from "@/components/ui/skeleton";
import { DynamicIcon } from "../icon";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { format } from "date-fns";
import { ar } from "date-fns/locale";

// Google brand colors
const G_BLUE = "#4285F4";
const G_RED = "#EA4335";
const G_YELLOW = "#FBBC04";
const G_GREEN = "#34A853";
const G_ORANGE = "#FF6D00";
const G_PURPLE = "#A142F4";
const G_TEAL = "#00897B";
const G_GRAY = "#5F6368";

interface Notification {
  id: string;
  type: "info" | "warning" | "success" | "reminder";
  icon: string;
  title: string;
  description: string;
  color: string;
  action?: string;
}

interface WaterData {
  total: number;
  goal: number;
  percentage: number;
  remaining: number;
}

interface PostureData {
  stoodCount: number;
  satCount: number;
  currentPosture: string;
  recommendedStands: number;
  percentage: number;
}

interface SummaryData {
  tasksDone: number;
  habitsCount: number;
  expenses: number;
  eventsCount: number;
  notificationsCount: number;
}

// Smart notification settings — each saved as a key-value in /api/settings
const NOTIFICATION_SETTINGS: Array<{
  key: string;
  label: string;
  description: string;
  icon: string;
  color: string;
  default: boolean;
}> = [
  {
    key: "notif_contextual",
    label: "إشعارات سياقية",
    description: "بناءً على موقعك (وصول/مغادرة)",
    icon: "MapPin",
    color: G_BLUE,
    default: true,
  },
  {
    key: "notif_prayer",
    label: "تنبيهات الصلاة الذكية",
    description: "تذكير قبل/بعد كل صلاة",
    icon: "BellRing",
    color: G_TEAL,
    default: true,
  },
  {
    key: "notif_daily_summary",
    label: "ملخص يومي",
    description: "مساءً في الساعة 9:00",
    icon: "FileText",
    color: G_PURPLE,
    default: true,
  },
  {
    key: "notif_water",
    label: "تذكير شرب الماء",
    description: "كل ساعتين",
    icon: "Droplets",
    color: G_BLUE,
    default: true,
  },
  {
    key: "notif_posture",
    label: "تنبيه الجلوس/الوقوف",
    description: "كل ساعة",
    icon: "Activity",
    color: G_ORANGE,
    default: true,
  },
  {
    key: "notif_weather",
    label: "تنبيهات الطقس المتقدمة",
    description: "عواصف، حرارة، برودة",
    icon: "Cloud",
    color: G_TEAL,
    default: false,
  },
  {
    key: "notif_medication",
    label: "تذكير الأدوية الذكي",
    description: "حسب الجدول الزمني",
    icon: "Heart",
    color: G_RED,
    default: true,
  },
  {
    key: "notif_budget",
    label: "تنبيهات الميزانية",
    description: "عند بلوغ 80% من الشهر",
    icon: "Wallet",
    color: G_YELLOW,
    default: true,
  },
  {
    key: "notif_departure",
    label: "تذكير المغادرة الذكي",
    description: "حسب الموعد والمسافة",
    icon: "Navigation",
    color: G_GREEN,
    default: false,
  },
  {
    key: "notif_vacation",
    label: "تتبع أيام العطلة",
    description: "تنبيهات للأعياد والعطل",
    icon: "CalendarDays",
    color: G_PURPLE,
    default: true,
  },
];

const NOTIF_COLOR_MAP: Record<string, { text: string; bg: string }> = {
  emerald: { text: G_GREEN, bg: `${G_GREEN}22` },
  amber: { text: G_YELLOW, bg: `${G_YELLOW}22` },
  rose: { text: G_RED, bg: `${G_RED}22` },
  teal: { text: G_TEAL, bg: `${G_TEAL}22` },
  purple: { text: G_PURPLE, bg: `${G_PURPLE}22` },
};

const TYPE_ICON_MAP: Record<string, string> = {
  info: "Bell",
  warning: "AlertCircle",
  success: "CheckCircle",
  reminder: "Clock",
};

export function SmartNotificationsSection() {
  const { toast } = useToast();
  const [notifications, setNotifications] = React.useState<Notification[]>([]);
  const [settings, setSettings] = React.useState<Record<string, string>>({});
  const [water, setWater] = React.useState<WaterData | null>(null);
  const [posture, setPosture] = React.useState<PostureData | null>(null);
  const [summary, setSummary] = React.useState<SummaryData | null>(null);
  const [loading, setLoading] = React.useState(true);
  const [refreshing, setRefreshing] = React.useState(false);

  const fetchAll = React.useCallback(async () => {
    try {
      const [nRes, sRes, wRes, pRes, statsRes] = await Promise.all([
        fetch("/api/notifications"),
        fetch("/api/settings"),
        fetch("/api/water"),
        fetch("/api/posture"),
        fetch("/api/stats?period=week"),
      ]);
      const [nJson, sJson, wJson, pJson, stJson] = await Promise.all([
        nRes.json(),
        sRes.json(),
        wRes.json(),
        pRes.json(),
        statsRes.json(),
      ]);
      if (nJson.success) setNotifications(nJson.data);
      if (sJson.success) setSettings(sJson.data);
      if (wJson.success) setWater(wJson);
      if (pJson.success) setPosture(pJson);
      if (stJson.success) {
        const d = stJson.data;
        const today = d.dailyStats?.find((s: { isToday: boolean }) => s.isToday);
        setSummary({
          tasksDone: today?.tasks ?? d.tasksDoneThisWeek ?? 0,
          habitsCount: today?.habits ?? d.habitsCompletedThisWeek ?? 0,
          expenses: today?.expenses ?? d.todayExpensesSYP ?? 0,
          eventsCount: d.eventsThisWeek ?? 0,
          notificationsCount: nJson?.data?.length ?? 0,
        });
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  React.useEffect(() => {
    fetchAll();
    // Refresh notifications every 5 minutes
    const id = setInterval(fetchAll, 5 * 60 * 1000);
    return () => clearInterval(id);
  }, [fetchAll]);

  const handleToggle = async (key: string, value: boolean) => {
    setSettings((prev) => ({ ...prev, [key]: String(value) }));
    try {
      await fetch("/api/settings", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ key, value: String(value) }),
      });
      toast({
        title: value ? "تم تفعيل الإشعار" : "تم تعطيل الإشعار",
        description: NOTIFICATION_SETTINGS.find((s) => s.key === key)?.label,
      });
    } catch {
      toast({ title: "فشل حفظ الإعداد", variant: "destructive" });
      setSettings((prev) => ({ ...prev, [key]: String(!value) }));
    }
  };

  const handleAddWater = async () => {
    try {
      await fetch("/api/water", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ glasses: 1 }),
      });
      fetchAll();
    } catch {
      toast({ title: "فشل تسجيل الماء", variant: "destructive" });
    }
  };

  const handleStoodUp = async () => {
    try {
      await fetch("/api/posture", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ type: "stood" }),
      });
      toast({ title: "أحسنت! سُجّل الوقوف ✓" });
      fetchAll();
    } catch {
      toast({ title: "فشل تسجيل الحالة", variant: "destructive" });
    }
  };

  const handleRefresh = () => {
    setRefreshing(true);
    fetchAll();
  };

  const activeCount = NOTIFICATION_SETTINGS.filter(
    (s) => settings[s.key] !== "false" && (settings[s.key] === "true" || s.default && settings[s.key] === undefined)
  ).length;

  return (
    <div className="space-y-1.5">
      {/* Header */}
      <Card className="p-2" style={{ backgroundColor: "var(--surface-container)" }}>
        <div className="flex items-center gap-1.5">
          <div
            className="flex h-7 w-7 items-center justify-center rounded-lg relative"
            style={{ backgroundColor: `${G_YELLOW}22`, color: G_YELLOW }}
          >
            <DynamicIcon name="Bell" className="h-4 w-4" />
            {notifications.length > 0 && (
              <span
                className="absolute -top-1 -right-1 h-3.5 w-3.5 rounded-full text-white text-[8px] font-bold flex items-center justify-center"
                style={{ backgroundColor: G_RED }}
              >
                {notifications.length > 9 ? "9+" : notifications.length}
              </span>
            )}
          </div>
          <div className="flex-1">
            <p className="text-xs font-bold text-foreground">مركز الإشعارات الذكي</p>
            <p className="text-[10px] text-muted-foreground">
              {activeCount}/{NOTIFICATION_SETTINGS.length} إشعار نشط
            </p>
          </div>
          <Button
            size="sm"
            variant="ghost"
            className="h-7 w-7 p-0"
            onClick={handleRefresh}
            disabled={refreshing}
          >
            <DynamicIcon
              name={refreshing ? "Loader2" : "RefreshCw"}
              className={cn("h-3.5 w-3.5", refreshing && "animate-spin")}
            />
          </Button>
        </div>
      </Card>

      {/* Trackers row: Water + Posture */}
      <div className="grid grid-cols-2 gap-1.5">
        {/* Water tracker */}
        <Card className="p-2" style={{ backgroundColor: "var(--surface-container)" }}>
          <div className="flex items-center gap-1.5 mb-1">
            <div
              className="flex h-6 w-6 items-center justify-center rounded-lg shrink-0"
              style={{ backgroundColor: `${G_BLUE}22`, color: G_BLUE }}
            >
              <DynamicIcon name="Droplets" className="h-3.5 w-3.5" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-[10px] font-bold text-foreground">الماء</p>
              <p className="text-[9px] text-muted-foreground">
                {water ? `${water.total}/${water.goal}` : "—"}
              </p>
            </div>
            <Button
              size="sm"
              className="h-6 w-6 p-0 rounded-full"
              style={{ backgroundColor: G_BLUE, color: "#fff" }}
              onClick={handleAddWater}
            >
              <DynamicIcon name="Plus" className="h-3 w-3" />
            </Button>
          </div>
          {/* Progress with droplet pips */}
          <div className="flex gap-0.5">
            {Array.from({ length: 8 }).map((_, i) => (
              <motion.div
                key={i}
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: i * 0.03, type: "spring", stiffness: 300, damping: 20 }}
                className="flex-1 h-3 rounded-full"
                style={{
                  backgroundColor: water && i < water.total ? G_BLUE : "rgba(255,255,255,0.06)",
                }}
              />
            ))}
          </div>
          {water && water.percentage >= 100 && (
            <p className="text-[9px] mt-0.5 font-bold" style={{ color: G_GREEN }}>
              ✓ هدف اليوم مكتمل!
            </p>
          )}
        </Card>

        {/* Posture tracker */}
        <Card className="p-2" style={{ backgroundColor: "var(--surface-container)" }}>
          <div className="flex items-center gap-1.5 mb-1">
            <div
              className="flex h-6 w-6 items-center justify-center rounded-lg shrink-0"
              style={{ backgroundColor: `${G_ORANGE}22`, color: G_ORANGE }}
            >
              <DynamicIcon name="Activity" className="h-3.5 w-3.5" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-[10px] font-bold text-foreground">الوقوف</p>
              <p className="text-[9px] text-muted-foreground">
                {posture ? `${posture.stoodCount}/${posture.recommendedStands}` : "—"}
              </p>
            </div>
            <Button
              size="sm"
              className="h-6 px-1.5 text-[9px] gap-0.5 rounded-full"
              style={{ backgroundColor: G_ORANGE, color: "#fff" }}
              onClick={handleStoodUp}
            >
              <DynamicIcon name="Check" className="h-3 w-3" />
              وقفت
            </Button>
          </div>
          {/* Progress with bar pips */}
          <div className="flex gap-0.5">
            {Array.from({ length: 8 }).map((_, i) => (
              <motion.div
                key={i}
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: i * 0.03, type: "spring", stiffness: 300, damping: 20 }}
                className="flex-1 h-3 rounded-full"
                style={{
                  backgroundColor:
                    posture && i < posture.stoodCount ? G_ORANGE : "rgba(255,255,255,0.06)",
                }}
              />
            ))}
          </div>
          {posture && posture.percentage >= 100 && (
            <p className="text-[9px] mt-0.5 font-bold" style={{ color: G_GREEN }}>
              ✓ تحركت بما يكفي!
            </p>
          )}
        </Card>
      </div>

      {/* Daily Summary preview */}
      <Card className="p-2" style={{ backgroundColor: "var(--surface-container)" }}>
        <div className="flex items-center gap-1.5 mb-1.5">
          <div
            className="flex h-6 w-6 items-center justify-center rounded-lg shrink-0"
            style={{ backgroundColor: `${G_PURPLE}22`, color: G_PURPLE }}
          >
            <DynamicIcon name="FileText" className="h-3.5 w-3.5" />
          </div>
          <h3 className="text-xs font-bold text-foreground">ملخص اليوم</h3>
          <span className="text-[9px] text-muted-foreground mr-auto">
            {format(new Date(), "d MMMM", { locale: ar })}
          </span>
        </div>
        {loading || !summary ? (
          <Skeleton className="h-16 rounded-lg" />
        ) : (
          <div className="grid grid-cols-4 gap-1">
            <SummaryStat icon="CheckCircle" color={G_GREEN} value={summary.tasksDone} label="مهام" />
            <SummaryStat icon="RefreshCw" color={G_TEAL} value={summary.habitsCount} label="عادات" />
            <SummaryStat icon="Calendar" color={G_BLUE} value={summary.eventsCount} label="أحداث" />
            <SummaryStat icon="Bell" color={G_YELLOW} value={summary.notificationsCount} label="تنبيهات" />
          </div>
        )}
        {summary && (
          <p className="text-[10px] text-muted-foreground mt-1.5 leading-snug">
            {summary.tasksDone > 0
              ? `أنجزت ${summary.tasksDone} مهمة اليوم — ${
                  summary.tasksDone >= 5 ? "يوم منتج! 🎉" : "حافظ على الإيقاع 💪"
                }`
              : "ابدأ يومك بإنجاز أول مهمة! 🚀"}
          </p>
        )}
      </Card>

      {/* Active notifications list */}
      <Card className="p-2" style={{ backgroundColor: "var(--surface-container)" }}>
        <div className="flex items-center justify-between mb-1.5">
          <div className="flex items-center gap-1.5">
            <div
              className="flex h-6 w-6 items-center justify-center rounded-lg shrink-0"
              style={{ backgroundColor: `${G_RED}22`, color: G_RED }}
            >
              <DynamicIcon name="BellRing" className="h-3.5 w-3.5" />
            </div>
            <h3 className="text-xs font-bold text-foreground">الإشعارات النشطة</h3>
          </div>
          <span
            className="text-[9px] px-1.5 py-0.5 rounded-full font-mono"
            style={{ backgroundColor: `${G_RED}22`, color: G_RED }}
          >
            {notifications.length}
          </span>
        </div>
        {loading ? (
          <div className="space-y-1">
            {Array.from({ length: 3 }).map((_, i) => (
              <Skeleton key={i} className="h-10 rounded-lg" />
            ))}
          </div>
        ) : notifications.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-3 text-center">
            <div
              className="flex h-8 w-8 items-center justify-center rounded-full mb-1"
              style={{ backgroundColor: `${G_GREEN}22`, color: G_GREEN }}
            >
              <DynamicIcon name="CheckCircle" className="h-4 w-4" />
            </div>
            <p className="text-[10px] font-medium text-foreground">كل شيء على ما يرام ✓</p>
            <p className="text-[9px] text-muted-foreground">لا إشعارات نشطة حالياً</p>
          </div>
        ) : (
          <div className="space-y-1 max-h-64 overflow-y-auto custom-scroll">
            <AnimatePresence>
              {notifications.map((n, i) => {
                const c = NOTIF_COLOR_MAP[n.color] || NOTIF_COLOR_MAP.amber;
                return (
                  <motion.div
                    key={n.id}
                    layout
                    initial={{ opacity: 0, x: 6 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -6 }}
                    transition={{ delay: i * 0.03 }}
                    className="flex items-start gap-1.5 p-1.5 rounded-lg"
                    style={{ backgroundColor: "var(--surface-container-high)" }}
                  >
                    <div
                      className="flex h-6 w-6 items-center justify-center rounded-lg shrink-0"
                      style={{ backgroundColor: c.bg, color: c.text }}
                    >
                      <DynamicIcon name={n.icon || TYPE_ICON_MAP[n.type]} className="h-3.5 w-3.5" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-[11px] font-medium text-foreground leading-tight">
                        {n.title}
                      </p>
                      <p className="text-[10px] text-muted-foreground leading-tight truncate">
                        {n.description}
                      </p>
                    </div>
                  </motion.div>
                );
              })}
            </AnimatePresence>
          </div>
        )}
      </Card>

      {/* Notification settings */}
      <Card className="p-2" style={{ backgroundColor: "var(--surface-container)" }}>
        <div className="flex items-center gap-1.5 mb-1.5">
          <div
            className="flex h-6 w-6 items-center justify-center rounded-lg shrink-0"
            style={{ backgroundColor: `${G_TEAL}22`, color: G_TEAL }}
          >
            <DynamicIcon name="Settings" className="h-3.5 w-3.5" />
          </div>
          <h3 className="text-xs font-bold text-foreground">إعدادات الإشعارات الذكية</h3>
        </div>
        {loading ? (
          <div className="space-y-1">
            {Array.from({ length: 5 }).map((_, i) => (
              <Skeleton key={i} className="h-10 rounded-lg" />
            ))}
          </div>
        ) : (
          <div className="space-y-1 max-h-96 overflow-y-auto custom-scroll">
            {NOTIFICATION_SETTINGS.map((s, i) => {
              const isChecked =
                settings[s.key] === "true" ||
                (settings[s.key] === undefined && s.default);
              return (
                <motion.div
                  key={s.key}
                  initial={{ opacity: 0, y: 4 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.02 }}
                  className={cn(
                    "flex items-center gap-1.5 p-1.5 rounded-lg transition-all",
                    !isChecked && "opacity-60"
                  )}
                  style={{
                    backgroundColor: isChecked ? `${s.color}12` : "var(--surface-container-high)",
                  }}
                >
                  <div
                    className="flex h-6 w-6 items-center justify-center rounded-lg shrink-0"
                    style={{ backgroundColor: `${s.color}22`, color: s.color }}
                  >
                    <DynamicIcon name={s.icon} className="h-3.5 w-3.5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-[11px] font-medium text-foreground leading-tight">
                      {s.label}
                    </p>
                    <p className="text-[9px] text-muted-foreground leading-tight">
                      {s.description}
                    </p>
                  </div>
                  <Switch checked={isChecked} onCheckedChange={(c) => handleToggle(s.key, c)} />
                </motion.div>
              );
            })}
          </div>
        )}
      </Card>
    </div>
  );
}

// ---------- Sub components ----------
function SummaryStat({
  icon,
  color,
  value,
  label,
}: {
  icon: string;
  color: string;
  value: number;
  label: string;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ type: "spring", stiffness: 300, damping: 20 }}
      className="flex flex-col items-center p-1 rounded-lg"
      style={{ backgroundColor: `${color}12` }}
    >
      <div
        className="flex h-6 w-6 items-center justify-center rounded-full mb-0.5"
        style={{ backgroundColor: `${color}22`, color }}
      >
        <DynamicIcon name={icon} className="h-3 w-3" />
      </div>
      <span className="text-xs font-bold font-mono text-foreground">{value}</span>
      <span className="text-[8px] text-muted-foreground">{label}</span>
    </motion.div>
  );
}

"use client";

import * as React from "react";
import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { DynamicIcon } from "../icon";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { USER_PROFILE } from "@/lib/constants";

// أذكار الصباح والمساء
const ADHKAR = {
  morning: [
    { text: "أَصْبَحْنَا وَأَصْبَحَ المُلْكُ لِلَّهِ، وَالحَمْدُ لِلَّهِ، لا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لا شَرِيكَ لَهُ", count: 1 },
    { text: "اللَّهُمَّ أَنْتَ رَبِّي لا إِلَهَ إِلَّا أَنْتَ، خَلَقْتَنِي وَأَنَا عَبْدُكَ", count: 1 },
    { text: "بِسْمِ اللَّهِ الَّذِي لا يَضُرُّ مَعَ اسْمِهِ شَيْءٌ فِي الأَرْضِ وَلا فِي السَّمَاءِ وَهُوَ السَّمِيعُ العَلِيمُ", count: 3 },
    { text: "رَضِيتُ بِاللَّهِ رَبًّا، وَبِالإِسْلامِ دِينًا، وَبِمُحَمَّدٍ صَلَّى اللَّهُ عَلَيْهِ وَسَلَّمَ نَبِيًّا", count: 3 },
    { text: "حَسْبِيَ اللَّهُ لا إِلَهَ إِلَّا هُوَ عَلَيْهِ تَوَكَّلْتُ وَهُوَ رَبُّ العَرْشِ العَظِيمِ", count: 7 },
    { text: "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ", count: 100 },
  ],
  evening: [
    { text: "أَمْسَيْنَا وَأَمْسَى المُلْكُ لِلَّهِ، وَالحَمْدُ لِلَّهِ، لا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لا شَرِيكَ لَهُ", count: 1 },
    { text: "اللَّهُمَّ بِكَ أَمْسَيْنَا، وَبِكَ أَصْبَحْنَا، وَبِكَ نَحْيَا، وَبِكَ نَمُوتُ، وَإِلَيْكَ المَصِيرُ", count: 1 },
    { text: "بِسْمِ اللَّهِ الَّذِي لا يَضُرُّ مَعَ اسْمِهِ شَيْءٌ فِي الأَرْضِ وَلا فِي السَّمَاءِ وَهُوَ السَّمِيعُ العَلِيمُ", count: 3 },
    { text: "أَعُوذُ بِكَلِمَاتِ اللَّهِ التَّامَّاتِ مِنْ شَرِّ مَا خَلَقَ", count: 3 },
    { text: "اللَّهُمَّ إِنِّي أَسْأَلُكَ العَفْوَ وَالعَافِيَةَ فِي الدُّنْيَا وَالآخِرَةِ", count: 1 },
    { text: "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ", count: 100 },
  ],
};

export function IslamicSection() {
  const [tab, setTab] = React.useState<"qibla" | "adhkar" | "quran">("qibla");

  return (
    <div className="space-y-2">
      {/* Tabs */}
      <Card className="glass p-2">
        <div className="flex gap-1">
          {[
            { id: "qibla", label: "موقع القبلة", icon: "Compass" },
            { id: "adhkar", label: "الأذكار", icon: "Sparkles" },
            { id: "quran", label: "ختمة القرآن", icon: "Book" },
          ].map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id as "qibla" | "adhkar" | "quran")}
              className={cn(
                "flex-1 flex items-center justify-center gap-2 py-2.5 rounded-lg text-sm font-medium transition-all",
                tab === t.id ? "bg-emerald-glow/15 text-emerald-glow" : "text-muted-foreground hover:text-foreground"
              )}
            >
              <DynamicIcon name={t.icon} className="h-4 w-4" />
              {t.label}
            </button>
          ))}
        </div>
      </Card>

      {tab === "qibla" && <QiblaTab />}
      {tab === "adhkar" && <AdhkarTab />}
      {tab === "quran" && <QuranTab />}
    </div>
  );
}

// ============ QIBLA ============
function QiblaTab() {
  const [qiblaDirection, setQiblaDirection] = React.useState<number | null>(null);
  const [compassHeading, setCompassHeading] = React.useState(0);

  React.useEffect(() => {
    // حساب اتجاه القبلة من حلب إلى مكة
    // مكة: 21.4225° N, 39.8262° E
    // حلب: 36.2021° N, 37.1343° E
    const lat1 = USER_PROFILE.lat * Math.PI / 180;
    const lat2 = 21.4225 * Math.PI / 180;
    const lon1 = USER_PROFILE.lng * Math.PI / 180;
    const lon2 = 39.8262 * Math.PI / 180;

    const dLon = lon2 - lon1;
    const y = Math.sin(dLon) * Math.cos(lat2);
    const x = Math.cos(lat1) * Math.sin(lat2) - Math.sin(lat1) * Math.cos(lat2) * Math.cos(dLon);
    const bearing = Math.atan2(y, x) * 180 / Math.PI;
    setQiblaDirection((bearing + 360) % 360);
  }, []);

  // محاكاة البوصلة (في الواقع ستستخدم DeviceOrientation API)
  React.useEffect(() => {
    const handler = (e: DeviceOrientationEvent) => {
      if (e.alpha !== null) {
        setCompassHeading(360 - e.alpha);
      }
    };
    window.addEventListener("deviceorientation", handler);
    return () => window.removeEventListener("deviceorientation", handler);
  }, []);

  const rotation = qiblaDirection !== null ? qiblaDirection - compassHeading : 0;

  return (
    <Card className="glass p-8 text-center">
      <div className="flex items-center justify-center gap-2 mb-1.5">
        <div className="flex h-7 w-7 items-center justify-center rounded-xl bg-emerald-glow/15 text-emerald-glow">
          <DynamicIcon name="Compass" className="h-5 w-5" />
        </div>
        <h3 className="text-base font-bold text-foreground">اتجاه القبلة</h3>
      </div>

      <div className="relative h-40 w-40 mx-auto mb-1.5">
        {/* Compass circle */}
        <div className="absolute inset-0 rounded-full border-4 border-border/40 glass">
          {/* Directions */}
          {["شمال", "شرق", "جنوب", "غرب"].map((dir, i) => (
            <div
              key={dir}
              className="absolute text-xs font-bold text-muted-foreground"
              style={{
                top: i === 0 ? "8px" : i === 2 ? "auto" : "50%",
                bottom: i === 2 ? "8px" : "auto",
                left: i === 3 ? "8px" : i === 1 ? "auto" : "50%",
                right: i === 1 ? "8px" : "auto",
                transform: "translate(-50%, -50%)",
              }}
            >
              {dir}
            </div>
          ))}
        </div>

        {/* Qibla arrow */}
        <motion.div
          className="absolute inset-0 flex items-center justify-center"
          animate={{ rotate: rotation }}
          transition={{ type: "spring", stiffness: 200, damping: 20 }}
        >
          <div className="relative">
            {/* Kaaba icon in center */}
            <div className="absolute left-1/2 -translate-x-1/2 -translate-y-20 w-10 h-10 rounded-lg bg-gradient-to-br from-emerald-glow to-amber-glow flex items-center justify-center text-background font-bold text-lg shadow-lg">
              ⟨
            </div>
            {/* Arrow pointing to Qibla */}
            <svg width="160" height="160" viewBox="0 0 160 160" className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2">
              <path d="M80 10 L95 80 L80 70 L65 80 Z" fill="var(--accent-primary)" opacity="0.9" />
            </svg>
          </div>
        </motion.div>

        {/* Center dot */}
        <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 h-4 w-4 rounded-full bg-foreground border-2 border-background" />
      </div>

      <div className="space-y-2">
        <p className="text-2xl font-bold text-emerald-glow">
          {qiblaDirection !== null ? `${Math.round(qiblaDirection)}°` : "—"}
        </p>
        <p className="text-sm text-muted-foreground">
          اتجاه القبلة من حلب إلى الكعبة المشرّفة
        </p>
        <p className="text-[11px] text-muted-foreground/70 mt-2">
          💡 وجّه سهم القبلة نحو الشمال للحصول على الاتجاه الصحيح
        </p>
      </div>
    </Card>
  );
}

// ============ ADHKAR ============
function AdhkarTab() {
  const [period, setPeriod] = React.useState<"morning" | "evening">("morning");
  const [counts, setCounts] = React.useState<Record<number, number>>({});

  const adhkar = ADHKAR[period];

  const handleCount = (index: number, max: number) => {
    setCounts((prev) => {
      const current = prev[index] || 0;
      if (current >= max) return prev;
      return { ...prev, [index]: current + 1 };
    });
  };

  React.useEffect(() => {
    setCounts({});
  }, [period]);

  const isMorning = period === "morning";

  return (
    <div className="space-y-2">
      <Card className="glass p-2">
        <div className="flex gap-1">
          <button
            onClick={() => setPeriod("morning")}
            className={cn(
              "flex-1 flex items-center justify-center gap-2 py-2.5 rounded-lg text-sm font-medium transition-all",
              isMorning ? "bg-amber-glow/15 text-amber-glow" : "text-muted-foreground"
            )}
          >
            <DynamicIcon name="Sunrise" className="h-4 w-4" />
            أذكار الصباح
          </button>
          <button
            onClick={() => setPeriod("evening")}
            className={cn(
              "flex-1 flex items-center justify-center gap-2 py-2.5 rounded-lg text-sm font-medium transition-all",
              !isMorning ? "bg-purple-500/15 text-purple-400" : "text-muted-foreground"
            )}
          >
            <DynamicIcon name="Moon" className="h-4 w-4" />
            أذكار المساء
          </button>
        </div>
      </Card>

      <div className="space-y-1.5">
        {adhkar.map((dhikr, i) => {
          const currentCount = counts[i] || 0;
          const isDone = currentCount >= dhikr.count;
          return (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
            >
              <Card
                className={cn(
                  "glass p-2 transition-all cursor-pointer",
                  isDone ? "border-emerald-glow/40 bg-emerald-glow/5" : "hover:border-emerald-glow/20"
                )}
                onClick={() => handleCount(i, dhikr.count)}
              >
                <div className="flex items-start gap-2">
                  <div className={cn(
                    "flex h-7 w-7 items-center justify-center rounded-xl shrink-0 font-bold text-sm",
                    isDone ? "bg-emerald-glow text-background" : "bg-muted/30 text-muted-foreground"
                  )}>
                    {isDone ? "✓" : currentCount}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-foreground leading-relaxed font-arabic">
                      {dhikr.text}
                    </p>
                    <div className="flex items-center gap-2 mt-2">
                      <span className={cn(
                        "text-[11px] px-2 py-0.5 rounded-full",
                        isDone ? "bg-emerald-glow/15 text-emerald-glow" : "bg-muted/30 text-muted-foreground"
                      )}>
                        {currentCount} / {dhikr.count}
                      </span>
                      {isDone && (
                        <span className="text-[10px] text-emerald-glow">تم بحمد الله</span>
                      )}
                    </div>
                  </div>
                </div>
              </Card>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}

// ============ QURAN ============
const SURAHS = [
  "الفاتحة", "البقرة", "آل عمران", "النساء", "المائدة", "الأنعام", "الأعراف", "الأنفال", "التوبة", "يونس",
  "هود", "يوسف", "الرعد", "إبراهيم", "الحجر", "النحل", "الإسراء", "الكهف", "مريم", "طه",
  "الأنبياء", "الحج", "المؤمنون", "النور", "الفرقان", "الشعراء", "النمل", "القصص", "العنكبوت", "الروم",
  "لقمان", "السجدة", "الأحزاب", "سبأ", "فاطر", "يس", "الصافات", "ص", "الزمر", "غافر",
  "فصلت", "الشورى", "الزخرف", "الدخان", "الجاثية", "الأحقاف", "محمد", "الفتح", "الحجرات", "ق",
  "الذاريات", "الطور", "النجم", "القمر", "الرحمن", "الواقعة", "الحديد", "المجادلة", "الحشر", "الممتحنة",
  "الصف", "الجمعة", "المنافقون", "التغابن", "الطلاق", "التحريم", "الملك", "القلم", "الحاقة", "المعارج",
  "نوح", "الجن", "المزمل", "المدثر", "القيامة", "الإنسان", "المرسلات", "النبأ", "النازعات", "عبس",
  "التكوير", "الانفطار", "المطففين", "الانشقاق", "البروج", "الطارق", "الأعلى", "الغاشية", "الفجر", "البلد",
  "الشمس", "الليل", "الضحى", "الشرح", "التين", "العلق", "القدر", "البينة", "الزلزلة", "العاديات",
  "القارعة", "التكاثر", "العصر", "الهمزة", "الفيل", "قريش", "الماعون", "الكوثر", "الكافرون", "النصر",
  "المسد", "الإخلاص", "الفلق", "الناس"
];

function QuranTab() {
  const [logs, setLogs] = React.useState<Array<{ id: string; surah: number; fromAyah: number; toAyah: number; juz: number | null; note: string | null; date: string }>>([]);
  const [stats, setStats] = React.useState({ totalAyahs: 0, surahsRead: 0, sessions: 0 });
  const [loading, setLoading] = React.useState(true);
  const [surah, setSurah] = React.useState("1");
  const [fromAyah, setFromAyah] = React.useState("1");
  const [toAyah, setToAyah] = React.useState("7");
  const [juz, setJuz] = React.useState("");
  const { toast } = useToast();

  const fetchData = React.useCallback(async () => {
    try {
      const res = await fetch("/api/quran");
      const json = await res.json();
      if (json.success) {
        setLogs(json.data);
        setStats(json.stats);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, []);

  React.useEffect(() => {
    fetchData();
  }, [fetchData]);

  const handleAdd = async () => {
    try {
      await fetch("/api/quran", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ surah: Number(surah), fromAyah: Number(fromAyah), toAyah: Number(toAyah), juz: juz ? Number(juz) : null }),
      });
      toast({ title: "تم تسجيل التلاوة 📖" });
      fetchData();
    } catch {
      toast({ title: "فشل الإضافة", variant: "destructive" });
    }
  };

  const handleDelete = async (id: string) => {
    await fetch(`/api/quran?id=${id}`, { method: "DELETE" });
    fetchData();
  };

  return (
    <div className="space-y-2">
      {/* Stats */}
      <div className="grid grid-cols-3 gap-2">
        <Card className="glass p-2.5 text-center">
          <p className="text-2xl font-bold text-emerald-glow">{stats.totalAyahs}</p>
          <p className="text-[11px] text-muted-foreground">آيات مقروءة</p>
        </Card>
        <Card className="glass p-2.5 text-center">
          <p className="text-2xl font-bold text-amber-glow">{stats.surahsRead}</p>
          <p className="text-[11px] text-muted-foreground">سورة</p>
        </Card>
        <Card className="glass p-2.5 text-center">
          <p className="text-2xl font-bold text-teal-400">{stats.sessions}</p>
          <p className="text-[11px] text-muted-foreground">جلسات</p>
        </Card>
      </div>

      {/* Add form */}
      <Card className="glass p-2">
        <h4 className="text-sm font-bold text-foreground mb-1.5">تسجيل تلاوة جديدة</h4>
        <div className="grid grid-cols-2 gap-2 mb-1.5">
          <div>
            <Label className="text-[11px]">السورة</Label>
            <Select value={surah} onValueChange={setSurah}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent className="glass-strong max-h-60">
                {SURAHS.map((s, i) => (
                  <SelectItem key={i} value={String(i + 1)}>{i + 1}. {s}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label className="text-[11px]">الجزء (اختياري)</Label>
            <Input type="number" min={1} max={30} value={juz} onChange={(e) => setJuz(e.target.value)} placeholder="1-30" />
          </div>
          <div>
            <Label className="text-[11px]">من آية</Label>
            <Input type="number" min={1} value={fromAyah} onChange={(e) => setFromAyah(e.target.value)} />
          </div>
          <div>
            <Label className="text-[11px]">إلى آية</Label>
            <Input type="number" min={1} value={toAyah} onChange={(e) => setToAyah(e.target.value)} />
          </div>
        </div>
        <Button onClick={handleAdd} className="w-full bg-emerald-glow hover:bg-emerald-glow/90 text-background">
          <DynamicIcon name="Plus" className="h-4 w-4" />
          تسجيل التلاوة
        </Button>
      </Card>

      {/* History */}
      <Card className="glass p-2">
        <h4 className="text-sm font-bold text-foreground mb-1.5">سجل التلاوات</h4>
        {loading ? (
          <div className="space-y-2">
            {Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-8 rounded-lg" />)}
          </div>
        ) : logs.length === 0 ? (
          <p className="text-sm text-muted-foreground text-center py-2">لا تلاوات مسجلة بعد</p>
        ) : (
          <div className="space-y-2 max-h-80 overflow-y-auto custom-scroll">
            {logs.map((log) => (
              <div key={log.id} className="flex items-center gap-2 rounded-xl border border-border/40 bg-background/30 p-2">
                <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-emerald-glow/15 text-emerald-glow shrink-0">
                  <DynamicIcon name="Book" className="h-4 w-4" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-foreground">
                    {SURAHS[log.surah - 1]} ({log.fromAyah}-{log.toAyah})
                  </p>
                  <p className="text-[10px] text-muted-foreground">
                    {log.juz ? `الجزء ${log.juz} • ` : ""}
                    {new Date(log.date).toLocaleDateString("ar-SY")}
                  </p>
                </div>
                <Button variant="ghost" size="icon" className="h-8 w-8 hover:text-rose-400" onClick={() => handleDelete(log.id)}>
                  <DynamicIcon name="Trash2" className="h-3.5 w-3.5" />
                </Button>
              </div>
            ))}
          </div>
        )}
      </Card>
    </div>
  );
}

"use client";

import * as React from "react";
import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger,
} from "@/components/ui/dialog";
import { DynamicIcon } from "../icon";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

// Google brand colors
const G_BLUE = "#4285F4";
const G_RED = "#EA4335";
const G_YELLOW = "#FBBC04";
const G_GREEN = "#34A853";
const G_ORANGE = "#FF6D00";
const G_PURPLE = "#A142F4";
const G_TEAL = "#00897B";

interface Asset {
  id: string;
  type: string;
  amount: number;
  unit: string;
  note?: string | null;
}

interface CurrencyData {
  usdToSYP: number;
  goldPerGramUSD: number;
  goldPerGramSYP: number;
  goldPerGram21USD: number;
  goldPerGram21SYP: number;
  updatedAt: string;
  note: string;
}

const assetConfig: Record<string, { label: string; icon: string; color: string; unit: string }> = {
  gold: { label: "الذهب", icon: "Coins", color: "amber", unit: "غرام" },
  usd: { label: "دولار أمريكي", icon: "DollarSign", color: "emerald", unit: "$" },
  syp: { label: "ليرة سورية", icon: "Banknote", color: "rose", unit: "ل.س" },
  bank: { label: "بنك", icon: "Building2", color: "teal", unit: "" },
  cash: { label: "نقد", icon: "Wallet", color: "emerald", unit: "" },
};

export function FinancesSection() {
  const [assets, setAssets] = React.useState<Asset[]>([]);
  const [currency, setCurrency] = React.useState<CurrencyData | null>(null);
  const [loading, setLoading] = React.useState(true);
  const [convertFrom, setConvertFrom] = React.useState("gold");
  const [convertAmount, setConvertAmount] = React.useState("1");
  const { toast } = useToast();

  const fetchData = React.useCallback(async () => {
    setLoading(true);
    try {
      const [assetsRes, currencyRes] = await Promise.all([
        fetch("/api/assets"),
        fetch("/api/currency"),
      ]);
      const assetsJson = await assetsRes.json();
      const currencyJson = await currencyRes.json();
      if (assetsJson.success) setAssets(assetsJson.data);
      if (currencyJson.success || currencyJson.data) setCurrency(currencyJson.data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, []);

  React.useEffect(() => {
    fetchData();
  }, [fetchData]);

  const getAssetValueSYP = (asset: Asset): number => {
    if (!currency) return 0;
    if (asset.type === "gold") {
      // نفترض عيار 21
      return asset.amount * currency.goldPerGram21SYP;
    }
    if (asset.type === "usd") {
      return asset.amount * currency.usdToSYP;
    }
    if (asset.type === "syp") {
      return asset.amount;
    }
    return 0;
  };

  const totalValueSYP = assets.reduce((acc, a) => acc + getAssetValueSYP(a), 0);
  const totalValueUSD = currency ? totalValueSYP / currency.usdToSYP : 0;

  const handleUpdateAmount = async (asset: Asset, newAmount: number) => {
    try {
      await fetch("/api/assets", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: asset.id, amount: newAmount }),
      });
      fetchData();
      toast({ title: "تم تحديث المبلغ" });
    } catch {
      toast({ title: "فشل التحديث", variant: "destructive" });
    }
  };

  // التحويل بين العملات
  const convertValue = (): { syp: number; usd: number; gold: number } => {
    const amount = parseFloat(convertAmount) || 0;
    if (!currency) return { syp: 0, usd: 0, gold: 0 };
    let syp = 0;
    if (convertFrom === "gold") syp = amount * currency.goldPerGram21SYP;
    else if (convertFrom === "usd") syp = amount * currency.usdToSYP;
    else if (convertFrom === "syp") syp = amount;
    return {
      syp,
      usd: syp / currency.usdToSYP,
      gold: syp / currency.goldPerGram21SYP,
    };
  };

  const converted = convertValue();

  const colorMap: Record<string, string> = {
    amber: "bg-amber-glow/10 text-amber-glow",
    emerald: "bg-emerald-glow/10 text-emerald-glow",
    rose: "bg-rose-500/10 text-rose-400",
    teal: "bg-teal-500/10 text-teal-400",
  };

  return (
    <div className="space-y-2">
      {/* Total wealth */}
      <motion.div initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }}>
        <Card className="glass-strong p-2 relative overflow-hidden">
          <div className="absolute -top-16 -left-16 h-20 w-20 rounded-full bg-amber-glow/10 blur-3xl" />
          <div className="absolute -bottom-16 -right-16 h-20 w-20 rounded-full bg-emerald-glow/10 blur-3xl" />
          <div className="relative">
            <div className="flex items-center gap-2 mb-2">
              <DynamicIcon name="Wallet" className="h-5 w-5 text-amber-glow" />
              <p className="text-sm text-muted-foreground">إجمالي الثروة (تقديري)</p>
            </div>
            {loading ? (
              <Skeleton className="h-8 w-48" />
            ) : (
              <>
                <p className="text-3xl lg:text-4xl font-bold text-gradient-gold mb-1">
                  {totalValueSYP.toLocaleString("ar-EG", { maximumFractionDigits: 0 })} ل.س
                </p>
                <p className="text-sm text-muted-foreground">
                  ≈ {totalValueUSD.toLocaleString("en-US", { maximumFractionDigits: 2 })} دولار
                </p>
                {currency && (
                  <p className="text-[10px] text-muted-foreground/70 mt-2">
                    {currency.note} • آخر تحديث: {new Date(currency.updatedAt).toLocaleTimeString("ar-SY")}
                  </p>
                )}
              </>
            )}
          </div>
        </Card>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-2">
        {/* Assets list */}
        <div className="lg:col-span-2 space-y-2">
          <Card className="glass p-2">
            <div className="flex items-center gap-2 mb-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-emerald-glow/15 text-emerald-glow">
                <DynamicIcon name="Coins" className="h-4 w-4" />
              </div>
              <h3 className="text-sm font-bold text-foreground">الأصول المالية</h3>
            </div>

            {loading ? (
              <div className="space-y-1.5">
                {Array.from({ length: 3 }).map((_, i) => (
                  <Skeleton key={i} className="h-16 rounded-xl" />
                ))}
              </div>
            ) : (
              <div className="space-y-1.5">
                {assets.map((asset, i) => {
                  const config = assetConfig[asset.type] || assetConfig.cash;
                  const valueSYP = getAssetValueSYP(asset);
                  return (
                    <motion.div
                      key={asset.id}
                      initial={{ opacity: 0, x: -8 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: i * 0.05 }}
                      className="flex items-center gap-2 rounded-xl border border-border/40 bg-background/40 p-2 hover:border-emerald-glow/30 transition-all group"
                    >
                      <div className={cn("flex h-8 w-8 items-center justify-center rounded-xl shrink-0", colorMap[config.color])}>
                        <DynamicIcon name={config.icon} className="h-6 w-6" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-bold text-foreground">{config.label}</p>
                        <p className="text-xs text-muted-foreground">
                          {asset.note || "—"}
                        </p>
                        <p className="text-[11px] text-emerald-glow mt-0.5">
                          ≈ {valueSYP.toLocaleString("ar-EG", { maximumFractionDigits: 0 })} ل.س
                        </p>
                      </div>
                      <div className="text-left shrink-0">
                        <p className="text-xl font-bold text-foreground">
                          {asset.amount.toLocaleString("ar-EG")}
                        </p>
                        <p className="text-[11px] text-muted-foreground">{config.unit}</p>
                      </div>
                      <EditAmountButton
                        asset={asset}
                        onSave={(amount) => handleUpdateAmount(asset, amount)}
                      />
                    </motion.div>
                  );
                })}
              </div>
            )}
          </Card>
        </div>

        {/* Currency converter */}
        <div className="space-y-2">
          <Card className="glass p-2">
            <div className="flex items-center gap-2 mb-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-amber-glow/15 text-amber-glow">
                <DynamicIcon name="RefreshCw" className="h-4 w-4" />
              </div>
              <h3 className="text-sm font-bold text-foreground">محول العملات</h3>
            </div>

            <div className="space-y-1.5">
              <div>
                <Label htmlFor="conv-from">من</Label>
                <div className="flex gap-2">
                  <Select value={convertFrom} onValueChange={setConvertFrom}>
                    <SelectTrigger className="flex-1"><SelectValue /></SelectTrigger>
                    <SelectContent className="glass-strong">
                      <SelectItem value="gold">ذهب (غرام)</SelectItem>
                      <SelectItem value="usd">دولار</SelectItem>
                      <SelectItem value="syp">ليرة سورية</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div>
                <Label htmlFor="conv-amount">المبلغ</Label>
                <Input
                  id="conv-amount"
                  type="number"
                  value={convertAmount}
                  onChange={(e) => setConvertAmount(e.target.value)}
                  className="bg-background/50 text-lg font-bold"
                  dir="ltr"
                />
              </div>

              <div className="space-y-2 pt-2">
                {convertFrom !== "gold" && (
                  <div className="flex items-center justify-between rounded-lg bg-amber-glow/5 border border-amber-glow/20 p-2.5">
                    <span className="text-xs text-muted-foreground flex items-center gap-1.5">
                      <DynamicIcon name="Coins" className="h-3.5 w-3.5 text-amber-glow" />
                      ذهب (غرام)
                    </span>
                    <span className="text-sm font-bold text-amber-glow" dir="ltr">
                      {converted.gold.toLocaleString("en-US", { maximumFractionDigits: 4 })}
                    </span>
                  </div>
                )}
                {convertFrom !== "usd" && (
                  <div className="flex items-center justify-between rounded-lg bg-emerald-glow/5 border border-emerald-glow/20 p-2.5">
                    <span className="text-xs text-muted-foreground flex items-center gap-1.5">
                      <DynamicIcon name="DollarSign" className="h-3.5 w-3.5 text-emerald-glow" />
                      دولار
                    </span>
                    <span className="text-sm font-bold text-emerald-glow" dir="ltr">
                      ${converted.usd.toLocaleString("en-US", { maximumFractionDigits: 2 })}
                    </span>
                  </div>
                )}
                {convertFrom !== "syp" && (
                  <div className="flex items-center justify-between rounded-lg bg-rose-500/5 border border-rose-500/20 p-2.5">
                    <span className="text-xs text-muted-foreground flex items-center gap-1.5">
                      <DynamicIcon name="Banknote" className="h-3.5 w-3.5 text-rose-400" />
                      ليرة سورية
                    </span>
                    <span className="text-sm font-bold text-rose-400" dir="ltr">
                      {converted.syp.toLocaleString("en-US", { maximumFractionDigits: 0 })} ل.س
                    </span>
                  </div>
                )}
              </div>
            </div>
          </Card>

          {/* Live rates */}
          {currency && (
            <Card className="glass p-2">
              <div className="flex items-center gap-2 mb-1.5">
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-teal-500/15 text-teal-400">
                  <DynamicIcon name="TrendingUp" className="h-4 w-4" />
                </div>
                <h3 className="text-sm font-bold text-foreground">الأسعار الحالية</h3>
              </div>
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-muted-foreground">دولار / ليرة</span>
                  <span className="font-mono font-bold text-foreground">
                    {currency.usdToSYP.toLocaleString("en-US", { maximumFractionDigits: 0 })}
                  </span>
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className="text-muted-foreground">غرام ذهب 21 / دولار</span>
                  <span className="font-mono font-bold text-amber-glow">
                    ${currency.goldPerGram21USD.toFixed(2)}
                  </span>
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className="text-muted-foreground">غرام ذهب 21 / ليرة</span>
                  <span className="font-mono font-bold text-amber-glow">
                    {currency.goldPerGram21SYP.toLocaleString("en-US", { maximumFractionDigits: 0 })}
                  </span>
                </div>
              </div>
            </Card>
          )}
        </div>
      </div>

      {/* Gold prices chart (historical mock + current) */}
      {currency && (
        <GoldPricesCard goldPerGramUSD={currency.goldPerGramUSD} goldPerGram21USD={currency.goldPerGram21USD} />
      )}
    </div>
  );
}

function EditAmountButton({ asset, onSave }: { asset: Asset; onSave: (amount: number) => void }) {
  const [open, setOpen] = React.useState(false);
  const [value, setValue] = React.useState(asset.amount.toString());
  const { toast } = useToast();

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="ghost" size="icon" className="h-8 w-8 opacity-0 group-hover:opacity-100">
          <DynamicIcon name="Pencil" className="h-3.5 w-3.5" />
        </Button>
      </DialogTrigger>
      <DialogContent className="glass-strong max-w-xs">
        <DialogHeader>
          <DialogTitle>تعديل المبلغ</DialogTitle>
        </DialogHeader>
        <Input
          type="number"
          value={value}
          onChange={(e) => setValue(e.target.value)}
          className="text-lg font-bold"
          dir="ltr"
        />
        <DialogFooter>
          <Button variant="outline" onClick={() => setOpen(false)}>إلغاء</Button>
          <Button
            className="bg-emerald-glow hover:bg-emerald-glow/90 text-background"
            onClick={() => {
              const num = parseFloat(value);
              if (isNaN(num) || num < 0) {
                toast({ title: "قيمة غير صالحة", variant: "destructive" });
                return;
              }
              onSave(num);
              setOpen(false);
            }}
          >
            حفظ
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

/* ---------------- Gold prices card with SVG line chart ---------------- */
interface GoldPricesCardProps {
  goldPerGramUSD: number;
  goldPerGram21USD: number;
}

// Build a deterministic mock series around the current price so the chart
// is stable across re-renders (no flicker).
function buildGoldSeries(currentPrice: number, points = 14): number[] {
  const series: number[] = [];
  // seed from price to get a stable pseudo-random trend
  let seed = Math.floor(currentPrice * 1000);
  const rand = () => {
    seed = (seed * 9301 + 49297) % 233280;
    return seed / 233280;
  };
  // Start ~5% below the current and drift upward with noise so the trend is positive overall
  let value = currentPrice * 0.95;
  for (let i = 0; i < points - 1; i++) {
    const noise = (rand() - 0.45) * currentPrice * 0.02;
    value = Math.max(currentPrice * 0.85, value + noise);
    series.push(Number(value.toFixed(2)));
  }
  series.push(Number(currentPrice.toFixed(2)));
  return series;
}

function GoldPricesCard({ goldPerGramUSD, goldPerGram21USD }: GoldPricesCardProps) {
  const series = React.useMemo(() => buildGoldSeries(goldPerGramUSD), [goldPerGramUSD]);
  const prev = series[series.length - 2] || goldPerGramUSD;
  const cur = series[series.length - 1];
  const change24h = cur - prev;
  const changePct = prev > 0 ? (change24h / prev) * 100 : 0;
  const isUp = change24h >= 0;

  // SVG layout
  const W = 320;
  const H = 96;
  const padX = 6;
  const padY = 12;
  const minVal = Math.min(...series);
  const maxVal = Math.max(...series);
  const range = maxVal - minVal || 1;
  const stepX = (W - padX * 2) / (series.length - 1);
  const points = series.map((v, i) => {
    const x = padX + i * stepX;
    const y = padY + (1 - (v - minVal) / range) * (H - padY * 2);
    return { x, y, v };
  });
  const linePath = points
    .map((p, i) => `${i === 0 ? "M" : "L"} ${p.x.toFixed(2)} ${p.y.toFixed(2)}`)
    .join(" ");
  const areaPath = `${linePath} L ${points[points.length - 1].x.toFixed(2)} ${H - padY} L ${points[0].x.toFixed(2)} ${H - padY} Z`;

  return (
    <Card className="glass p-2">
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-amber-glow/15 text-amber-glow">
            <DynamicIcon name="Coins" className="h-4 w-4" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-foreground">أسعار الذهب</h3>
            <p className="text-[10px] text-muted-foreground">آخر 14 يوماً (تقريبي)</p>
          </div>
        </div>
        <div className="text-left">
          <div className="flex items-center gap-1.5">
            <span className="text-base font-bold text-amber-glow">${cur.toFixed(2)}</span>
            <span className="text-[10px] text-muted-foreground">/ غرام 24</span>
          </div>
          <div
            className="flex items-center justify-end gap-0.5 text-[10px] font-bold"
            style={{ color: isUp ? G_GREEN : G_RED }}
          >
            <DynamicIcon name={isUp ? "ArrowUp" : "ArrowDown"} className="h-2.5 w-2.5" />
            {isUp ? "+" : ""}{change24h.toFixed(2)} ({changePct.toFixed(2)}%)
            <span className="text-muted-foreground font-normal">24h</span>
          </div>
        </div>
      </div>

      {/* SVG line chart */}
      <div className="w-full overflow-hidden rounded-lg" style={{ backgroundColor: "var(--surface-container)" }}>
        <svg viewBox={`0 0 ${W} ${H}`} className="w-full" style={{ maxHeight: 120 }}>
          <defs>
            <linearGradient id="goldArea" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor={G_YELLOW} stopOpacity={0.35} />
              <stop offset="100%" stopColor={G_YELLOW} stopOpacity={0} />
            </linearGradient>
          </defs>
          {/* horizontal grid lines */}
          {[0.25, 0.5, 0.75].map((t) => (
            <line
              key={t}
              x1={padX}
              x2={W - padX}
              y1={padY + t * (H - padY * 2)}
              y2={padY + t * (H - padY * 2)}
              stroke="currentColor"
              strokeOpacity={0.06}
              strokeDasharray="2 3"
            />
          ))}
          <path d={areaPath} fill="url(#goldArea)" />
          <path
            d={linePath}
            fill="none"
            stroke={G_YELLOW}
            strokeWidth={1.5}
            strokeLinejoin="round"
            strokeLinecap="round"
          />
          {/* current price marker */}
          <circle
            cx={points[points.length - 1].x}
            cy={points[points.length - 1].y}
            r={3}
            fill={G_YELLOW}
            stroke="#000"
            strokeWidth={0.5}
          />
        </svg>
      </div>

      {/* footer: prices */}
      <div className="grid grid-cols-3 gap-1.5 mt-2">
        <div className="rounded-lg p-1.5" style={{ backgroundColor: `${G_YELLOW}15` }}>
          <p className="text-[9px] text-muted-foreground">غرام 24 / دولار</p>
          <p className="text-xs font-bold" style={{ color: G_YELLOW }}>
            ${goldPerGramUSD.toFixed(2)}
          </p>
        </div>
        <div className="rounded-lg p-1.5" style={{ backgroundColor: `${G_ORANGE}15` }}>
          <p className="text-[9px] text-muted-foreground">غرام 21 / دولار</p>
          <p className="text-xs font-bold" style={{ color: G_ORANGE }}>
            ${goldPerGram21USD.toFixed(2)}
          </p>
        </div>
        <div
          className="rounded-lg p-1.5 flex items-center justify-center gap-1"
          style={{ backgroundColor: `${isUp ? G_GREEN : G_RED}15` }}
        >
          <DynamicIcon
            name={isUp ? "TrendingUp" : "TrendingDown"}
            className="h-3 w-3"
            style={{ color: isUp ? G_GREEN : G_RED }}
          />
          <span
            className="text-[10px] font-bold"
            style={{ color: isUp ? G_GREEN : G_RED }}
          >
            {isUp ? "صعود" : "هبوط"}
          </span>
        </div>
      </div>
      <p className="text-[9px] text-muted-foreground mt-1.5 text-center">
        * البيانات السابقة تقريبية لأغراض العرض فقط — السعر الحالي من /api/currency
      </p>
    </Card>
  );
}

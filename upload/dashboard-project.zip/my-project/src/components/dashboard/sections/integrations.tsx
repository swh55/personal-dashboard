"use client";

import * as React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";
import { DynamicIcon } from "../icon";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { formatDistanceToNow } from "date-fns";
import { ar } from "date-fns/locale";

// Google brand colors
const G_BLUE = "#4285F4";
const G_RED = "#EA4335";
const G_YELLOW = "#FBBC04";
const G_GREEN = "#34A853";
const G_ORANGE = "#FF6D00";
const G_PURPLE = "#A142F4";
const G_TEAL = "#00897B";

// Catalog of all supported integrations (with Google-style colored icons)
const INTEGRATIONS_CATALOG = [
  {
    service: "google_calendar",
    name: "Google Calendar",
    description: "مزامنة الأحداث والتذكيرات مع تقويم جوجل",
    icon: "Calendar",
    color: G_BLUE,
  },
  {
    service: "google_drive",
    name: "Google Drive",
    description: "نسخ احتياطي للملفات والمستندات على السحابة",
    icon: "Database",
    color: G_GREEN,
  },
  {
    service: "telegram",
    name: "Telegram",
    description: "إرسال إشعارات وتنبيهات عبر بوت تيليجرام",
    icon: "Send",
    color: G_TEAL,
  },
  {
    service: "email",
    name: "Email",
    description: "إرسال ومزامنة البريد الإلكتروني",
    icon: "Mail",
    color: G_RED,
  },
  {
    service: "github",
    name: "GitHub",
    description: "ربط المستودعات والـ commits والـ issues",
    icon: "Database",
    color: G_PURPLE,
  },
  {
    service: "google_contacts",
    name: "Google Contacts",
    description: "مزامنة جهات الاتصال مع جهات جوجل",
    icon: "Users",
    color: G_BLUE,
  },
  {
    service: "cloud_sync",
    name: "Cloud Sync",
    description: "مزامنة شاملة لجميع البيانات عبر الأجهزة",
    icon: "RefreshCw",
    color: G_ORANGE,
  },
] as const;

interface Integration {
  id: string;
  service: string;
  name: string;
  connected: boolean;
  config: string | null;
  lastSync: string | null;
  createdAt: string;
  updatedAt: string;
}

function catalogEntry(service: string) {
  return INTEGRATIONS_CATALOG.find((c) => c.service === service);
}

export function IntegrationsSection() {
  const { toast } = useToast();
  const [integrations, setIntegrations] = React.useState<Integration[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [togglingId, setTogglingId] = React.useState<string | null>(null);

  const fetchAll = React.useCallback(async () => {
    try {
      const res = await fetch("/api/integrations");
      const json = await res.json();
      if (json.success) setIntegrations(json.data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, []);

  React.useEffect(() => {
    fetchAll();
  }, [fetchAll]);

  // Merge catalog with stored integrations so every available service shows up.
  const merged = React.useMemo(() => {
    const map = new Map<string, Integration>();
    for (const c of INTEGRATIONS_CATALOG) {
      const existing = integrations.find((i) => i.service === c.service);
      if (existing) {
        map.set(c.service, existing);
      } else {
        // Placeholder (not yet stored)
        map.set(c.service, {
          id: `pending-${c.service}`,
          service: c.service,
          name: c.name,
          connected: false,
          config: null,
          lastSync: null,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        });
      }
    }
    return Array.from(map.values());
  }, [integrations]);

  const connectedCount = merged.filter((m) => m.connected).length;

  const handleToggle = async (integration: Integration) => {
    const entry = catalogEntry(integration.service);
    if (!entry) return;

    // Google services need OAuth flow, not just toggle
    if (entry.service.startsWith("google_") && !integration.connected) {
      // Redirect to Google OAuth
      window.open("/api/auth/google", "_self");
      return;
    }

    const isPending = integration.id.startsWith("pending-");
    setTogglingId(integration.id);
    try {
      if (isPending) {
        await fetch("/api/integrations", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ service: integration.service, name: entry.name, connected: !integration.connected }),
        });
      } else {
        await fetch("/api/integrations", {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ id: integration.id, connected: !integration.connected }),
        });
      }
      toast({ title: integration.connected ? `تم فصل ${entry.name}` : `تم ربط ${entry.name} ✓` });
      fetchAll();
    } catch {
      toast({ title: "فشل تحديث حالة التكامل", variant: "destructive" });
    } finally {
      setTogglingId(null);
    }
  };

  // مزامنة فعلية مع Google
  const [syncing, setSyncing] = React.useState<string | null>(null);
  const [syncResults, setSyncResults] = React.useState<Record<string, string>>({});

  const handleSync = async (service: string) => {
    setSyncing(service);
    try {
      const syncApiMap: Record<string, string> = {
        google_calendar: "/api/sync/calendar",
        google_contacts: "/api/sync/contacts",
        google_drive: "/api/sync/drive",
      };
      const api = syncApiMap[service];
      if (!api) {
        toast({ title: "المزامنة غير متاحة لهذا التكامل", variant: "destructive" });
        return;
      }

      const res = await fetch(api, { method: "POST" });
      const json = await res.json();

      if (json.success) {
        const data = json.data;
        let msg = "";
        if (service === "google_calendar") {
          msg = `استيراد ${data.imported}، تصدير ${data.exported} حدث`;
        } else if (service === "google_contacts") {
          msg = `استيراد ${data.imported} جهة اتصال (${data.skipped} موجودة)`;
        } else if (service === "google_drive") {
          msg = `تم الرفع: ${data.filename} (${data.size ? Math.round(data.size / 1024) : 0} KB)`;
        }
        setSyncResults({ ...syncResults, [service]: msg });
        toast({ title: `اكتملت المزامنة ✓`, description: msg });
        fetchAll();
      } else {
        toast({ title: json.error || "فشلت المزامنة", variant: "destructive" });
      }
    } catch {
      toast({ title: "فشل الاتصال بخادم المزامنة", variant: "destructive" });
    } finally {
      setSyncing(null);
    }
  };

  return (
    <div className="space-y-1.5">
      {/* Header / summary */}
      <Card className="p-2" style={{ backgroundColor: "var(--surface-container)" }}>
        <div className="flex items-center gap-1.5">
          <div
            className="flex h-7 w-7 items-center justify-center rounded-lg"
            style={{ backgroundColor: `${G_BLUE}22`, color: G_BLUE }}
          >
            <DynamicIcon name="Zap" className="h-4 w-4" />
          </div>
          <div className="flex-1">
            <p className="text-xs font-bold text-foreground">التكاملات الخارجية</p>
            <p className="text-[10px] text-muted-foreground">اربط خدماتك المفضلة بلوحة التحكم</p>
          </div>
          <div
            className="text-[10px] font-mono px-1.5 py-0.5 rounded-full"
            style={{ backgroundColor: `${G_GREEN}22`, color: G_GREEN }}
          >
            {connectedCount} / {merged.length} مربوط
          </div>
        </div>
      </Card>

      {/* Grid of integration cards */}
      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
          {Array.from({ length: 6 }).map((_, i) => (
            <Skeleton key={i} className="h-20 rounded-lg" />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
          <AnimatePresence>
            {merged.map((integration, i) => {
              const entry = catalogEntry(integration.service);
              if (!entry) return null;
              const color = entry.color;
              const isPending = integration.id.startsWith("pending-");
              const isToggling = togglingId === integration.id;
              return (
                <motion.div
                  key={integration.service}
                  layout
                  initial={{ opacity: 0, y: 6 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, x: -10 }}
                  transition={{ delay: i * 0.03 }}
                >
                  <Card
                    className="p-2 h-full"
                    style={{
                      backgroundColor: "var(--surface-container)",
                      borderColor: integration.connected ? `${color}55` : "var(--border)",
                    }}
                  >
                    <div className="flex items-start gap-1.5">
                      <div
                        className="flex h-8 w-8 items-center justify-center rounded-lg shrink-0"
                        style={{ backgroundColor: `${color}22`, color }}
                      >
                        <DynamicIcon name={entry.icon} className="h-4 w-4" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-1">
                          <p className="text-xs font-bold text-foreground truncate">{entry.name}</p>
                          {integration.connected && (
                            <span
                              className="text-[9px] px-1 py-0.5 rounded-full shrink-0 flex items-center gap-0.5"
                              style={{ backgroundColor: `${G_GREEN}22`, color: G_GREEN }}
                            >
                              <span className="h-1.5 w-1.5 rounded-full" style={{ backgroundColor: G_GREEN }} />
                              مربوط
                            </span>
                          )}
                        </div>
                        <p className="text-[10px] text-muted-foreground leading-snug mt-0.5 line-clamp-2">
                          {entry.description}
                        </p>
                      </div>
                      <Switch
                        checked={integration.connected}
                        onCheckedChange={() => handleToggle(integration)}
                        disabled={isToggling}
                      />
                    </div>

                    {/* Footer: last sync / sync button / connect button */}
                    <div className="flex items-center justify-between mt-1.5 pt-1.5 border-t" style={{ borderColor: "var(--border)" }}>
                      {integration.connected ? (
                        <div className="flex items-center gap-1 text-[10px] text-muted-foreground truncate">
                          <DynamicIcon name="RefreshCw" className="h-2.5 w-2.5 shrink-0" />
                          {integration.lastSync
                            ? formatDistanceToNow(new Date(integration.lastSync), { addSuffix: true, locale: ar })
                            : "لم تتم المزامنة"}
                        </div>
                      ) : (
                        <span className="text-[10px] text-muted-foreground">غير مربوط</span>
                      )}
                      <div className="flex gap-1 shrink-0">
                        {/* زر المزامنة الفعلية */}
                        {integration.connected && integration.service.startsWith("google_") && (
                          <Button
                            size="sm"
                            variant="outline"
                            className="h-5 text-[10px] px-1.5"
                            disabled={syncing === integration.service}
                            onClick={() => handleSync(integration.service)}
                            style={{ borderColor: `${color}55`, color }}
                          >
                            {syncing === integration.service ? (
                              <DynamicIcon name="Loader2" className="h-3 w-3 animate-spin" />
                            ) : (
                              <>
                                <DynamicIcon name="RefreshCw" className="h-3 w-3" />
                                مزامنة
                              </>
                            )}
                          </Button>
                        )}
                        <Button
                          size="sm"
                          variant={integration.connected ? "outline" : "default"}
                          className="h-5 text-[10px] px-1.5"
                          disabled={isToggling}
                          onClick={() => handleToggle(integration)}
                          style={
                            integration.connected
                              ? {}
                              : { backgroundColor: color, color: "#fff" }
                          }
                        >
                          {isToggling ? (
                            <DynamicIcon name="Loader2" className="h-3 w-3 animate-spin" />
                          ) : integration.connected ? (
                            <>
                              <DynamicIcon name="X" className="h-3 w-3" />
                              فصل
                            </>
                          ) : (
                            <>
                              <DynamicIcon name="Plus" className="h-3 w-3" />
                              ربط
                            </>
                          )}
                        </Button>
                      </div>
                    </div>
                    {/* نتيجة المزامنة */}
                    {syncResults[integration.service] && (
                      <p className="text-[9px] mt-1" style={{ color: G_GREEN }}>
                        ✓ {syncResults[integration.service]}
                      </p>
                    )}
                  </Card>
                </motion.div>
              );
            })}
          </AnimatePresence>
        </div>
      )}

      {/* Info card */}
      <Card className="p-2" style={{ backgroundColor: "var(--surface-container)" }}>
        <div className="flex items-start gap-1.5">
          <div
            className="flex h-6 w-6 items-center justify-center rounded-lg shrink-0"
            style={{ backgroundColor: `${G_YELLOW}22`, color: G_YELLOW }}
          >
            <DynamicIcon name="Lightbulb" className="h-3.5 w-3.5" />
          </div>
          <div>
            <p className="text-[10px] font-bold text-foreground">ملاحظة</p>
            <p className="text-[10px] text-muted-foreground leading-snug">
              الربط هنا تجريبي (placeholder). لتفعيل OAuth حقيقي (Google/Telgram/GitHub) يجب إعداد مفاتيح API في الخادم.
            </p>
          </div>
        </div>
      </Card>
    </div>
  );
}

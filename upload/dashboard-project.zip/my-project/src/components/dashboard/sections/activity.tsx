"use client";

import * as React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { DynamicIcon } from "../icon";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { format, formatDistanceToNow, isToday, isYesterday } from "date-fns";
import { ar } from "date-fns/locale";
import { formatSyrianDate, SYRIAN_MONTHS } from "@/lib/syrian-date";

interface ActivityEntry {
  id: string;
  action: string;
  entity: string;
  title: string;
  details?: string | null;
  createdAt: string;
}

const actionConfig: Record<string, { label: string; icon: string; color: string }> = {
  create: { label: "إضافة", icon: "Plus", color: "emerald" },
  update: { label: "تعديل", icon: "Pencil", color: "amber" },
  delete: { label: "حذف", icon: "Trash2", color: "rose" },
  toggle: { label: "تبديل", icon: "CheckCircle", color: "teal" },
  login: { label: "تسجيل دخول", icon: "LogOut", color: "purple" },
  export: { label: "تصدير", icon: "Download", color: "teal" },
};

const entityConfig: Record<string, { label: string; icon: string }> = {
  task: { label: "مهمة", icon: "CheckSquare" },
  contact: { label: "جهة اتصال", icon: "Users" },
  event: { label: "حدث", icon: "Calendar" },
  expense: { label: "مصروف", icon: "Receipt" },
  note: { label: "ملاحظة", icon: "StickyNote" },
  habit: { label: "عادة", icon: "RefreshCw" },
  occasion: { label: "مناسبة", icon: "Cake" },
  asset: { label: "أصل", icon: "Wallet" },
  account: { label: "حساب", icon: "Globe" },
  data: { label: "بيانات", icon: "Database" },
};

const colorMap: Record<string, { text: string; bg: string }> = {
  emerald: { text: "text-emerald-glow", bg: "bg-emerald-glow/15" },
  amber: { text: "text-amber-glow", bg: "bg-amber-glow/15" },
  rose: { text: "text-rose-400", bg: "bg-rose-500/15" },
  teal: { text: "text-teal-400", bg: "bg-teal-500/15" },
  purple: { text: "text-purple-400", bg: "bg-purple-500/15" },
};

export function ActivitySection() {
  const [logs, setLogs] = React.useState<ActivityEntry[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [filter, setFilter] = React.useState<string>("all");
  const { toast } = useToast();

  const fetchLogs = React.useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/activity?limit=100");
      const json = await res.json();
      if (json.success) setLogs(json.data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, []);

  React.useEffect(() => {
    fetchLogs();
  }, [fetchLogs]);

  const handleClear = async () => {
    await fetch("/api/activity", { method: "DELETE" });
    toast({ title: "تم مسح سجل النشاط" });
    fetchLogs();
  };

  const filtered = filter === "all" ? logs : logs.filter((l) => l.entity === filter);

  // تجميع حسب اليوم
  const grouped = filtered.reduce((acc, log) => {
    const date = new Date(log.createdAt);
    let key: string;
    if (isToday(date)) key = "today";
    else if (isYesterday(date)) key = "yesterday";
    else key = format(date, "yyyy-MM-dd");
    if (!acc[key]) acc[key] = [];
    acc[key].push(log);
    return acc;
  }, {} as Record<string, ActivityEntry[]>);

  const groupLabels: Record<string, string> = {
    today: "اليوم",
    yesterday: "أمس",
  };

  const stats = {
    total: logs.length,
    today: logs.filter((l) => isToday(new Date(l.createdAt))).length,
    creates: logs.filter((l) => l.action === "create").length,
    deletes: logs.filter((l) => l.action === "delete").length,
  };

  return (
    <div className="space-y-2">
      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-2">
        {[
          { label: "إجمالي الأنشطة", value: stats.total, icon: "History", color: "emerald" },
          { label: "نشاطات اليوم", value: stats.today, icon: "Clock", color: "amber" },
          { label: "عمليات إضافة", value: stats.creates, icon: "Plus", color: "teal" },
          { label: "عمليات حذف", value: stats.deletes, icon: "Trash2", color: "rose" },
        ].map((s, i) => {
          const cm = colorMap[s.color];
          return (
            <motion.div key={s.label} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}>
              <Card className="glass p-2.5">
                <div className="flex items-center gap-2">
                  <div className={cn("flex h-7 w-7 items-center justify-center rounded-xl shrink-0", cm.bg, cm.text)}>
                    <DynamicIcon name={s.icon} className="h-5 w-5" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-foreground">{s.value}</p>
                    <p className="text-[11px] text-muted-foreground">{s.label}</p>
                  </div>
                </div>
              </Card>
            </motion.div>
          );
        })}
      </div>

      {/* Filter + Clear */}
      <Card className="glass p-2.5">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
          <div className="flex flex-wrap gap-1.5">
            <button
              onClick={() => setFilter("all")}
              className={cn(
                "px-3 py-1.5 text-xs rounded-lg border transition-all",
                filter === "all" ? "bg-emerald-glow/15 text-emerald-glow border-emerald-glow/30" : "border-border/40 text-muted-foreground"
              )}
            >
              الكل
            </button>
            {Object.entries(entityConfig).slice(0, 6).map(([key, cfg]) => (
              <button
                key={key}
                onClick={() => setFilter(key)}
                className={cn(
                  "flex items-center gap-1 px-3 py-1.5 text-xs rounded-lg border transition-all",
                  filter === key ? "bg-emerald-glow/15 text-emerald-glow border-emerald-glow/30" : "border-border/40 text-muted-foreground"
                )}
              >
                <DynamicIcon name={cfg.icon} className="h-3 w-3" />
                {cfg.label}
              </button>
            ))}
          </div>
          <div className="flex-1" />
          <Button variant="outline" size="sm" onClick={handleClear} className="text-rose-400 hover:text-rose-500">
            <DynamicIcon name="Trash2" className="h-4 w-4" />
            مسح السجل
          </Button>
        </div>
      </Card>

      {/* Timeline */}
      <Card className="glass p-2">
        <div className="flex items-center gap-2 mb-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-emerald-glow/15 text-emerald-glow">
            <DynamicIcon name="History" className="h-4 w-4" />
          </div>
          <h3 className="text-sm font-bold text-foreground">الخط الزمني للنشاط</h3>
          <span className="text-xs text-muted-foreground">({filtered.length})</span>
        </div>

        {loading ? (
          <div className="space-y-1.5">
            {Array.from({ length: 6 }).map((_, i) => (
              <Skeleton key={i} className="h-8 rounded-lg" />
            ))}
          </div>
        ) : filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-3 text-center">
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-muted/30 mb-1.5">
              <DynamicIcon name="History" className="h-6 w-6 text-muted-foreground" />
            </div>
            <p className="text-sm font-medium text-foreground">لا نشاط مسجل</p>
            <p className="text-xs text-muted-foreground mt-1">ستظهر هنا كل العمليات التي تقوم بها</p>
          </div>
        ) : (
          <div className="space-y-1.5">
            {Object.entries(grouped).map(([groupKey, groupLogs]) => (
              <div key={groupKey}>
                {/* Day header */}
                <div className="flex items-center gap-2 mb-2">
                  <div className="h-px flex-1 bg-border/40" />
                  <span className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground px-2">
                    {groupLabels[groupKey] || formatSyrianDate(new Date(groupKey), "d MMMM yyyy")}
                  </span>
                  <div className="h-px flex-1 bg-border/40" />
                </div>

                {/* Activity items */}
                <div className="space-y-1.5">
                  <AnimatePresence>
                    {groupLogs.map((log, i) => {
                      const action = actionConfig[log.action] || actionConfig.update;
                      const entity = entityConfig[log.entity] || entityConfig.data;
                      const cm = colorMap[action.color] || colorMap.amber;
                      return (
                        <motion.div
                          key={log.id}
                          layout
                          initial={{ opacity: 0, x: 8 }}
                          animate={{ opacity: 1, x: 0 }}
                          exit={{ opacity: 0, x: -20 }}
                          transition={{ delay: i * 0.02 }}
                          className="flex items-center gap-2 rounded-xl border border-border/40 bg-background/30 p-2 hover:border-emerald-glow/20 transition-all group"
                        >
                          {/* Action icon */}
                          <div className={cn("flex h-9 w-9 items-center justify-center rounded-lg shrink-0", cm.bg, cm.text)}>
                            <DynamicIcon name={action.icon} className="h-4 w-4" />
                          </div>

                          {/* Content */}
                          <div className="flex-1 min-w-0">
                            <p className="text-sm text-foreground truncate">{log.title}</p>
                            <div className="flex items-center gap-2 mt-0.5">
                              <span className={cn("text-[10px] px-1.5 py-0.5 rounded-full", cm.bg, cm.text)}>
                                {action.label}
                              </span>
                              <span className="text-[10px] text-muted-foreground flex items-center gap-0.5">
                                <DynamicIcon name={entity.icon} className="h-2.5 w-2.5" />
                                {entity.label}
                              </span>
                            </div>
                          </div>

                          {/* Time */}
                          <span className="text-[10px] text-muted-foreground shrink-0">
                            {formatDistanceToNow(new Date(log.createdAt), { addSuffix: true, locale: ar })}
                          </span>
                        </motion.div>
                      );
                    })}
                  </AnimatePresence>
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>
    </div>
  );
}

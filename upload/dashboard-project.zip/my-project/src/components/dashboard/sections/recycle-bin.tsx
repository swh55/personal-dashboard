"use client";

import * as React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { DynamicIcon } from "../icon";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { formatDistanceToNow } from "date-fns";
import { ar } from "date-fns/locale";

interface RecycleItem {
  id: string;
  type: "task" | "note" | "event" | "contact" | "expense";
  title: string;
  subtitle?: string;
  deletedAt: string;
  icon: string;
  color: string;
}

interface RecycleData {
  tasks: Array<{ id: string; title: string; category: string; deletedAt: string | null }>;
  notes: Array<{ id: string; title: string; content: string; deletedAt: string | null }>;
  events: Array<{ id: string; title: string; startDate: string; deletedAt: string | null }>;
  contacts: Array<{ id: string; name: string; phone: string; deletedAt: string | null }>;
  expenses: Array<{ id: string; amount: number; currency: string; description: string | null; category: string; deletedAt: string | null }>;
  totalCount: number;
}

const typeConfig: Record<string, { label: string; icon: string; color: string }> = {
  task: { label: "مهمة", icon: "CheckSquare", color: "emerald" },
  note: { label: "ملاحظة", icon: "StickyNote", color: "teal" },
  event: { label: "حدث", icon: "Calendar", color: "rose" },
  contact: { label: "جهة اتصال", icon: "Users", color: "amber" },
  expense: { label: "مصروف", icon: "Receipt", color: "rose" },
};

const colorMap: Record<string, { text: string; bg: string }> = {
  emerald: { text: "text-emerald-glow", bg: "bg-emerald-glow/15" },
  amber: { text: "text-amber-glow", bg: "bg-amber-glow/15" },
  rose: { text: "text-rose-400", bg: "bg-rose-500/15" },
  teal: { text: "text-teal-400", bg: "bg-teal-500/15" },
};

export function RecycleBinSection() {
  const [data, setData] = React.useState<RecycleData | null>(null);
  const [loading, setLoading] = React.useState(true);
  const [filter, setFilter] = React.useState<string>("all");
  const { toast } = useToast();

  const fetchData = React.useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/recycle-bin");
      const json = await res.json();
      if (json.success) setData(json.data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, []);

  React.useEffect(() => {
    fetchData();
  }, [fetchData]);

  const allItems: RecycleItem[] = React.useMemo(() => {
    if (!data) return [];
    const items: RecycleItem[] = [];
    data.tasks.forEach((t) => items.push({
      id: t.id, type: "task", title: t.title, subtitle: t.category,
      deletedAt: t.deletedAt || new Date().toISOString(), icon: "CheckSquare", color: "emerald"
    }));
    data.notes.forEach((n) => items.push({
      id: n.id, type: "note", title: n.title, subtitle: n.content.slice(0, 40),
      deletedAt: n.deletedAt || new Date().toISOString(), icon: "StickyNote", color: "teal"
    }));
    data.events.forEach((e) => items.push({
      id: e.id, type: "event", title: e.title, subtitle: new Date(e.startDate).toLocaleDateString("ar-SY"),
      deletedAt: e.deletedAt || new Date().toISOString(), icon: "Calendar", color: "rose"
    }));
    data.contacts.forEach((c) => items.push({
      id: c.id, type: "contact", title: c.name, subtitle: c.phone,
      deletedAt: c.deletedAt || new Date().toISOString(), icon: "Users", color: "amber"
    }));
    data.expenses.forEach((e) => items.push({
      id: e.id, type: "expense", title: e.description || e.category, subtitle: `${e.amount} ${e.currency}`,
      deletedAt: e.deletedAt || new Date().toISOString(), icon: "Receipt", color: "rose"
    }));
    return items.sort((a, b) => new Date(b.deletedAt).getTime() - new Date(a.deletedAt).getTime());
  }, [data]);

  const filtered = filter === "all" ? allItems : allItems.filter((i) => i.type === filter);

  const handleRestore = async (type: string, id: string) => {
    try {
      await fetch("/api/recycle-bin", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ type, id, action: "restore" }),
      });
      toast({ title: "تمت الاستعادة بنجاح" });
      fetchData();
    } catch {
      toast({ title: "فشلت الاستعادة", variant: "destructive" });
    }
  };

  const handleForceDelete = async (type: string, id: string) => {
    try {
      await fetch("/api/recycle-bin", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ type, id, action: "force-delete" }),
      });
      toast({ title: "تم الحذف نهائياً" });
      fetchData();
    } catch {
      toast({ title: "فشل الحذف", variant: "destructive" });
    }
  };

  const handleEmpty = async () => {
    try {
      await fetch("/api/recycle-bin", { method: "DELETE" });
      toast({ title: "تم إفراغ سلة المحذوفات" });
      fetchData();
    } catch {
      toast({ title: "فشل الإفراغ", variant: "destructive" });
    }
  };

  const counts = {
    total: allItems.length,
    tasks: allItems.filter((i) => i.type === "task").length,
    notes: allItems.filter((i) => i.type === "note").length,
    events: allItems.filter((i) => i.type === "event").length,
    contacts: allItems.filter((i) => i.type === "contact").length,
    expenses: allItems.filter((i) => i.type === "expense").length,
  };

  return (
    <div className="space-y-2">
      {/* Header */}
      <Card className="glass p-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="flex h-7 w-7 items-center justify-center rounded-xl bg-rose-500/15 text-rose-400">
              <DynamicIcon name="Trash" className="h-5 w-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-foreground">سلة المحذوفات</h2>
              <p className="text-xs text-muted-foreground">{counts.total} عنصر محذوف</p>
            </div>
          </div>
          {counts.total > 0 && (
            <Button variant="outline" size="sm" onClick={handleEmpty} className="text-rose-400 hover:text-rose-500">
              <DynamicIcon name="Trash2" className="h-4 w-4" />
              إفراغ السلة
            </Button>
          )}
        </div>
      </Card>

      {/* Filter */}
      {counts.total > 0 && (
        <Card className="glass p-2">
          <div className="flex flex-wrap gap-1.5">
            <button
              onClick={() => setFilter("all")}
              className={cn(
                "px-3 py-1.5 text-xs rounded-lg border transition-all",
                filter === "all" ? "bg-emerald-glow/15 text-emerald-glow border-emerald-glow/30" : "border-border/40 text-muted-foreground"
              )}
            >
              الكل ({counts.total})
            </button>
            {Object.entries(typeConfig).map(([key, cfg]) => {
              const count = (counts as Record<string, number>)[key + "s"] || 0;
              if (count === 0) return null;
              return (
                <button
                  key={key}
                  onClick={() => setFilter(key)}
                  className={cn(
                    "flex items-center gap-1 px-3 py-1.5 text-xs rounded-lg border transition-all",
                    filter === key ? "bg-emerald-glow/15 text-emerald-glow border-emerald-glow/30" : "border-border/40 text-muted-foreground"
                  )}
                >
                  <DynamicIcon name={cfg.icon} className="h-3 w-3" />
                  {cfg.label} ({count})
                </button>
              );
            })}
          </div>
        </Card>
      )}

      {/* Items */}
      <Card className="glass p-2">
        {loading ? (
          <div className="space-y-2">
            {Array.from({ length: 5 }).map((_, i) => (
              <Skeleton key={i} className="h-10 rounded-lg" />
            ))}
          </div>
        ) : filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-muted/30 mb-1.5">
              <DynamicIcon name="Trash" className="h-7 w-7 text-muted-foreground" />
            </div>
            <p className="text-sm font-medium text-foreground">سلة المحذوفات فارغة</p>
            <p className="text-xs text-muted-foreground mt-1">العناصر المحذوفة ستظهر هنا للاستعادة</p>
          </div>
        ) : (
          <div className="space-y-2">
            <AnimatePresence>
              {filtered.map((item, i) => {
                const cfg = typeConfig[item.type];
                const cm = colorMap[item.color] || colorMap.emerald;
                return (
                  <motion.div
                    key={`${item.type}-${item.id}`}
                    layout
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    transition={{ delay: i * 0.03 }}
                    className="group flex items-center gap-2 rounded-xl border border-border/40 bg-background/30 p-2 hover:border-emerald-glow/20 transition-all"
                  >
                    <div className={cn("flex h-7 w-7 items-center justify-center rounded-lg shrink-0", cm.bg, cm.text)}>
                      <DynamicIcon name={item.icon} className="h-5 w-5" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-foreground truncate">{item.title}</p>
                      <div className="flex items-center gap-2 mt-0.5">
                        <span className={cn("text-[10px] px-1.5 py-0.5 rounded-full", cm.bg, cm.text)}>
                          {cfg.label}
                        </span>
                        {item.subtitle && (
                          <span className="text-[10px] text-muted-foreground truncate">{item.subtitle}</span>
                        )}
                      </div>
                    </div>
                    <span className="text-[10px] text-muted-foreground shrink-0 hidden sm:block">
                      {formatDistanceToNow(new Date(item.deletedAt), { addSuffix: true, locale: ar })}
                    </span>
                    <div className="flex gap-1">
                      <Button
                        size="sm"
                        variant="outline"
                        className="h-8 px-2 bg-emerald-glow/5 border-emerald-glow/20 hover:bg-emerald-glow/15 text-emerald-glow"
                        onClick={() => handleRestore(item.type, item.id)}
                      >
                        <DynamicIcon name="RotateCcw" className="h-3.5 w-3.5" />
                        استعادة
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        className="h-8 px-2 hover:text-rose-400"
                        onClick={() => handleForceDelete(item.type, item.id)}
                      >
                        <DynamicIcon name="Trash2" className="h-3.5 w-3.5" />
                      </Button>
                    </div>
                  </motion.div>
                );
              })}
            </AnimatePresence>
          </div>
        )}
      </Card>

      {/* Warning */}
      {counts.total > 0 && (
        <Card className="glass p-2.5 border-amber-glow/20">
          <div className="flex items-start gap-2">
            <DynamicIcon name="AlertCircle" className="h-4 w-4 text-amber-glow shrink-0 mt-0.5" />
            <div>
              <p className="text-xs font-medium text-foreground">ملاحظة</p>
              <p className="text-[11px] text-muted-foreground mt-0.5">
                العناصر في سلة المحذوفات لا تظهر في أقسام لوحة التحكم. يمكنك استعادتها أو حذفها نهائياً.
              </p>
            </div>
          </div>
        </Card>
      )}
    </div>
  );
}

"use client";

import * as React from "react";
import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { PrayerTimesWidget } from "../widgets/prayer-times";
import { WeatherWidget } from "../widgets/weather";
import { LiveClockWidget } from "../widgets/live-clock";
import { PomodoroWidget } from "../widgets/pomodoro";
import { QuickCaptureWidget } from "../widgets/quick-capture";
import { AIAssistantWidget } from "../widgets/ai-assistant";
import { WeeklyStatsWidget } from "../widgets/weekly-stats";
import { HabitsHeatmapWidget } from "../widgets/habits-heatmap";
import { SmartNotificationsWidget } from "../widgets/smart-notifications";
import { DynamicIcon } from "../icon";
import { useDashboardStore } from "@/store/use-dashboard-store";
import { DAILY_SCHEDULE, TASK_CATEGORIES } from "@/lib/constants";
import { cn } from "@/lib/utils";
import { format, formatDistanceToNow } from "date-fns";
import { ar } from "date-fns/locale";
import { formatSyrianDate, SYRIAN_MONTHS } from "@/lib/syrian-date";

interface DashboardData {
  todayEvents: Array<{
    id: string;
    title: string;
    description?: string | null;
    startDate: string;
    endDate?: string | null;
    type: string;
    color: string;
    location?: string | null;
  }>;
  taskStats: {
    pending: number;
    done: number;
    total: number;
    byCategory: Array<{ category: string; _count: number }>;
  };
  contactStats: { total: number; favorites: number };
  upcomingHolidays: Array<{ date: string; name: string; daysUntil: number }>;
  todayHoliday: { isHoliday: boolean; name?: string };
  recentCalls: Array<{ id: string; name: string; phone: string; type: string; createdAt: string }>;
}

const eventTypeColors: Record<string, { bg: string; text: string; icon: string }> = {
  work: { bg: "bg-emerald-glow/10", text: "text-emerald-glow", icon: "Briefcase" },
  personal: { bg: "bg-amber-glow/10", text: "text-amber-glow", icon: "User" },
  inspection: { bg: "bg-rose-500/10", text: "text-rose-400", icon: "Building2" },
  holiday: { bg: "bg-purple-500/10", text: "text-purple-400", icon: "Calendar" },
  birthday: { bg: "bg-pink-500/10", text: "text-pink-400", icon: "Cake" },
  prayer: { bg: "bg-teal-500/10", text: "text-teal-400", icon: "Sparkles" },
  custom: { bg: "bg-slate-500/10", text: "text-slate-400", icon: "Calendar" },
};

function StatCard({
  icon, label, value, sublabel, color = "emerald", delay = 0,
}: {
  icon: string; label: string; value: string | number; sublabel?: string;
  color?: string; delay?: number;
}) {
  const colorMap: Record<string, string> = {
    emerald: "bg-emerald-glow/15 text-emerald-glow",
    amber: "bg-amber-glow/15 text-amber-glow",
    rose: "bg-rose-500/15 text-rose-400",
    teal: "bg-teal-500/15 text-teal-400",
  };
  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay }}
    >
      <Card className="glass p-2 hover:border-emerald-glow/30 transition-all group">
        <div className="flex items-center justify-between mb-1.5">
          <div className={cn("flex h-7 w-7 items-center justify-center rounded-xl", colorMap[color])}>
            <DynamicIcon name={icon} className="h-5 w-5" />
          </div>
        </div>
        <p className="text-2xl font-bold text-foreground tick-up">{value}</p>
        <p className="text-xs text-muted-foreground/90 mt-1 font-medium">{label}</p>
        {sublabel && <p className="text-[10px] text-muted-foreground/70 mt-0.5">{sublabel}</p>}
      </Card>
    </motion.div>
  );
}

export function OverviewSection() {
  const [data, setData] = React.useState<DashboardData | null>(null);
  const [loading, setLoading] = React.useState(true);
  const { setActiveSection } = useDashboardStore();

  React.useEffect(() => {
    fetch("/api/dashboard")
      .then((r) => r.json())
      .then((json) => {
        if (json.success) setData(json.data);
      })
      .finally(() => setLoading(false));
  }, []);

  const now = new Date();
  const currentTime = now.getHours() * 60 + now.getMinutes();
  const isWorkTime = currentTime >= 8 * 60 && currentTime <= 15 * 60;
  const isWednesday = now.getDay() === 3;

  return (
    <div className="space-y-2 lg:space-y-1.5 max-w-[1600px] mx-auto">
      {/* Welcome header */}
      <motion.div
        initial={{ opacity: 0, y: -8 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative overflow-hidden rounded-2xl glass-strong p-2 lg:p-2"
      >
        <div className="absolute inset-0 bg-gradient-to-l from-emerald-glow/10 via-transparent to-amber-glow/10" />
        <div className="relative flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-2xl">👋</span>
              <h1 className="text-xl lg:text-2xl font-bold text-foreground">
                أهلاً وسهلاً، عبد الله
              </h1>
            </div>
            <p className="text-sm text-muted-foreground">
              {data?.todayHoliday?.isHoliday
                ? `عطلة اليوم: ${data.todayHoliday.name}`
                : isWorkTime
                ? "أنت في دوام السجل التجاري الآن"
                : "نتمنى لك يوماً موفقاً ومثمراً"}
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Badge variant="outline" className="bg-emerald-glow/10 text-emerald-glow border-emerald-glow/30">
              <DynamicIcon name="MapPin" className="h-3 w-3 ml-1" />
              حلب
            </Badge>
            {isWednesday && (
              <Badge variant="outline" className="bg-rose-500/10 text-rose-400 border-rose-500/30">
                <DynamicIcon name="Building2" className="h-3 w-3 ml-1" />
                يوم الكشف الحسي
              </Badge>
            )}
          </div>
        </div>
      </motion.div>

      {/* Stats grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-2 lg:gap-2">
        {loading ? (
          Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-28 rounded-2xl" />
          ))
        ) : (
          <>
            <StatCard
              icon="CheckSquare"
              label="مهام معلّقة"
              value={data?.taskStats.pending || 0}
              sublabel={`من ${data?.taskStats.total || 0} مهمة`}
              color="emerald"
              delay={0}
            />
            <StatCard
              icon="Users"
              label="جهات الاتصال"
              value={data?.contactStats.total || 0}
              sublabel={`${data?.contactStats.favorites || 0} مفضّلة`}
              color="amber"
              delay={0.05}
            />
            <StatCard
              icon="Calendar"
              label="أحداث اليوم"
              value={data?.todayEvents.length || 0}
              sublabel="في جدولك"
              color="teal"
              delay={0.1}
            />
            <StatCard
              icon="Sparkles"
              label="مهام منجزة"
              value={data?.taskStats.done || 0}
              sublabel="أنجزتها"
              color="rose"
              delay={0.15}
            />
          </>
        )}
      </div>

      {/* Main content grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-2">
        {/* Left column - Notifications + Today's schedule + tasks */}
        <div className="lg:col-span-2 space-y-2 lg:space-y-1.5">
          {/* Smart Notifications */}
          <SmartNotificationsWidget />

          {/* Today's schedule */}
          <Card className="glass p-2">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-emerald-glow/15 text-emerald-glow">
                  <DynamicIcon name="Calendar" className="h-4 w-4" />
                </div>
                <h3 className="text-sm font-bold text-foreground">جدول اليوم</h3>
              </div>
              <Button
                variant="ghost"
                size="sm"
                className="text-xs text-muted-foreground hover:text-emerald-glow"
                onClick={() => setActiveSection("calendar")}
              >
                عرض التقويم
                <DynamicIcon name="ChevronLeft" className="h-3.5 w-3.5" />
              </Button>
            </div>

            {loading ? (
              <div className="space-y-2">
                {Array.from({ length: 4 }).map((_, i) => (
                  <Skeleton key={i} className="h-10 rounded-lg" />
                ))}
              </div>
            ) : data?.todayEvents.length ? (
              <div className="space-y-2">
                {data.todayEvents.map((event, i) => {
                  const colors = eventTypeColors[event.type] || eventTypeColors.custom;
                  const eventTime = new Date(event.startDate);
                  const isPast = eventTime < now;
                  return (
                    <motion.div
                      key={event.id}
                      initial={{ opacity: 0, x: -8 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: i * 0.05 }}
                      className={cn(
                        "flex items-center gap-2 rounded-xl border p-2 transition-all",
                        isPast
                          ? "bg-background/20 border-border/20 opacity-50"
                          : "bg-background/40 border-border/40 hover:border-emerald-glow/30"
                      )}
                    >
                      <div className={cn("flex h-7 w-7 items-center justify-center rounded-lg shrink-0", colors.bg)}>
                        <DynamicIcon name={colors.icon} className={cn("h-5 w-5", colors.text)} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className={cn("text-sm font-medium truncate", isPast ? "line-through" : "text-foreground")}>
                          {event.title}
                        </p>
                        {event.location && (
                          <p className="text-[11px] text-muted-foreground flex items-center gap-1">
                            <DynamicIcon name="MapPin" className="h-3 w-3" />
                            {event.location}
                          </p>
                        )}
                      </div>
                      <div className="text-left shrink-0">
                        <p className="text-sm font-mono font-bold text-foreground">
                          {format(eventTime, "HH:mm")}
                        </p>
                        {event.endDate && (
                          <p className="text-[10px] text-muted-foreground">
                            حتى {format(new Date(event.endDate), "HH:mm")}
                          </p>
                        )}
                      </div>
                    </motion.div>
                  );
                })}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-3 text-center">
                <div className="flex h-8 w-8 items-center justify-center rounded-full bg-muted/30 mb-1.5">
                  <DynamicIcon name="Calendar" className="h-6 w-6 text-muted-foreground" />
                </div>
                <p className="text-sm text-muted-foreground">لا أحداث اليوم</p>
                <p className="text-xs text-muted-foreground/70 mt-1">
                  استمتع بيومك!
                </p>
              </div>
            )}
          </Card>

          {/* Tasks by category */}
          <Card className="glass p-2">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-amber-glow/15 text-amber-glow">
                  <DynamicIcon name="CheckSquare" className="h-4 w-4" />
                </div>
                <h3 className="text-sm font-bold text-foreground">المهام حسب الفئة</h3>
              </div>
              <Button
                variant="ghost"
                size="sm"
                className="text-xs text-muted-foreground hover:text-amber-glow"
                onClick={() => setActiveSection("tasks")}
              >
                إدارة المهام
                <DynamicIcon name="ChevronLeft" className="h-3.5 w-3.5" />
              </Button>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {TASK_CATEGORIES.map((cat, i) => {
                const count = data?.taskStats.byCategory.find(
                  (c) => c.category === cat.id
                )?._count || 0;
                const colorMap: Record<string, string> = {
                  emerald: "bg-emerald-glow/10 text-emerald-glow border-emerald-glow/20",
                  amber: "bg-amber-glow/10 text-amber-glow border-amber-glow/20",
                  rose: "bg-rose-500/10 text-rose-400 border-rose-500/20",
                  teal: "bg-teal-500/10 text-teal-400 border-teal-500/20",
                };
                return (
                  <motion.button
                    key={cat.id}
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: i * 0.05 }}
                    onClick={() => setActiveSection("tasks")}
                    className={cn(
                      "rounded-xl border p-2 text-right transition-all hover:scale-[1.02]",
                      colorMap[cat.color]
                    )}
                  >
                    <DynamicIcon name={cat.icon} className="h-5 w-5 mb-2" />
                    <p className="text-2xl font-bold">{count}</p>
                    <p className="text-[11px] opacity-80">{cat.label}</p>
                  </motion.button>
                );
              })}
            </div>
          </Card>

          {/* Recent calls */}
          {data?.recentCalls && data.recentCalls.length > 0 && (
            <Card className="glass p-2">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-rose-500/15 text-rose-400">
                    <DynamicIcon name="Phone" className="h-4 w-4" />
                  </div>
                  <h3 className="text-sm font-bold text-foreground">آخر المكالمات</h3>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  className="text-xs text-muted-foreground hover:text-rose-400"
                  onClick={() => setActiveSection("callpad")}
                >
                  لوحة الاتصال
                  <DynamicIcon name="ChevronLeft" className="h-3.5 w-3.5" />
                </Button>
              </div>
              <div className="space-y-1.5">
                {data.recentCalls.slice(0, 4).map((call) => (
                  <div
                    key={call.id}
                    className="flex items-center gap-2 rounded-lg p-2 hover:bg-accent/30 transition-colors"
                  >
                    <div className="flex h-8 w-8 items-center justify-center rounded-full bg-muted/30 text-muted-foreground">
                      <DynamicIcon
                        name={call.type === "whatsapp" ? "MessageCircle" : call.type === "sms" ? "MessageCircle" : "Phone"}
                        className="h-3.5 w-3.5"
                      />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-foreground truncate">{call.name}</p>
                      <p className="text-[10px] text-muted-foreground">{call.phone}</p>
                    </div>
                    <p className="text-[10px] text-muted-foreground shrink-0">
                      {formatDistanceToNow(new Date(call.createdAt), { addSuffix: true, locale: ar })}
                    </p>
                  </div>
                ))}
              </div>
            </Card>
          )}

          {/* Weekly Statistics */}
          <WeeklyStatsWidget />

          {/* Habits Heatmap */}
          <HabitsHeatmapWidget />
        </div>

        {/* Right column - Clock + Quick Capture + Prayer + Weather + Pomodoro + AI + Holidays */}
        <div className="space-y-2 lg:space-y-1.5">
          <LiveClockWidget />
          <QuickCaptureWidget />
          <AIAssistantWidget />
          <PrayerTimesWidget />
          <WeatherWidget />
          <PomodoroWidget />

          {/* Upcoming holidays */}
          <Card className="glass p-2">
            <div className="flex items-center gap-2 mb-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-purple-500/15 text-purple-400">
                <DynamicIcon name="CalendarDays" className="h-4 w-4" />
              </div>
              <h3 className="text-sm font-bold text-foreground">العطل القادمة</h3>
            </div>
            {loading ? (
              <div className="space-y-2">
                {Array.from({ length: 3 }).map((_, i) => (
                  <Skeleton key={i} className="h-14 rounded-lg" />
                ))}
              </div>
            ) : data?.upcomingHolidays.length ? (
              <div className="space-y-2">
                {data.upcomingHolidays.map((holiday, i) => (
                  <motion.div
                    key={holiday.date}
                    initial={{ opacity: 0, x: 8 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.05 }}
                    className="flex items-center gap-2 rounded-lg bg-background/40 border border-border/40 p-2.5"
                  >
                    <div className="flex h-9 w-9 flex-col items-center justify-center rounded-lg bg-purple-500/10 text-purple-400 shrink-0">
                      <span className="text-sm font-bold leading-none">{holiday.daysUntil}</span>
                      <span className="text-[8px] leading-none mt-0.5">يوم</span>
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-medium text-foreground truncate">
                        {holiday.name}
                      </p>
                      <p className="text-[10px] text-muted-foreground">
                        {formatSyrianDate(new Date(holiday.date), "d MMMM yyyy")}
                      </p>
                    </div>
                  </motion.div>
                ))}
              </div>
            ) : (
              <p className="text-xs text-muted-foreground text-center py-2">
                لا عطل قادمة
              </p>
            )}
          </Card>
        </div>
      </div>
    </div>
  );
}

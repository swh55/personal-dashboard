"use client";

import * as React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger } from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { DynamicIcon } from "../icon";
import { useToast } from "@/hooks/use-toast";
import { EXPENSE_CATEGORIES } from "@/lib/constants";
import { cn } from "@/lib/utils";
import { format, formatDistanceToNow, subDays, isSameDay } from "date-fns";
import { ar } from "date-fns/locale";

interface Expense {
  id: string;
  amount: number;
  currency: string;
  category: string;
  description?: string | null;
  date: string;
}

const colorMap: Record<string, { text: string; bg: string; border: string; hex: string }> = {
  emerald: { text: "text-emerald-glow", bg: "bg-emerald-glow/15", border: "border-emerald-glow/30", hex: "#10b981" },
  amber: { text: "text-amber-glow", bg: "bg-amber-glow/15", border: "border-amber-glow/30", hex: "#f59e0b" },
  rose: { text: "text-rose-400", bg: "bg-rose-500/15", border: "border-rose-500/30", hex: "#f43f5e" },
  teal: { text: "text-teal-400", bg: "bg-teal-500/15", border: "border-teal-500/30", hex: "#14b8a6" },
  purple: { text: "text-purple-400", bg: "bg-purple-500/15", border: "border-purple-500/30", hex: "#a855f7" },
  slate: { text: "text-slate-400", bg: "bg-slate-500/15", border: "border-slate-500/30", hex: "#64748b" },
};

export function ExpensesSection() {
  const [expenses, setExpenses] = React.useState<Expense[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [period, setPeriod] = React.useState<"today" | "week" | "month" | "all">("week");
  const [dialogOpen, setDialogOpen] = React.useState(false);
  const [editingExpense, setEditingExpense] = React.useState<Expense | null>(null);
  const { toast } = useToast();

  const fetchExpenses = React.useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/expenses?period=${period}`);
      const json = await res.json();
      if (json.success) {
        setExpenses(json.data);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, [period]);

  React.useEffect(() => {
    fetchExpenses();
  }, [fetchExpenses]);

  const handleDelete = async (id: string) => {
    await fetch(`/api/expenses?id=${id}`, { method: "DELETE" });
    toast({ title: "تم حذف المصروف" });
    fetchExpenses();
  };

  // حساب الإحصائيات
  const totalSYP = expenses.reduce(
    (sum, e) => sum + (e.currency === "usd" ? e.amount * 12500 : e.amount),
    0
  );
  const today = new Date();
  const todayExpenses = expenses.filter((e) => isSameDay(new Date(e.date), today));
  const todayTotal = todayExpenses.reduce(
    (sum, e) => sum + (e.currency === "usd" ? e.amount * 12500 : e.amount),
    0
  );

  // الإحصائيات حسب الفئة
  const byCategory = EXPENSE_CATEGORIES.map((cat) => {
    const catExpenses = expenses.filter((e) => e.category === cat.id);
    const total = catExpenses.reduce(
      (sum, e) => sum + (e.currency === "usd" ? e.amount * 12500 : e.amount),
      0
    );
    return { ...cat, total, count: catExpenses.length };
  }).filter((c) => c.count > 0).sort((a, b) => b.total - a.total);

  const maxCategoryTotal = Math.max(...byCategory.map((c) => c.total), 1);

  // بيانات آخر 7 أيام للرسم البياني
  const last7Days = Array.from({ length: 7 }, (_, i) => {
    const date = subDays(today, 6 - i);
    const dayExpenses = expenses.filter((e) => isSameDay(new Date(e.date), date));
    const total = dayExpenses.reduce(
      (sum, e) => sum + (e.currency === "usd" ? e.amount * 12500 : e.amount),
      0
    );
    return {
      date,
      label: format(date, "EEEEEE", { locale: ar }),
      total,
      isToday: isSameDay(date, today),
    };
  });
  const maxDayTotal = Math.max(...last7Days.map((d) => d.total), 1);

  const formatAmount = (amount: number) => {
    if (amount >= 1000000) return (amount / 1000000).toFixed(1) + "M";
    if (amount >= 1000) return (amount / 1000).toFixed(1) + "K";
    return amount.toLocaleString("en-US", { maximumFractionDigits: 0 });
  };

  return (
    <div className="space-y-2">
      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-2">
        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}>
          <Card className="glass p-2.5">
            <div className="flex items-center gap-2">
              <div className="flex h-7 w-7 items-center justify-center rounded-xl bg-emerald-glow/15 text-emerald-glow">
                <DynamicIcon name="Wallet" className="h-5 w-5" />
              </div>
              <div>
                <p className="text-xl font-bold text-foreground">{formatAmount(totalSYP)}</p>
                <p className="text-[11px] text-muted-foreground">إجمالي الفترة</p>
              </div>
            </div>
          </Card>
        </motion.div>
        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.05 }}>
          <Card className="glass p-2.5">
            <div className="flex items-center gap-2">
              <div className="flex h-7 w-7 items-center justify-center rounded-xl bg-amber-glow/15 text-amber-glow">
                <DynamicIcon name="Calendar" className="h-5 w-5" />
              </div>
              <div>
                <p className="text-xl font-bold text-foreground">{formatAmount(todayTotal)}</p>
                <p className="text-[11px] text-muted-foreground">مصروفات اليوم</p>
              </div>
            </div>
          </Card>
        </motion.div>
        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
          <Card className="glass p-2.5">
            <div className="flex items-center gap-2">
              <div className="flex h-7 w-7 items-center justify-center rounded-xl bg-rose-500/15 text-rose-400">
                <DynamicIcon name="Receipt" className="h-5 w-5" />
              </div>
              <div>
                <p className="text-xl font-bold text-foreground">{expenses.length}</p>
                <p className="text-[11px] text-muted-foreground">عدد المصروفات</p>
              </div>
            </div>
          </Card>
        </motion.div>
        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }}>
          <Card className="glass p-2.5">
            <div className="flex items-center gap-2">
              <div className="flex h-7 w-7 items-center justify-center rounded-xl bg-teal-500/15 text-teal-400">
                <DynamicIcon name="TrendingDown" className="h-5 w-5" />
              </div>
              <div>
                <p className="text-xl font-bold text-foreground">
                  {expenses.length > 0 ? formatAmount(totalSYP / expenses.length) : 0}
                </p>
                <p className="text-[11px] text-muted-foreground">متوسط المصروف</p>
              </div>
            </div>
          </Card>
        </motion.div>
      </div>

      {/* Period filter + Add button */}
      <Card className="glass p-2.5">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
          <div className="flex rounded-lg bg-muted/30 p-0.5">
            {[
              { id: "today", label: "اليوم" },
              { id: "week", label: "الأسبوع" },
              { id: "month", label: "الشهر" },
              { id: "all", label: "الكل" },
            ].map((p) => (
              <button
                key={p.id}
                onClick={() => setPeriod(p.id as "today" | "week" | "month" | "all")}
                className={cn(
                  "px-3 py-1.5 text-xs rounded-md transition-all",
                  period === p.id ? "bg-emerald-glow/15 text-emerald-glow" : "text-muted-foreground"
                )}
              >
                {p.label}
              </button>
            ))}
          </div>
          <div className="flex-1" />
          <ExpenseDialog
            open={dialogOpen}
            onOpenChange={setDialogOpen}
            editingExpense={editingExpense}
            onSaved={() => {
              setDialogOpen(false);
              setEditingExpense(null);
              fetchExpenses();
            }}
          >
            <Button className="bg-emerald-glow hover:bg-emerald-glow/90 text-background">
              <DynamicIcon name="Plus" className="h-4 w-4" />
              إضافة مصروف
            </Button>
          </ExpenseDialog>
        </div>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-2">
        {/* 7-day chart */}
        <Card className="glass p-2 lg:col-span-2">
          <div className="flex items-center gap-2 mb-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-emerald-glow/15 text-emerald-glow">
              <DynamicIcon name="BarChart3" className="h-4 w-4" />
            </div>
            <h3 className="text-sm font-bold text-foreground">المصروفات آخر 7 أيام</h3>
          </div>
          <div className="flex items-end justify-between gap-2 h-20 mb-1">
            {last7Days.map((day, i) => {
              const heightPercent = (day.total / maxDayTotal) * 100;
              return (
                <motion.div
                  key={i}
                  initial={{ height: 0 }}
                  animate={{ height: `${Math.max(heightPercent, 2)}%` }}
                  transition={{ delay: i * 0.05, type: "spring", stiffness: 200, damping: 25 }}
                  className={cn(
                    "flex-1 rounded-t-lg relative group cursor-pointer",
                    day.isToday
                      ? "bg-gradient-to-t from-emerald-glow to-amber-glow"
                      : "bg-gradient-to-t from-emerald-glow/40 to-emerald-glow/20"
                  )}
                >
                  <div className="absolute -top-8 left-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-opacity bg-background/90 rounded-md px-2 py-1 text-[10px] font-mono font-bold text-foreground whitespace-nowrap border border-border/40">
                    {formatAmount(day.total)}
                  </div>
                </motion.div>
              );
            })}
          </div>
          <div className="flex justify-between">
            {last7Days.map((day, i) => (
              <div key={i} className="flex-1 text-center">
                <span className={cn(
                  "text-[10px]",
                  day.isToday ? "text-emerald-glow font-bold" : "text-muted-foreground"
                )}>
                  {day.label}
                </span>
              </div>
            ))}
          </div>
        </Card>

        {/* By category */}
        <Card className="glass p-2">
          <div className="flex items-center gap-2 mb-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-amber-glow/15 text-amber-glow">
              <DynamicIcon name="PieChart" className="h-4 w-4" />
            </div>
            <h3 className="text-sm font-bold text-foreground">حسب الفئة</h3>
          </div>
          {loading ? (
            <div className="space-y-2">
              {Array.from({ length: 4 }).map((_, i) => (
                <Skeleton key={i} className="h-10 rounded-lg" />
              ))}
            </div>
          ) : byCategory.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-3 text-center">
              <DynamicIcon name="PieChart" className="h-8 w-8 text-muted-foreground/50 mb-2" />
              <p className="text-xs text-muted-foreground">لا مصروفات في هذه الفترة</p>
            </div>
          ) : (
            <div className="space-y-2.5">
              {byCategory.slice(0, 6).map((cat, i) => {
                const colors = colorMap[cat.color] || colorMap.slate;
                const percent = (cat.total / maxCategoryTotal) * 100;
                const totalPercent = (cat.total / totalSYP) * 100;
                return (
                  <motion.div
                    key={cat.id}
                    initial={{ opacity: 0, x: 8 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.05 }}
                  >
                    <div className="flex items-center gap-2 mb-1">
                      <div className={cn("flex h-6 w-6 items-center justify-center rounded-md", colors.bg, colors.text)}>
                        <DynamicIcon name={cat.icon} className="h-3.5 w-3.5" />
                      </div>
                      <span className="text-xs text-foreground flex-1">{cat.label}</span>
                      <span className="text-xs font-mono font-bold text-foreground">
                        {formatAmount(cat.total)}
                      </span>
                      <span className="text-[10px] text-muted-foreground w-10 text-left">
                        {totalPercent.toFixed(0)}%
                      </span>
                    </div>
                    <div className="h-1.5 rounded-full bg-muted/20 overflow-hidden">
                      <motion.div
                        initial={{ width: 0 }}
                        animate={{ width: `${percent}%` }}
                        transition={{ delay: i * 0.05 + 0.1, type: "spring", stiffness: 200 }}
                        className="h-full rounded-full"
                        style={{ backgroundColor: colors.hex }}
                      />
                    </div>
                  </motion.div>
                );
              })}
            </div>
          )}
        </Card>
      </div>

      {/* Recent expenses list */}
      <Card className="glass p-2">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-rose-500/15 text-rose-400">
              <DynamicIcon name="Receipt" className="h-4 w-4" />
            </div>
            <h3 className="text-sm font-bold text-foreground">المصروفات الأخيرة</h3>
          </div>
          <span className="text-xs text-muted-foreground">{expenses.length} مصروف</span>
        </div>

        {loading ? (
          <div className="space-y-2">
            {Array.from({ length: 5 }).map((_, i) => (
              <Skeleton key={i} className="h-8 rounded-lg" />
            ))}
          </div>
        ) : expenses.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-3 text-center">
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-muted/30 mb-1.5">
              <DynamicIcon name="Receipt" className="h-6 w-6 text-muted-foreground" />
            </div>
            <p className="text-sm font-medium text-foreground">لا مصروفات مسجلة</p>
            <p className="text-xs text-muted-foreground mt-1">ابدأ بتسجيل مصروفاتك لتتبع إنفاقك</p>
          </div>
        ) : (
          <div className="space-y-1.5 max-h-full overflow-y-auto custom-scroll">
            <AnimatePresence>
              {expenses.map((expense, i) => {
                const cat = EXPENSE_CATEGORIES.find((c) => c.id === expense.category) || EXPENSE_CATEGORIES[EXPENSE_CATEGORIES.length - 1];
                const colors = colorMap[cat.color] || colorMap.slate;
                return (
                  <motion.div
                    key={expense.id}
                    layout
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    transition={{ delay: i * 0.02 }}
                    className="group flex items-center gap-2 rounded-xl border border-border/40 bg-background/40 p-2 hover:border-emerald-glow/30 transition-all"
                  >
                    <div className={cn("flex h-7 w-7 items-center justify-center rounded-lg shrink-0", colors.bg, colors.text)}>
                      <DynamicIcon name={cat.icon} className="h-5 w-5" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-foreground truncate">
                        {expense.description || cat.label}
                      </p>
                      <div className="flex items-center gap-2 mt-0.5">
                        <span className={cn("text-[10px] px-1.5 py-0.5 rounded-full", colors.bg, colors.text)}>
                          {cat.label}
                        </span>
                        <span className="text-[10px] text-muted-foreground">
                          {formatDistanceToNow(new Date(expense.date), { addSuffix: true, locale: ar })}
                        </span>
                      </div>
                    </div>
                    <div className="text-left shrink-0">
                      <p className="text-sm font-mono font-bold text-rose-400">
                        {expense.currency === "usd" ? "$" : ""}
                        {expense.amount.toLocaleString("en-US", { maximumFractionDigits: 0 })}
                        {expense.currency === "syp" ? " ل.س" : ""}
                      </p>
                    </div>
                    <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8"
                        onClick={() => { setEditingExpense(expense); setDialogOpen(true); }}
                      >
                        <DynamicIcon name="Pencil" className="h-3.5 w-3.5" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 hover:text-rose-400"
                        onClick={() => handleDelete(expense.id)}
                      >
                        <DynamicIcon name="Trash2" className="h-3.5 w-3.5" />
                      </Button>
                    </div>
                  </motion.div>
                );
              })}
            </AnimatePresence>
          </div>
        )}
      </Card>
    </div>
  );
}

function ExpenseDialog({
  open, onOpenChange, editingExpense, onSaved, children,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  editingExpense: Expense | null;
  onSaved: () => void;
  children: React.ReactNode;
}) {
  const [amount, setAmount] = React.useState("");
  const [currency, setCurrency] = React.useState("syp");
  const [category, setCategory] = React.useState("food");
  const [description, setDescription] = React.useState("");
  const [date, setDate] = React.useState(new Date().toISOString().split("T")[0]);
  const { toast } = useToast();

  React.useEffect(() => {
    if (editingExpense) {
      setAmount(editingExpense.amount.toString());
      setCurrency(editingExpense.currency);
      setCategory(editingExpense.category);
      setDescription(editingExpense.description || "");
      setDate(editingExpense.date.split("T")[0]);
    } else {
      setAmount(""); setCurrency("syp"); setCategory("food"); setDescription("");
      setDate(new Date().toISOString().split("T")[0]);
    }
  }, [editingExpense, open]);

  const handleSave = async () => {
    const numAmount = parseFloat(amount);
    if (!numAmount || numAmount <= 0) {
      toast({ title: "المبلغ غير صالح", variant: "destructive" });
      return;
    }
    const payload = {
      amount: numAmount,
      currency,
      category,
      description,
      date: new Date(date).toISOString(),
    };
    try {
      if (editingExpense) {
        await fetch("/api/expenses", {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ id: editingExpense.id, ...payload }),
        });
        toast({ title: "تم التحديث" });
      } else {
        await fetch("/api/expenses", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
        toast({ title: "تمت إضافة المصروف" });
      }
      onSaved();
    } catch {
      toast({ title: "فشل الحفظ", variant: "destructive" });
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogTrigger asChild>{children}</DialogTrigger>
      <DialogContent className="glass-strong max-w-md">
        <DialogHeader>
          <DialogTitle>{editingExpense ? "تعديل مصروف" : "إضافة مصروف جديد"}</DialogTitle>
        </DialogHeader>
        <div className="space-y-1.5">
          <div className="grid grid-cols-2 gap-2">
            <div>
              <Label htmlFor="e-amount">المبلغ</Label>
              <Input
                id="e-amount"
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="0"
                dir="ltr"
                className="text-lg font-bold"
              />
            </div>
            <div>
              <Label htmlFor="e-currency">العملة</Label>
              <Select value={currency} onValueChange={setCurrency}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent className="glass-strong">
                  <SelectItem value="syp">ليرة سورية</SelectItem>
                  <SelectItem value="usd">دولار</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div>
            <Label>الفئة</Label>
            <div className="grid grid-cols-4 gap-2 mt-1">
              {EXPENSE_CATEGORIES.map((cat) => {
                const colors = colorMap[cat.color] || colorMap.slate;
                return (
                  <button
                    key={cat.id}
                    onClick={() => setCategory(cat.id)}
                    className={cn(
                      "flex flex-col items-center gap-1 p-2 rounded-lg border transition-all",
                      category === cat.id
                        ? cn(colors.bg, colors.border, colors.text)
                        : "border-border/40 text-muted-foreground hover:border-emerald-glow/20"
                    )}
                  >
                    <DynamicIcon name={cat.icon} className="h-4 w-4" />
                    <span className="text-[9px] text-center leading-tight">{cat.label}</span>
                  </button>
                );
              })}
            </div>
          </div>
          <div>
            <Label htmlFor="e-date">التاريخ</Label>
            <Input id="e-date" type="date" value={date} onChange={(e) => setDate(e.target.value)} />
          </div>
          <div>
            <Label htmlFor="e-desc">الوصف (اختياري)</Label>
            <Textarea id="e-desc" value={description} onChange={(e) => setDescription(e.target.value)} rows={2} placeholder="تفاصيل المصروف" />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>إلغاء</Button>
          <Button onClick={handleSave} className="bg-emerald-glow hover:bg-emerald-glow/90 text-background">
            {editingExpense ? "حفظ" : "إضافة"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

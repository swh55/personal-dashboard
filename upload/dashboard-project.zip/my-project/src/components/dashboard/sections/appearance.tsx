"use client";

import * as React from "react";
import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Checkbox } from "@/components/ui/checkbox";
import { Slider } from "@/components/ui/slider";
import { Skeleton } from "@/components/ui/skeleton";
import { DynamicIcon } from "../icon";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

// Google brand colors
const G_BLUE = "#4285F4";
const G_RED = "#EA4335";
const G_YELLOW = "#FBBC04";
const G_GREEN = "#34A853";
const G_ORANGE = "#FF6D00";
const G_PURPLE = "#A142F4";
const G_TEAL = "#00897B";
const G_GRAY = "#5F6368";

// --- Layout density options ---
const DENSITY_OPTIONS = [
  { value: "compact", label: "مدمج", icon: "Minimize2", color: G_BLUE },
  { value: "normal", label: "عادي", icon: "Layout", color: G_GREEN },
  { value: "comfortable", label: "مريح", icon: "Maximize2", color: G_ORANGE },
] as const;

// --- Font size options ---
const FONT_OPTIONS = [
  { value: "0.875rem", label: "صغير", sample: "Aa", color: G_TEAL },
  { value: "1rem", label: "متوسط", sample: "Aa", color: G_BLUE },
  { value: "1.125rem", label: "كبير", sample: "Aa", color: G_PURPLE },
  { value: "1.25rem", label: "ضخم", sample: "Aa", color: G_RED },
] as const;

// --- Icon set options ---
const ICON_SETS = [
  { value: "default", label: "افتراضي", icon: "Sparkles", color: G_BLUE },
  { value: "minimal", label: "بسيط", icon: "Layout", color: G_TEAL },
  { value: "filled", label: "مملوء", icon: "Star", color: G_ORANGE },
] as const;

// --- Seasonal themes ---
const SEASONAL_THEMES = [
  { value: "auto", label: "تلقائي", icon: "RefreshCw", color: G_GRAY, accent: "#10b981" },
  { value: "ramadan", label: "رمضان", icon: "Moon", color: G_PURPLE, accent: "#A142F4" },
  { value: "eid", label: "العيد", icon: "Star", color: G_YELLOW, accent: "#FBBC04" },
  { value: "winter", label: "الشتاء", icon: "CloudSnow", color: G_BLUE, accent: "#4285F4" },
  { value: "summer", label: "الصيف", icon: "Sun", color: G_ORANGE, accent: "#FF6D00" },
] as const;

// --- Background swatches ---
const BG_SWATCHES = [
  { value: "#0f1419", label: "أسود", color: "#0f1419" },
  { value: "#1a1f2e", label: "كحلي", color: "#1a1f2e" },
  { value: "#1c1917", label: "بني داكن", color: "#1c1917" },
  { value: "#0c2233", label: "أزرق ليلي", color: "#0c2233" },
  { value: "#1a2e1a", label: "أخضر داكن", color: "#1a2e1a" },
] as const;

// --- Dock sections ---
const DOCK_SECTIONS = [
  { key: "dockOverview", label: "نظرة عامة", icon: "LayoutDashboard", color: G_BLUE },
  { key: "dockCalendar", label: "التقويم", icon: "Calendar", color: G_RED },
  { key: "dockTasks", label: "المهام", icon: "CheckSquare", color: G_GREEN },
  { key: "dockContacts", label: "جهات الاتصال", icon: "Users", color: G_TEAL },
  { key: "dockFinances", label: "المالية", icon: "Wallet", color: G_YELLOW },
  { key: "dockHealth", label: "الصحة", icon: "Heart", color: G_RED },
  { key: "dockAnalytics", label: "التحليلات", icon: "BarChart3", color: G_PURPLE },
  { key: "dockSettings", label: "الإعدادات", icon: "Settings", color: G_GRAY },
] as const;

export function AppearanceSection() {
  const { toast } = useToast();
  const [loading, setLoading] = React.useState(true);
  const [saving, setSaving] = React.useState(false);

  // Local working copy of preferences
  const [prefs, setPrefs] = React.useState<Record<string, string>>({});
  // Original loaded copy to detect changes
  const [original, setOriginal] = React.useState<Record<string, string>>({});

  React.useEffect(() => {
    fetch("/api/settings")
      .then((r) => r.json())
      .then((json) => {
        if (json.success) {
          const merged = { ...DEFAULT_PREFS, ...json.data };
          setPrefs(merged);
          setOriginal(merged);
          applyDensity(merged.density);
          applyFontSize(merged.fontSize);
          applyNightMode(merged.nightMode === "true");
          applyAnimations(merged.animations === "true");
        }
      })
      .catch(() => {
        setPrefs(DEFAULT_PREFS);
      })
      .finally(() => setLoading(false));
  }, []);

  // Live preview effects
  React.useEffect(() => {
    if (!loading) applyDensity(prefs.density);
  }, [prefs.density, loading]);
  React.useEffect(() => {
    if (!loading) applyFontSize(prefs.fontSize);
  }, [prefs.fontSize, loading]);
  React.useEffect(() => {
    if (!loading) applyNightMode(prefs.nightMode === "true");
  }, [prefs.nightMode, loading]);
  React.useEffect(() => {
    if (!loading) applyAnimations(prefs.animations === "true");
  }, [prefs.animations, loading]);

  const dirtyKeys = React.useMemo(
    () => Object.keys(prefs).filter((k) => prefs[k] !== original[k]),
    [prefs, original]
  );
  const hasChanges = dirtyKeys.length > 0;

  const setPref = (key: string, value: string) =>
    setPrefs((prev) => ({ ...prev, [key]: value }));

  const handleSave = async () => {
    if (!hasChanges) return;
    setSaving(true);
    try {
      await Promise.all(
        dirtyKeys.map((k) =>
          fetch("/api/settings", {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ key: k, value: prefs[k] }),
          })
        )
      );
      setOriginal({ ...prefs });
      toast({ title: "تم حفظ التخصيصات ✓", description: `${dirtyKeys.length} تغيير` });
    } catch {
      toast({ title: "فشل حفظ التخصيصات", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  const handleReset = () => {
    setPrefs(original);
    toast({ title: "تم التراجع عن التغييرات" });
  };

  if (loading) {
    return (
      <div className="space-y-1.5">
        {Array.from({ length: 4 }).map((_, i) => (
          <Skeleton key={i} className="h-20 rounded-2xl" />
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-1.5">
      {/* Header */}
      <Card className="p-2" style={{ backgroundColor: "var(--surface-container)" }}>
        <div className="flex items-center gap-1.5">
          <div
            className="flex h-7 w-7 items-center justify-center rounded-lg"
            style={{ backgroundColor: `${G_PURPLE}22`, color: G_PURPLE }}
          >
            <DynamicIcon name="Palette" className="h-4 w-4" />
          </div>
          <div className="flex-1">
            <p className="text-xs font-bold text-foreground">المظهر والتخصيص</p>
            <p className="text-[10px] text-muted-foreground">خصّص واجهتك كما يحلو لك</p>
          </div>
          {hasChanges && (
            <Button
              size="sm"
              variant="ghost"
              className="h-7 text-[10px]"
              onClick={handleReset}
            >
              تراجع
            </Button>
          )}
          <Button
            size="sm"
            className="h-7 text-[10px] gap-1"
            disabled={!hasChanges || saving}
            onClick={handleSave}
            style={{ backgroundColor: G_GREEN, color: "#fff" }}
          >
            <DynamicIcon
              name={saving ? "Loader2" : "Save"}
              className={cn("h-3 w-3", saving && "animate-spin")}
            />
            حفظ
          </Button>
        </div>
      </Card>

      {/* Layout Density */}
      <Card className="p-2" style={{ backgroundColor: "var(--surface-container)" }}>
        <SectionHeader icon="Layout" color={G_BLUE} title="كثافة الواجهة" hint="تحكم في تباعد العناصر" />
        <div className="grid grid-cols-3 gap-1 mt-1.5">
          {DENSITY_OPTIONS.map((opt) => {
            const selected = prefs.density === opt.value;
            return (
              <button
                key={opt.value}
                onClick={() => setPref("density", opt.value)}
                className={cn(
                  "flex flex-col items-center gap-0.5 py-1.5 rounded-lg border transition-all text-[10px] font-medium",
                  selected
                    ? "border-transparent"
                    : "border-border/40 text-muted-foreground hover:border-primary/30"
                )}
                style={selected ? { backgroundColor: `${opt.color}22`, color: opt.color } : {}}
              >
                <DynamicIcon name={opt.icon} className="h-3.5 w-3.5" />
                {opt.label}
              </button>
            );
          })}
        </div>
        {/* Visual slider reflecting density */}
        <div className="mt-1.5">
          <Slider
            value={[DENSITY_OPTIONS.findIndex((d) => d.value === prefs.density)]}
            min={0}
            max={2}
            step={1}
            onValueChange={(v) =>
              setPref("density", DENSITY_OPTIONS[v[0] ?? 1].value)
            }
          />
        </div>
      </Card>

      {/* Font Size */}
      <Card className="p-2" style={{ backgroundColor: "var(--surface-container)" }}>
        <SectionHeader icon="BookOpen" color={G_TEAL} title="حجم الخط" hint="اختر حجم النص المناسب" />
        <div className="grid grid-cols-4 gap-1 mt-1.5">
          {FONT_OPTIONS.map((opt) => {
            const selected = prefs.fontSize === opt.value;
            return (
              <button
                key={opt.value}
                onClick={() => setPref("fontSize", opt.value)}
                className={cn(
                  "flex flex-col items-center gap-0.5 py-1.5 rounded-lg border transition-all",
                  selected
                    ? "border-transparent"
                    : "border-border/40 text-muted-foreground hover:border-primary/30"
                )}
                style={selected ? { backgroundColor: `${opt.color}22`, color: opt.color } : {}}
              >
                <span className="font-bold leading-none" style={{ fontSize: 12 }}>
                  {opt.sample}
                </span>
                <span className="text-[9px]">{opt.label}</span>
              </button>
            );
          })}
        </div>
      </Card>

      {/* Toggles Row: Night Mode + Animations */}
      <div className="grid grid-cols-2 gap-1.5">
        <Card className="p-2" style={{ backgroundColor: "var(--surface-container)" }}>
          <div className="flex items-center gap-1.5">
            <div
              className="flex h-6 w-6 items-center justify-center rounded-lg shrink-0"
              style={{ backgroundColor: `${G_YELLOW}22`, color: G_YELLOW }}
            >
              <DynamicIcon name="Moon" className="h-3.5 w-3.5" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-xs font-medium text-foreground">وضع القراءة الليلي</p>
              <p className="text-[9px] text-muted-foreground">فلتر دافئ</p>
            </div>
            <Switch
              checked={prefs.nightMode === "true"}
              onCheckedChange={(c) => setPref("nightMode", String(c))}
            />
          </div>
        </Card>
        <Card className="p-2" style={{ backgroundColor: "var(--surface-container)" }}>
          <div className="flex items-center gap-1.5">
            <div
              className="flex h-6 w-6 items-center justify-center rounded-lg shrink-0"
              style={{ backgroundColor: `${G_ORANGE}22`, color: G_ORANGE }}
            >
              <DynamicIcon name="Zap" className="h-3.5 w-3.5" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-xs font-medium text-foreground">الحركات</p>
              <p className="text-[9px] text-muted-foreground">تفعيل/تعطيل</p>
            </div>
            <Switch
              checked={prefs.animations === "true"}
              onCheckedChange={(c) => setPref("animations", String(c))}
            />
          </div>
        </Card>
      </div>

      {/* Icon Set */}
      <Card className="p-2" style={{ backgroundColor: "var(--surface-container)" }}>
        <SectionHeader icon="Sparkles" color={G_PURPLE} title="طقم الأيقونات" hint="النمط البصري للأيقونات" />
        <div className="grid grid-cols-3 gap-1 mt-1.5">
          {ICON_SETS.map((opt) => {
            const selected = prefs.iconSet === opt.value;
            return (
              <button
                key={opt.value}
                onClick={() => setPref("iconSet", opt.value)}
                className={cn(
                  "flex flex-col items-center gap-0.5 py-1.5 rounded-lg border transition-all text-[10px] font-medium",
                  selected
                    ? "border-transparent"
                    : "border-border/40 text-muted-foreground hover:border-primary/30"
                )}
                style={selected ? { backgroundColor: `${opt.color}22`, color: opt.color } : {}}
              >
                <DynamicIcon name={opt.icon} className="h-3.5 w-3.5" />
                {opt.label}
              </button>
            );
          })}
        </div>
      </Card>

      {/* Seasonal Themes */}
      <Card className="p-2" style={{ backgroundColor: "var(--surface-container)" }}>
        <SectionHeader icon="CalendarDays" color={G_RED} title="الثيمات الموسمية" hint="غيّر لون التمييز حسب الموسم" />
        <div className="grid grid-cols-5 gap-1 mt-1.5">
          {SEASONAL_THEMES.map((opt) => {
            const selected = prefs.seasonalTheme === opt.value;
            return (
              <button
                key={opt.value}
                onClick={() => setPref("seasonalTheme", opt.value)}
                className={cn(
                  "flex flex-col items-center gap-0.5 py-1.5 rounded-lg border transition-all",
                  selected
                    ? "border-transparent"
                    : "border-border/40 text-muted-foreground hover:border-primary/30"
                )}
                style={selected ? { backgroundColor: `${opt.color}22`, color: opt.color } : {}}
              >
                <DynamicIcon name={opt.icon} className="h-3.5 w-3.5" />
                <span className="text-[9px]">{opt.label}</span>
              </button>
            );
          })}
        </div>
        {prefs.seasonalTheme && prefs.seasonalTheme !== "auto" && (
          <div className="mt-1.5 flex items-center gap-1.5 text-[10px] text-muted-foreground">
            <span>اللون التمييزي:</span>
            <div
              className="h-3 w-3 rounded-full"
              style={{
                backgroundColor:
                  SEASONAL_THEMES.find((t) => t.value === prefs.seasonalTheme)?.accent ||
                  G_GREEN,
              }}
            />
            <span className="font-mono">
              {SEASONAL_THEMES.find((t) => t.value === prefs.seasonalTheme)?.accent}
            </span>
          </div>
        )}
      </Card>

      {/* Custom Background */}
      <Card className="p-2" style={{ backgroundColor: "var(--surface-container)" }}>
        <SectionHeader icon="Palette" color={G_GREEN} title="الخلفية المخصصة" hint="اختر لوناً للخلفية" />
        <div className="flex items-center gap-1.5 mt-1.5">
          {BG_SWATCHES.map((sw) => {
            const selected = prefs.bgColor === sw.value;
            return (
              <motion.button
                key={sw.value}
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setPref("bgColor", sw.value)}
                className={cn(
                  "flex-1 h-7 rounded-full border-2 transition-all relative",
                  selected ? "border-foreground" : "border-transparent"
                )}
                style={{ backgroundColor: sw.color }}
                aria-label={sw.label}
              >
                {selected && (
                  <DynamicIcon
                    name="Check"
                    className="h-3 w-3 absolute inset-0 m-auto text-white"
                  />
                )}
              </motion.button>
            );
          })}
        </div>
        <div className="flex items-center gap-1.5 mt-1.5">
          <input
            type="color"
            value={prefs.bgColor || "#0f1419"}
            onChange={(e) => setPref("bgColor", e.target.value)}
            className="h-6 w-8 rounded cursor-pointer bg-transparent border border-border/40"
            aria-label="منتقي لون الخلفية"
          />
          <span className="text-[10px] text-muted-foreground font-mono">{prefs.bgColor}</span>
        </div>
      </Card>

      {/* Dock Customization */}
      <Card className="p-2" style={{ backgroundColor: "var(--surface-container)" }}>
        <SectionHeader icon="Layout" color={G_ORANGE} title="تخصيص الشريط الجانبي" hint="تحكم بأقسام الشريط" />
        <div className="grid grid-cols-2 gap-1 mt-1.5">
          {DOCK_SECTIONS.map((sec) => {
            const checked = prefs[sec.key] !== "false"; // default visible
            return (
              <label
                key={sec.key}
                className={cn(
                  "flex items-center gap-1.5 p-1.5 rounded-lg border cursor-pointer transition-all",
                  checked
                    ? "border-transparent"
                    : "border-border/40 opacity-60"
                )}
                style={checked ? { backgroundColor: `${sec.color}15` } : {}}
              >
                <Checkbox
                  checked={checked}
                  onCheckedChange={(c) => setPref(sec.key, String(c === true))}
                />
                <div
                  className="flex h-5 w-5 items-center justify-center rounded-md shrink-0"
                  style={{ backgroundColor: `${sec.color}22`, color: sec.color }}
                >
                  <DynamicIcon name={sec.icon} className="h-3 w-3" />
                </div>
                <span className="text-[10px] font-medium text-foreground truncate">
                  {sec.label}
                </span>
              </label>
            );
          })}
        </div>
      </Card>

      {/* Save bar */}
      {hasChanges && (
        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ type: "spring", stiffness: 300, damping: 20 }}
        >
          <Card className="p-2" style={{ backgroundColor: "var(--surface-container)" }}>
            <div className="flex items-center justify-between gap-1.5">
              <div className="flex items-center gap-1.5">
                <div
                  className="flex h-6 w-6 items-center justify-center rounded-full"
                  style={{ backgroundColor: `${G_YELLOW}22`, color: G_YELLOW }}
                >
                  <DynamicIcon name="AlertCircle" className="h-3.5 w-3.5" />
                </div>
                <p className="text-[10px] text-muted-foreground">
                  {dirtyKeys.length} تغيير غير محفوظ
                </p>
              </div>
              <Button
                size="sm"
                className="h-7 gap-1"
                onClick={handleSave}
                disabled={saving}
                style={{ backgroundColor: G_GREEN, color: "#fff" }}
              >
                <DynamicIcon
                  name={saving ? "Loader2" : "Save"}
                  className={cn("h-3.5 w-3.5", saving && "animate-spin")}
                />
                حفظ التغييرات
              </Button>
            </div>
          </Card>
        </motion.div>
      )}
    </div>
  );
}

// --- Defaults ---
const DEFAULT_PREFS: Record<string, string> = {
  density: "normal",
  fontSize: "1rem",
  nightMode: "false",
  animations: "true",
  iconSet: "default",
  seasonalTheme: "auto",
  bgColor: "#0f1419",
  dockOverview: "true",
  dockCalendar: "true",
  dockTasks: "true",
  dockContacts: "true",
  dockFinances: "true",
  dockHealth: "true",
  dockAnalytics: "true",
  dockSettings: "true",
};

// --- Live preview side-effects (CSS class on body) ---
function applyDensity(density: string) {
  if (typeof document === "undefined") return;
  document.body.classList.remove("density-compact", "density-normal", "density-comfortable");
  document.body.classList.add(`density-${density || "normal"}`);
}

function applyFontSize(size: string) {
  if (typeof document === "undefined") return;
  document.documentElement.style.setProperty("--app-font-size", size || "1rem");
}

function applyNightMode(on: boolean) {
  if (typeof document === "undefined") return;
  document.body.classList.toggle("reading-night-mode", on);
}

function applyAnimations(on: boolean) {
  if (typeof document === "undefined") return;
  document.body.classList.toggle("no-animations", !on);
}

// --- Reusable sub-components ---
function SectionHeader({
  icon,
  color,
  title,
  hint,
}: {
  icon: string;
  color: string;
  title: string;
  hint?: string;
}) {
  return (
    <div className="flex items-center gap-1.5">
      <div
        className="flex h-6 w-6 items-center justify-center rounded-lg shrink-0"
        style={{ backgroundColor: `${color}22`, color }}
      >
        <DynamicIcon name={icon} className="h-3.5 w-3.5" />
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-xs font-bold text-foreground">{title}</p>
        {hint && <p className="text-[10px] text-muted-foreground">{hint}</p>}
      </div>
    </div>
  );
}

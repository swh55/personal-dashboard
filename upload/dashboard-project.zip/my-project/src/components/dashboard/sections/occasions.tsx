"use client";

import * as React from "react";
import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger } from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { DynamicIcon } from "../icon";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { format, differenceInDays } from "date-fns";
import { ar } from "date-fns/locale";

interface Occasion {
  id: string;
  title: string;
  date: string;
  type: string;
  recurring: boolean;
  note?: string | null;
}

const typeConfig: Record<string, { label: string; icon: string; color: string }> = {
  birthday: { label: "عيد ميلاد", icon: "Cake", color: "#E91E63" },
  anniversary: { label: "ذكرى سنوية", icon: "Heart", color: "#EA4335" },
  holiday: { label: "عطلة", icon: "Calendar", color: "#A142F4" },
};

function getNextOccurrenceDate(dateStr: string): Date {
  const date = new Date(dateStr);
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const thisYear = new Date(today.getFullYear(), date.getMonth(), date.getDate());
  if (thisYear < today) {
    return new Date(today.getFullYear() + 1, date.getMonth(), date.getDate());
  }
  return thisYear;
}

export function OccasionsSection() {
  const [occasions, setOccasions] = React.useState<Occasion[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [dialogOpen, setDialogOpen] = React.useState(false);
  const [editingOccasion, setEditingOccasion] = React.useState<Occasion | null>(null);
  const { toast } = useToast();

  const fetchOccasions = React.useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/occasions");
      const json = await res.json();
      if (json.success) setOccasions(json.data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, []);

  React.useEffect(() => {
    fetchOccasions();
  }, [fetchOccasions]);

  const handleDelete = async (id: string) => {
    await fetch(`/api/occasions?id=${id}`, { method: "DELETE" });
    toast({ title: "تم حذف المناسبة" });
    fetchOccasions();
  };

  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const sorted = [...occasions].sort((a, b) => {
    const aNext = getNextOccurrenceDate(a.date);
    const bNext = getNextOccurrenceDate(b.date);
    return aNext.getTime() - bNext.getTime();
  });

  return (
    <div className="space-y-1.5">
      {/* Compact header */}
      <div className="flex items-center justify-between px-1">
        <div className="flex items-center gap-2">
          <DynamicIcon name="Cake" className="h-4 w-4" style={{ color: "#E91E63" }} />
          <span className="text-sm font-medium text-foreground">{occasions.length} مناسبة</span>
        </div>
        <OccasionDialog
          open={dialogOpen}
          onOpenChange={setDialogOpen}
          editingOccasion={editingOccasion}
          onSaved={() => {
            setDialogOpen(false);
            setEditingOccasion(null);
            fetchOccasions();
          }}
        >
          <Button size="sm" className="h-7 px-2 text-xs" style={{ backgroundColor: "#4285F4", color: "white" }}>
            <DynamicIcon name="Plus" className="h-3 w-3" />
            إضافة
          </Button>
        </OccasionDialog>
      </div>

      {/* Dense grid */}
      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-1.5">
          {Array.from({ length: 3 }).map((_, i) => (
            <Skeleton key={i} className="h-16 rounded-lg" />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-1.5">
          {sorted.map((occasion, i) => {
            const config = typeConfig[occasion.type] || typeConfig.birthday;
            const nextDate = getNextOccurrenceDate(occasion.date);
            const daysUntil = differenceInDays(nextDate, today);
            const isToday = daysUntil === 0;
            const isSoon = daysUntil <= 7;
            const birthDate = new Date(occasion.date);
            const age = nextDate.getFullYear() - birthDate.getFullYear();
            return (
              <motion.div
                key={occasion.id}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: i * 0.03 }}
              >
                <div
                  className={cn(
                    "rounded-lg p-2 transition-all group relative",
                    isToday ? "ring-1 ring-pink-500/40" : ""
                  )}
                  style={{ backgroundColor: "var(--surface-container)" }}
                >
                  {isToday && (
                    <span className="absolute top-1 left-1 px-1 py-0.5 rounded text-[8px] font-bold text-white" style={{ backgroundColor: "#E91E63" }}>
                      🎉 اليوم
                    </span>
                  )}
                  {/* Row 1: icon + name + days */}
                  <div className="flex items-center gap-1.5 mb-1">
                    <div className="flex h-7 w-7 items-center justify-center rounded-full shrink-0" style={{ backgroundColor: config.color + "22" }}>
                      <DynamicIcon name={config.icon} className="h-3.5 w-3.5" style={{ color: config.color }} />
                    </div>
                    <p className="text-xs font-medium text-foreground truncate flex-1">{occasion.title}</p>
                    <span
                      className="text-base font-bold leading-none shrink-0"
                      style={{ color: isToday ? "#E91E63" : isSoon ? "#FBBC04" : "var(--on-surface-variant)" }}
                    >
                      {isToday ? "🎉" : daysUntil}
                    </span>
                    {!isToday && <span className="text-[8px] text-on-surface-variant shrink-0">يوم</span>}
                  </div>

                  {/* Row 2: date + age */}
                  <div className="flex items-center justify-between text-[9px] text-on-surface-variant">
                    <span>{format(nextDate, "d MMM yyyy", { locale: ar })}</span>
                    <span style={{ color: "#34A853" }}>{age} سنة</span>
                  </div>

                  {/* Row 3: note (if exists) */}
                  {occasion.note && (
                    <p className="text-[9px] text-on-surface-variant/70 mt-0.5 line-clamp-1">{occasion.note}</p>
                  )}

                  {/* Hover actions */}
                  <div className="flex gap-0.5 mt-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button
                      className="flex h-5 w-5 items-center justify-center rounded text-on-surface-variant hover:text-foreground"
                      onClick={() => { setEditingOccasion(occasion); setDialogOpen(true); }}
                    >
                      <DynamicIcon name="Pencil" className="h-2.5 w-2.5" />
                    </button>
                    <button
                      className="flex h-5 w-5 items-center justify-center rounded text-on-surface-variant hover:text-red-400"
                      onClick={() => handleDelete(occasion.id)}
                    >
                      <DynamicIcon name="Trash2" className="h-2.5 w-2.5" />
                    </button>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      )}
    </div>
  );
}

function OccasionDialog({
  open, onOpenChange, editingOccasion, onSaved, children,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  editingOccasion: Occasion | null;
  onSaved: () => void;
  children: React.ReactNode;
}) {
  const [title, setTitle] = React.useState("");
  const [date, setDate] = React.useState("");
  const [type, setType] = React.useState("birthday");
  const [note, setNote] = React.useState("");
  const [recurring, setRecurring] = React.useState(true);
  const { toast } = useToast();

  React.useEffect(() => {
    if (editingOccasion) {
      setTitle(editingOccasion.title);
      setDate(editingOccasion.date.split("T")[0]);
      setType(editingOccasion.type);
      setNote(editingOccasion.note || "");
      setRecurring(editingOccasion.recurring);
    } else {
      setTitle(""); setDate(""); setType("birthday"); setNote(""); setRecurring(true);
    }
  }, [editingOccasion, open]);

  const handleSave = async () => {
    if (!title || !date) {
      toast({ title: "العنوان والتاريخ مطلوبان", variant: "destructive" });
      return;
    }
    const payload = { title, date: new Date(date).toISOString(), type, note, recurring };
    try {
      if (editingOccasion) {
        await fetch("/api/occasions", {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ id: editingOccasion.id, ...payload }),
        });
        toast({ title: "تم التحديث" });
      } else {
        await fetch("/api/occasions", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
        toast({ title: "تمت الإضافة" });
      }
      onSaved();
    } catch {
      toast({ title: "فشل الحفظ", variant: "destructive" });
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogTrigger asChild>{children}</DialogTrigger>
      <DialogContent className="glass-strong max-w-md">
        <DialogHeader>
          <DialogTitle>{editingOccasion ? "تعديل مناسبة" : "إضافة مناسبة"}</DialogTitle>
        </DialogHeader>
        <div className="space-y-2">
          <div>
            <Label htmlFor="o-title" className="text-xs">العنوان</Label>
            <Input id="o-title" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="مثلاً: عيد ميلاد سوسو" className="h-8 text-sm" />
          </div>
          <div className="grid grid-cols-2 gap-2">
            <div>
              <Label htmlFor="o-date" className="text-xs">التاريخ</Label>
              <Input id="o-date" type="date" value={date} onChange={(e) => setDate(e.target.value)} className="h-8 text-sm" />
            </div>
            <div>
              <Label htmlFor="o-type" className="text-xs">النوع</Label>
              <select
                value={type}
                onChange={(e) => setType(e.target.value)}
                className="w-full h-8 rounded-md border border-border bg-background/50 px-2 text-sm"
              >
                <option value="birthday">عيد ميلاد</option>
                <option value="anniversary">ذكرى سنوية</option>
                <option value="holiday">عطلة</option>
              </select>
            </div>
          </div>
          <div>
            <Label htmlFor="o-note" className="text-xs">ملاحظة</Label>
            <Textarea id="o-note" value={note} onChange={(e) => setNote(e.target.value)} rows={2} className="text-sm" />
          </div>
          <label className="flex items-center gap-2 text-xs cursor-pointer">
            <input type="checkbox" checked={recurring} onChange={(e) => setRecurring(e.target.checked)} className="h-3.5 w-3.5 rounded" />
            مناسبة سنوية متكررة
          </label>
        </div>
        <DialogFooter>
          <Button variant="outline" size="sm" onClick={() => onOpenChange(false)}>إلغاء</Button>
          <Button size="sm" onClick={handleSave} style={{ backgroundColor: "#4285F4", color: "white" }}>
            {editingOccasion ? "حفظ" : "إضافة"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

"use client";

import * as React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { DynamicIcon } from "../icon";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

// Google brand colors
const G_BLUE = "#4285F4";
const G_RED = "#EA4335";
const G_YELLOW = "#FBBC04";
const G_GREEN = "#34A853";
const G_ORANGE = "#FF6D00";
const G_PURPLE = "#A142F4";
const G_TEAL = "#00897B";
const G_GRAY = "#5F6368";

// Rotating pool of motivational messages (extra local variety)
const EXTRA_MOTIVATION = [
  "أحسنت! استمر في التقدم 🌟",
  "كل خطوة صغيرة تقربك من هدفك 💪",
  "الإتقان في العمل عبادة 🤲",
  "أنت تتحسن كل يوم 📈",
  "النجاح هو مجموع الجهود الصغيرة المتكررة ✨",
  "اليوم فرصة جديدة لإنجاز أكثر 🚀",
  "ثابر قليلاً... النتيجة ستذهلك 🎯",
  "العادات الصغيرة تبني المستقبل العظيم 🌱",
];

// Color cycle for achievement badges
const BADGE_COLORS = [
  G_BLUE,
  G_RED,
  G_YELLOW,
  G_GREEN,
  G_PURPLE,
  G_TEAL,
  G_ORANGE,
];

interface GamificationData {
  points: {
    today: number;
    total: number;
    level: number;
  };
  achievements: {
    unlocked: number;
    total: number;
  };
  challenge: {
    current: {
      id: string;
      title: string;
      description: string | null;
      target: number;
      progress: number;
      weekStart: string;
      weekEnd: string;
    } | null;
  };
  streak: number;
  motivationalMessage: string;
}

interface Achievement {
  type: string;
  title: string;
  description: string;
  icon: string;
  unlocked: boolean;
  unlockedAt: string | null;
}

export function GamificationSection() {
  const { toast } = useToast();
  const [data, setData] = React.useState<GamificationData | null>(null);
  const [achievements, setAchievements] = React.useState<Achievement[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [motivationIdx, setMotivationIdx] = React.useState(0);
  const [refreshing, setRefreshing] = React.useState(false);

  const fetchData = React.useCallback(async () => {
    try {
      const [gRes, aRes] = await Promise.all([
        fetch("/api/gamification"),
        fetch("/api/achievements"),
      ]);
      const gJson = await gRes.json();
      const aJson = await aRes.json();
      if (gJson.success) setData(gJson);
      if (aJson.success) setAchievements(aJson.data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  React.useEffect(() => {
    fetchData();
  }, [fetchData]);

  // Rotate motivational message every 8s
  React.useEffect(() => {
    const id = setInterval(() => {
      setMotivationIdx((i) => (i + 1) % EXTRA_MOTIVATION.length);
    }, 8000);
    return () => clearInterval(id);
  }, []);

  const handleRefresh = () => {
    setRefreshing(true);
    fetchData();
    toast({ title: "تم تحديث بيانات التحفيز" });
  };

  if (loading || !data) {
    return (
      <div className="space-y-1.5">
        {Array.from({ length: 4 }).map((_, i) => (
          <Skeleton key={i} className="h-20 rounded-2xl" />
        ))}
      </div>
    );
  }

  const currentMessage = EXTRA_MOTIVATION[motivationIdx] || data.motivationalMessage;

  // Level progress: points in current level vs points needed for next level (each level = 100 points)
  const pointsInLevel = data.points.total % 100;
  const levelProgress = (pointsInLevel / 100) * 100;
  const pointsToNext = 100 - pointsInLevel;

  const challenge = data.challenge.current;
  const challengeProgress =
    challenge && challenge.target > 0
      ? Math.min(100, (challenge.progress / challenge.target) * 100)
      : 0;

  return (
    <div className="space-y-1.5">
      {/* Header */}
      <Card className="p-2" style={{ backgroundColor: "var(--surface-container)" }}>
        <div className="flex items-center gap-1.5">
          <div
            className="flex h-7 w-7 items-center justify-center rounded-lg"
            style={{ backgroundColor: `${G_YELLOW}22`, color: G_YELLOW }}
          >
            <DynamicIcon name="Trophy" className="h-4 w-4" />
          </div>
          <div className="flex-1">
            <p className="text-xs font-bold text-foreground">التحفيز والإنجازات</p>
            <p className="text-[10px] text-muted-foreground">تابع تقدّمك وحقق إنجازاتك</p>
          </div>
          <Button
            size="sm"
            variant="ghost"
            className="h-7 w-7 p-0"
            onClick={handleRefresh}
            disabled={refreshing}
          >
            <DynamicIcon
              name={refreshing ? "Loader2" : "RefreshCw"}
              className={cn("h-3.5 w-3.5", refreshing && "animate-spin")}
            />
          </Button>
        </div>
      </Card>

      {/* Points + Level card */}
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ type: "spring", stiffness: 300, damping: 20 }}
      >
        <Card
          className="p-3 relative overflow-hidden"
          style={{ backgroundColor: "var(--surface-container)" }}
        >
          {/* Decorative glow */}
          <div
            className="absolute -top-8 -right-8 h-24 w-24 rounded-full blur-3xl pointer-events-none"
            style={{ backgroundColor: `${G_YELLOW}33` }}
          />
          <div className="relative">
            <div className="flex items-center gap-2 mb-2">
              <motion.div
                animate={{ scale: [1, 1.08, 1] }}
                transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
                className="flex h-10 w-10 items-center justify-center rounded-full text-white font-bold text-sm shrink-0"
                style={{
                  background: `linear-gradient(135deg, ${G_YELLOW}, ${G_ORANGE})`,
                  boxShadow: `0 4px 12px ${G_YELLOW}55`,
                }}
              >
                {data.points.level}
              </motion.div>
              <div className="flex-1">
                <p className="text-[10px] text-muted-foreground">المستوى الحالي</p>
                <p className="text-sm font-bold text-foreground">المستوى {data.points.level}</p>
              </div>
              <div className="text-left">
                <p className="text-[10px] text-muted-foreground">النقاط الكلية</p>
                <p className="text-sm font-bold font-mono" style={{ color: G_YELLOW }}>
                  {data.points.total}
                </p>
              </div>
            </div>

            {/* Progress to next level */}
            <div className="mb-2">
              <div className="flex items-center justify-between text-[10px] text-muted-foreground mb-1">
                <span>التقدم للمستوى التالي</span>
                <span className="font-mono">
                  {pointsInLevel}/100 · ينقص {pointsToNext}
                </span>
              </div>
              <div className="h-2 rounded-full bg-white/5 overflow-hidden">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${levelProgress}%` }}
                  transition={{ type: "spring", stiffness: 300, damping: 20, delay: 0.2 }}
                  className="h-full rounded-full"
                  style={{
                    background: `linear-gradient(90deg, ${G_YELLOW}, ${G_ORANGE})`,
                  }}
                />
              </div>
            </div>

            {/* Today + Streak chips */}
            <div className="grid grid-cols-2 gap-1.5">
              <div
                className="flex items-center gap-1.5 rounded-2xl p-1.5"
                style={{ backgroundColor: `${G_GREEN}18` }}
              >
                <div
                  className="flex h-6 w-6 items-center justify-center rounded-full shrink-0"
                  style={{ backgroundColor: `${G_GREEN}22`, color: G_GREEN }}
                >
                  <DynamicIcon name="Star" className="h-3.5 w-3.5" />
                </div>
                <div className="min-w-0">
                  <p className="text-sm font-bold font-mono" style={{ color: G_GREEN }}>
                    +{data.points.today}
                  </p>
                  <p className="text-[9px] text-muted-foreground">نقاط اليوم</p>
                </div>
              </div>
              <div
                className="flex items-center gap-1.5 rounded-2xl p-1.5"
                style={{ backgroundColor: `${G_ORANGE}18` }}
              >
                <motion.div
                  animate={{ scale: [1, 1.15, 1] }}
                  transition={{ duration: 1.4, repeat: Infinity, ease: "easeInOut" }}
                  className="flex h-6 w-6 items-center justify-center rounded-full shrink-0"
                  style={{ backgroundColor: `${G_ORANGE}22`, color: G_ORANGE }}
                >
                  <DynamicIcon name="Flame" className="h-3.5 w-3.5" />
                </motion.div>
                <div className="min-w-0">
                  <p className="text-sm font-bold font-mono" style={{ color: G_ORANGE }}>
                    {data.streak}
                  </p>
                  <p className="text-[9px] text-muted-foreground">أيام متتالية 🔥</p>
                </div>
              </div>
            </div>
          </div>
        </Card>
      </motion.div>

      {/* Motivational message */}
      <Card className="p-2" style={{ backgroundColor: "var(--surface-container)" }}>
        <div className="flex items-center gap-1.5">
          <div
            className="flex h-6 w-6 items-center justify-center rounded-lg shrink-0"
            style={{ backgroundColor: `${G_PURPLE}22`, color: G_PURPLE }}
          >
            <DynamicIcon name="Sparkles" className="h-3.5 w-3.5" />
          </div>
          <AnimatePresence mode="wait">
            <motion.p
              key={motivationIdx}
              initial={{ opacity: 0, x: 6 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -6 }}
              transition={{ type: "spring", stiffness: 300, damping: 20 }}
              className="text-xs font-medium text-foreground flex-1"
            >
              {currentMessage}
            </motion.p>
          </AnimatePresence>
        </div>
      </Card>

      {/* Weekly challenge */}
      <Card className="p-2" style={{ backgroundColor: "var(--surface-container)" }}>
        <div className="flex items-center gap-1.5 mb-1.5">
          <div
            className="flex h-6 w-6 items-center justify-center rounded-lg shrink-0"
            style={{ backgroundColor: `${G_BLUE}22`, color: G_BLUE }}
          >
            <DynamicIcon name="Target" className="h-3.5 w-3.5" />
          </div>
          <div className="flex-1">
            <p className="text-xs font-bold text-foreground">تحدي الأسبوع</p>
            {challenge ? (
              <p className="text-[10px] text-muted-foreground truncate">
                {challenge.title}
                {challenge.description ? ` · ${challenge.description}` : ""}
              </p>
            ) : (
              <p className="text-[10px] text-muted-foreground">لا يوجد تحدٍّ حالياً</p>
            )}
          </div>
        </div>
        {challenge ? (
          <>
            <div className="flex items-center justify-between text-[10px] text-muted-foreground mb-1">
              <span>التقدم</span>
              <span className="font-mono">
                {challenge.progress}/{challenge.target}
              </span>
            </div>
            <div className="h-2 rounded-full bg-white/5 overflow-hidden">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${challengeProgress}%` }}
                transition={{ type: "spring", stiffness: 300, damping: 20, delay: 0.3 }}
                className="h-full rounded-full"
                style={{
                  background: `linear-gradient(90deg, ${G_BLUE}, ${G_TEAL})`,
                }}
              />
            </div>
            {challengeProgress >= 100 && (
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ type: "spring", stiffness: 300, damping: 20 }}
                className="mt-1.5 flex items-center gap-1 text-[10px] font-bold"
                style={{ color: G_GREEN }}
              >
                <DynamicIcon name="Trophy" className="h-3 w-3" />
                تم إنجاز التحدي! 🎉
              </motion.div>
            )}
          </>
        ) : (
          <p className="text-[10px] text-muted-foreground">
            تحدٍّ جديد يظهر تلقائياً كل أسبوع.
          </p>
        )}
      </Card>

      {/* Achievements grid */}
      <Card className="p-2" style={{ backgroundColor: "var(--surface-container)" }}>
        <div className="flex items-center justify-between mb-1.5">
          <div className="flex items-center gap-1.5">
            <div
              className="flex h-6 w-6 items-center justify-center rounded-lg shrink-0"
              style={{ backgroundColor: `${G_TEAL}22`, color: G_TEAL }}
            >
              <DynamicIcon name="Award" className="h-3.5 w-3.5" />
            </div>
            <h3 className="text-xs font-bold text-foreground">الإنجازات والشارات</h3>
          </div>
          <span
            className="text-[10px] px-1.5 py-0.5 rounded-full font-mono"
            style={{ backgroundColor: `${G_TEAL}22`, color: G_TEAL }}
          >
            {data.achievements.unlocked}/{data.achievements.total}
          </span>
        </div>

        {achievements.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-4 text-center">
            <div
              className="flex h-10 w-10 items-center justify-center rounded-full mb-1.5"
              style={{ backgroundColor: `${G_GRAY}22`, color: G_GRAY }}
            >
              <DynamicIcon name="Award" className="h-5 w-5" />
            </div>
            <p className="text-xs font-medium text-foreground">لا شارات بعد</p>
            <p className="text-[10px] text-muted-foreground mt-0.5">
              أنجز مهاماً لفتح شاراتك الأولى
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-3 sm:grid-cols-4 gap-1.5 max-h-96 overflow-y-auto custom-scroll p-0.5">
            {achievements.map((a, i) => {
              const color = BADGE_COLORS[i % BADGE_COLORS.length];
              return (
                <motion.div
                  key={a.type}
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{
                    delay: i * 0.03,
                    type: "spring",
                    stiffness: 300,
                    damping: 20,
                  }}
                  whileHover={{ scale: 1.05 }}
                  className={cn(
                    "flex flex-col items-center text-center p-1.5 rounded-2xl border transition-all cursor-default",
                    a.unlocked ? "border-transparent" : "border-border/30 opacity-50"
                  )}
                  style={{
                    backgroundColor: a.unlocked ? `${color}15` : "var(--surface-container-high)",
                  }}
                  title={a.description}
                >
                  <div
                    className="flex h-9 w-9 items-center justify-center rounded-full mb-1 relative"
                    style={{
                      backgroundColor: a.unlocked ? `${color}22` : `${G_GRAY}22`,
                      color: a.unlocked ? color : G_GRAY,
                    }}
                  >
                    <DynamicIcon name={a.unlocked ? a.icon : "Lock"} className="h-4 w-4" />
                    {a.unlocked && (
                      <motion.span
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        transition={{ delay: i * 0.03 + 0.2, type: "spring", stiffness: 400 }}
                        className="absolute -top-0.5 -right-0.5 h-3 w-3 rounded-full flex items-center justify-center"
                        style={{ backgroundColor: G_GREEN }}
                      >
                        <DynamicIcon name="Check" className="h-2 w-2 text-white" />
                      </motion.span>
                    )}
                  </div>
                  <p
                    className="text-[9px] font-bold leading-tight truncate w-full"
                    style={{ color: a.unlocked ? color : G_GRAY }}
                  >
                    {a.title}
                  </p>
                  <p className="text-[8px] text-muted-foreground leading-tight line-clamp-2">
                    {a.description}
                  </p>
                </motion.div>
              );
            })}
          </div>
        )}
      </Card>

      {/* Streak counter */}
      <Card className="p-2" style={{ backgroundColor: "var(--surface-container)" }}>
        <div className="flex items-center gap-1.5">
          <motion.div
            animate={{ scale: [1, 1.1, 1] }}
            transition={{ duration: 1.8, repeat: Infinity, ease: "easeInOut" }}
            className="flex h-8 w-8 items-center justify-center rounded-full shrink-0"
            style={{
              background: `linear-gradient(135deg, ${G_ORANGE}, ${G_RED})`,
            }}
          >
            <DynamicIcon name="Flame" className="h-4 w-4 text-white" />
          </motion.div>
          <div className="flex-1">
            <p className="text-xs font-bold text-foreground">
              سلسلة {data.streak} يوم متتالي
            </p>
            <p className="text-[10px] text-muted-foreground">
              {data.streak >= 30
                ? "إنجاز استثنائي! 🔥"
                : data.streak >= 7
                ? "أسبوع كامل من النشاط!"
                : data.streak > 0
                ? "استمر! لا تكسر السلسلة"
                : "ابدأ سلسلتك اليوم بإنجاز مهمة"}
            </p>
          </div>
          {/* Streak pips (last 7 days indicator) */}
          <div className="flex gap-0.5">
            {Array.from({ length: 7 }).map((_, i) => (
              <motion.div
                key={i}
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: i * 0.05, type: "spring", stiffness: 300 }}
                className="h-1.5 w-1.5 rounded-full"
                style={{
                  backgroundColor: i < Math.min(7, data.streak) ? G_ORANGE : `${G_GRAY}33`,
                }}
              />
            ))}
          </div>
        </div>
      </Card>
    </div>
  );
}

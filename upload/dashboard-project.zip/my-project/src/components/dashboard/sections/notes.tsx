"use client";

import * as React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger } from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { DynamicIcon } from "../icon";
import { ReadingMode } from "../reading-mode";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { format } from "date-fns";
import { ar } from "date-fns/locale";
import { formatSyrianDate, SYRIAN_MONTHS } from "@/lib/syrian-date";

interface Note {
  id: string;
  title: string;
  content: string;
  color: string;
  pinned: boolean;
  createdAt: string;
  updatedAt: string;
}

export function NotesSection() {
  const [notes, setNotes] = React.useState<Note[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [dialogOpen, setDialogOpen] = React.useState(false);
  const [editingNote, setEditingNote] = React.useState<Note | null>(null);
  const [search, setSearch] = React.useState("");
  const [readingNote, setReadingNote] = React.useState<Note | null>(null);
  const [readingOpen, setReadingOpen] = React.useState(false);
  const { toast } = useToast();

  const fetchNotes = React.useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/notes");
      const json = await res.json();
      if (json.success) setNotes(json.data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, []);

  React.useEffect(() => {
    fetchNotes();
  }, [fetchNotes]);

  const handleDelete = async (id: string) => {
    await fetch(`/api/notes?id=${id}`, { method: "DELETE" });
    toast({ title: "تم حذف الملاحظة" });
    fetchNotes();
  };

  const handleTogglePin = async (note: Note) => {
    await fetch("/api/notes", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: note.id, pinned: !note.pinned }),
    });
    fetchNotes();
  };

  const filtered = notes.filter(
    (n) => !search || n.title.includes(search) || n.content.includes(search)
  );

  return (
    <div className="space-y-2">
      <Card className="glass p-2.5">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="بحث في الملاحظات..."
            className="bg-background/50 sm:max-w-xs"
          />
          <div className="flex-1" />
          <NoteDialog
            open={dialogOpen}
            onOpenChange={setDialogOpen}
            editingNote={editingNote}
            onSaved={() => {
              setDialogOpen(false);
              setEditingNote(null);
              fetchNotes();
            }}
          >
            <Button className="bg-emerald-glow hover:bg-emerald-glow/90 text-background">
              <DynamicIcon name="Plus" className="h-4 w-4" />
              ملاحظة جديدة
            </Button>
          </NoteDialog>
        </div>
      </Card>

      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
          {Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-12 rounded-lg" />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <Card className="glass p-12">
          <div className="flex flex-col items-center justify-center text-center">
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-muted/30 mb-1.5">
              <DynamicIcon name="StickyNote" className="h-6 w-6 text-muted-foreground" />
            </div>
            <p className="text-sm font-medium text-foreground">لا ملاحظات</p>
            <p className="text-xs text-muted-foreground mt-1">ابدأ بكتابة أول ملاحظة</p>
          </div>
        </Card>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
          <AnimatePresence>
            {filtered.map((note, i) => (
              <motion.div
                key={note.id}
                layout
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ delay: i * 0.03 }}
              >
                <Card className={cn(
                  "glass p-2.5 hover:border-emerald-glow/30 transition-all group relative",
                  note.pinned && "ring-1 ring-amber-glow/30"
                )}>
                  {note.pinned && (
                    <div className="absolute top-2 left-2">
                      <DynamicIcon name="Pin" className="h-3.5 w-3.5 text-amber-glow fill-amber-glow" />
                    </div>
                  )}
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <h3 className="text-sm font-bold text-foreground flex-1 pr-6">{note.title}</h3>
                  </div>
                  <p className="text-xs text-muted-foreground whitespace-pre-wrap line-clamp-2 mb-1.5">
                    {note.content}
                  </p>
                  <p className="text-[10px] text-muted-foreground/70 mb-2">
                    {formatSyrianDate(new Date(note.updatedAt), "d MMMM yyyy، HH:mm")}
                  </p>
                  <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <Button
                      size="sm"
                      variant="ghost"
                      className="h-7 px-2"
                      onClick={() => { setReadingNote(note); setReadingOpen(true); }}
                      title="وضع القراءة"
                    >
                      <DynamicIcon name="Book" className="h-3 w-3" />
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      className="h-7 px-2"
                      onClick={() => handleTogglePin(note)}
                    >
                      <DynamicIcon
                        name="Pin"
                        className={cn("h-3 w-3", note.pinned ? "text-amber-glow fill-amber-glow" : "text-muted-foreground")}
                      />
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      className="h-7 px-2"
                      onClick={() => { setEditingNote(note); setDialogOpen(true); }}
                    >
                      <DynamicIcon name="Pencil" className="h-3 w-3" />
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      className="h-7 px-2 hover:text-rose-400"
                      onClick={() => handleDelete(note.id)}
                    >
                      <DynamicIcon name="Trash2" className="h-3 w-3" />
                    </Button>
                  </div>
                </Card>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      )}

      {/* Reading Mode */}
      <ReadingMode
        note={readingNote}
        open={readingOpen}
        onClose={() => setReadingOpen(false)}
        notes={filtered}
        onNavigate={(n) => setReadingNote(n)}
      />
    </div>
  );
}

function NoteDialog({
  open, onOpenChange, editingNote, onSaved, children,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  editingNote: Note | null;
  onSaved: () => void;
  children: React.ReactNode;
}) {
  const [title, setTitle] = React.useState("");
  const [content, setContent] = React.useState("");
  const [pinned, setPinned] = React.useState(false);
  const { toast } = useToast();

  React.useEffect(() => {
    if (editingNote) {
      setTitle(editingNote.title);
      setContent(editingNote.content);
      setPinned(editingNote.pinned);
    } else {
      setTitle(""); setContent(""); setPinned(false);
    }
  }, [editingNote, open]);

  const handleSave = async () => {
    if (!title || !content) {
      toast({ title: "العنوان والمحتوى مطلوبان", variant: "destructive" });
      return;
    }
    const payload = { title, content, pinned };
    try {
      if (editingNote) {
        await fetch("/api/notes", {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ id: editingNote.id, ...payload }),
        });
        toast({ title: "تم التحديث" });
      } else {
        await fetch("/api/notes", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
        toast({ title: "تمت الإضافة" });
      }
      onSaved();
    } catch {
      toast({ title: "فشل الحفظ", variant: "destructive" });
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogTrigger asChild>{children}</DialogTrigger>
      <DialogContent className="glass-strong max-w-md">
        <DialogHeader>
          <DialogTitle>{editingNote ? "تعديل ملاحظة" : "ملاحظة جديدة"}</DialogTitle>
        </DialogHeader>
        <div className="space-y-1.5">
          <div>
            <Label htmlFor="n-title">العنوان</Label>
            <Input id="n-title" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="عنوان الملاحظة" />
          </div>
          <div>
            <Label htmlFor="n-content">المحتوى</Label>
            <Textarea id="n-content" value={content} onChange={(e) => setContent(e.target.value)} rows={6} placeholder="اكتب ملاحظاتك هنا..." />
          </div>
          <label className="flex items-center gap-2 text-sm cursor-pointer">
            <input
              type="checkbox"
              checked={pinned}
              onChange={(e) => setPinned(e.target.checked)}
              className="h-4 w-4 rounded accent-emerald-500"
            />
            تثبيت الملاحظة في الأعلى
          </label>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>إلغاء</Button>
          <Button onClick={handleSave} className="bg-emerald-glow hover:bg-emerald-glow/90 text-background">
            {editingNote ? "حفظ" : "إضافة"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

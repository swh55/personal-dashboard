"use client";

import * as React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Skeleton } from "@/components/ui/skeleton";
import { DynamicIcon } from "../icon";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { formatDistanceToNow } from "date-fns";
import { ar } from "date-fns/locale";

interface Contact {
  id: string;
  name: string;
  phone: string;
  whatsapp?: string | null;
  relation: string;
  category?: string | null;
  favorite: boolean;
}

interface CallLog {
  id: string;
  name: string;
  phone: string;
  type: string;
  direction: string;
  createdAt: string;
}

const dialPad = [
  ["1", ""], ["2", "ABC"], ["3", "DEF"],
  ["4", "GHI"], ["5", "JKL"], ["6", "MNO"],
  ["7", "PQRS"], ["8", "TUV"], ["9", "WXYZ"],
  ["*", ""], ["0", "+"], ["#", ""],
];

export function CallPadSection() {
  const [number, setNumber] = React.useState("");
  const [contacts, setContacts] = React.useState<Contact[]>([]);
  const [logs, setLogs] = React.useState<CallLog[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [tab, setTab] = React.useState<"dial" | "favorites" | "recent">("dial");
  const [search, setSearch] = React.useState("");
  const { toast } = useToast();

  const fetchData = React.useCallback(async () => {
    setLoading(true);
    try {
      const [contactsRes, logsRes] = await Promise.all([
        fetch("/api/contacts"),
        fetch("/api/calllogs"),
      ]);
      const contactsJson = await contactsRes.json();
      const logsJson = await logsRes.json();
      if (contactsJson.success) setContacts(contactsJson.data);
      if (logsJson.success) setLogs(logsJson.data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, []);

  React.useEffect(() => {
    fetchData();
  }, [fetchData]);

  const handleDial = (digit: string) => {
    setNumber((prev) => prev + digit);
  };

  const handleBackspace = () => {
    setNumber((prev) => prev.slice(0, -1));
  };

  const logCall = async (name: string, phone: string, type: string) => {
    try {
      await fetch("/api/calllogs", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, phone, type, direction: "outgoing" }),
      });
      fetchData();
    } catch (e) {
      console.error(e);
    }
  };

  const handleCall = (phone: string, name?: string) => {
    if (!phone || phone === "—") {
      toast({ title: "لا يوجد رقم هاتف", variant: "destructive" });
      return;
    }
    const cleanPhone = phone.replace(/[^0-9+]/g, "");
    window.location.href = `tel:${cleanPhone}`;
    logCall(name || "غير معروف", phone, "call");
    toast({ title: `جاري الاتصال بـ ${name || phone}` });
  };

  const handleSMS = (phone: string, name?: string) => {
    if (!phone || phone === "—") {
      toast({ title: "لا يوجد رقم هاتف", variant: "destructive" });
      return;
    }
    const cleanPhone = phone.replace(/[^0-9+]/g, "");
    window.location.href = `sms:${cleanPhone}`;
    logCall(name || "غير معروف", phone, "sms");
  };

  const handleWhatsApp = (phone: string, name?: string) => {
    if (!phone || phone === "—") {
      toast({ title: "لا يوجد رقم هاتف", variant: "destructive" });
      return;
    }
    let cleanPhone = phone.replace(/[^0-9]/g, "");
    // إضافة رمز سوريا إذا لم يبدأ به
    if (cleanPhone.startsWith("0")) {
      cleanPhone = "963" + cleanPhone.slice(1);
    } else if (!cleanPhone.startsWith("963") && !cleanPhone.startsWith("00")) {
      cleanPhone = "963" + cleanPhone;
    }
    window.open(`https://wa.me/${cleanPhone}`, "_blank");
    logCall(name || "غير معروف", phone, "whatsapp");
  };

  const matchedContacts = number
    ? contacts.filter(
        (c) => c.phone.replace(/\s/g, "").includes(number) || c.name.includes(number)
      )
    : [];

  const favoriteContacts = contacts.filter((c) => c.favorite);
  const filteredContacts = search
    ? contacts.filter(
        (c) => c.name.includes(search) || c.phone.includes(search)
      )
    : contacts;

  return (
    <div className="space-y-2">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-2">
        {/* Dial Pad */}
        <Card className="glass p-2 lg:col-span-1">
          <div className="flex items-center gap-2 mb-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-emerald-glow/15 text-emerald-glow">
              <DynamicIcon name="Phone" className="h-4 w-4" />
            </div>
            <h3 className="text-sm font-bold text-foreground">لوحة الاتصال</h3>
          </div>

          {/* Number display */}
          <div className="relative mb-2">
            <Input
              value={number}
              onChange={(e) => setNumber(e.target.value.replace(/[^0-9+*#]/g, ""))}
              placeholder="أدخل الرقم"
              className="text-center text-2xl font-mono font-bold h-14 bg-background/50 border-border/40"
              dir="ltr"
            />
            {number && (
              <button
                onClick={handleBackspace}
                className="absolute left-2 top-1/2 -translate-y-1/2 flex h-8 w-8 items-center justify-center rounded-lg hover:bg-accent/40 text-muted-foreground"
              >
                <DynamicIcon name="ChevronRight" className="h-4 w-4" />
              </button>
            )}
          </div>

          {/* Matched contacts */}
          <AnimatePresence>
            {matchedContacts.length > 0 && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                className="mb-1.5 space-y-1"
              >
                {matchedContacts.slice(0, 3).map((c) => (
                  <button
                    key={c.id}
                    onClick={() => setNumber(c.phone.replace(/\s/g, ""))}
                    className="w-full flex items-center gap-2 rounded-lg p-2 hover:bg-accent/30 text-right"
                  >
                    <div className="flex h-7 w-7 items-center justify-center rounded-full bg-emerald-glow/10 text-emerald-glow text-xs font-bold">
                      {c.name[0]}
                    </div>
                    <span className="text-xs font-medium text-foreground">{c.name}</span>
                    <span className="text-[10px] text-muted-foreground mr-auto" dir="ltr">{c.phone}</span>
                  </button>
                ))}
              </motion.div>
            )}
          </AnimatePresence>

          {/* Dial pad grid */}
          <div className="grid grid-cols-3 gap-2 mb-2">
            {dialPad.map(([digit, letters]) => (
              <motion.button
                key={digit}
                whileTap={{ scale: 0.92 }}
                onClick={() => handleDial(digit)}
                className="aspect-square rounded-xl bg-background/40 border border-border/30 hover:border-emerald-glow/40 hover:bg-emerald-glow/5 transition-all flex flex-col items-center justify-center"
              >
                <span className="text-2xl font-bold text-foreground">{digit}</span>
                {letters && (
                  <span className="text-[9px] text-muted-foreground tracking-wider">{letters}</span>
                )}
              </motion.button>
            ))}
          </div>

          {/* Action buttons */}
          <div className="grid grid-cols-3 gap-2">
            <Button
              onClick={() => number && handleWhatsApp(number)}
              disabled={!number}
              className="bg-green-600 hover:bg-green-700 text-white"
              size="lg"
            >
              <DynamicIcon name="MessageCircle" className="h-5 w-5" />
            </Button>
            <Button
              onClick={() => number && handleCall(number)}
              disabled={!number}
              className="bg-emerald-glow hover:bg-emerald-glow/90 text-background"
              size="lg"
            >
              <DynamicIcon name="Phone" className="h-5 w-5" />
            </Button>
            <Button
              onClick={() => number && handleSMS(number)}
              disabled={!number}
              className="bg-amber-glow hover:bg-amber-glow/90 text-background"
              size="lg"
            >
              <DynamicIcon name="MessageCircle" className="h-5 w-5" />
            </Button>
          </div>
        </Card>

        {/* Quick contacts / recent */}
        <Card className="glass p-2 lg:col-span-2">
          {/* Tabs */}
          <div className="flex items-center gap-1 mb-2 rounded-lg bg-muted/30 p-1">
            {[
              { id: "favorites", label: "المفضلة", icon: "Star" },
              { id: "recent", label: "الأخيرة", icon: "Clock" },
              { id: "all", label: "الكل", icon: "Users" },
            ].map((t) => (
              <button
                key={t.id}
                onClick={() => setTab(t.id as "dial" | "favorites" | "recent")}
                className={cn(
                  "flex-1 flex items-center justify-center gap-1.5 py-2 text-xs rounded-md transition-all",
                  tab === t.id
                    ? "bg-emerald-glow/15 text-emerald-glow"
                    : "text-muted-foreground hover:text-foreground"
                )}
              >
                <DynamicIcon name={t.icon} className="h-3.5 w-3.5" />
                {t.label}
              </button>
            ))}
          </div>

          {tab === "favorites" && (
            <div>
              <h3 className="text-sm font-bold text-foreground mb-1.5">جهات الاتصال المفضلة</h3>
              {loading ? (
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {Array.from({ length: 6 }).map((_, i) => (
                    <Skeleton key={i} className="h-10 rounded-lg" />
                  ))}
                </div>
              ) : favoriteContacts.length === 0 ? (
                <p className="text-sm text-muted-foreground text-center py-3">لا مفضلات</p>
              ) : (
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {favoriteContacts.map((contact, i) => (
                    <motion.div
                      key={contact.id}
                      initial={{ opacity: 0, scale: 0.95 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ delay: i * 0.03 }}
                      className="group rounded-xl border border-border/40 bg-background/40 p-2 hover:border-emerald-glow/30 transition-all"
                    >
                      <div className="flex items-center gap-2 mb-2">
                        <div className={cn(
                          "flex h-9 w-9 items-center justify-center rounded-full text-xs font-bold shrink-0",
                          contact.relation === "family" ? "bg-rose-500/15 text-rose-400" : "bg-emerald-glow/15 text-emerald-glow"
                        )}>
                          {contact.name[0]}
                        </div>
                        <div className="min-w-0 flex-1">
                          <p className="text-xs font-bold text-foreground truncate">{contact.name}</p>
                          <p className="text-[10px] text-muted-foreground truncate">
                            {contact.relation === "family" ? "عائلة" : contact.category === "work-friends" ? "صديق عمل" : "اتصال"}
                          </p>
                        </div>
                      </div>
                      <div className="flex gap-1">
                        <Button
                          size="sm"
                          variant="outline"
                          className="flex-1 h-8 bg-emerald-glow/5 border-emerald-glow/20 hover:bg-emerald-glow/15 text-emerald-glow"
                          onClick={() => handleCall(contact.phone, contact.name)}
                        >
                          <DynamicIcon name="Phone" className="h-3.5 w-3.5" />
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          className="flex-1 h-8 bg-green-600/5 border-green-600/20 hover:bg-green-600/15 text-green-500"
                          onClick={() => handleWhatsApp(contact.whatsapp || contact.phone, contact.name)}
                        >
                          <DynamicIcon name="MessageCircle" className="h-3.5 w-3.5" />
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          className="flex-1 h-8 bg-amber-glow/5 border-amber-glow/20 hover:bg-amber-glow/15 text-amber-glow"
                          onClick={() => handleSMS(contact.phone, contact.name)}
                        >
                          <DynamicIcon name="MessageCircle" className="h-3.5 w-3.5" />
                        </Button>
                      </div>
                    </motion.div>
                  ))}
                </div>
              )}
            </div>
          )}

          {tab === "recent" && (
            <div>
              <h3 className="text-sm font-bold text-foreground mb-1.5">سجل المكالمات الأخيرة</h3>
              {loading ? (
                <div className="space-y-2">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Skeleton key={i} className="h-8 rounded-lg" />
                  ))}
                </div>
              ) : logs.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-3">
                  <div className="flex h-8 w-8 items-center justify-center rounded-full bg-muted/30 mb-2">
                    <DynamicIcon name="Clock" className="h-5 w-5 text-muted-foreground" />
                  </div>
                  <p className="text-sm text-muted-foreground">لا مكالمات حديثة</p>
                </div>
              ) : (
                <ScrollArea className="max-h-[420px] custom-scroll">
                  <div className="space-y-1.5">
                    {logs.map((log) => (
                      <div
                        key={log.id}
                        className="flex items-center gap-2 rounded-lg p-2.5 hover:bg-accent/30 border border-transparent hover:border-border/40 transition-all group"
                      >
                        <div className={cn(
                          "flex h-9 w-9 items-center justify-center rounded-full shrink-0",
                          log.type === "whatsapp" ? "bg-green-600/15 text-green-500"
                          : log.type === "sms" ? "bg-amber-glow/15 text-amber-glow"
                          : "bg-emerald-glow/15 text-emerald-glow"
                        )}>
                          <DynamicIcon
                            name={log.type === "whatsapp" || log.type === "sms" ? "MessageCircle" : "Phone"}
                            className="h-4 w-4"
                          />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium text-foreground truncate">{log.name}</p>
                          <p className="text-[10px] text-muted-foreground" dir="ltr">{log.phone}</p>
                        </div>
                        <p className="text-[10px] text-muted-foreground shrink-0">
                          {formatDistanceToNow(new Date(log.createdAt), { addSuffix: true, locale: ar })}
                        </p>
                        <Button
                          size="icon"
                          variant="ghost"
                          className="h-8 w-8 opacity-0 group-hover:opacity-100"
                          onClick={() => handleCall(log.phone, log.name)}
                        >
                          <DynamicIcon name="Phone" className="h-3.5 w-3.5 text-emerald-glow" />
                        </Button>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              )}
            </div>
          )}

          {tab === "all" && (
            <div>
              <div className="flex items-center gap-2 mb-1.5">
                <Input
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="بحث بالاسم أو الرقم..."
                  className="bg-background/50"
                />
              </div>
              <h3 className="text-sm font-bold text-foreground mb-1.5">جميع جهات الاتصال ({filteredContacts.length})</h3>
              {loading ? (
                <div className="space-y-2">
                  {Array.from({ length: 6 }).map((_, i) => (
                    <Skeleton key={i} className="h-8 rounded-lg" />
                  ))}
                </div>
              ) : (
                <ScrollArea className="max-h-[400px] custom-scroll">
                  <div className="space-y-1">
                    {filteredContacts.map((contact) => (
                      <div
                        key={contact.id}
                        className="flex items-center gap-2 rounded-lg p-2 hover:bg-accent/30 group transition-colors"
                      >
                        <div className={cn(
                          "flex h-8 w-8 items-center justify-center rounded-full text-xs font-bold shrink-0",
                          contact.relation === "family" ? "bg-rose-500/15 text-rose-400"
                          : "bg-emerald-glow/15 text-emerald-glow"
                        )}>
                          {contact.name[0]}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium text-foreground truncate">{contact.name}</p>
                          <p className="text-[10px] text-muted-foreground" dir="ltr">{contact.phone}</p>
                        </div>
                        <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                          <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => handleCall(contact.phone, contact.name)}>
                            <DynamicIcon name="Phone" className="h-3.5 w-3.5 text-emerald-glow" />
                          </Button>
                          <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => handleWhatsApp(contact.whatsapp || contact.phone, contact.name)}>
                            <DynamicIcon name="MessageCircle" className="h-3.5 w-3.5 text-green-500" />
                          </Button>
                          <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => handleSMS(contact.phone, contact.name)}>
                            <DynamicIcon name="MessageCircle" className="h-3.5 w-3.5 text-amber-glow" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              )}
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}

"use client";

import * as React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { DynamicIcon } from "../icon";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { format, startOfMonth, endOfMonth, eachDayOfInterval, startOfWeek, endOfWeek, addMonths, subMonths, isSameDay, isToday, addDays } from "date-fns";
import { ar } from "date-fns/locale";
import { SYRIAN_MONTHS, SYRIAN_WEEKDAYS_SHORT, formatSyrianDate, WEEK_STARTS_ON } from "@/lib/syrian-date";
import { isHoliday } from "@/lib/holidays";

interface CalEvent {
  id: string;
  title: string;
  description?: string | null;
  startDate: string;
  endDate?: string | null;
  allDay: boolean;
  type: string;
  color: string;
  location?: string | null;
}

const eventTypeColors: Record<string, { bg: string; text: string; dot: string; icon: string }> = {
  work: { bg: "bg-emerald-glow/15", text: "text-emerald-glow", dot: "bg-emerald-glow", icon: "Briefcase" },
  personal: { bg: "bg-amber-glow/15", text: "text-amber-glow", dot: "bg-amber-glow", icon: "User" },
  inspection: { bg: "bg-rose-500/15", text: "text-rose-400", dot: "bg-rose-400", icon: "Building2" },
  holiday: { bg: "bg-purple-500/15", text: "text-purple-400", dot: "bg-purple-400", icon: "Calendar" },
  birthday: { bg: "bg-pink-500/15", text: "text-pink-400", dot: "bg-pink-400", icon: "Cake" },
  prayer: { bg: "bg-teal-500/15", text: "text-teal-400", dot: "bg-teal-400", icon: "Sparkles" },
  custom: { bg: "bg-slate-500/15", text: "text-slate-400", dot: "bg-slate-400", icon: "Calendar" },
};

// أيام الأسبوع تبدأ بالسبت
const weekDays = ["السبت", "الأحد", "الإثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة"];
const weekDaysShort = ["سبت", "أحد", "إثن", "ثلا", "أرب", "خمي", "جمع"];

export function CalendarSection() {
  const [currentDate, setCurrentDate] = React.useState(new Date());
  const [selectedDate, setSelectedDate] = React.useState<Date | null>(null);
  const [events, setEvents] = React.useState<CalEvent[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [view, setView] = React.useState<"month" | "week">("month");
  const [dialogOpen, setDialogOpen] = React.useState(false);
  const [editingEvent, setEditingEvent] = React.useState<CalEvent | null>(null);
  const { toast } = useToast();

  const fetchEvents = React.useCallback(async () => {
    setLoading(true);
    const monthStart = startOfMonth(currentDate);
    const monthEnd = endOfMonth(currentDate);
    const from = addDays(startOfWeek(monthStart, { weekStartsOn: 6 }), -1).toISOString();
    const to = addDays(endOfWeek(monthEnd, { weekStartsOn: 6 }), 1).toISOString();
    try {
      const res = await fetch(`/api/events?from=${from}&to=${to}`);
      const json = await res.json();
      if (json.success) setEvents(json.data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, [currentDate]);

  React.useEffect(() => {
    fetchEvents();
  }, [fetchEvents]);

  const monthStart = startOfMonth(currentDate);
  const monthEnd = endOfMonth(currentDate);
  const calendarStart = startOfWeek(monthStart, { weekStartsOn: 6 });
  const calendarEnd = endOfWeek(monthEnd, { weekStartsOn: 6 });
  const days = eachDayOfInterval({ start: calendarStart, end: calendarEnd });

  const getEventsForDay = (day: Date) =>
    events.filter((e) => isSameDay(new Date(e.startDate), day));

  const selectedDayEvents = selectedDate ? getEventsForDay(selectedDate) : [];

  const handlePrev = () => setCurrentDate(subMonths(currentDate, 1));
  const handleNext = () => setCurrentDate(addMonths(currentDate, 1));
  const handleToday = () => setCurrentDate(new Date());

  const handleDelete = async (id: string) => {
    try {
      await fetch(`/api/events?id=${id}`, { method: "DELETE" });
      toast({ title: "تم حذف الحدث" });
      fetchEvents();
    } catch {
      toast({ title: "فشل الحذف", variant: "destructive" });
    }
  };

  return (
    <div className="space-y-2 max-w-[1600px] mx-auto">
      {/* Calendar header */}
      <Card className="glass p-2.5 lg:p-2">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-2">
          <div className="flex items-center gap-2">
            <div className="flex h-7 w-7 items-center justify-center rounded-xl bg-emerald-glow/15 text-emerald-glow">
              <DynamicIcon name="Calendar" className="h-5 w-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-foreground">
                {SYRIAN_MONTHS[currentDate.getMonth()]} {currentDate.getFullYear()}
              </h2>
              <p className="text-xs text-muted-foreground">التقويم الشخصي</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* View toggle */}
            <div className="flex rounded-lg bg-muted/30 p-0.5">
              <button
                onClick={() => setView("month")}
                className={cn(
                  "px-3 py-1.5 text-xs rounded-md transition-all",
                  view === "month" ? "bg-emerald-glow/15 text-emerald-glow" : "text-muted-foreground"
                )}
              >
                شهري
              </button>
              <button
                onClick={() => setView("week")}
                className={cn(
                  "px-3 py-1.5 text-xs rounded-md transition-all",
                  view === "week" ? "bg-emerald-glow/15 text-emerald-glow" : "text-muted-foreground"
                )}
              >
                أسبوعي
              </button>
            </div>

            <Button variant="outline" size="sm" onClick={handleToday}>
              اليوم
            </Button>
            <div className="flex gap-1">
              <Button variant="ghost" size="icon" onClick={handlePrev} className="h-9 w-9">
                <DynamicIcon name="ChevronRight" className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="icon" onClick={handleNext} className="h-9 w-9">
                <DynamicIcon name="ChevronLeft" className="h-4 w-4" />
              </Button>
            </div>

            <EventDialog
              open={dialogOpen}
              onOpenChange={setDialogOpen}
              editingEvent={editingEvent}
              defaultDate={selectedDate || new Date()}
              onSaved={() => {
                setDialogOpen(false);
                setEditingEvent(null);
                fetchEvents();
              }}
            >
              <Button size="sm" className="bg-emerald-glow hover:bg-emerald-glow/90 text-background">
                <DynamicIcon name="Plus" className="h-4 w-4" />
                حدث جديد
              </Button>
            </EventDialog>
          </div>
        </div>

        {/* Weekday headers */}
        <div className="grid grid-cols-7 gap-1 mb-2">
          {weekDaysShort.map((day, i) => (
            <div
              key={day}
              className={cn(
                "text-center text-[11px] font-semibold py-2",
                i === 5 ? "text-emerald-glow" : i === 6 ? "text-rose-400" : "text-muted-foreground"
              )}
            >
              {day}
            </div>
          ))}
        </div>

        {/* Calendar grid */}
        {loading ? (
          <div className="grid grid-cols-7 gap-1">
            {Array.from({ length: 35 }).map((_, i) => (
              <Skeleton key={i} className="aspect-square rounded-lg" />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-7 gap-1">
            {days.map((day, i) => {
              const dayEvents = getEventsForDay(day);
              const isCurrentMonth = day.getMonth() === currentDate.getMonth();
              const today = isToday(day);
              const holiday = isHoliday(day);
              const isSelected = selectedDate && isSameDay(day, selectedDate);

              return (
                <motion.button
                  key={i}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: i * 0.005 }}
                  onClick={() => setSelectedDate(day)}
                  onDoubleClick={() => {
                    setSelectedDate(day);
                    setEditingEvent(null);
                    setDialogOpen(true);
                  }}
                  className={cn(
                    "relative aspect-square rounded-lg border p-1.5 text-right transition-all hover:border-emerald-glow/40 hover:scale-[1.02]",
                    isSelected
                      ? "border-emerald-glow/50 bg-emerald-glow/5"
                      : "border-border/30 bg-background/30",
                    !isCurrentMonth && "opacity-30",
                    today && "ring-1 ring-emerald-glow/40"
                  )}
                >
                  <div className="flex items-center justify-between">
                    <span
                      className={cn(
                        "text-xs font-medium",
                        today
                          ? "flex h-5 w-5 items-center justify-center rounded-full bg-emerald-glow text-background"
                          : holiday.isHoliday
                          ? "text-rose-400"
                          : "text-foreground"
                      )}
                    >
                      {format(day, "d")}
                    </span>
                    {holiday.isHoliday && (
                      <span className="text-[8px] text-rose-400/70">●</span>
                    )}
                  </div>

                  {/* Events */}
                  <div className="mt-1 space-y-0.5 overflow-hidden">
                    {dayEvents.slice(0, 2).map((event) => {
                      const colors = eventTypeColors[event.type] || eventTypeColors.custom;
                      return (
                        <div
                          key={event.id}
                          className={cn("text-[9px] truncate px-1 py-0.5 rounded", colors.bg, colors.text)}
                        >
                          {format(new Date(event.startDate), "HH:mm")} {event.title}
                        </div>
                      );
                    })}
                    {dayEvents.length > 2 && (
                      <p className="text-[8px] text-muted-foreground px-1">
                        +{dayEvents.length - 2} أخرى
                      </p>
                    )}
                  </div>
                </motion.button>
              );
            })}
          </div>
        )}
      </Card>

      {/* Selected day details */}
      <AnimatePresence>
        {selectedDate && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
          >
            <Card className="glass p-2">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <div className="flex h-8 w-8 flex-col items-center justify-center rounded-xl bg-emerald-glow/15 text-emerald-glow">
                    <span className="text-lg font-bold leading-none">
                      {format(selectedDate, "d")}
                    </span>
                    <span className="text-[9px] leading-none mt-0.5">
                      {SYRIAN_MONTHS[selectedDate.getMonth()].slice(0, 4)}
                    </span>
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-foreground">
                      {formatSyrianDate(selectedDate, "EEEE d MMMM yyyy")}
                    </h3>
                    <p className="text-xs text-muted-foreground">
                      {selectedDayEvents.length} حدث • {isHoliday(selectedDate).isHoliday ? "عطلة" : "يوم عمل"}
                    </p>
                  </div>
                </div>
                <EventDialog
                  open={dialogOpen}
                  onOpenChange={setDialogOpen}
                  editingEvent={null}
                  defaultDate={selectedDate}
                  onSaved={() => {
                    setDialogOpen(false);
                    fetchEvents();
                  }}
                >
                  <Button size="sm" variant="outline">
                    <DynamicIcon name="Plus" className="h-4 w-4" />
                    إضافة حدث
                  </Button>
                </EventDialog>
              </div>

              {selectedDayEvents.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-3 text-center">
                  <div className="flex h-8 w-8 items-center justify-center rounded-full bg-muted/30 mb-2">
                    <DynamicIcon name="Calendar" className="h-5 w-5 text-muted-foreground" />
                  </div>
                  <p className="text-sm text-muted-foreground">لا أحداث في هذا اليوم</p>
                </div>
              ) : (
                <div className="space-y-2">
                  {selectedDayEvents
                    .sort((a, b) => new Date(a.startDate).getTime() - new Date(b.startDate).getTime())
                    .map((event) => {
                      const colors = eventTypeColors[event.type] || eventTypeColors.custom;
                      return (
                        <motion.div
                          key={event.id}
                          layout
                          className="group flex items-center gap-2 rounded-xl border border-border/40 bg-background/40 p-2 hover:border-emerald-glow/30"
                        >
                          <div className={cn("flex h-7 w-7 items-center justify-center rounded-lg shrink-0", colors.bg)}>
                            <DynamicIcon name={colors.icon} className={cn("h-5 w-5", colors.text)} />
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium text-foreground truncate">
                              {event.title}
                            </p>
                            <div className="flex items-center gap-2 mt-0.5">
                              <span className="text-[11px] text-muted-foreground flex items-center gap-1">
                                <DynamicIcon name="Clock" className="h-3 w-3" />
                                {format(new Date(event.startDate), "HH:mm")}
                                {event.endDate && ` - ${format(new Date(event.endDate), "HH:mm")}`}
                              </span>
                              {event.location && (
                                <span className="text-[11px] text-muted-foreground flex items-center gap-1">
                                  <DynamicIcon name="MapPin" className="h-3 w-3" />
                                  {event.location}
                                </span>
                              )}
                            </div>
                            {event.description && (
                              <p className="text-[11px] text-muted-foreground/70 mt-1 line-clamp-1">
                                {event.description}
                              </p>
                            )}
                          </div>
                          <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8"
                              onClick={() => {
                                setEditingEvent(event);
                                setDialogOpen(true);
                              }}
                            >
                              <DynamicIcon name="Pencil" className="h-3.5 w-3.5" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8 hover:text-rose-400"
                              onClick={() => handleDelete(event.id)}
                            >
                              <DynamicIcon name="Trash2" className="h-3.5 w-3.5" />
                            </Button>
                          </div>
                        </motion.div>
                      );
                    })}
                </div>
              )}
            </Card>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function EventDialog({
  open, onOpenChange, editingEvent, defaultDate, onSaved, children,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  editingEvent: CalEvent | null;
  defaultDate: Date;
  onSaved: () => void;
  children: React.ReactNode;
}) {
  const [title, setTitle] = React.useState("");
  const [description, setDescription] = React.useState("");
  const [date, setDate] = React.useState("");
  const [startTime, setStartTime] = React.useState("09:00");
  const [endTime, setEndTime] = React.useState("10:00");
  const [type, setType] = React.useState("custom");
  const [location, setLocation] = React.useState("");
  const [color, setColor] = React.useState("emerald");
  const { toast } = useToast();

  React.useEffect(() => {
    if (editingEvent) {
      setTitle(editingEvent.title);
      setDescription(editingEvent.description || "");
      const sd = new Date(editingEvent.startDate);
      setDate(sd.toISOString().split("T")[0]);
      setStartTime(format(sd, "HH:mm"));
      if (editingEvent.endDate) setEndTime(format(new Date(editingEvent.endDate), "HH:mm"));
      setType(editingEvent.type);
      setLocation(editingEvent.location || "");
      setColor(editingEvent.color);
    } else {
      setTitle("");
      setDescription("");
      setDate(defaultDate.toISOString().split("T")[0]);
      setStartTime("09:00");
      setEndTime("10:00");
      setType("custom");
      setLocation("");
      setColor("emerald");
    }
  }, [editingEvent, defaultDate, open]);

  const handleSave = async () => {
    if (!title || !date) {
      toast({ title: "العنوان والتاريخ مطلوبان", variant: "destructive" });
      return;
    }
    const startDate = new Date(`${date}T${startTime}:00`);
    const endDate = new Date(`${date}T${endTime}:00`);

    const payload = {
      title,
      description,
      startDate: startDate.toISOString(),
      endDate: endDate.toISOString(),
      type,
      color,
      location,
    };

    try {
      if (editingEvent) {
        await fetch(`/api/events`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ id: editingEvent.id, ...payload }),
        });
        toast({ title: "تم تحديث الحدث" });
      } else {
        await fetch(`/api/events`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
        toast({ title: "تم إضافة الحدث" });
      }
      onSaved();
    } catch {
      toast({ title: "فشل الحفظ", variant: "destructive" });
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogTrigger asChild>{children}</DialogTrigger>
      <DialogContent className="glass-strong max-w-md">
        <DialogHeader>
          <DialogTitle>{editingEvent ? "تعديل حدث" : "إضافة حدث جديد"}</DialogTitle>
        </DialogHeader>
        <div className="space-y-1.5">
          <div>
            <Label htmlFor="title">العنوان</Label>
            <Input id="title" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="عنوان الحدث" />
          </div>
          <div className="grid grid-cols-2 gap-2">
            <div>
              <Label htmlFor="date">التاريخ</Label>
              <Input id="date" type="date" value={date} onChange={(e) => setDate(e.target.value)} />
            </div>
            <div>
              <Label htmlFor="type">النوع</Label>
              <Select value={type} onValueChange={setType}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="work">عمل</SelectItem>
                  <SelectItem value="personal">شخصي</SelectItem>
                  <SelectItem value="inspection">كشف حسي</SelectItem>
                  <SelectItem value="holiday">عطلة</SelectItem>
                  <SelectItem value="birthday">عيد ميلاد</SelectItem>
                  <SelectItem value="prayer">صلاة</SelectItem>
                  <SelectItem value="custom">مخصص</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <div>
              <Label htmlFor="startTime">من</Label>
              <Input id="startTime" type="time" value={startTime} onChange={(e) => setStartTime(e.target.value)} />
            </div>
            <div>
              <Label htmlFor="endTime">إلى</Label>
              <Input id="endTime" type="time" value={endTime} onChange={(e) => setEndTime(e.target.value)} />
            </div>
          </div>
          <div>
            <Label htmlFor="location">المكان</Label>
            <Input id="location" value={location} onChange={(e) => setLocation(e.target.value)} placeholder="الموقع (اختياري)" />
          </div>
          <div>
            <Label htmlFor="description">الوصف</Label>
            <Textarea id="description" value={description} onChange={(e) => setDescription(e.target.value)} placeholder="ملاحظات إضافية" rows={2} />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>إلغاء</Button>
          <Button onClick={handleSave} className="bg-emerald-glow hover:bg-emerald-glow/90 text-background">
            {editingEvent ? "حفظ التغييرات" : "إضافة"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

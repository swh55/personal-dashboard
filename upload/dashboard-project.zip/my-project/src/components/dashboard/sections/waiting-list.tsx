"use client";

import * as React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Skeleton } from "@/components/ui/skeleton";
import { DynamicIcon } from "../icon";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

// Google brand colors
const G_BLUE = "#4285F4";
const G_RED = "#EA4335";
const G_YELLOW = "#FBBC04";
const G_GREEN = "#34A853";
const G_ORANGE = "#FF6D00";
const G_PURPLE = "#A142F4";
const G_TEAL = "#00897B";

interface WaitingItem {
  id: string;
  title: string;
  description: string | null;
  priority: number;
  ready: boolean;
  createdAt: string;
  updatedAt: string;
}

// priority 0..5 → color
function priorityColor(p: number): string {
  if (p >= 5) return G_RED;
  if (p >= 4) return G_ORANGE;
  if (p >= 3) return G_YELLOW;
  if (p >= 2) return G_BLUE;
  if (p >= 1) return G_TEAL;
  return "#9AA0A6";
}

function priorityLabel(p: number): string {
  if (p >= 5) return "حرجة";
  if (p >= 4) return "عالية جداً";
  if (p >= 3) return "عالية";
  if (p >= 2) return "متوسطة";
  if (p >= 1) return "منخفضة";
  return "بدون";
}

export function WaitingListSection() {
  const { toast } = useToast();
  const [items, setItems] = React.useState<WaitingItem[]>([]);
  const [loading, setLoading] = React.useState(true);

  // New item form
  const [title, setTitle] = React.useState("");
  const [description, setDescription] = React.useState("");
  const [priority, setPriority] = React.useState<number>(2);
  const [creating, setCreating] = React.useState(false);
  const [movingId, setMovingId] = React.useState<string | null>(null);

  const fetchItems = React.useCallback(async () => {
    try {
      const res = await fetch("/api/waiting-list");
      const json = await res.json();
      if (json.success) setItems(json.data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, []);

  React.useEffect(() => {
    fetchItems();
  }, [fetchItems]);

  const sorted = React.useMemo(
    () => [...items].sort((a, b) => b.priority - a.priority),
    [items]
  );

  const handleAdd = async () => {
    if (!title.trim()) {
      toast({ title: "العنوان مطلوب", variant: "destructive" });
      return;
    }
    setCreating(true);
    try {
      const res = await fetch("/api/waiting-list", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title: title.trim(), description, priority }),
      });
      const json = await res.json();
      if (json.success) {
        toast({ title: "تمت الإضافة لقائمة الانتظار ✓" });
        setTitle(""); setDescription(""); setPriority(2);
        fetchItems();
      } else {
        toast({ title: json.error || "فشل الإضافة", variant: "destructive" });
      }
    } catch {
      toast({ title: "فشل الإضافة", variant: "destructive" });
    } finally {
      setCreating(false);
    }
  };

  const handleToggleReady = async (item: WaitingItem) => {
    try {
      await fetch("/api/waiting-list", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: item.id, ready: !item.ready }),
      });
      toast({ title: item.ready ? "تم التراجع" : "أصبح جاهزاً ✓" });
      fetchItems();
    } catch {
      toast({ title: "فشل التحديث", variant: "destructive" });
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await fetch(`/api/waiting-list?id=${id}`, { method: "DELETE" });
      toast({ title: "تم الحذف" });
      fetchItems();
    } catch {
      toast({ title: "فشل الحذف", variant: "destructive" });
    }
  };

  const handleMoveToTasks = async (item: WaitingItem) => {
    setMovingId(item.id);
    try {
      const res = await fetch("/api/tasks", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title: item.title,
          description: item.description || undefined,
          category: "home",
          priority: item.priority >= 4 ? "high" : item.priority >= 2 ? "medium" : "low",
          status: "todo",
        }),
      });
      const json = await res.json();
      if (json.success) {
        // remove from waiting list
        await fetch(`/api/waiting-list?id=${item.id}`, { method: "DELETE" });
        toast({ title: "تم النقل إلى المهام ✓" });
        fetchItems();
      } else {
        toast({ title: "فشل النقل", variant: "destructive" });
      }
    } catch {
      toast({ title: "فشل النقل", variant: "destructive" });
    } finally {
      setMovingId(null);
    }
  };

  const readyCount = items.filter((i) => i.ready).length;
  const pendingCount = items.length - readyCount;

  return (
    <div className="space-y-1.5">
      {/* Summary header */}
      <Card className="p-2" style={{ backgroundColor: "var(--surface-container)" }}>
        <div className="flex items-center gap-1.5">
          <div
            className="flex h-7 w-7 items-center justify-center rounded-lg"
            style={{ backgroundColor: `${G_PURPLE}22`, color: G_PURPLE }}
          >
            <DynamicIcon name="Clock" className="h-4 w-4" />
          </div>
          <div className="flex-1">
            <p className="text-xs font-bold text-foreground">قائمة الانتظار</p>
            <p className="text-[10px] text-muted-foreground">أفكار ومهام تنتظر الظروف المناسبة</p>
          </div>
          <div className="flex gap-1">
            <span
              className="text-[10px] font-mono px-1.5 py-0.5 rounded-full"
              style={{ backgroundColor: `${G_YELLOW}22`, color: G_YELLOW }}
            >
              {pendingCount} منتظرة
            </span>
            <span
              className="text-[10px] font-mono px-1.5 py-0.5 rounded-full"
              style={{ backgroundColor: `${G_GREEN}22`, color: G_GREEN }}
            >
              {readyCount} جاهزة
            </span>
          </div>
        </div>
      </Card>

      {/* New item form */}
      <Card className="p-2" style={{ backgroundColor: "var(--surface-container)" }}>
        <div className="flex items-center gap-1.5 mb-1.5">
          <div
            className="flex h-6 w-6 items-center justify-center rounded-lg"
            style={{ backgroundColor: `${G_GREEN}22`, color: G_GREEN }}
          >
            <DynamicIcon name="Plus" className="h-3.5 w-3.5" />
          </div>
          <h3 className="text-xs font-bold text-foreground">إضافة عنصر جديد</h3>
        </div>

        <div className="space-y-1.5">
          <div>
            <Label className="text-[10px]">العنوان</Label>
            <Input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="ما الذي تنتظره؟"
              className="mt-0.5"
            />
          </div>
          <div>
            <Label className="text-[10px]">الوصف (اختياري)</Label>
            <Textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={2}
              placeholder="تفاصيل إضافية..."
              className="mt-0.5"
            />
          </div>
          <div>
            <Label className="text-[10px]">الأولوية: {priority} ({priorityLabel(priority)})</Label>
            <div className="flex items-center gap-1 mt-1">
              {[0, 1, 2, 3, 4, 5].map((p) => (
                <button
                  key={p}
                  onClick={() => setPriority(p)}
                  className={cn(
                    "flex-1 h-7 rounded-md text-[10px] font-bold transition-all",
                    priority === p ? "scale-105" : "opacity-60 hover:opacity-100"
                  )}
                  style={{
                    backgroundColor: priority === p ? priorityColor(p) : `${priorityColor(p)}22`,
                    color: priority === p ? "#fff" : priorityColor(p),
                  }}
                >
                  {p}
                </button>
              ))}
            </div>
          </div>
          <Button
            size="sm"
            className="w-full"
            onClick={handleAdd}
            disabled={creating}
            style={{ backgroundColor: G_GREEN, color: "#fff" }}
          >
            {creating ? (
              <DynamicIcon name="Loader2" className="h-3.5 w-3.5 animate-spin" />
            ) : (
              <DynamicIcon name="Plus" className="h-3.5 w-3.5" />
            )}
            إضافة للقائمة
          </Button>
        </div>
      </Card>

      {/* Items list */}
      <Card className="p-2" style={{ backgroundColor: "var(--surface-container)" }}>
        <div className="flex items-center justify-between mb-1.5">
          <div className="flex items-center gap-1.5">
            <div
              className="flex h-6 w-6 items-center justify-center rounded-lg"
              style={{ backgroundColor: `${G_BLUE}22`, color: G_BLUE }}
            >
              <DynamicIcon name="List" className="h-3.5 w-3.5" />
            </div>
            <h3 className="text-xs font-bold text-foreground">العناصر (مرتبة حسب الأولوية)</h3>
          </div>
          <span className="text-[10px] text-muted-foreground">{items.length} عنصر</span>
        </div>

        {loading ? (
          <div className="space-y-1.5">
            {Array.from({ length: 3 }).map((_, i) => (
              <Skeleton key={i} className="h-14 rounded-lg" />
            ))}
          </div>
        ) : sorted.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-4 text-center">
            <div
              className="flex h-10 w-10 items-center justify-center rounded-full mb-1.5"
              style={{ backgroundColor: `${G_PURPLE}22`, color: G_PURPLE }}
            >
              <DynamicIcon name="Clock" className="h-5 w-5" />
            </div>
            <p className="text-xs font-medium text-foreground">قائمة الانتظار فارغة</p>
            <p className="text-[10px] text-muted-foreground mt-0.5">أضف أفكارك أو مهامك المؤجلة</p>
          </div>
        ) : (
          <div className="space-y-1 max-h-96 overflow-y-auto custom-scroll">
            <AnimatePresence>
              {sorted.map((item, i) => {
                const color = priorityColor(item.priority);
                return (
                  <motion.div
                    key={item.id}
                    layout
                    initial={{ opacity: 0, y: 6 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, x: -10 }}
                    transition={{ delay: i * 0.03 }}
                    className="group rounded-lg p-1.5"
                    style={{
                      backgroundColor: item.ready
                        ? `${G_GREEN}10`
                        : "var(--surface-container-high)",
                      borderRight: `3px solid ${color}`,
                    }}
                  >
                    <div className="flex items-start gap-1.5">
                      {/* Priority badge */}
                      <div
                        className="flex h-7 w-7 shrink-0 items-center justify-center rounded-md font-bold text-[11px]"
                        style={{ backgroundColor: `${color}22`, color }}
                        title={priorityLabel(item.priority)}
                      >
                        {item.priority}
                      </div>

                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-1.5">
                          <p
                            className={cn(
                              "text-xs font-bold text-foreground truncate",
                              item.ready && "line-through opacity-70"
                            )}
                          >
                            {item.title}
                          </p>
                          <span
                            className="text-[9px] px-1 py-0.5 rounded-full shrink-0"
                            style={{ backgroundColor: `${color}22`, color }}
                          >
                            {priorityLabel(item.priority)}
                          </span>
                          {item.ready && (
                            <span
                              className="text-[9px] px-1 py-0.5 rounded-full shrink-0 flex items-center gap-0.5"
                              style={{ backgroundColor: `${G_GREEN}22`, color: G_GREEN }}
                            >
                              <DynamicIcon name="CheckCircle" className="h-2.5 w-2.5" />
                              جاهز
                            </span>
                          )}
                        </div>
                        {item.description && (
                          <p className="text-[10px] text-muted-foreground mt-0.5 line-clamp-2">
                            {item.description}
                          </p>
                        )}
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="flex items-center gap-1 mt-1">
                      <div className="flex items-center gap-1">
                        <Switch
                          checked={item.ready}
                          onCheckedChange={() => handleToggleReady(item)}
                          className="scale-75 origin-right"
                        />
                        <span className="text-[9px] text-muted-foreground">جاهز</span>
                      </div>
                      <div className="flex-1" />
                      {item.ready && (
                        <Button
                          size="sm"
                          className="h-6 px-2 text-[10px]"
                          disabled={movingId === item.id}
                          onClick={() => handleMoveToTasks(item)}
                          style={{ backgroundColor: G_BLUE, color: "#fff" }}
                        >
                          {movingId === item.id ? (
                            <DynamicIcon name="Loader2" className="h-2.5 w-2.5 animate-spin" />
                          ) : (
                            <DynamicIcon name="CheckSquare" className="h-2.5 w-2.5" />
                          )}
                          نقل للمهام
                        </Button>
                      )}
                      <Button
                        size="sm"
                        variant="ghost"
                        className="h-6 w-6 p-0 opacity-0 group-hover:opacity-100 hover:text-red-400"
                        onClick={() => handleDelete(item.id)}
                      >
                        <DynamicIcon name="Trash2" className="h-3 w-3" />
                      </Button>
                    </div>
                  </motion.div>
                );
              })}
            </AnimatePresence>
          </div>
        )}
      </Card>
    </div>
  );
}

"use client";

import * as React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";
import { DynamicIcon } from "../icon";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { formatDistanceToNow } from "date-fns";
import { ar } from "date-fns/locale";

// Google brand colors
const G_BLUE = "#4285F4";
const G_RED = "#EA4335";
const G_YELLOW = "#FBBC04";
const G_GREEN = "#34A853";
const G_ORANGE = "#FF6D00";
const G_PURPLE = "#A142F4";
const G_TEAL = "#00897B";

interface AutomationRule {
  id: string;
  name: string;
  trigger: string;
  triggerData: string | null;
  action: string;
  actionData: string | null;
  active: boolean;
  lastTriggered: string | null;
  createdAt: string;
}

// Trigger catalog
const TRIGGERS = [
  { id: "arrive_work", label: "الوصول للعمل", icon: "Briefcase", color: G_BLUE },
  { id: "leave_work", label: "مغادرة العمل", icon: "LogOut", color: G_ORANGE },
  { id: "prayer_time", label: "وقت الصلاة", icon: "BellRing", color: G_TEAL },
  { id: "time_based", label: "وقت محدد", icon: "Clock", color: G_PURPLE },
] as const;

// Action catalog
const ACTIONS = [
  { id: "send_message", label: "إرسال رسالة", icon: "Send", color: G_GREEN },
  { id: "create_task", label: "إنشاء مهمة", icon: "CheckSquare", color: G_YELLOW },
  { id: "reminder", label: "تذكير", icon: "Bell", color: G_RED },
  { id: "toggle_dnd", label: "تفعيل عدم الإزعاج", icon: "Moon", color: G_PURPLE },
] as const;

function triggerMeta(id: string) {
  return TRIGGERS.find((t) => t.id === id) || TRIGGERS[0];
}
function actionMeta(id: string) {
  return ACTIONS.find((a) => a.id === id) || ACTIONS[0];
}

export function AutomationSection() {
  const { toast } = useToast();
  const [rules, setRules] = React.useState<AutomationRule[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [togglingId, setTogglingId] = React.useState<string | null>(null);

  // New rule form state
  const [name, setName] = React.useState("");
  const [trigger, setTrigger] = React.useState<string>("arrive_work");
  const [action, setAction] = React.useState<string>("send_message");
  const [creating, setCreating] = React.useState(false);

  const fetchRules = React.useCallback(async () => {
    try {
      const res = await fetch("/api/automation");
      const json = await res.json();
      if (json.success) setRules(json.data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, []);

  React.useEffect(() => {
    fetchRules();
  }, [fetchRules]);

  const handleCreate = async () => {
    if (!name.trim()) {
      toast({ title: "أدخل اسم القاعدة", variant: "destructive" });
      return;
    }
    setCreating(true);
    try {
      const res = await fetch("/api/automation", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: name.trim(), trigger, action, active: true }),
      });
      const json = await res.json();
      if (json.success) {
        toast({ title: "تم إنشاء القاعدة ✓" });
        setName("");
        setTrigger("arrive_work");
        setAction("send_message");
        fetchRules();
      } else {
        toast({ title: json.error || "فشل الإنشاء", variant: "destructive" });
      }
    } catch {
      toast({ title: "فشل الإنشاء", variant: "destructive" });
    } finally {
      setCreating(false);
    }
  };

  const handleToggle = async (rule: AutomationRule) => {
    setTogglingId(rule.id);
    try {
      await fetch("/api/automation", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: rule.id, active: !rule.active }),
      });
      toast({ title: rule.active ? "تم تعطيل القاعدة" : "تم تفعيل القاعدة ✓" });
      fetchRules();
    } catch {
      toast({ title: "فشل التحديث", variant: "destructive" });
    } finally {
      setTogglingId(null);
    }
  };

  const handleDelete = async (id: string) => {
    await fetch(`/api/automation?id=${id}`, { method: "DELETE" });
    toast({ title: "تم حذف القاعدة" });
    fetchRules();
  };

  const activeCount = rules.filter((r) => r.active).length;

  return (
    <div className="space-y-1.5">
      {/* Header / summary */}
      <Card className="p-2" style={{ backgroundColor: "var(--surface-container)" }}>
        <div className="flex items-center gap-1.5">
          <div
            className="flex h-7 w-7 items-center justify-center rounded-lg"
            style={{ backgroundColor: `${G_BLUE}22`, color: G_BLUE }}
          >
            <DynamicIcon name="Zap" className="h-4 w-4" />
          </div>
          <div className="flex-1">
            <p className="text-xs font-bold text-foreground">قواعد الأتمتة (If → Then)</p>
            <p className="text-[10px] text-muted-foreground">أتمت مهامك بمحفّزات وإجراءات</p>
          </div>
          <div
            className="text-[10px] font-mono px-1.5 py-0.5 rounded-full"
            style={{ backgroundColor: `${G_GREEN}22`, color: G_GREEN }}
          >
            {activeCount} نشطة
          </div>
        </div>
      </Card>

      {/* New rule form */}
      <Card className="p-2" style={{ backgroundColor: "var(--surface-container)" }}>
        <div className="flex items-center gap-1.5 mb-1.5">
          <div
            className="flex h-6 w-6 items-center justify-center rounded-lg"
            style={{ backgroundColor: `${G_GREEN}22`, color: G_GREEN }}
          >
            <DynamicIcon name="Plus" className="h-3.5 w-3.5" />
          </div>
          <h3 className="text-xs font-bold text-foreground">إنشاء قاعدة جديدة</h3>
        </div>

        <div className="space-y-1.5">
          <div>
            <Label className="text-[10px]">اسم القاعدة</Label>
            <Input
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="مثال: عند الوصول للعمل، اذكرني بفحص البريد"
              className="mt-0.5"
            />
          </div>
          <div className="grid grid-cols-2 gap-1.5">
            <div>
              <Label className="text-[10px]">المحفّز (If)</Label>
              <Select value={trigger} onValueChange={setTrigger}>
                <SelectTrigger className="mt-0.5">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {TRIGGERS.map((t) => (
                    <SelectItem key={t.id} value={t.id}>
                      <div className="flex items-center gap-1.5">
                        <DynamicIcon name={t.icon} className="h-3.5 w-3.5" />
                        {t.label}
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-[10px]">الإجراء (Then)</Label>
              <Select value={action} onValueChange={setAction}>
                <SelectTrigger className="mt-0.5">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {ACTIONS.map((a) => (
                    <SelectItem key={a.id} value={a.id}>
                      <div className="flex items-center gap-1.5">
                        <DynamicIcon name={a.icon} className="h-3.5 w-3.5" />
                        {a.label}
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          {/* Visual preview */}
          <div className="flex items-center justify-center gap-1.5 py-1">
            <span
              className="flex items-center gap-1 px-2 py-1 rounded-lg text-[10px] font-medium"
              style={{ backgroundColor: `${triggerMeta(trigger).color}22`, color: triggerMeta(trigger).color }}
            >
              <DynamicIcon name={triggerMeta(trigger).icon} className="h-3 w-3" />
              {triggerMeta(trigger).label}
            </span>
            <motion.div
              animate={{ x: [0, 3, 0] }}
              transition={{ duration: 1, repeat: Infinity }}
              style={{ color: G_BLUE }}
            >
              <DynamicIcon name="ArrowLeft" className="h-3.5 w-3.5" />
            </motion.div>
            <span
              className="flex items-center gap-1 px-2 py-1 rounded-lg text-[10px] font-medium"
              style={{ backgroundColor: `${actionMeta(action).color}22`, color: actionMeta(action).color }}
            >
              <DynamicIcon name={actionMeta(action).icon} className="h-3 w-3" />
              {actionMeta(action).label}
            </span>
          </div>
          <Button
            size="sm"
            className="w-full"
            onClick={handleCreate}
            disabled={creating}
            style={{ backgroundColor: G_GREEN, color: "#fff" }}
          >
            {creating ? (
              <DynamicIcon name="Loader2" className="h-3.5 w-3.5 animate-spin" />
            ) : (
              <DynamicIcon name="Plus" className="h-3.5 w-3.5" />
            )}
            إنشاء القاعدة
          </Button>
        </div>
      </Card>

      {/* Rules list */}
      <Card className="p-2" style={{ backgroundColor: "var(--surface-container)" }}>
        <div className="flex items-center justify-between mb-1.5">
          <div className="flex items-center gap-1.5">
            <div
              className="flex h-6 w-6 items-center justify-center rounded-lg"
              style={{ backgroundColor: `${G_PURPLE}22`, color: G_PURPLE }}
            >
              <DynamicIcon name="List" className="h-3.5 w-3.5" />
            </div>
            <h3 className="text-xs font-bold text-foreground">القواعد الحالية</h3>
          </div>
          <span className="text-[10px] text-muted-foreground">{rules.length} قاعدة</span>
        </div>

        {loading ? (
          <div className="space-y-1.5">
            {Array.from({ length: 3 }).map((_, i) => (
              <Skeleton key={i} className="h-16 rounded-lg" />
            ))}
          </div>
        ) : rules.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-4 text-center">
            <div
              className="flex h-10 w-10 items-center justify-center rounded-full mb-1.5"
              style={{ backgroundColor: `${G_PURPLE}22`, color: G_PURPLE }}
            >
              <DynamicIcon name="Zap" className="h-5 w-5" />
            </div>
            <p className="text-xs font-medium text-foreground">لا توجد قواعد أتمتة</p>
            <p className="text-[10px] text-muted-foreground mt-0.5">ابدأ بإنشاء قاعدتك الأولى</p>
          </div>
        ) : (
          <div className="space-y-1 max-h-96 overflow-y-auto custom-scroll">
            <AnimatePresence>
              {rules.map((rule, i) => {
                const tMeta = triggerMeta(rule.trigger);
                const aMeta = actionMeta(rule.action);
                const isToggling = togglingId === rule.id;
                return (
                  <motion.div
                    key={rule.id}
                    layout
                    initial={{ opacity: 0, y: 6 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, x: -10 }}
                    transition={{ delay: i * 0.03 }}
                    className="group rounded-lg p-1.5 transition-all hover:bg-white/5"
                    style={{
                      backgroundColor: rule.active ? "var(--surface-container-high)" : "var(--surface-container)",
                      opacity: rule.active ? 1 : 0.65,
                    }}
                  >
                    {/* Top row: name + switch */}
                    <div className="flex items-center gap-1.5 mb-1">
                      <span
                        className={cn(
                          "flex h-2 w-2 rounded-full shrink-0",
                          rule.active && "animate-pulse"
                        )}
                        style={{ backgroundColor: rule.active ? G_GREEN : "var(--muted-foreground)" }}
                      />
                      <p className="text-xs font-medium text-foreground flex-1 truncate">{rule.name}</p>
                      <Switch
                        checked={rule.active}
                        onCheckedChange={() => handleToggle(rule)}
                        disabled={isToggling}
                      />
                      <Button
                        size="sm"
                        variant="ghost"
                        className="h-5 w-5 p-0 opacity-0 group-hover:opacity-100 hover:text-red-400"
                        onClick={() => handleDelete(rule.id)}
                      >
                        <DynamicIcon name="Trash2" className="h-3 w-3" />
                      </Button>
                    </div>

                    {/* Trigger → Action */}
                    <div className="flex items-center gap-1">
                      <span
                        className="flex items-center gap-0.5 px-1.5 py-0.5 rounded-md text-[10px] font-medium flex-1 min-w-0"
                        style={{ backgroundColor: `${tMeta.color}22`, color: tMeta.color }}
                      >
                        <DynamicIcon name={tMeta.icon} className="h-2.5 w-2.5 shrink-0" />
                        <span className="truncate">{tMeta.label}</span>
                      </span>
                      <DynamicIcon name="ArrowLeft" className="h-3 w-3 shrink-0" style={{ color: G_BLUE }} />
                      <span
                        className="flex items-center gap-0.5 px-1.5 py-0.5 rounded-md text-[10px] font-medium flex-1 min-w-0"
                        style={{ backgroundColor: `${aMeta.color}22`, color: aMeta.color }}
                      >
                        <DynamicIcon name={aMeta.icon} className="h-2.5 w-2.5 shrink-0" />
                        <span className="truncate">{aMeta.label}</span>
                      </span>
                    </div>

                    {/* Footer: last triggered */}
                    {rule.lastTriggered && (
                      <div className="flex items-center gap-0.5 mt-1 text-[9px] text-muted-foreground">
                        <DynamicIcon name="History" className="h-2 w-2" />
                        آخر تشغيل {formatDistanceToNow(new Date(rule.lastTriggered), { addSuffix: true, locale: ar })}
                      </div>
                    )}
                  </motion.div>
                );
              })}
            </AnimatePresence>
          </div>
        )}
      </Card>
    </div>
  );
}

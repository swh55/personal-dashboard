"use client";

import * as React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger } from "@/components/ui/dialog";
import { DynamicIcon } from "../icon";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { EXPENSE_CATEGORIES } from "@/lib/constants";

// Google brand colors
const G_BLUE = "#4285F4";
const G_RED = "#EA4335";
const G_YELLOW = "#FBBC04";
const G_GREEN = "#34A853";
const G_ORANGE = "#FF6D00";
const G_PURPLE = "#A142F4";
const G_TEAL = "#00897B";

interface Budget {
  id: string;
  category: string;
  limit: number;
  month: number;
  year: number;
  spent: number;
  remaining: number;
  percent: number;
  overBudget: boolean;
}

function formatAmount(n: number) {
  if (Math.abs(n) >= 1_000_000) return (n / 1_000_000).toFixed(1) + "M";
  if (Math.abs(n) >= 1000) return (n / 1000).toFixed(1) + "K";
  return Math.round(n).toLocaleString("en-US");
}

function categoryMeta(id: string) {
  const found = EXPENSE_CATEGORIES.find((c) => c.id === id);
  return found
    ? { label: found.label, icon: found.icon }
    : { label: id, icon: "Wallet" };
}

// Returns the status color depending on spent percentage
function statusColor(percent: number): { color: string; label: string; bg: string } {
  if (percent >= 90) return { color: G_RED, label: "تجاوز", bg: `${G_RED}22` };
  if (percent >= 70) return { color: G_ORANGE, label: "تحذير", bg: `${G_ORANGE}22` };
  return { color: G_GREEN, label: "ضمن الحد", bg: `${G_GREEN}22` };
}

export function BudgetSection() {
  const { toast } = useToast();
  const [budgets, setBudgets] = React.useState<Budget[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [dialogOpen, setDialogOpen] = React.useState(false);
  const [editingBudget, setEditingBudget] = React.useState<Budget | null>(null);
  const [defaultCategory, setDefaultCategory] = React.useState<string>("food");

  const fetchBudgets = React.useCallback(async () => {
    try {
      const res = await fetch("/api/budget");
      const json = await res.json();
      if (json.success) setBudgets(json.data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, []);

  React.useEffect(() => {
    fetchBudgets();
  }, [fetchBudgets]);

  const totalLimit = budgets.reduce((s, b) => s + b.limit, 0);
  const totalSpent = budgets.reduce((s, b) => s + b.spent, 0);
  const totalRemaining = totalLimit - totalSpent;
  const totalPercent = totalLimit > 0 ? Math.round((totalSpent / totalLimit) * 100) : 0;

  const handleDelete = async (id: string) => {
    await fetch(`/api/budget?id=${id}`, { method: "DELETE" });
    toast({ title: "تم حذف الميزانية" });
    fetchBudgets();
  };

  const categoriesWithBudget = new Set(budgets.map((b) => b.category));
  const availableCategories = EXPENSE_CATEGORIES.filter(
    (c) => !categoriesWithBudget.has(c.id)
  );

  const handleAddFor = (categoryId: string) => {
    setEditingBudget(null);
    setDefaultCategory(categoryId);
    setDialogOpen(true);
  };

  const handleEdit = (b: Budget) => {
    setEditingBudget(b);
    setDefaultCategory(b.category);
    setDialogOpen(true);
  };

  return (
    <div className="space-y-1.5">
      {/* Total summary */}
      <div className="grid grid-cols-3 gap-1.5">
        <motion.div initial={{ opacity: 0, y: 4 }} animate={{ opacity: 1, y: 0 }}>
          <Card className="p-2" style={{ backgroundColor: "var(--surface-container)" }}>
            <div className="flex items-center gap-1.5">
              <div
                className="flex h-6 w-6 items-center justify-center rounded-lg shrink-0"
                style={{ backgroundColor: `${G_BLUE}22`, color: G_BLUE }}
              >
                <DynamicIcon name="Wallet" className="h-3.5 w-3.5" />
              </div>
              <div className="min-w-0">
                <p className="text-sm font-bold text-foreground font-mono">{formatAmount(totalLimit)}</p>
                <p className="text-[10px] text-muted-foreground">إجمالي الميزانية</p>
              </div>
            </div>
          </Card>
        </motion.div>
        <motion.div initial={{ opacity: 0, y: 4 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.05 }}>
          <Card className="p-2" style={{ backgroundColor: "var(--surface-container)" }}>
            <div className="flex items-center gap-1.5">
              <div
                className="flex h-6 w-6 items-center justify-center rounded-lg shrink-0"
                style={{ backgroundColor: `${G_RED}22`, color: G_RED }}
              >
                <DynamicIcon name="TrendingUp" className="h-3.5 w-3.5" />
              </div>
              <div className="min-w-0">
                <p className="text-sm font-bold text-foreground font-mono">{formatAmount(totalSpent)}</p>
                <p className="text-[10px] text-muted-foreground">المصروف</p>
              </div>
            </div>
          </Card>
        </motion.div>
        <motion.div initial={{ opacity: 0, y: 4 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
          <Card className="p-2" style={{ backgroundColor: "var(--surface-container)" }}>
            <div className="flex items-center gap-1.5">
              <div
                className="flex h-6 w-6 items-center justify-center rounded-lg shrink-0"
                style={{ backgroundColor: `${G_GREEN}22`, color: G_GREEN }}
              >
                <DynamicIcon name="CheckCircle" className="h-3.5 w-3.5" />
              </div>
              <div className="min-w-0">
                <p
                  className="text-sm font-bold font-mono"
                  style={{ color: totalRemaining >= 0 ? G_GREEN : G_RED }}
                >
                  {formatAmount(totalRemaining)}
                </p>
                <p className="text-[10px] text-muted-foreground">المتبقي</p>
              </div>
            </div>
          </Card>
        </motion.div>
      </div>

      {/* Total progress bar */}
      <Card className="p-2" style={{ backgroundColor: "var(--surface-container)" }}>
        <div className="flex items-center justify-between mb-1">
          <span className="text-[10px] text-muted-foreground">إجمالي الإنفاق الشهري</span>
          <span className="text-[10px] font-mono font-bold" style={{ color: statusColor(totalPercent).color }}>
            {totalPercent}%
          </span>
        </div>
        <div className="h-2 rounded-full bg-white/5 overflow-hidden">
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: `${Math.min(totalPercent, 100)}%` }}
            transition={{ type: "spring", stiffness: 200 }}
            className="h-full rounded-full"
            style={{ backgroundColor: statusColor(totalPercent).color }}
          />
        </div>
      </Card>

      {/* Budget cards grid */}
      <Card className="p-2" style={{ backgroundColor: "var(--surface-container)" }}>
        <div className="flex items-center justify-between mb-1.5">
          <div className="flex items-center gap-1.5">
            <div
              className="flex h-6 w-6 items-center justify-center rounded-lg"
              style={{ backgroundColor: `${G_YELLOW}22`, color: G_YELLOW }}
            >
              <DynamicIcon name="PieChart" className="h-3.5 w-3.5" />
            </div>
            <h3 className="text-xs font-bold text-foreground">ميزانيات الفئات</h3>
          </div>
          <BudgetDialog
            open={dialogOpen}
            onOpenChange={setDialogOpen}
            editingBudget={editingBudget}
            defaultCategory={defaultCategory}
            availableCategories={availableCategories}
            onSaved={() => {
              setDialogOpen(false);
              setEditingBudget(null);
              fetchBudgets();
            }}
          >
            <Button
              size="sm"
              className="h-6"
              style={{ backgroundColor: G_GREEN, color: "#fff" }}
              onClick={() => {
                if (availableCategories.length === 0) {
                  toast({ title: "كل الفئات لها ميزانية", variant: "destructive" });
                  return;
                }
                setEditingBudget(null);
                setDefaultCategory(availableCategories[0].id);
                setDialogOpen(true);
              }}
            >
              <DynamicIcon name="Plus" className="h-3.5 w-3.5" />
              إضافة
            </Button>
          </BudgetDialog>
        </div>

        {loading ? (
          <div className="space-y-1.5">
            {Array.from({ length: 4 }).map((_, i) => (
              <Skeleton key={i} className="h-14 rounded-lg" />
            ))}
          </div>
        ) : budgets.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-4 text-center">
            <div
              className="flex h-10 w-10 items-center justify-center rounded-full mb-1.5"
              style={{ backgroundColor: `${G_YELLOW}22`, color: G_YELLOW }}
            >
              <DynamicIcon name="PieChart" className="h-5 w-5" />
            </div>
            <p className="text-xs font-medium text-foreground">لا ميزانيات معرفة</p>
            <p className="text-[10px] text-muted-foreground mt-0.5">أضف ميزانية لكل فئة لتتبع الإنفاق</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
            <AnimatePresence>
              {budgets.map((b, i) => {
                const meta = categoryMeta(b.category);
                const status = statusColor(b.percent);
                return (
                  <motion.div
                    key={b.id}
                    layout
                    initial={{ opacity: 0, y: 6 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, x: -10 }}
                    transition={{ delay: i * 0.03 }}
                    className="group rounded-lg p-1.5 transition-all hover:bg-white/5"
                    style={{ backgroundColor: "var(--surface-container-high)" }}
                  >
                    <div className="flex items-center gap-1.5 mb-1">
                      <div
                        className="flex h-6 w-6 items-center justify-center rounded-lg shrink-0"
                        style={{ backgroundColor: `${status.color}22`, color: status.color }}
                      >
                        <DynamicIcon name={meta.icon} className="h-3.5 w-3.5" />
                      </div>
                      <span className="text-xs font-medium text-foreground flex-1 truncate">{meta.label}</span>
                      <span
                        className="text-[9px] px-1 py-0.5 rounded-full"
                        style={{ backgroundColor: status.bg, color: status.color }}
                      >
                        {status.label}
                      </span>
                      <div className="flex gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity">
                        <Button
                          size="sm"
                          variant="ghost"
                          className="h-5 w-5 p-0"
                          onClick={() => handleEdit(b)}
                        >
                          <DynamicIcon name="Pencil" className="h-3 w-3" />
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          className="h-5 w-5 p-0 hover:text-red-400"
                          onClick={() => handleDelete(b.id)}
                        >
                          <DynamicIcon name="Trash2" className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                    {/* Progress */}
                    <div className="h-1.5 rounded-full bg-white/5 overflow-hidden mb-1">
                      <motion.div
                        initial={{ width: 0 }}
                        animate={{ width: `${Math.min(b.percent, 100)}%` }}
                        transition={{ delay: i * 0.03 + 0.1, type: "spring", stiffness: 200 }}
                        className="h-full rounded-full"
                        style={{ backgroundColor: status.color }}
                      />
                    </div>
                    <div className="flex items-center justify-between text-[10px]">
                      <span className="text-muted-foreground">
                        <span className="font-mono" style={{ color: G_RED }}>{formatAmount(b.spent)}</span>
                        {" / "}
                        <span className="font-mono">{formatAmount(b.limit)}</span>
                      </span>
                      <span className="font-mono font-bold" style={{ color: status.color }}>
                        {b.percent}%
                      </span>
                    </div>
                    {b.overBudget && (
                      <p className="text-[9px] mt-0.5" style={{ color: G_RED }}>
                        تجاوز بمقدار {formatAmount(b.spent - b.limit)} ل.س
                      </p>
                    )}
                  </motion.div>
                );
              })}
            </AnimatePresence>
          </div>
        )}
      </Card>

      {/* Add for category not yet budgeted */}
      {!loading && availableCategories.length > 0 && budgets.length > 0 && (
        <Card className="p-2" style={{ backgroundColor: "var(--surface-container)" }}>
          <div className="flex items-center gap-1.5 mb-1.5">
            <div
              className="flex h-6 w-6 items-center justify-center rounded-lg"
              style={{ backgroundColor: `${G_TEAL}22`, color: G_TEAL }}
            >
              <DynamicIcon name="Plus" className="h-3.5 w-3.5" />
            </div>
            <h3 className="text-xs font-bold text-foreground">فئات بدون ميزانية</h3>
          </div>
          <div className="flex flex-wrap gap-1">
            {availableCategories.map((c) => (
              <button
                key={c.id}
                onClick={() => handleAddFor(c.id)}
                className="flex items-center gap-1 px-2 py-1 rounded-full text-[10px] transition-all hover:opacity-80"
                style={{ backgroundColor: `${G_BLUE}22`, color: G_BLUE }}
              >
                <DynamicIcon name={c.icon} className="h-3 w-3" />
                {c.label}
                <DynamicIcon name="Plus" className="h-2.5 w-2.5" />
              </button>
            ))}
          </div>
        </Card>
      )}
    </div>
  );
}

function BudgetDialog({
  open,
  onOpenChange,
  editingBudget,
  defaultCategory,
  availableCategories,
  onSaved,
  children,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  editingBudget: Budget | null;
  defaultCategory: string;
  availableCategories: typeof EXPENSE_CATEGORIES;
  onSaved: () => void;
  children: React.ReactNode;
}) {
  const [category, setCategory] = React.useState(defaultCategory);
  const [limit, setLimit] = React.useState("");
  const [saving, setSaving] = React.useState(false);
  const { toast } = useToast();

  React.useEffect(() => {
    if (open) {
      if (editingBudget) {
        setCategory(editingBudget.category);
        setLimit(String(editingBudget.limit));
      } else {
        setCategory(defaultCategory);
        setLimit("");
      }
    }
  }, [editingBudget, open, defaultCategory]);

  const handleSave = async () => {
    const num = parseFloat(limit);
    if (!num || num <= 0) {
      toast({ title: "أدخل مبلغاً صحيحاً", variant: "destructive" });
      return;
    }
    setSaving(true);
    try {
      const payload: Record<string, unknown> = { category, limit: num };
      if (editingBudget) payload.id = editingBudget.id;
      await fetch("/api/budget", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      toast({ title: editingBudget ? "تم تحديث الميزانية" : "تمت إضافة الميزانية ✓" });
      onSaved();
    } catch {
      toast({ title: "فشل الحفظ", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  const selectableCats = editingBudget
    ? EXPENSE_CATEGORIES
    : availableCategories.length > 0
    ? availableCategories
    : EXPENSE_CATEGORIES;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogTrigger asChild>{children}</DialogTrigger>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>{editingBudget ? "تعديل ميزانية" : "إضافة ميزانية جديدة"}</DialogTitle>
        </DialogHeader>
        <div className="space-y-1.5">
          <div>
            <Label>الفئة</Label>
            <div className="grid grid-cols-4 gap-1 mt-1">
              {selectableCats.map((c) => {
                const meta = categoryMeta(c.id);
                const selected = category === c.id;
                return (
                  <button
                    key={c.id}
                    onClick={() => setCategory(c.id)}
                    className={cn(
                      "flex flex-col items-center gap-0.5 p-1.5 rounded-lg border transition-all",
                      selected
                        ? "border-primary"
                        : "border-border/40 text-muted-foreground hover:border-primary/30"
                    )}
                    style={selected ? { backgroundColor: `${G_BLUE}22`, color: G_BLUE } : {}}
                  >
                    <DynamicIcon name={meta.icon} className="h-3.5 w-3.5" />
                    <span className="text-[9px] text-center leading-tight">{meta.label}</span>
                  </button>
                );
              })}
            </div>
          </div>
          <div>
            <Label htmlFor="budget-limit">حد الميزانية (ليرة سورية)</Label>
            <Input
              id="budget-limit"
              type="number"
              value={limit}
              onChange={(e) => setLimit(e.target.value)}
              placeholder="0"
              dir="ltr"
              className="text-base font-bold"
              autoFocus
            />
          </div>
          {limit && parseFloat(limit) > 0 && (
            <p className="text-[10px] text-muted-foreground">
              ≈ {(parseFloat(limit) / 12500).toFixed(2)} دولار
            </p>
          )}
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>إلغاء</Button>
          <Button
            onClick={handleSave}
            disabled={saving}
            style={{ backgroundColor: G_GREEN, color: "#fff" }}
          >
            {saving ? <DynamicIcon name="Loader2" className="h-3.5 w-3.5 animate-spin" /> : <DynamicIcon name="Save" className="h-3.5 w-3.5" />}
            {editingBudget ? "حفظ" : "إضافة"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

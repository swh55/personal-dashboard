"use client";

import * as React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger } from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { DynamicIcon } from "../icon";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { format, subDays, isSameDay, startOfWeek, addDays } from "date-fns";
import { ar } from "date-fns/locale";

interface HabitLog {
  id: string;
  date: string;
  count: number;
}

interface Habit {
  id: string;
  name: string;
  description?: string | null;
  icon: string;
  color: string;
  target: number;
  logs: HabitLog[];
}

const colorMap: Record<string, { text: string; bg: string; border: string; ring: string }> = {
  emerald: { text: "text-emerald-glow", bg: "bg-emerald-glow/15", border: "border-emerald-glow/30", ring: "ring-emerald-glow/40" },
  amber: { text: "text-amber-glow", bg: "bg-amber-glow/15", border: "border-amber-glow/30", ring: "ring-amber-glow/40" },
  rose: { text: "text-rose-400", bg: "bg-rose-500/15", border: "border-rose-500/30", ring: "ring-rose-500/40" },
  teal: { text: "text-teal-400", bg: "bg-teal-500/15", border: "border-teal-500/30", ring: "ring-teal-500/40" },
};

const habitIcons = ["CheckCircle", "Sunrise", "Book", "Activity", "Droplets", "Target", "Heart", "Coffee", "Moon", "Flame"];

export function HabitsSection() {
  const [habits, setHabits] = React.useState<Habit[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [dialogOpen, setDialogOpen] = React.useState(false);
  const [editingHabit, setEditingHabit] = React.useState<Habit | null>(null);
  const { toast } = useToast();

  const fetchHabits = React.useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/habits");
      const json = await res.json();
      if (json.success) setHabits(json.data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, []);

  React.useEffect(() => {
    fetchHabits();
  }, [fetchHabits]);

  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const isDoneToday = (habit: Habit) => {
    return habit.logs.some((l) => isSameDay(new Date(l.date), today) && l.count >= habit.target);
  };

  const getStreak = (habit: Habit) => {
    let streak = 0;
    let checkDate = new Date(today);
    while (true) {
      const done = habit.logs.some((l) => isSameDay(new Date(l.date), checkDate) && l.count >= habit.target);
      if (done) {
        streak++;
        checkDate = subDays(checkDate, 1);
      } else {
        break;
      }
    }
    return streak;
  };

  const getWeekProgress = (habit: Habit) => {
    const weekStart = startOfWeek(today, { weekStartsOn: 6 }); // السبت
    let count = 0;
    for (let i = 0; i < 7; i++) {
      const day = addDays(weekStart, i);
      if (day > today) break;
      const done = habit.logs.some((l) => isSameDay(new Date(l.date), day) && l.count >= habit.target);
      if (done) count++;
    }
    return count;
  };

  const toggleHabit = async (habit: Habit) => {
    const done = isDoneToday(habit);
    try {
      await fetch("/api/habits/log", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          habitId: habit.id,
          date: today.toISOString(),
          action: done ? "remove" : "create",
        }),
      });
      if (done) {
        toast({ title: "تم إلغاء التسجيل" });
      } else {
        toast({ title: "أحسنت! تم إنجاز العادة اليوم 🎉" });
      }
      fetchHabits();
    } catch {
      toast({ title: "فشل التحديث", variant: "destructive" });
    }
  };

  const handleDelete = async (id: string) => {
    await fetch(`/api/habits?id=${id}`, { method: "DELETE" });
    toast({ title: "تم حذف العادة" });
    fetchHabits();
  };

  // آخر 7 أيام للعرض
  const last7Days = Array.from({ length: 7 }, (_, i) => {
    const d = subDays(today, 6 - i);
    return { date: d, label: format(d, "EEEEEE", { locale: ar }) };
  });

  const todayCount = habits.filter(isDoneToday).length;
  const totalHabits = habits.length;
  const completionRate = totalHabits > 0 ? Math.round((todayCount / totalHabits) * 100) : 0;

  return (
    <div className="space-y-2">
      {/* Stats header */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-2">
        <Card className="glass p-2.5">
          <div className="flex items-center gap-2">
            <div className="flex h-7 w-7 items-center justify-center rounded-xl bg-emerald-glow/15 text-emerald-glow">
              <DynamicIcon name="CheckCircle" className="h-5 w-5" />
            </div>
            <div>
              <p className="text-2xl font-bold text-foreground">{todayCount}/{totalHabits}</p>
              <p className="text-[11px] text-muted-foreground">عادات اليوم</p>
            </div>
          </div>
        </Card>
        <Card className="glass p-2.5">
          <div className="flex items-center gap-2">
            <div className="flex h-7 w-7 items-center justify-center rounded-xl bg-amber-glow/15 text-amber-glow">
              <DynamicIcon name="TrendingUp" className="h-5 w-5" />
            </div>
            <div>
              <p className="text-2xl font-bold text-foreground">{completionRate}%</p>
              <p className="text-[11px] text-muted-foreground">نسبة الإنجاز</p>
            </div>
          </div>
        </Card>
        <Card className="glass p-2.5">
          <div className="flex items-center gap-2">
            <div className="flex h-7 w-7 items-center justify-center rounded-xl bg-rose-500/15 text-rose-400">
              <DynamicIcon name="Flame" className="h-5 w-5" />
            </div>
            <div>
              <p className="text-2xl font-bold text-foreground">
                {habits.length > 0 ? Math.max(...habits.map(getStreak)) : 0}
              </p>
              <p className="text-[11px] text-muted-foreground">أطول سلسلة</p>
            </div>
          </div>
        </Card>
        <Card className="glass p-2.5">
          <div className="flex items-center gap-2">
            <div className="flex h-7 w-7 items-center justify-center rounded-xl bg-teal-500/15 text-teal-400">
              <DynamicIcon name="Calendar" className="h-5 w-5" />
            </div>
            <div>
              <p className="text-2xl font-bold text-foreground">
                {habits.reduce((acc, h) => acc + getWeekProgress(h), 0)}
              </p>
              <p className="text-[11px] text-muted-foreground">إنجازات الأسبوع</p>
            </div>
          </div>
        </Card>
      </div>

      {/* Progress bar */}
      <Card className="glass p-2">
        <div className="flex items-center justify-between mb-1.5">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-emerald-glow/15 text-emerald-glow">
              <DynamicIcon name="Target" className="h-4 w-4" />
            </div>
            <h3 className="text-sm font-bold text-foreground">تقدم اليوم</h3>
          </div>
          <span className="text-2xl font-bold text-gradient-emerald">{completionRate}%</span>
        </div>
        <div className="h-3 rounded-full bg-muted/30 overflow-hidden">
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: `${completionRate}%` }}
            transition={{ type: "spring", stiffness: 200, damping: 30 }}
            className="h-full rounded-full bg-gradient-to-l from-emerald-glow to-amber-glow relative"
          >
            <div className="absolute inset-0 shimmer" />
          </motion.div>
        </div>
        <div className="flex justify-between mt-2 text-[10px] text-muted-foreground">
          <span>{todayCount} مكتملة</span>
          <span>{totalHabits - todayCount} متبقية</span>
        </div>
      </Card>

      {/* Habits list */}
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-bold text-foreground">العادات اليومية</h3>
        <HabitDialog
          open={dialogOpen}
          onOpenChange={setDialogOpen}
          editingHabit={editingHabit}
          onSaved={() => {
            setDialogOpen(false);
            setEditingHabit(null);
            fetchHabits();
          }}
        >
          <Button size="sm" className="bg-emerald-glow hover:bg-emerald-glow/90 text-background">
            <DynamicIcon name="Plus" className="h-4 w-4" />
            عادة جديدة
          </Button>
        </HabitDialog>
      </div>

      {loading ? (
        <div className="space-y-2">
          {Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-16 rounded-2xl" />
          ))}
        </div>
      ) : habits.length === 0 ? (
        <Card className="glass p-12">
          <div className="flex flex-col items-center justify-center text-center">
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-muted/30 mb-1.5">
              <DynamicIcon name="RefreshCw" className="h-6 w-6 text-muted-foreground" />
            </div>
            <p className="text-sm font-medium text-foreground">لا عادات بعد</p>
            <p className="text-xs text-muted-foreground mt-1">ابدأ ببناء عادات إيجابية يومية</p>
          </div>
        </Card>
      ) : (
        <div className="space-y-2">
          <AnimatePresence>
            {habits.map((habit, i) => {
              const colors = colorMap[habit.color] || colorMap.emerald;
              const done = isDoneToday(habit);
              const streak = getStreak(habit);
              const weekProgress = getWeekProgress(habit);
              return (
                <motion.div
                  key={habit.id}
                  layout
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ delay: i * 0.03 }}
                >
                  <Card className={cn(
                    "glass p-2.5 transition-all group",
                    done && cn("ring-1", colors.ring)
                  )}>
                    <div className="flex items-center gap-2">
                      {/* Toggle button */}
                      <button
                        onClick={() => toggleHabit(habit)}
                        className={cn(
                          "flex h-8 w-8 items-center justify-center rounded-xl border-2 transition-all shrink-0",
                          done
                            ? cn(colors.bg, colors.border, colors.text)
                            : "border-border/40 bg-background/30 text-muted-foreground hover:border-emerald-glow/30"
                        )}
                      >
                        <DynamicIcon
                          name={done ? "CheckCircle" : habit.icon}
                          className={cn("h-6 w-6", done && "tick-up")}
                        />
                      </button>

                      {/* Habit info */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <p className={cn(
                            "text-sm font-bold truncate",
                            done ? "text-foreground" : "text-foreground"
                          )}>
                            {habit.name}
                          </p>
                          {streak > 0 && (
                            <span className={cn("flex items-center gap-0.5 text-[10px] font-medium px-1.5 py-0.5 rounded-full", colors.bg, colors.text)}>
                              <DynamicIcon name="Flame" className="h-2.5 w-2.5" />
                              {streak}
                            </span>
                          )}
                        </div>
                        {habit.description && (
                          <p className="text-[11px] text-muted-foreground truncate">
                            {habit.description}
                          </p>
                        )}
                        {/* Last 7 days mini view */}
                        <div className="flex items-center gap-1 mt-1.5">
                          {last7Days.map((day, di) => {
                            const dayDone = habit.logs.some((l) => isSameDay(new Date(l.date), day.date) && l.count >= habit.target);
                            const isToday = isSameDay(day.date, today);
                            return (
                              <div key={di} className="flex flex-col items-center gap-0.5">
                                <div className={cn(
                                  "h-5 w-5 rounded-md flex items-center justify-center text-[8px]",
                                  dayDone
                                    ? cn(colors.bg, colors.text)
                                    : "bg-muted/20 text-muted-foreground/50",
                                  isToday && "ring-1 ring-emerald-glow/40"
                                )}>
                                  {dayDone && <DynamicIcon name="Check" className="h-3 w-3" />}
                                </div>
                                <span className="text-[8px] text-muted-foreground/60">{day.label}</span>
                              </div>
                            );
                          })}
                          <div className="mr-auto flex items-center gap-1 text-[10px] text-muted-foreground">
                            <DynamicIcon name="Calendar" className="h-3 w-3" />
                            {weekProgress}/7 هذا الأسبوع
                          </div>
                        </div>
                      </div>

                      {/* Actions */}
                      <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8"
                          onClick={() => { setEditingHabit(habit); setDialogOpen(true); }}
                        >
                          <DynamicIcon name="Pencil" className="h-3.5 w-3.5" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 hover:text-rose-400"
                          onClick={() => handleDelete(habit.id)}
                        >
                          <DynamicIcon name="Trash2" className="h-3.5 w-3.5" />
                        </Button>
                      </div>
                    </div>
                  </Card>
                </motion.div>
              );
            })}
          </AnimatePresence>
        </div>
      )}
    </div>
  );
}

function HabitDialog({
  open, onOpenChange, editingHabit, onSaved, children,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  editingHabit: Habit | null;
  onSaved: () => void;
  children: React.ReactNode;
}) {
  const [name, setName] = React.useState("");
  const [description, setDescription] = React.useState("");
  const [icon, setIcon] = React.useState("CheckCircle");
  const [color, setColor] = React.useState("emerald");
  const [target, setTarget] = React.useState(1);
  const { toast } = useToast();

  React.useEffect(() => {
    if (editingHabit) {
      setName(editingHabit.name);
      setDescription(editingHabit.description || "");
      setIcon(editingHabit.icon);
      setColor(editingHabit.color);
      setTarget(editingHabit.target);
    } else {
      setName(""); setDescription(""); setIcon("CheckCircle"); setColor("emerald"); setTarget(1);
    }
  }, [editingHabit, open]);

  const handleSave = async () => {
    if (!name) {
      toast({ title: "الاسم مطلوب", variant: "destructive" });
      return;
    }
    const payload = { name, description, icon, color, target };
    try {
      if (editingHabit) {
        await fetch("/api/habits", {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ id: editingHabit.id, ...payload }),
        });
        toast({ title: "تم التحديث" });
      } else {
        await fetch("/api/habits", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
        toast({ title: "تمت الإضافة" });
      }
      onSaved();
    } catch {
      toast({ title: "فشل الحفظ", variant: "destructive" });
    }
  };

  const colors = ["emerald", "amber", "rose", "teal"];

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogTrigger asChild>{children}</DialogTrigger>
      <DialogContent className="glass-strong max-w-md">
        <DialogHeader>
          <DialogTitle>{editingHabit ? "تعديل عادة" : "عادة جديدة"}</DialogTitle>
        </DialogHeader>
        <div className="space-y-1.5">
          <div>
            <Label htmlFor="h-name">اسم العادة</Label>
            <Input id="h-name" value={name} onChange={(e) => setName(e.target.value)} placeholder="مثلاً: قراءة القرآن" />
          </div>
          <div>
            <Label htmlFor="h-desc">الوصف</Label>
            <Textarea id="h-desc" value={description} onChange={(e) => setDescription(e.target.value)} rows={2} placeholder="تفاصيل إضافية" />
          </div>
          <div>
            <Label>الأيقونة</Label>
            <div className="flex flex-wrap gap-2 mt-1">
              {habitIcons.map((ic) => (
                <button
                  key={ic}
                  onClick={() => setIcon(ic)}
                  className={cn(
                    "flex h-9 w-9 items-center justify-center rounded-lg border transition-all",
                    icon === ic ? "bg-emerald-glow/15 border-emerald-glow/30 text-emerald-glow" : "border-border/40 text-muted-foreground hover:border-emerald-glow/20"
                  )}
                >
                  <DynamicIcon name={ic} className="h-4 w-4" />
                </button>
              ))}
            </div>
          </div>
          <div>
            <Label>اللون</Label>
            <div className="flex gap-2 mt-1">
              {colors.map((c) => {
                const cm = colorMap[c];
                return (
                  <button
                    key={c}
                    onClick={() => setColor(c)}
                    className={cn(
                      "h-8 w-8 rounded-lg border-2 transition-all",
                      color === c ? cm.border : "border-transparent",
                      cm.bg
                    )}
                  >
                    <DynamicIcon name="CheckCircle" className={cn("h-4 w-4", cm.text)} />
                  </button>
                );
              })}
            </div>
          </div>
          <div>
            <Label htmlFor="h-target">الهدف اليومي (مرات)</Label>
            <Input id="h-target" type="number" min={1} max={20} value={target} onChange={(e) => setTarget(parseInt(e.target.value) || 1)} />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>إلغاء</Button>
          <Button onClick={handleSave} className="bg-emerald-glow hover:bg-emerald-glow/90 text-background">
            {editingHabit ? "حفظ" : "إضافة"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

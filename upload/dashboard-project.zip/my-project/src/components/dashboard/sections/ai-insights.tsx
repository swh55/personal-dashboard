"use client";

import * as React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { DynamicIcon } from "../icon";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { EXPENSE_CATEGORIES } from "@/lib/constants";

// Google brand colors
const G_BLUE = "#4285F4";
const G_RED = "#EA4335";
const G_YELLOW = "#FBBC04";
const G_GREEN = "#34A853";
const G_ORANGE = "#FF6D00";
const G_PURPLE = "#A142F4";
const G_TEAL = "#00897B";

interface SpendingPattern {
  category: string;
  total: number;
  count: number;
  average: number;
  budget: number | null;
  percentOfBudget: number | null;
  trend: "up" | "down" | "stable";
  insight: string;
}

interface TaskSuggestion {
  type: string;
  title: string;
  reason: string;
  priority: "high" | "medium" | "low";
  relatedTaskId?: string;
}

interface BestTime {
  type: "hour" | "day";
  label: string;
  value: number;
  count: number;
  recommendation: string;
}

interface PredictiveAlert {
  severity: "critical" | "warning" | "info";
  type: string;
  title: string;
  message: string;
  data?: Record<string, unknown>;
}

type Tab = "spending" | "tasks" | "times" | "alerts";

const TABS: Array<{ id: Tab; label: string; icon: string; color: string }> = [
  { id: "spending", label: "أنماط الإنفاق", icon: "PieChart", color: G_BLUE },
  { id: "tasks", label: "اقتراحات المهام", icon: "CheckSquare", color: G_GREEN },
  { id: "times", label: "أفضل الأوقات", icon: "Clock", color: G_ORANGE },
  { id: "alerts", label: "تنبيهات تنبؤية", icon: "BellRing", color: G_RED },
];

function formatAmount(n: number) {
  if (n >= 1_000_000) return (n / 1_000_000).toFixed(1) + "M";
  if (n >= 1000) return (n / 1000).toFixed(1) + "K";
  return Math.round(n).toLocaleString("en-US");
}

function categoryLabel(id: string): { label: string; icon: string } {
  const found = EXPENSE_CATEGORIES.find((c) => c.id === id);
  return found ? { label: found.label, icon: found.icon } : { label: id, icon: "Wallet" };
}

export function AiInsightsSection() {
  const { toast } = useToast();
  const [tab, setTab] = React.useState<Tab>("spending");
  const [loading, setLoading] = React.useState(true);
  const [refreshing, setRefreshing] = React.useState(false);
  const [data, setData] = React.useState<{
    spendingPatterns: SpendingPattern[];
    taskSuggestions: TaskSuggestion[];
    bestTimes: BestTime[];
    predictiveAlerts: PredictiveAlert[];
  }>({ spendingPatterns: [], taskSuggestions: [], bestTimes: [], predictiveAlerts: [] });

  const fetchData = React.useCallback(async () => {
    try {
      const res = await fetch("/api/ai-insights");
      const json = await res.json();
      if (json.success) setData(json.data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  React.useEffect(() => {
    fetchData();
  }, [fetchData]);

  const handleRefresh = () => {
    setRefreshing(true);
    fetchData();
    toast({ title: "تم تحديث التحليلات" });
  };

  const handleSuggestionAction = (s: TaskSuggestion) => {
    toast({
      title: "تم اتخاذ الإجراء",
      description: s.title,
    });
  };

  const currentTab = TABS.find((t) => t.id === tab)!;

  return (
    <div className="space-y-1.5">
      {/* Header */}
      <Card className="p-2" style={{ backgroundColor: "var(--surface-container)" }}>
        <div className="flex items-center gap-1.5">
          <div
            className="flex h-7 w-7 items-center justify-center rounded-lg"
            style={{ backgroundColor: `${G_BLUE}22`, color: G_BLUE }}
          >
            <DynamicIcon name="Sparkles" className="h-4 w-4" />
          </div>
          <div className="flex-1">
            <p className="text-xs font-bold text-foreground">التحليلات الذكية</p>
            <p className="text-[10px] text-muted-foreground">تحليل بياناتك آلياً واكتشاف الأنماط</p>
          </div>
          <Button
            size="sm"
            variant="ghost"
            onClick={handleRefresh}
            disabled={refreshing}
            className="h-7 w-7 p-0"
          >
            <DynamicIcon name={refreshing ? "Loader2" : "RefreshCw"} className={cn("h-3.5 w-3.5", refreshing && "animate-spin")} />
          </Button>
        </div>
      </Card>

      {/* Tabs */}
      <Card className="p-1" style={{ backgroundColor: "var(--surface-container)" }}>
        <div className="grid grid-cols-4 gap-0.5">
          {TABS.map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={cn(
                "flex flex-col items-center gap-0.5 py-1.5 rounded-lg transition-all text-[10px] font-medium",
                tab === t.id ? "text-foreground" : "text-muted-foreground hover:text-foreground"
              )}
              style={tab === t.id ? { backgroundColor: `${t.color}22`, color: t.color } : {}}
            >
              <DynamicIcon name={t.icon} className="h-3.5 w-3.5" />
              <span className="leading-tight text-center">{t.label}</span>
            </button>
          ))}
        </div>
      </Card>

      {/* Tab content */}
      <AnimatePresence mode="wait">
        <motion.div
          key={tab}
          initial={{ opacity: 0, y: 6 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -6 }}
          transition={{ duration: 0.15 }}
        >
          {loading ? (
            <Card className="p-2 space-y-1.5" style={{ backgroundColor: "var(--surface-container)" }}>
              {Array.from({ length: 4 }).map((_, i) => (
                <Skeleton key={i} className="h-12 rounded-lg" />
              ))}
            </Card>
          ) : tab === "spending" ? (
            <SpendingTab data={data.spendingPatterns} />
          ) : tab === "tasks" ? (
            <TasksTab data={data.taskSuggestions} onAction={handleSuggestionAction} />
          ) : tab === "times" ? (
            <TimesTab data={data.bestTimes} />
          ) : (
            <AlertsTab data={data.predictiveAlerts} />
          )}
        </motion.div>
      </AnimatePresence>

      <p className="text-[10px] text-muted-foreground text-center px-2">
        {currentTab.label} · تحليل تلقائي للبيانات
      </p>
    </div>
  );
}

// ---------- Spending Patterns Tab ----------

function SpendingTab({ data }: { data: SpendingPattern[] }) {
  if (data.length === 0) {
    return (
      <EmptyState icon="PieChart" color={G_BLUE} title="لا بيانات إنفاق" hint="سجّل مصروفات لاكتشاف الأنماط" />
    );
  }
  const maxTotal = Math.max(...data.map((d) => d.total), 1);
  return (
    <div className="space-y-1">
      {data.slice(0, 8).map((p, i) => {
        const cat = categoryLabel(p.category);
        const trendColor =
          p.trend === "up" ? G_RED : p.trend === "down" ? G_GREEN : G_YELLOW;
        const trendIcon = p.trend === "up" ? "TrendingUp" : p.trend === "down" ? "TrendingDown" : "Activity";
        return (
          <motion.div
            key={p.category}
            initial={{ opacity: 0, x: 6 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: i * 0.04 }}
          >
            <Card className="p-2" style={{ backgroundColor: "var(--surface-container)" }}>
              <div className="flex items-center gap-1.5 mb-1">
                <div
                  className="flex h-6 w-6 items-center justify-center rounded-lg shrink-0"
                  style={{ backgroundColor: `${G_BLUE}22`, color: G_BLUE }}
                >
                  <DynamicIcon name={cat.icon} className="h-3.5 w-3.5" />
                </div>
                <span className="text-xs font-medium text-foreground flex-1">{cat.label}</span>
                <div
                  className="flex items-center gap-0.5 px-1 py-0.5 rounded text-[10px] font-mono"
                  style={{ backgroundColor: `${trendColor}22`, color: trendColor }}
                >
                  <DynamicIcon name={trendIcon} className="h-2.5 w-2.5" />
                  {p.trend === "up" ? "صعود" : p.trend === "down" ? "هبوط" : "ثابت"}
                </div>
                <span className="text-xs font-mono font-bold text-foreground">
                  {formatAmount(p.total)}
                </span>
              </div>
              {/* Bar */}
              <div className="h-1.5 rounded-full bg-white/5 overflow-hidden mb-1">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${(p.total / maxTotal) * 100}%` }}
                  transition={{ delay: i * 0.04 + 0.1, type: "spring", stiffness: 200 }}
                  className="h-full rounded-full"
                  style={{ backgroundColor: G_BLUE }}
                />
              </div>
              <p className="text-[10px] text-muted-foreground leading-snug">{p.insight}</p>
              <div className="flex items-center gap-1.5 mt-0.5 text-[10px] text-muted-foreground">
                <span>{p.count} عملية</span>
                <span>·</span>
                <span>متوسط {formatAmount(p.average)}</span>
                {p.percentOfBudget !== null && (
                  <>
                    <span>·</span>
                    <span style={{
                      color: (p.percentOfBudget || 0) >= 100 ? G_RED : (p.percentOfBudget || 0) >= 80 ? G_ORANGE : G_GREEN,
                    }}>
                      {p.percentOfBudget}% من الميزانية
                    </span>
                  </>
                )}
              </div>
            </Card>
          </motion.div>
        );
      })}
    </div>
  );
}

// ---------- Task Suggestions Tab ----------

function TasksTab({
  data,
  onAction,
}: {
  data: TaskSuggestion[];
  onAction: (s: TaskSuggestion) => void;
}) {
  if (data.length === 0) {
    return (
      <EmptyState icon="CheckSquare" color={G_GREEN} title="لا اقتراحات حالياً" hint="كل مهامك تحت السيطرة ✓" />
    );
  }
  const priorityColors: Record<string, string> = {
    high: G_RED,
    medium: G_ORANGE,
    low: G_TEAL,
  };
  const priorityLabels: Record<string, string> = {
    high: "عالية",
    medium: "متوسطة",
    low: "منخفضة",
  };
  return (
    <div className="space-y-1">
      {data.slice(0, 10).map((s, i) => {
        const color = priorityColors[s.priority];
        return (
          <motion.div
            key={`${s.type}-${i}`}
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.04 }}
          >
            <Card className="p-2" style={{ backgroundColor: "var(--surface-container)" }}>
              <div className="flex items-start gap-1.5">
                <div
                  className="flex h-6 w-6 items-center justify-center rounded-lg shrink-0"
                  style={{ backgroundColor: `${color}22`, color }}
                >
                  <DynamicIcon name="Lightbulb" className="h-3.5 w-3.5" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-medium text-foreground leading-tight">{s.title}</p>
                  <p className="text-[10px] text-muted-foreground mt-0.5">{s.reason}</p>
                </div>
                <span
                  className="text-[10px] px-1.5 py-0.5 rounded-full shrink-0"
                  style={{ backgroundColor: `${color}22`, color }}
                >
                  {priorityLabels[s.priority]}
                </span>
              </div>
              <Button
                size="sm"
                variant="outline"
                className="w-full mt-1.5 h-6 text-[10px]"
                onClick={() => onAction(s)}
              >
                <DynamicIcon name="Zap" className="h-3 w-3" />
                تنفيذ
              </Button>
            </Card>
          </motion.div>
        );
      })}
    </div>
  );
}

// ---------- Best Times Tab ----------

function TimesTab({ data }: { data: BestTime[] }) {
  if (data.length === 0 || (data.length === 1 && data[0].value === -1)) {
    return (
      <EmptyState icon="Clock" color={G_ORANGE} title="لا بيانات كافية" hint="أنجز مهاماً لاكتشاف أنماطك" />
    );
  }
  const hours = data.filter((d) => d.type === "hour");
  const days = data.filter((d) => d.type === "day");
  const maxCount = Math.max(...data.map((d) => d.count), 1);

  const typeColor = (type: "hour" | "day") =>
    type === "hour" ? G_ORANGE : G_PURPLE;
  const typeIcon = (type: "hour" | "day") => (type === "hour" ? "Clock" : "Calendar");

  return (
    <div className="space-y-1.5">
      {hours.length > 0 && (
        <Card className="p-2" style={{ backgroundColor: "var(--surface-container)" }}>
          <div className="flex items-center gap-1.5 mb-1.5">
            <div
              className="flex h-6 w-6 items-center justify-center rounded-lg"
              style={{ backgroundColor: `${G_ORANGE}22`, color: G_ORANGE }}
            >
              <DynamicIcon name="Clock" className="h-3.5 w-3.5" />
            </div>
            <h3 className="text-xs font-bold text-foreground">أفضل الساعات</h3>
          </div>
          <div className="space-y-1">
            {hours.map((h, i) => (
              <div key={`${h.type}-${h.value}-${i}`} className="flex items-center gap-1.5">
                <span className="text-[10px] text-muted-foreground w-20 shrink-0">{h.label}</span>
                <div className="flex-1 h-3 rounded-full bg-white/5 overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${(h.count / maxCount) * 100}%` }}
                    transition={{ delay: i * 0.05, type: "spring", stiffness: 200 }}
                    className="h-full rounded-full flex items-center justify-end pr-1"
                    style={{ backgroundColor: G_ORANGE }}
                  >
                    <span className="text-[9px] font-mono text-white font-bold">{h.count}</span>
                  </motion.div>
                </div>
              </div>
            ))}
          </div>
        </Card>
      )}

      {days.length > 0 && (
        <Card className="p-2" style={{ backgroundColor: "var(--surface-container)" }}>
          <div className="flex items-center gap-1.5 mb-1.5">
            <div
              className="flex h-6 w-6 items-center justify-center rounded-lg"
              style={{ backgroundColor: `${G_PURPLE}22`, color: G_PURPLE }}
            >
              <DynamicIcon name="Calendar" className="h-3.5 w-3.5" />
            </div>
            <h3 className="text-xs font-bold text-foreground">أفضل الأيام</h3>
          </div>
          <div className="space-y-1">
            {days.map((d, i) => (
              <div key={`${d.type}-${d.value}-${i}`} className="flex items-center gap-1.5">
                <span className="text-[10px] text-muted-foreground w-20 shrink-0">{d.label}</span>
                <div className="flex-1 h-3 rounded-full bg-white/5 overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${(d.count / maxCount) * 100}%` }}
                    transition={{ delay: i * 0.05 + 0.1, type: "spring", stiffness: 200 }}
                    className="h-full rounded-full flex items-center justify-end pr-1"
                    style={{ backgroundColor: G_PURPLE }}
                  >
                    <span className="text-[9px] font-mono text-white font-bold">{d.count}</span>
                  </motion.div>
                </div>
              </div>
            ))}
          </div>
        </Card>
      )}

      {/* Recommendation */}
      {data[0] && (
        <Card className="p-2" style={{ backgroundColor: "var(--surface-container)" }}>
          <div className="flex items-start gap-1.5">
            <div
              className="flex h-6 w-6 items-center justify-center rounded-lg shrink-0"
              style={{
                backgroundColor: `${typeColor(data[0].type)}22`,
                color: typeColor(data[0].type),
              }}
            >
              <DynamicIcon name={typeIcon(data[0].type)} className="h-3.5 w-3.5" />
            </div>
            <div>
              <p className="text-[10px] font-bold text-foreground">توصية</p>
              <p className="text-[10px] text-muted-foreground leading-snug">{data[0].recommendation}</p>
            </div>
          </div>
        </Card>
      )}
    </div>
  );
}

// ---------- Predictive Alerts Tab ----------

function AlertsTab({ data }: { data: PredictiveAlert[] }) {
  if (data.length === 0) {
    return (
      <EmptyState icon="BellRing" color={G_GREEN} title="لا تنبيهات" hint="كل شيء على ما يرام ✓" />
    );
  }
  const severityColors: Record<string, string> = {
    critical: G_RED,
    warning: G_ORANGE,
    info: G_BLUE,
  };
  const severityIcons: Record<string, string> = {
    critical: "AlertCircle",
    warning: "BellRing",
    info: "Lightbulb",
  };
  const severityLabels: Record<string, string> = {
    critical: "حرج",
    warning: "تحذير",
    info: "معلومة",
  };
  return (
    <div className="space-y-1">
      {data.map((a, i) => {
        const color = severityColors[a.severity];
        return (
          <motion.div
            key={`${a.type}-${i}`}
            initial={{ opacity: 0, x: 6 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: i * 0.04 }}
          >
            <Card
              className="p-2"
              style={{
                backgroundColor: "var(--surface-container)",
                borderRight: `3px solid ${color}`,
              }}
            >
              <div className="flex items-start gap-1.5">
                <div
                  className="flex h-6 w-6 items-center justify-center rounded-lg shrink-0"
                  style={{ backgroundColor: `${color}22`, color }}
                >
                  <DynamicIcon name={severityIcons[a.severity]} className="h-3.5 w-3.5" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5">
                    <p className="text-xs font-bold text-foreground flex-1">{a.title}</p>
                    <span
                      className="text-[9px] px-1.5 py-0.5 rounded-full shrink-0"
                      style={{ backgroundColor: `${color}22`, color }}
                    >
                      {severityLabels[a.severity]}
                    </span>
                  </div>
                  <p className="text-[10px] text-muted-foreground mt-0.5 leading-snug">{a.message}</p>
                </div>
              </div>
            </Card>
          </motion.div>
        );
      })}
    </div>
  );
}

// ---------- Empty State ----------

function EmptyState({
  icon,
  color,
  title,
  hint,
}: {
  icon: string;
  color: string;
  title: string;
  hint: string;
}) {
  return (
    <Card className="p-4" style={{ backgroundColor: "var(--surface-container)" }}>
      <div className="flex flex-col items-center justify-center text-center">
        <div
          className="flex h-10 w-10 items-center justify-center rounded-full mb-1.5"
          style={{ backgroundColor: `${color}22`, color }}
        >
          <DynamicIcon name={icon} className="h-5 w-5" />
        </div>
        <p className="text-xs font-medium text-foreground">{title}</p>
        <p className="text-[10px] text-muted-foreground mt-0.5">{hint}</p>
      </div>
    </Card>
  );
}

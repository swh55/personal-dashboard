"use client";

import * as React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";
import { DynamicIcon } from "../icon";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { USER_PROFILE } from "@/lib/constants";
import { formatDistanceToNow, format } from "date-fns";
import { ar } from "date-fns/locale";

// Google brand colors
const G_BLUE = "#4285F4";
const G_RED = "#EA4335";
const G_YELLOW = "#FBBC04";
const G_GREEN = "#34A853";
const G_ORANGE = "#FF6D00";
const G_PURPLE = "#A142F4";
const G_TEAL = "#00897B";

const ALEPPO_LAT = USER_PROFILE.lat;
const ALEPPO_LNG = USER_PROFILE.lng;

interface SavedLocation {
  id: string;
  name: string;
  address: string;
  lat: number;
  lng: number;
  icon: string;
  color: string;
  createdAt: string;
}

interface TrackRoute {
  id: string;
  name: string;
  startPoint: string;
  endPoint: string | null;
  startLat: number | null;
  startLng: number | null;
  endLat: number | null;
  endLng: number | null;
  distance: number | null;
  duration: number | null;
  startTime: string;
  endTime: string | null;
}

// Build a Google Maps embed URL for a coordinate
function embedUrl(lat: number, lng: number, traffic: boolean) {
  const base = `https://maps.google.com/maps?q=${lat},${lng}&z=14&output=embed`;
  // The "layer=t" query adds the traffic layer (works only on some embeds).
  return traffic ? `${base}&layer=t` : base;
}

function getCurrentPosition(): Promise<GeolocationPosition> {
  return new Promise((resolve, reject) => {
    if (typeof navigator === "undefined" || !navigator.geolocation) {
      reject(new Error("الموقع غير مدعوم"));
      return;
    }
    navigator.geolocation.getCurrentPosition(resolve, reject, {
      enableHighAccuracy: true,
      timeout: 10000,
      maximumAge: 0,
    });
  });
}

export function MapsSection() {
  const { toast } = useToast();
  const [traffic, setTraffic] = React.useState(false);
  const [locations, setLocations] = React.useState<SavedLocation[]>([]);
  const [routes, setRoutes] = React.useState<TrackRoute[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [activeRoute, setActiveRoute] = React.useState<TrackRoute | null>(null);
  const [routeName, setRouteName] = React.useState("");
  const [savingLocation, setSavingLocation] = React.useState(false);
  const [locationName, setLocationName] = React.useState("");

  const fetchAll = React.useCallback(async () => {
    try {
      const [locRes, routeRes] = await Promise.all([
        fetch("/api/locations"),
        fetch("/api/routes"),
      ]);
      const locJson = await locRes.json();
      const routeJson = await routeRes.json();
      if (locJson.success) setLocations(locJson.data);
      if (routeJson.success) {
        setRoutes(routeJson.data);
        const active = routeJson.data.find((r: TrackRoute) => !r.endTime);
        setActiveRoute(active || null);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, []);

  React.useEffect(() => {
    fetchAll();
  }, [fetchAll]);

  // ---------- Actions ----------

  const handleNearestMosque = () => {
    const url = `https://www.google.com/maps/search/mosques+near+${ALEPPO_LAT},${ALEPPO_LNG}`;
    window.open(url, "_blank", "noopener,noreferrer");
    toast({ title: "فتح البحث عن أقرب مسجد" });
  };

  const handleSaveCurrentLocation = async () => {
    if (!locationName.trim()) {
      toast({ title: "أدخل اسماً للموقع", variant: "destructive" });
      return;
    }
    setSavingLocation(true);
    try {
      const pos = await getCurrentPosition();
      const { latitude, longitude } = pos.coords;
      await fetch("/api/locations", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: locationName.trim(),
          address: `${latitude.toFixed(5)}, ${longitude.toFixed(5)}`,
          lat: latitude,
          lng: longitude,
          icon: "MapPin",
          color: "blue",
        }),
      });
      toast({ title: "تم حفظ الموقع الحالي ✓" });
      setLocationName("");
      fetchAll();
    } catch (e) {
      const msg = e instanceof Error ? e.message : "فشل الحصول على الموقع";
      toast({ title: `تعذر الحصول على الموقع: ${msg}`, variant: "destructive" });
    } finally {
      setSavingLocation(false);
    }
  };

  const handleShareLiveLocation = async () => {
    try {
      const pos = await getCurrentPosition();
      const { latitude, longitude } = pos.coords;
      const link = `https://www.google.com/maps?q=${latitude},${longitude}`;
      if (navigator.clipboard) {
        await navigator.clipboard.writeText(link);
      }
      toast({ title: "تم نسخ رابط الموقع الحي", description: "الرابط جاهز للمشاركة" });
    } catch (e) {
      const msg = e instanceof Error ? e.message : "فشل الحصول على الموقع";
      toast({ title: `تعذر الحصول على الموقع: ${msg}`, variant: "destructive" });
    }
  };

  const handleNavigateTo = (loc: SavedLocation) => {
    const url = `https://www.google.com/maps/dir/?api=1&destination=${loc.lat},${loc.lng}`;
    window.open(url, "_blank", "noopener,noreferrer");
    toast({ title: `بدء الملاحة إلى ${loc.name}` });
  };

  const handleDeleteLocation = async (id: string) => {
    await fetch(`/api/locations?id=${id}`, { method: "DELETE" });
    toast({ title: "تم حذف الموقع" });
    fetchAll();
  };

  // ---------- Route tracking ----------

  const handleStartRoute = async () => {
    const name = routeName.trim() || `مسار ${new Date().toLocaleString("ar")}`;
    try {
      const pos = await getCurrentPosition();
      const { latitude, longitude } = pos.coords;
      const res = await fetch("/api/routes", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name,
          startPoint: `${latitude.toFixed(5)}, ${longitude.toFixed(5)}`,
          startLat: latitude,
          startLng: longitude,
          startTime: new Date().toISOString(),
        }),
      });
      const json = await res.json();
      if (json.success) {
        toast({ title: "بدأ تسجيل المسار 🚗" });
        setRouteName("");
        fetchAll();
      }
    } catch (e) {
      const msg = e instanceof Error ? e.message : "فشل بدء المسار";
      toast({ title: `تعذر بدء المسار: ${msg}`, variant: "destructive" });
    }
  };

  const handleEndRoute = async () => {
    if (!activeRoute) return;
    try {
      const pos = await getCurrentPosition();
      const { latitude, longitude } = pos.coords;
      await fetch("/api/routes", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          id: activeRoute.id,
          endPoint: `${latitude.toFixed(5)}, ${longitude.toFixed(5)}`,
          endLat: latitude,
          endLng: longitude,
          endTime: new Date().toISOString(),
        }),
      });
      toast({ title: "تم إنهاء المسار ✓" });
      fetchAll();
    } catch (e) {
      const msg = e instanceof Error ? e.message : "فشل إنهاء المسار";
      toast({ title: `تعذر إنهاء المسار: ${msg}`, variant: "destructive" });
    }
  };

  const handleDeleteRoute = async (id: string) => {
    await fetch(`/api/routes?id=${id}`, { method: "DELETE" });
    toast({ title: "تم حذف المسار" });
    fetchAll();
  };

  // ---------- Render ----------

  return (
    <div className="space-y-1.5">
      {/* Map embed + traffic toggle */}
      <Card className="overflow-hidden p-0" style={{ backgroundColor: "var(--surface-container)" }}>
        <div className="flex items-center justify-between gap-1.5 p-2 border-b" style={{ borderColor: "var(--border)" }}>
          <div className="flex items-center gap-1.5">
            <div
              className="flex h-6 w-6 items-center justify-center rounded-lg"
              style={{ backgroundColor: `${G_BLUE}22`, color: G_BLUE }}
            >
              <DynamicIcon name="MapPin" className="h-3.5 w-3.5" />
            </div>
            <h3 className="text-xs font-bold text-foreground">خريطة حلب</h3>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="text-[10px] text-muted-foreground">عرض المرور</span>
            <Switch checked={traffic} onCheckedChange={setTraffic} />
          </div>
        </div>
        <iframe
          title="خريطة حلب"
          src={embedUrl(ALEPPO_LAT, ALEPPO_LNG, traffic)}
          className="w-full"
          style={{ height: 220, border: 0 }}
          loading="lazy"
          referrerPolicy="no-referrer-when-downgrade"
          allowFullScreen
        />
      </Card>

      {/* Quick action buttons */}
      <div className="grid grid-cols-2 gap-1.5 sm:grid-cols-4">
        <QuickAction
          color={G_GREEN}
          icon="Compass"
          label="أقرب مسجد"
          onClick={handleNearestMosque}
        />
        <QuickAction
          color={G_BLUE}
          icon="MapPin"
          label="حفظ موقعي"
          onClick={handleSaveCurrentLocation}
          loading={savingLocation}
        />
        <QuickAction
          color={G_ORANGE}
          icon="Share2"
          label="مشاركة الموقع"
          onClick={handleShareLiveLocation}
        />
        <QuickAction
          color={G_PURPLE}
          icon="Navigation"
          label="مسجد قريب"
          onClick={() => {
            const url = `https://www.google.com/maps/search/mosques/@${ALEPPO_LAT},${ALEPPO_LNG},13z`;
            window.open(url, "_blank", "noopener,noreferrer");
          }}
        />
      </div>

      {/* Save current location form */}
      <Card className="p-2" style={{ backgroundColor: "var(--surface-container)" }}>
        <div className="flex items-center gap-1.5">
          <div
            className="flex h-6 w-6 items-center justify-center rounded-lg shrink-0"
            style={{ backgroundColor: `${G_BLUE}22`, color: G_BLUE }}
          >
            <DynamicIcon name="Plus" className="h-3.5 w-3.5" />
          </div>
          <Input
            value={locationName}
            onChange={(e) => setLocationName(e.target.value)}
            placeholder="اسم الموقع (العمل، المنزل...)"
            className="flex-1"
            onKeyDown={(e) => e.key === "Enter" && handleSaveCurrentLocation()}
          />
          <Button
            size="sm"
            onClick={handleSaveCurrentLocation}
            disabled={savingLocation}
            style={{ backgroundColor: G_GREEN, color: "#fff" }}
            className="hover:opacity-90"
          >
            <DynamicIcon name="Save" className="h-3.5 w-3.5" />
            حفظ
          </Button>
        </div>
      </Card>

      {/* Route tracking */}
      <Card className="p-2" style={{ backgroundColor: "var(--surface-container)" }}>
        <div className="flex items-center gap-1.5 mb-1.5">
          <div
            className="flex h-6 w-6 items-center justify-center rounded-lg"
            style={{ backgroundColor: `${G_RED}22`, color: G_RED }}
          >
            <DynamicIcon name="Navigation" className="h-3.5 w-3.5" />
          </div>
          <h3 className="text-xs font-bold text-foreground">تتبع المسار</h3>
          {activeRoute && (
            <span
              className="ml-auto text-[10px] font-mono px-1.5 py-0.5 rounded-full"
              style={{ backgroundColor: `${G_GREEN}22`, color: G_GREEN }}
            >
              ● جاري التتبع
            </span>
          )}
        </div>

        {activeRoute ? (
          <div className="space-y-1.5">
            <div className="text-[10px] text-muted-foreground">
              المسار الحالي: <span className="text-foreground font-medium">{activeRoute.name}</span>
              <br />
              بدأ في: {format(new Date(activeRoute.startTime), "HH:mm", { locale: ar })}
            </div>
            <Button
              size="sm"
              className="w-full"
              onClick={handleEndRoute}
              style={{ backgroundColor: G_RED, color: "#fff" }}
            >
              <DynamicIcon name="Square" className="h-3.5 w-3.5" />
              إنهاء المسار
            </Button>
          </div>
        ) : (
          <div className="flex items-center gap-1.5">
            <Input
              value={routeName}
              onChange={(e) => setRouteName(e.target.value)}
              placeholder="اسم المسار (اختياري)"
              className="flex-1"
            />
            <Button
              size="sm"
              onClick={handleStartRoute}
              style={{ backgroundColor: G_GREEN, color: "#fff" }}
            >
              <DynamicIcon name="Play" className="h-3.5 w-3.5" />
              ابدأ
            </Button>
          </div>
        )}
      </Card>

      <div className="grid grid-cols-1 gap-1.5 lg:grid-cols-2">
        {/* Saved locations */}
        <Card className="p-2" style={{ backgroundColor: "var(--surface-container)" }}>
          <div className="flex items-center gap-1.5 mb-1.5">
            <div
              className="flex h-6 w-6 items-center justify-center rounded-lg"
              style={{ backgroundColor: `${G_YELLOW}22`, color: G_YELLOW }}
            >
              <DynamicIcon name="Star" className="h-3.5 w-3.5" />
            </div>
            <h3 className="text-xs font-bold text-foreground">الأماكن المحفوظة</h3>
            <span className="ml-auto text-[10px] text-muted-foreground">{locations.length}</span>
          </div>

          {loading ? (
            <div className="space-y-1">
              {Array.from({ length: 3 }).map((_, i) => (
                <Skeleton key={i} className="h-8 rounded-lg" />
              ))}
            </div>
          ) : locations.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-3 text-center">
              <DynamicIcon name="MapPin" className="h-6 w-6 text-muted-foreground/50 mb-1" />
              <p className="text-[10px] text-muted-foreground">لا أماكن محفوظة</p>
            </div>
          ) : (
            <div className="space-y-1 max-h-48 overflow-y-auto custom-scroll">
              <AnimatePresence>
                {locations.map((loc, i) => (
                  <motion.div
                    key={loc.id}
                    layout
                    initial={{ opacity: 0, y: 4 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, x: -10 }}
                    transition={{ delay: i * 0.02 }}
                    className="group flex items-center gap-1.5 rounded-lg p-1.5 hover:bg-white/5"
                  >
                    <div
                      className="flex h-6 w-6 items-center justify-center rounded-lg shrink-0"
                      style={{ backgroundColor: `${G_BLUE}22`, color: G_BLUE }}
                    >
                      <DynamicIcon name={loc.icon || "MapPin"} className="h-3.5 w-3.5" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-medium text-foreground truncate">{loc.name}</p>
                      <p className="text-[10px] text-muted-foreground truncate">{loc.address}</p>
                    </div>
                    <Button
                      size="sm"
                      variant="ghost"
                      className="h-6 px-1.5"
                      onClick={() => handleNavigateTo(loc)}
                      style={{ color: G_GREEN }}
                    >
                      <DynamicIcon name="Navigation" className="h-3.5 w-3.5" />
                      ملاحة
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      className="h-6 w-6 p-0 opacity-0 group-hover:opacity-100"
                      onClick={() => handleDeleteLocation(loc.id)}
                    >
                      <DynamicIcon name="Trash2" className="h-3.5 w-3.5" />
                    </Button>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          )}
        </Card>

        {/* Recent routes */}
        <Card className="p-2" style={{ backgroundColor: "var(--surface-container)" }}>
          <div className="flex items-center gap-1.5 mb-1.5">
            <div
              className="flex h-6 w-6 items-center justify-center rounded-lg"
              style={{ backgroundColor: `${G_TEAL}22`, color: G_TEAL }}
            >
              <DynamicIcon name="History" className="h-3.5 w-3.5" />
            </div>
            <h3 className="text-xs font-bold text-foreground">المسارات السابقة</h3>
            <span className="ml-auto text-[10px] text-muted-foreground">{routes.length}</span>
          </div>

          {loading ? (
            <div className="space-y-1">
              {Array.from({ length: 3 }).map((_, i) => (
                <Skeleton key={i} className="h-8 rounded-lg" />
              ))}
            </div>
          ) : routes.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-3 text-center">
              <DynamicIcon name="Navigation" className="h-6 w-6 text-muted-foreground/50 mb-1" />
              <p className="text-[10px] text-muted-foreground">لا مسارات مسجلة</p>
            </div>
          ) : (
            <div className="space-y-1 max-h-48 overflow-y-auto custom-scroll">
              {routes.map((route, i) => {
                const isDone = !!route.endTime;
                return (
                  <motion.div
                    key={route.id}
                    initial={{ opacity: 0, y: 4 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.02 }}
                    className="group flex items-center gap-1.5 rounded-lg p-1.5 hover:bg-white/5"
                  >
                    <div
                      className="flex h-6 w-6 items-center justify-center rounded-lg shrink-0"
                      style={{
                        backgroundColor: isDone ? `${G_GREEN}22` : `${G_ORANGE}22`,
                        color: isDone ? G_GREEN : G_ORANGE,
                      }}
                    >
                      <DynamicIcon name={isDone ? "CheckCircle" : "Navigation"} className="h-3.5 w-3.5" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-medium text-foreground truncate">{route.name}</p>
                      <p className="text-[10px] text-muted-foreground">
                        {formatDistanceToNow(new Date(route.startTime), { addSuffix: true, locale: ar })}
                        {route.duration ? ` · ${route.duration} دقيقة` : ""}
                      </p>
                    </div>
                    <Button
                      size="sm"
                      variant="ghost"
                      className="h-6 w-6 p-0 opacity-0 group-hover:opacity-100"
                      onClick={() => handleDeleteRoute(route.id)}
                    >
                      <DynamicIcon name="Trash2" className="h-3.5 w-3.5" />
                    </Button>
                  </motion.div>
                );
              })}
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}

function QuickAction({
  color,
  icon,
  label,
  onClick,
  loading,
}: {
  color: string;
  icon: string;
  label: string;
  onClick: () => void;
  loading?: boolean;
}) {
  return (
    <motion.button
      whileTap={{ scale: 0.96 }}
      onClick={onClick}
      disabled={loading}
      className="flex flex-col items-center gap-1 p-2 rounded-xl transition-all hover:opacity-90 disabled:opacity-50"
      style={{ backgroundColor: "var(--surface-container)" }}
    >
      <div
        className={cn("flex h-8 w-8 items-center justify-center rounded-full", loading && "animate-pulse")}
        style={{ backgroundColor: `${color}22`, color }}
      >
        <DynamicIcon name={loading ? "Loader2" : icon} className={cn("h-4 w-4", loading && "animate-spin")} />
      </div>
      <span className="text-[10px] font-medium text-foreground">{label}</span>
    </motion.button>
  );
}

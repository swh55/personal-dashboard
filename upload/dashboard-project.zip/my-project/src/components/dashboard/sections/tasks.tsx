"use client";

import * as React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger } from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { DynamicIcon } from "../icon";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { TASK_CATEGORIES, TASK_PRIORITIES } from "@/lib/constants";
import { format } from "date-fns";
import { ar } from "date-fns/locale";

interface Task {
  id: string;
  title: string;
  description?: string | null;
  category: string;
  status: string;
  priority: string;
  dueDate?: string | null;
  createdAt: string;
}

const priorityColors: Record<string, { bg: string; text: string; border: string }> = {
  low: { bg: "bg-emerald-glow/10", text: "text-emerald-glow", border: "border-emerald-glow/20" },
  medium: { bg: "bg-amber-glow/10", text: "text-amber-glow", border: "border-amber-glow/20" },
  high: { bg: "bg-rose-500/10", text: "text-rose-400", border: "border-rose-500/20" },
};

const categoryColors: Record<string, string> = {
  emerald: "text-emerald-glow",
  amber: "text-amber-glow",
  rose: "text-rose-400",
  teal: "text-teal-400",
};

export function TasksSection() {
  const [tasks, setTasks] = React.useState<Task[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [activeCategory, setActiveCategory] = React.useState<string>("shopping");
  const [filter, setFilter] = React.useState<"all" | "todo" | "doing" | "done">("all");
  const [search, setSearch] = React.useState("");
  const [dialogOpen, setDialogOpen] = React.useState(false);
  const [editingTask, setEditingTask] = React.useState<Task | null>(null);
  const { toast } = useToast();

  const fetchTasks = React.useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/tasks");
      const json = await res.json();
      if (json.success) setTasks(json.data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, []);

  React.useEffect(() => {
    fetchTasks();
  }, [fetchTasks]);

  const filteredTasks = tasks
    .filter((t) => t.category === activeCategory)
    .filter((t) => filter === "all" || t.status === filter)
    .filter((t) => !search || t.title.includes(search));

  const handleToggleStatus = async (task: Task) => {
    const newStatus = task.status === "done" ? "todo" : "done";
    try {
      await fetch("/api/tasks", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: task.id, status: newStatus }),
      });
      fetchTasks();
    } catch {
      toast({ title: "فشل التحديث", variant: "destructive" });
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await fetch(`/api/tasks?id=${id}`, { method: "DELETE" });
      toast({ title: "تم حذف المهمة" });
      fetchTasks();
    } catch {
      toast({ title: "فشل الحذف", variant: "destructive" });
    }
  };

  const categoryCounts = TASK_CATEGORIES.map((cat) => ({
    ...cat,
    count: tasks.filter((t) => t.category === cat.id && t.status !== "done").length,
    total: tasks.filter((t) => t.category === cat.id).length,
  }));

  return (
    <div className="space-y-2">
      {/* Category tabs */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
        {categoryCounts.map((cat) => {
          const isActive = activeCategory === cat.id;
          const colorClass = categoryColors[cat.color];
          return (
            <motion.button
              key={cat.id}
              whileTap={{ scale: 0.97 }}
              onClick={() => setActiveCategory(cat.id)}
              className={cn(
                "relative rounded-xl border p-2 text-right transition-all overflow-hidden",
                isActive
                  ? "border-emerald-glow/40 bg-emerald-glow/5"
                  : "border-border/40 bg-background/30 hover:border-border/60"
              )}
            >
              {isActive && (
                <motion.div
                  layoutId="active-cat"
                  className="absolute inset-0 bg-gradient-to-l from-emerald-glow/10 to-transparent"
                />
              )}
              <div className="relative">
                <div className="flex items-center justify-between mb-2">
                  <DynamicIcon name={cat.icon} className={cn("h-5 w-5", isActive ? colorClass : "text-muted-foreground")} />
                  <span className={cn(
                    "text-xs font-bold px-2 py-0.5 rounded-full",
                    cat.count > 0 ? "bg-emerald-glow/15 text-emerald-glow" : "bg-muted/30 text-muted-foreground"
                  )}>
                    {cat.count}
                  </span>
                </div>
                <p className={cn("text-xs font-semibold", isActive ? "text-foreground" : "text-muted-foreground")}>
                  {cat.label}
                </p>
                <p className="text-[10px] text-muted-foreground/70 mt-0.5">
                  {cat.total} إجمالي
                </p>
              </div>
            </motion.button>
          );
        })}
      </div>

      {/* Toolbar */}
      <Card className="glass p-2.5">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="بحث في المهام..."
            className="bg-background/50 sm:max-w-xs"
          />
          <div className="flex rounded-lg bg-muted/30 p-0.5">
            {[
              { id: "all", label: "الكل" },
              { id: "todo", label: "معلّقة" },
              { id: "doing", label: "قيد التنفيذ" },
              { id: "done", label: "منجزة" },
            ].map((f) => (
              <button
                key={f.id}
                onClick={() => setFilter(f.id as "all" | "todo" | "doing" | "done")}
                className={cn(
                  "px-3 py-1.5 text-xs rounded-md transition-all",
                  filter === f.id ? "bg-emerald-glow/15 text-emerald-glow" : "text-muted-foreground"
                )}
              >
                {f.label}
              </button>
            ))}
          </div>
          <div className="flex-1" />
          <TaskDialog
            open={dialogOpen}
            onOpenChange={setDialogOpen}
            editingTask={editingTask}
            defaultCategory={activeCategory}
            onSaved={() => {
              setDialogOpen(false);
              setEditingTask(null);
              fetchTasks();
            }}
          >
            <Button className="bg-emerald-glow hover:bg-emerald-glow/90 text-background">
              <DynamicIcon name="Plus" className="h-4 w-4" />
              مهمة جديدة
            </Button>
          </TaskDialog>
        </div>
      </Card>

      {/* Tasks list */}
      <Card className="glass p-2.5">
        {loading ? (
          <div className="space-y-2">
            {Array.from({ length: 5 }).map((_, i) => (
              <Skeleton key={i} className="h-10 rounded-lg" />
            ))}
          </div>
        ) : filteredTasks.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-muted/30 mb-1.5">
              <DynamicIcon name="CheckSquare" className="h-7 w-7 text-muted-foreground" />
            </div>
            <p className="text-sm font-medium text-foreground">لا مهام هنا</p>
            <p className="text-xs text-muted-foreground mt-1">
              ابدأ بإضافة مهمة جديدة في هذه الفئة
            </p>
          </div>
        ) : (
          <div className="space-y-2">
            <AnimatePresence>
              {filteredTasks.map((task, i) => {
                const priority = priorityColors[task.priority] || priorityColors.medium;
                const isDone = task.status === "done";
                return (
                  <motion.div
                    key={task.id}
                    layout
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    transition={{ delay: i * 0.03 }}
                    className={cn(
                      "group flex items-start gap-2 rounded-xl border p-2 transition-all",
                      isDone
                        ? "bg-background/20 border-border/20 opacity-60"
                        : cn("bg-background/40 border-border/40 hover:border-emerald-glow/30", priority.border)
                    )}
                  >
                    <Checkbox
                      checked={isDone}
                      onCheckedChange={() => handleToggleStatus(task)}
                      className="mt-1 data-[state=checked]:bg-emerald-glow data-[state=checked]:border-emerald-glow"
                    />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <p className={cn(
                          "text-sm font-medium",
                          isDone ? "line-through text-muted-foreground" : "text-foreground"
                        )}>
                          {task.title}
                        </p>
                        <span className={cn("text-[10px] px-1.5 py-0.5 rounded-full", priority.bg, priority.text)}>
                          {TASK_PRIORITIES.find((p) => p.id === task.priority)?.label}
                        </span>
                        {task.dueDate && (
                          <span className="text-[10px] text-muted-foreground flex items-center gap-1">
                            <DynamicIcon name="Clock" className="h-3 w-3" />
                            {format(new Date(task.dueDate), "d MMM", { locale: ar })}
                          </span>
                        )}
                      </div>
                      {task.description && (
                        <p className="text-xs text-muted-foreground mt-1 line-clamp-2">
                          {task.description}
                        </p>
                      )}
                    </div>
                    <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8"
                        onClick={() => {
                          setEditingTask(task);
                          setDialogOpen(true);
                        }}
                      >
                        <DynamicIcon name="Pencil" className="h-3.5 w-3.5" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 hover:text-rose-400"
                        onClick={() => handleDelete(task.id)}
                      >
                        <DynamicIcon name="Trash2" className="h-3.5 w-3.5" />
                      </Button>
                    </div>
                  </motion.div>
                );
              })}
            </AnimatePresence>
          </div>
        )}
      </Card>
    </div>
  );
}

function TaskDialog({
  open, onOpenChange, editingTask, defaultCategory, onSaved, children,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  editingTask: Task | null;
  defaultCategory: string;
  onSaved: () => void;
  children: React.ReactNode;
}) {
  const [title, setTitle] = React.useState("");
  const [description, setDescription] = React.useState("");
  const [category, setCategory] = React.useState(defaultCategory);
  const [priority, setPriority] = React.useState("medium");
  const [dueDate, setDueDate] = React.useState("");
  const { toast } = useToast();

  React.useEffect(() => {
    if (editingTask) {
      setTitle(editingTask.title);
      setDescription(editingTask.description || "");
      setCategory(editingTask.category);
      setPriority(editingTask.priority);
      setDueDate(editingTask.dueDate ? editingTask.dueDate.split("T")[0] : "");
    } else {
      setTitle("");
      setDescription("");
      setCategory(defaultCategory);
      setPriority("medium");
      setDueDate("");
    }
  }, [editingTask, defaultCategory, open]);

  const handleSave = async () => {
    if (!title) {
      toast({ title: "العنوان مطلوب", variant: "destructive" });
      return;
    }
    const payload = {
      title,
      description,
      category,
      priority,
      dueDate: dueDate ? new Date(dueDate).toISOString() : null,
    };
    try {
      if (editingTask) {
        await fetch("/api/tasks", {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ id: editingTask.id, ...payload }),
        });
        toast({ title: "تم تحديث المهمة" });
      } else {
        await fetch("/api/tasks", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
        toast({ title: "تم إضافة المهمة" });
      }
      onSaved();
    } catch {
      toast({ title: "فشل الحفظ", variant: "destructive" });
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogTrigger asChild>{children}</DialogTrigger>
      <DialogContent className="glass-strong max-w-md">
        <DialogHeader>
          <DialogTitle>{editingTask ? "تعديل مهمة" : "مهمة جديدة"}</DialogTitle>
        </DialogHeader>
        <div className="space-y-1.5">
          <div>
            <Label htmlFor="task-title">العنوان</Label>
            <Input id="task-title" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="ما المهمة؟" />
          </div>
          <div>
            <Label htmlFor="task-desc">الوصف</Label>
            <Textarea id="task-desc" value={description} onChange={(e) => setDescription(e.target.value)} placeholder="تفاصيل إضافية" rows={2} />
          </div>
          <div className="grid grid-cols-2 gap-2">
            <div>
              <Label htmlFor="task-cat">الفئة</Label>
              <Select value={category} onValueChange={setCategory}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {TASK_CATEGORIES.map((c) => (
                    <SelectItem key={c.id} value={c.id}>{c.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="task-pri">الأولوية</Label>
              <Select value={priority} onValueChange={setPriority}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {TASK_PRIORITIES.map((p) => (
                    <SelectItem key={p.id} value={p.id}>{p.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div>
            <Label htmlFor="task-due">تاريخ الاستحقاق</Label>
            <Input id="task-due" type="date" value={dueDate} onChange={(e) => setDueDate(e.target.value)} />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>إلغاء</Button>
          <Button onClick={handleSave} className="bg-emerald-glow hover:bg-emerald-glow/90 text-background">
            {editingTask ? "حفظ" : "إضافة"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

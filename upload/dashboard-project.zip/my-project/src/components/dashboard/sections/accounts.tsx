"use client";

import * as React from "react";
import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger } from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { DynamicIcon } from "../icon";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

interface Account {
  id: string;
  name: string;
  platform: string;
  username: string;
  url: string;
  icon?: string | null;
  category: string;
}

const platformConfig: Record<string, { icon: string; color: string; bg: string }> = {
  gmail: { icon: "Mail", color: "text-rose-400", bg: "bg-rose-500/15" },
  outlook: { icon: "Mail", color: "text-sky-400", bg: "bg-sky-500/15" },
  facebook: { icon: "Facebook", color: "text-blue-400", bg: "bg-blue-500/15" },
  social: { icon: "Users", color: "text-purple-400", bg: "bg-purple-500/15" },
  banking: { icon: "Building2", color: "text-emerald-glow", bg: "bg-emerald-glow/15" },
  other: { icon: "Globe", color: "text-amber-glow", bg: "bg-amber-glow/15" },
};

const categoryLabels: Record<string, string> = {
  work: "العمل",
  personal: "شخصي",
  social: "تواصل اجتماعي",
  banking: "بنكي",
};

export function AccountsSection() {
  const [accounts, setAccounts] = React.useState<Account[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [dialogOpen, setDialogOpen] = React.useState(false);
  const [editingAccount, setEditingAccount] = React.useState<Account | null>(null);
  const { toast } = useToast();

  const fetchAccounts = React.useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/accounts");
      const json = await res.json();
      if (json.success) setAccounts(json.data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, []);

  React.useEffect(() => {
    fetchAccounts();
  }, [fetchAccounts]);

  const handleOpen = (url: string) => {
    window.open(url, "_blank", "noopener,noreferrer");
  };

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({ title: "تم نسخ النص" });
  };

  const handleDelete = async (id: string) => {
    await fetch(`/api/accounts?id=${id}`, { method: "DELETE" });
    toast({ title: "تم حذف الحساب" });
    fetchAccounts();
  };

  // Group by category
  const grouped = accounts.reduce((acc, a) => {
    if (!acc[a.category]) acc[a.category] = [];
    acc[a.category].push(a);
    return acc;
  }, {} as Record<string, Account[]>);

  return (
    <div className="space-y-2">
      {/* Header */}
      <Card className="glass p-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="flex h-7 w-7 items-center justify-center rounded-xl bg-emerald-glow/15 text-emerald-glow">
              <DynamicIcon name="Globe" className="h-5 w-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-foreground">الحسابات على الإنترنت</h2>
              <p className="text-xs text-muted-foreground">{accounts.length} حساب محفوظ</p>
            </div>
          </div>
          <AccountDialog
            open={dialogOpen}
            onOpenChange={setDialogOpen}
            editingAccount={editingAccount}
            onSaved={() => {
              setDialogOpen(false);
              setEditingAccount(null);
              fetchAccounts();
            }}
          >
            <Button className="bg-emerald-glow hover:bg-emerald-glow/90 text-background">
              <DynamicIcon name="Plus" className="h-4 w-4" />
              إضافة حساب
            </Button>
          </AccountDialog>
        </div>
      </Card>

      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
          {Array.from({ length: 3 }).map((_, i) => (
            <Skeleton key={i} className="h-12 rounded-lg" />
          ))}
        </div>
      ) : (
        <div className="space-y-1.5">
          {Object.entries(grouped).map(([category, items], catIdx) => (
            <div key={category}>
              <h3 className="text-sm font-bold text-foreground mb-1.5 flex items-center gap-2">
                <DynamicIcon name="Folder" className="h-4 w-4 text-emerald-glow" />
                {categoryLabels[category] || category}
                <span className="text-xs text-muted-foreground">({items.length})</span>
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
                {items.map((account, i) => {
                  const config = platformConfig[account.platform] || platformConfig.other;
                  return (
                    <motion.div
                      key={account.id}
                      initial={{ opacity: 0, y: 8 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: (catIdx * 0.1) + (i * 0.03) }}
                    >
                      <Card className="glass p-2.5 hover:border-emerald-glow/30 transition-all group">
                        <div className="flex items-start gap-2 mb-1.5">
                          <div className={cn("flex h-8 w-8 items-center justify-center rounded-xl shrink-0", config.bg, config.color)}>
                            <DynamicIcon name={config.icon} className="h-5 w-5" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-bold text-foreground truncate">{account.name}</p>
                            <p className="text-[11px] text-muted-foreground truncate" dir="ltr">{account.username}</p>
                            <span className="text-[10px] text-muted-foreground capitalize">{account.platform}</span>
                          </div>
                        </div>

                        <div className="flex gap-1.5">
                          <Button
                            size="sm"
                            variant="outline"
                            className="flex-1 h-8 bg-emerald-glow/5 border-emerald-glow/20 hover:bg-emerald-glow/15 text-emerald-glow"
                            onClick={() => handleOpen(account.url)}
                          >
                            <DynamicIcon name="ExternalLink" className="h-3.5 w-3.5" />
                            فتح
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            className="h-8 px-2"
                            onClick={() => handleCopy(account.username)}
                          >
                            <DynamicIcon name="Copy" className="h-3.5 w-3.5" />
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            className="h-8 px-2 opacity-0 group-hover:opacity-100"
                            onClick={() => { setEditingAccount(account); setDialogOpen(true); }}
                          >
                            <DynamicIcon name="Pencil" className="h-3.5 w-3.5" />
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            className="h-8 px-2 hover:text-rose-400 opacity-0 group-hover:opacity-100"
                            onClick={() => handleDelete(account.id)}
                          >
                            <DynamicIcon name="Trash2" className="h-3.5 w-3.5" />
                          </Button>
                        </div>
                      </Card>
                    </motion.div>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function AccountDialog({
  open, onOpenChange, editingAccount, onSaved, children,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  editingAccount: Account | null;
  onSaved: () => void;
  children: React.ReactNode;
}) {
  const [name, setName] = React.useState("");
  const [platform, setPlatform] = React.useState("other");
  const [username, setUsername] = React.useState("");
  const [url, setUrl] = React.useState("");
  const [category, setCategory] = React.useState("personal");
  const { toast } = useToast();

  React.useEffect(() => {
    if (editingAccount) {
      setName(editingAccount.name);
      setPlatform(editingAccount.platform);
      setUsername(editingAccount.username);
      setUrl(editingAccount.url);
      setCategory(editingAccount.category);
    } else {
      setName(""); setPlatform("other"); setUsername(""); setUrl(""); setCategory("personal");
    }
  }, [editingAccount, open]);

  const handleSave = async () => {
    if (!name || !url) {
      toast({ title: "الاسم والرابط مطلوبان", variant: "destructive" });
      return;
    }
    const payload = { name, platform, username, url, category };
    try {
      if (editingAccount) {
        await fetch("/api/accounts", {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ id: editingAccount.id, ...payload }),
        });
        toast({ title: "تم التحديث" });
      } else {
        await fetch("/api/accounts", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
        toast({ title: "تمت الإضافة" });
      }
      onSaved();
    } catch {
      toast({ title: "فشل الحفظ", variant: "destructive" });
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogTrigger asChild>{children}</DialogTrigger>
      <DialogContent className="glass-strong max-w-md">
        <DialogHeader>
          <DialogTitle>{editingAccount ? "تعديل حساب" : "إضافة حساب"}</DialogTitle>
        </DialogHeader>
        <div className="space-y-1.5">
          <div>
            <Label htmlFor="a-name">اسم الحساب</Label>
            <Input id="a-name" value={name} onChange={(e) => setName(e.target.value)} placeholder="مثلاً: بريد العمل" />
          </div>
          <div className="grid grid-cols-2 gap-2">
            <div>
              <Label htmlFor="a-platform">المنصة</Label>
              <Select value={platform} onValueChange={setPlatform}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent className="glass-strong">
                  <SelectItem value="gmail">Gmail</SelectItem>
                  <SelectItem value="outlook">Outlook</SelectItem>
                  <SelectItem value="facebook">Facebook</SelectItem>
                  <SelectItem value="social">شبكة اجتماعية</SelectItem>
                  <SelectItem value="banking">بنك</SelectItem>
                  <SelectItem value="other">أخرى</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="a-cat">الفئة</Label>
              <Select value={category} onValueChange={setCategory}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent className="glass-strong">
                  <SelectItem value="work">العمل</SelectItem>
                  <SelectItem value="personal">شخصي</SelectItem>
                  <SelectItem value="social">اجتماعي</SelectItem>
                  <SelectItem value="banking">بنكي</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div>
            <Label htmlFor="a-username">اسم المستخدم / البريد</Label>
            <Input id="a-username" value={username} onChange={(e) => setUsername(e.target.value)} dir="ltr" />
          </div>
          <div>
            <Label htmlFor="a-url">الرابط</Label>
            <Input id="a-url" value={url} onChange={(e) => setUrl(e.target.value)} dir="ltr" placeholder="https://..." />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>إلغاء</Button>
          <Button onClick={handleSave} className="bg-emerald-glow hover:bg-emerald-glow/90 text-background">
            {editingAccount ? "حفظ" : "إضافة"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

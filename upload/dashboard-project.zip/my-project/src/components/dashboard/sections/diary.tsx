"use client";

import * as React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger } from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { DynamicIcon } from "../icon";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { format } from "date-fns";
import { ar } from "date-fns/locale";
import { formatSyrianDate, SYRIAN_MONTHS } from "@/lib/syrian-date";

interface DiaryEntry {
  id: string;
  date: string;
  mood: string;
  title: string | null;
  content: string;
  weather: string | null;
}

const moods = [
  { id: "happy", emoji: "😊", label: "سعيد", color: "text-emerald-glow" },
  { id: "excited", emoji: "🤩", label: "متحمس", color: "text-amber-glow" },
  { id: "neutral", emoji: "😐", label: "محايد", color: "text-muted-foreground" },
  { id: "tired", emoji: "😴", label: "متعب", color: "text-purple-400" },
  { id: "sad", emoji: "😢", label: "حزين", color: "text-blue-400" },
  { id: "angry", emoji: "😠", label: "غاضب", color: "text-rose-400" },
];

const moodMap = Object.fromEntries(moods.map(m => [m.id, m]));

export function DiarySection() {
  const [entries, setEntries] = React.useState<DiaryEntry[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [dialogOpen, setDialogOpen] = React.useState(false);
  const [title, setTitle] = React.useState("");
  const [content, setContent] = React.useState("");
  const [mood, setMood] = React.useState("neutral");
  const { toast } = useToast();

  const fetchData = React.useCallback(async () => {
    try {
      const res = await fetch("/api/diary");
      const json = await res.json();
      if (json.success) setEntries(json.data);
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  }, []);

  React.useEffect(() => { fetchData(); }, [fetchData]);

  const handleAdd = async () => {
    if (!content) { toast({ title: "المحتوى مطلوب", variant: "destructive" }); return; }
    try {
      await fetch("/api/diary", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title, content, mood }),
      });
      toast({ title: "تم حفظ المذكرة 📝" });
      setTitle(""); setContent(""); setMood("neutral"); setDialogOpen(false);
      fetchData();
    } catch { toast({ title: "فشل الحفظ", variant: "destructive" }); }
  };

  const handleDelete = async (id: string) => {
    await fetch(`/api/diary?id=${id}`, { method: "DELETE" });
    fetchData();
  };

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="flex h-7 w-7 items-center justify-center rounded-xl bg-purple-500/15 text-purple-400">
            <DynamicIcon name="Book" className="h-5 w-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-foreground">المذكرات الشخصية</h2>
            <p className="text-xs text-muted-foreground">{entries.length} مذكرة</p>
          </div>
        </div>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-emerald-glow hover:bg-emerald-glow/90 text-background">
              <DynamicIcon name="Plus" className="h-4 w-4" />
              مذكرة جديدة
            </Button>
          </DialogTrigger>
          <DialogContent className="glass-strong max-w-md">
            <DialogHeader><DialogTitle>مذكرة جديدة</DialogTitle></DialogHeader>
            <div className="space-y-1.5">
              <div>
                <Label>المزاج</Label>
                <div className="flex gap-2 mt-1">
                  {moods.map((m) => (
                    <button
                      key={m.id}
                      onClick={() => setMood(m.id)}
                      className={cn(
                        "flex flex-col items-center gap-1 p-2 rounded-lg border-2 transition-all flex-1",
                        mood === m.id ? "border-current " + m.color : "border-transparent"
                      )}
                    >
                      <span className="text-xl">{m.emoji}</span>
                      <span className="text-[9px]">{m.label}</span>
                    </button>
                  ))}
                </div>
              </div>
              <div><Label>العنوان (اختياري)</Label><Input value={title} onChange={(e) => setTitle(e.target.value)} /></div>
              <div><Label>المحتوى</Label><Textarea value={content} onChange={(e) => setContent(e.target.value)} rows={5} /></div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setDialogOpen(false)}>إلغاء</Button>
              <Button onClick={handleAdd} className="bg-emerald-glow hover:bg-emerald-glow/90 text-background">حفظ</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {loading ? (
        <div className="space-y-1.5">{Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-12 rounded-lg" />)}</div>
      ) : entries.length === 0 ? (
        <Card className="glass p-12 text-center">
          <DynamicIcon name="Book" className="h-8 w-8 text-muted-foreground/50 mx-auto mb-1.5" />
          <p className="text-sm font-medium text-foreground">لا مذكرات بعد</p>
          <p className="text-xs text-muted-foreground mt-1">ابدأ بكتابة يومك</p>
        </Card>
      ) : (
        <div className="space-y-1.5">
          <AnimatePresence>
            {entries.map((entry, i) => {
              const m = moodMap[entry.mood] || moodMap.neutral;
              return (
                <motion.div
                  key={entry.id}
                  layout
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ delay: i * 0.03 }}
                >
                  <Card className="glass p-2 group">
                    <div className="flex items-start gap-2">
                      <div className="text-3xl shrink-0">{m.emoji}</div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between mb-1">
                          {entry.title && <h3 className="text-sm font-bold text-foreground">{entry.title}</h3>}
                          <span className="text-[10px] text-muted-foreground ml-auto">
                            {formatSyrianDate(new Date(entry.date), "EEEE d MMMM yyyy")}
                          </span>
                        </div>
                        <p className="text-sm text-foreground/80 whitespace-pre-wrap line-clamp-2">{entry.content}</p>
                        <div className="flex items-center gap-2 mt-2">
                          <span className={cn("text-[10px]", m.color)}>{m.label}</span>
                          {entry.weather && <span className="text-[10px] text-muted-foreground">• {entry.weather}</span>}
                        </div>
                      </div>
                      <Button variant="ghost" size="icon" className="h-8 w-8 opacity-0 group-hover:opacity-100 hover:text-rose-400" onClick={() => handleDelete(entry.id)}>
                        <DynamicIcon name="Trash2" className="h-3.5 w-3.5" />
                      </Button>
                    </div>
                  </Card>
                </motion.div>
              );
            })}
          </AnimatePresence>
        </div>
      )}
    </div>
  );
}

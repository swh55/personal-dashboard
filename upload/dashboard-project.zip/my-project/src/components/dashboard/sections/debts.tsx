"use client";

import * as React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger } from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { DynamicIcon } from "../icon";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { formatDistanceToNow, isPast, differenceInDays } from "date-fns";
import { ar } from "date-fns/locale";

interface Debt {
  id: string;
  personName: string;
  amount: number;
  currency: string;
  type: string;
  description: string | null;
  dueDate: string | null;
  settled: boolean;
  createdAt: string;
}

const formatAmount = (n: number) => n.toLocaleString("en-US", { maximumFractionDigits: 0 });

export function DebtsSection() {
  const [debts, setDebts] = React.useState<Debt[]>([]);
  const [stats, setStats] = React.useState({ totalOwed: 0, totalOwe: 0, count: 0 });
  const [loading, setLoading] = React.useState(true);
  const [dialogOpen, setDialogOpen] = React.useState(false);
  const { toast } = useToast();

  const [personName, setPersonName] = React.useState("");
  const [amount, setAmount] = React.useState("");
  const [currency, setCurrency] = React.useState("syp");
  const [type, setType] = React.useState("owed");
  const [description, setDescription] = React.useState("");
  const [dueDate, setDueDate] = React.useState("");

  const fetchData = React.useCallback(async () => {
    try {
      const res = await fetch("/api/debts");
      const json = await res.json();
      if (json.success) { setDebts(json.data); setStats(json.stats); }
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  }, []);

  React.useEffect(() => { fetchData(); }, [fetchData]);

  const handleAdd = async () => {
    if (!personName || !amount) { toast({ title: "الاسم والمبلغ مطلوبان", variant: "destructive" }); return; }
    try {
      await fetch("/api/debts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ personName, amount: Number(amount), currency, type, description, dueDate }),
      });
      toast({ title: "تم إضافة الدين" });
      setPersonName(""); setAmount(""); setDescription(""); setDueDate("");
      setDialogOpen(false);
      fetchData();
    } catch { toast({ title: "فشل الإضافة", variant: "destructive" }); }
  };

  const handleSettle = async (id: string) => {
    await fetch("/api/debts", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id, settled: true }),
    });
    toast({ title: "تمت التسوية ✓" });
    fetchData();
  };

  const handleDelete = async (id: string) => {
    await fetch(`/api/debts?id=${id}`, { method: "DELETE" });
    fetchData();
  };

  return (
    <div className="space-y-2">
      {/* Stats */}
      <div className="grid grid-cols-3 gap-2">
        <Card className="glass p-2.5">
          <div className="flex items-center gap-2">
            <div className="flex h-7 w-7 items-center justify-center rounded-xl bg-emerald-glow/15 text-emerald-glow">
              <DynamicIcon name="TrendingUp" className="h-5 w-5" />
            </div>
            <div>
              <p className="text-xl font-bold text-emerald-glow">{formatAmount(stats.totalOwed)}</p>
              <p className="text-[11px] text-muted-foreground">مستحقة لي (ل.س)</p>
            </div>
          </div>
        </Card>
        <Card className="glass p-2.5">
          <div className="flex items-center gap-2">
            <div className="flex h-7 w-7 items-center justify-center rounded-xl bg-rose-500/15 text-rose-400">
              <DynamicIcon name="TrendingDown" className="h-5 w-5" />
            </div>
            <div>
              <p className="text-xl font-bold text-rose-400">{formatAmount(stats.totalOwe)}</p>
              <p className="text-[11px] text-muted-foreground">أنا مدين (ل.س)</p>
            </div>
          </div>
        </Card>
        <Card className="glass p-2.5">
          <div className="flex items-center gap-2">
            <div className="flex h-7 w-7 items-center justify-center rounded-xl bg-amber-glow/15 text-amber-glow">
              <DynamicIcon name="HandCoins" className="h-5 w-5" />
            </div>
            <div>
              <p className="text-xl font-bold text-amber-glow">{stats.count}</p>
              <p className="text-[11px] text-muted-foreground">ديون نشطة</p>
            </div>
          </div>
        </Card>
      </div>

      {/* Add button */}
      <div className="flex justify-end">
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-emerald-glow hover:bg-emerald-glow/90 text-background">
              <DynamicIcon name="Plus" className="h-4 w-4" />
              إضافة دين
            </Button>
          </DialogTrigger>
          <DialogContent className="glass-strong max-w-md">
            <DialogHeader><DialogTitle>إضافة دين جديد</DialogTitle></DialogHeader>
            <div className="space-y-1.5">
              <div><Label>اسم الشخص</Label><Input value={personName} onChange={(e) => setPersonName(e.target.value)} /></div>
              <div className="grid grid-cols-2 gap-2">
                <div><Label>المبلغ</Label><Input type="number" value={amount} onChange={(e) => setAmount(e.target.value)} dir="ltr" /></div>
                <div><Label>العملة</Label>
                  <Select value={currency} onValueChange={setCurrency}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent className="glass-strong"><SelectItem value="syp">ليرة سورية</SelectItem><SelectItem value="usd">دولار</SelectItem></SelectContent>
                  </Select>
                </div>
              </div>
              <div><Label>النوع</Label>
                <Select value={type} onValueChange={setType}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent className="glass-strong"><SelectItem value="owed">مستحقة لي</SelectItem><SelectItem value="owe">أنا مدين</SelectItem></SelectContent>
                </Select>
              </div>
              <div><Label>تاريخ الاستحقاق (اختياري)</Label><Input type="date" value={dueDate} onChange={(e) => setDueDate(e.target.value)} /></div>
              <div><Label>الوصف (اختياري)</Label><Input value={description} onChange={(e) => setDescription(e.target.value)} /></div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setDialogOpen(false)}>إلغاء</Button>
              <Button onClick={handleAdd} className="bg-emerald-glow hover:bg-emerald-glow/90 text-background">إضافة</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {/* List */}
      <Card className="glass p-2">
        {loading ? (
          <Skeleton className="h-10 rounded-lg" />
        ) : debts.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-3 text-center">
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-muted/30 mb-1.5">
              <DynamicIcon name="HandCoins" className="h-6 w-6 text-muted-foreground" />
            </div>
            <p className="text-sm font-medium text-foreground">لا ديون نشطة</p>
            <p className="text-xs text-muted-foreground mt-1">أنت خالٍ من الديون الحالية</p>
          </div>
        ) : (
          <div className="space-y-2">
            <AnimatePresence>
              {debts.map((debt, i) => {
                const isOwed = debt.type === "owed";
                const overdue = debt.dueDate && isPast(new Date(debt.dueDate));
                const daysOverdue = debt.dueDate ? differenceInDays(new Date(), new Date(debt.dueDate)) : 0;
                return (
                  <motion.div
                    key={debt.id}
                    layout
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    transition={{ delay: i * 0.03 }}
                    className={cn(
                      "group flex items-center gap-2 rounded-xl border p-2 transition-all",
                      overdue ? "border-rose-500/30 bg-rose-500/5" : "border-border/40 bg-background/30"
                    )}
                  >
                    <div className={cn(
                      "flex h-7 w-7 items-center justify-center rounded-lg shrink-0",
                      isOwed ? "bg-emerald-glow/15 text-emerald-glow" : "bg-rose-500/15 text-rose-400"
                    )}>
                      <DynamicIcon name={isOwed ? "TrendingUp" : "TrendingDown"} className="h-5 w-5" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-bold text-foreground">{debt.personName}</p>
                      <div className="flex items-center gap-2 mt-0.5">
                        <span className={cn(
                          "text-xs font-mono font-bold",
                          isOwed ? "text-emerald-glow" : "text-rose-400"
                        )}>
                          {isOwed ? "+" : "-"}{formatAmount(debt.amount)} {debt.currency === "usd" ? "$" : "ل.س"}
                        </span>
                        {debt.description && <span className="text-[10px] text-muted-foreground truncate">{debt.description}</span>}
                      </div>
                      {debt.dueDate && (
                        <p className={cn("text-[10px] mt-0.5", overdue ? "text-rose-400 font-bold" : "text-muted-foreground")}>
                          {overdue ? `متأخر ${daysOverdue} يوم` : `استحقاق: ${new Date(debt.dueDate).toLocaleDateString("ar-SY")}`}
                        </p>
                      )}
                    </div>
                    <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      <Button size="sm" variant="outline" className="h-8 bg-emerald-glow/5 border-emerald-glow/20 text-emerald-glow" onClick={() => handleSettle(debt.id)}>
                        تسوية
                      </Button>
                      <Button variant="ghost" size="icon" className="h-8 w-8 hover:text-rose-400" onClick={() => handleDelete(debt.id)}>
                        <DynamicIcon name="Trash2" className="h-3.5 w-3.5" />
                      </Button>
                    </div>
                  </motion.div>
                );
              })}
            </AnimatePresence>
          </div>
        )}
      </Card>
    </div>
  );
}

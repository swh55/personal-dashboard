"use client";

import * as React from "react";
import {
  LayoutDashboard, Calendar, Phone, Users, CheckSquare, Wallet, Globe,
  Cake, StickyNote, Sparkles, ShoppingCart, Package, Home, Building2,
  Sun, Cloud, CloudSun, CloudRain, CloudSnow, CloudFog, CloudDrizzle,
  CloudLightning, CloudRainWind, Wind, Droplets, Gauge, Mail, Facebook,
  Star, Heart, Plus, Trash2, Pencil, X, Check, ChevronLeft, ChevronRight,
  ChevronDown, ChevronUp, Search, Phone as PhoneIcon, MessageCircle,
  Clock, MapPin, Bell, Settings, Menu, Moon, Sunrise, Sunset, Coffee,
  Briefcase, AlertCircle, Loader2, Copy, ExternalLink, Filter, ArrowUp,
  ArrowDown, TrendingUp, TrendingDown, Coins, DollarSign, Banknote,
  Crown, User, UserPlus, PhoneCall, PhoneMissed, PhoneIncoming, PhoneOutgoing,
  Edit, Save, MoreVertical, Pin, CalendarDays, CalendarRange,
  Download, Share2, RefreshCw, Eye, EyeOff, Maximize2, Minimize2,
  Folder, Palette, Zap, Send, Mic, Volume2, Camera, MessageSquare,
  Lightbulb, Tag, Plane, Book, Compass, Languages, Keyboard, Lock,
  Trophy, Target, List, Layout, Calculator, QrCode, ChartBar,
  CheckCircle, Activity, Flame, Pause, Play, RotateCcw, Command,
  Receipt, Car, Gamepad2, PieChart, BarChart3, HelpCircle, CornerDownLeft,
  History, Shield, ShieldCheck, Upload, Trash, LogOut, Database,
  FileText, BellRing, HandCoins, BookOpen, Scissors, Shirt, Navigation,
  Wrench, Leaf, Music, Apple, Beef, Award, Medal, Gem, Diamond, Smile,
  Waves, PersonStanding, PiggyBank, Rocket, Headphones, Dumbbell,
  CalendarCheck, Milestone, SunMedium, Snowflake, Trees, Flower2,
  type LucideProps,
} from "lucide-react";

const iconMap: Record<string, React.ComponentType<LucideProps>> = {
  LayoutDashboard, Calendar, Phone, Users, CheckSquare, Wallet, Globe,
  Cake, StickyNote, Sparkles, ShoppingCart, Package, Home, Building2,
  Sun, Cloud, CloudSun, CloudRain, CloudSnow, CloudFog, CloudDrizzle,
  CloudLightning, CloudRainWind, Wind, Droplets, Gauge, Mail, Facebook,
  Star, Heart, Plus, Trash2, Pencil, X, Check, ChevronLeft, ChevronRight,
  ChevronDown, ChevronUp, Search, MessageCircle, Clock, MapPin, Bell,
  Settings, Menu, Moon, Sunrise, Sunset, Coffee, Briefcase, AlertCircle,
  Loader2, Copy, ExternalLink, Filter, ArrowUp, ArrowDown, TrendingUp,
  TrendingDown, Coins, DollarSign, Banknote, Crown, User, UserPlus,
  PhoneCall, PhoneMissed, PhoneIncoming, PhoneOutgoing, Edit, Save,
  MoreVertical, Pin, CalendarDays, CalendarRange, Download, Share2,
  RefreshCw, Eye, EyeOff, Maximize2, Minimize2,
  Folder, Palette, Zap, Send, Mic, Volume2, Camera, MessageSquare,
  Lightbulb, Tag, Plane, Book, Compass, Languages, Keyboard, Lock,
  Trophy, Target, List, Layout, Calculator, QrCode, ChartBar,
  CheckCircle, Activity, Flame, Pause, Play, RotateCcw, Command,
  Receipt, Car, Gamepad2, PieChart, BarChart3, HelpCircle, CornerDownLeft,
  History, Shield, ShieldCheck, Upload, Trash, LogOut, Database,
  FileText, BellRing, HandCoins, BookOpen, Scissors, Shirt, Navigation,
  Wrench, Leaf, Music, Apple, Beef, Award, Medal, Gem, Diamond, Smile,
  Waves, PersonStanding, PiggyBank, Rocket, Headphones, Dumbbell,
  CalendarCheck, Milestone, SunMedium, Snowflake, Trees, Flower2,
};

export interface DynamicIconProps extends LucideProps {
  name: string;
}

export const DynamicIcon = React.forwardRef<SVGSVGElement, DynamicIconProps>(
  ({ name, ...props }, ref) => {
    const Icon = iconMap[name] || Sparkles;
    return <Icon ref={ref} {...props} />;
  }
);
DynamicIcon.displayName = "DynamicIcon";

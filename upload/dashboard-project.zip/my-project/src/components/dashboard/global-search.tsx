"use client";

import * as React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { DynamicIcon } from "./icon";
import { useDashboardStore } from "@/store/use-dashboard-store";
import { cn } from "@/lib/utils";

interface SearchResult {
  tasks: Array<{ id: string; title: string; category: string; status: string }>;
  contacts: Array<{ id: string; name: string; phone: string; relation: string }>;
  notes: Array<{ id: string; title: string; content: string }>;
  events: Array<{ id: string; title: string; startDate: string; type: string }>;
  occasions: Array<{ id: string; title: string; date: string }>;
  expenses: Array<{ id: string; amount: number; currency: string; description: string | null; category: string }>;
}

interface ResultGroup {
  type: keyof SearchResult;
  label: string;
  icon: string;
  color: string;
  items: Array<{ id: string; title: string; subtitle?: string; section: string }>;
}

const colorMap: Record<string, string> = {
  emerald: "text-emerald-glow bg-emerald-glow/10",
  amber: "text-amber-glow bg-amber-glow/10",
  rose: "text-rose-400 bg-rose-500/10",
  teal: "text-teal-400 bg-teal-500/10",
  purple: "text-purple-400 bg-purple-500/10",
  slate: "text-slate-400 bg-slate-500/10",
};

export function GlobalSearch() {
  const [open, setOpen] = React.useState(false);
  const [query, setQuery] = React.useState("");
  const [results, setResults] = React.useState<SearchResult | null>(null);
  const [loading, setLoading] = React.useState(false);
  const [selectedIndex, setSelectedIndex] = React.useState(0);
  const { setActiveSection } = useDashboardStore();
  const inputRef = React.useRef<HTMLInputElement>(null);
  const debounceRef = React.useRef<ReturnType<typeof setTimeout> | null>(null);

  // فتح بـ Ctrl+Shift+F أو Cmd+Shift+F
  React.useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.shiftKey && e.key.toLowerCase() === "f") {
        e.preventDefault();
        setOpen((o) => !o);
      }
      if (e.key === "Escape" && open) {
        setOpen(false);
      }
    };
    const openHandler = () => setOpen(true);
    window.addEventListener("keydown", handler);
    window.addEventListener("open-global-search", openHandler);
    return () => {
      window.removeEventListener("keydown", handler);
      window.removeEventListener("open-global-search", openHandler);
    };
  }, [open]);

  React.useEffect(() => {
    if (open) {
      setTimeout(() => inputRef.current?.focus(), 50);
      setQuery("");
      setResults(null);
    }
  }, [open]);

  // البحث مع debounce
  React.useEffect(() => {
    if (!query.trim() || query.length < 2) {
      setResults(null);
      return;
    }
    if (debounceRef.current) clearTimeout(debounceRef.current);
    setLoading(true);
    debounceRef.current = setTimeout(async () => {
      try {
        const res = await fetch(`/api/search?q=${encodeURIComponent(query)}`);
        const json = await res.json();
        if (json.success) setResults(json.data);
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    }, 300);
    return () => {
      if (debounceRef.current) clearTimeout(debounceRef.current);
    };
  }, [query]);

  const groups: ResultGroup[] = React.useMemo(() => {
    if (!results) return [];
    const groups: ResultGroup[] = [];
    if (results.tasks.length > 0) {
      groups.push({
        type: "tasks",
        label: "المهام",
        icon: "CheckSquare",
        color: "emerald",
        items: results.tasks.map((t) => ({ id: t.id, title: t.title, subtitle: t.category, section: "tasks" })),
      });
    }
    if (results.contacts.length > 0) {
      groups.push({
        type: "contacts",
        label: "جهات الاتصال",
        icon: "Users",
        color: "amber",
        items: results.contacts.map((c) => ({ id: c.id, title: c.name, subtitle: c.phone, section: "contacts" })),
      });
    }
    if (results.notes.length > 0) {
      groups.push({
        type: "notes",
        label: "الملاحظات",
        icon: "StickyNote",
        color: "teal",
        items: results.notes.map((n) => ({ id: n.id, title: n.title, subtitle: n.content.slice(0, 40), section: "notes" })),
      });
    }
    if (results.events.length > 0) {
      groups.push({
        type: "events",
        label: "الأحداث",
        icon: "Calendar",
        color: "rose",
        items: results.events.map((e) => ({ id: e.id, title: e.title, subtitle: new Date(e.startDate).toLocaleDateString("ar-SY"), section: "calendar" })),
      });
    }
    if (results.occasions.length > 0) {
      groups.push({
        type: "occasions",
        label: "المناسبات",
        icon: "Cake",
        color: "purple",
        items: results.occasions.map((o) => ({ id: o.id, title: o.title, subtitle: new Date(o.date).toLocaleDateString("ar-SY"), section: "occasions" })),
      });
    }
    if (results.expenses.length > 0) {
      groups.push({
        type: "expenses",
        label: "المصروفات",
        icon: "Receipt",
        color: "rose",
        items: results.expenses.map((e) => ({ id: e.id, title: e.description || e.category, subtitle: `${e.amount} ${e.currency}`, section: "expenses" })),
      });
    }
    return groups;
  }, [results]);

  const flatItems = groups.flatMap((g) => g.items);
  const totalResults = flatItems.length;

  const handleSelect = (section: string) => {
    setActiveSection(section as never);
    setOpen(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "ArrowDown") {
      e.preventDefault();
      setSelectedIndex((i) => Math.min(i + 1, Math.max(flatItems.length - 1, 0)));
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setSelectedIndex((i) => Math.max(i - 1, 0));
    } else if (e.key === "Enter") {
      e.preventDefault();
      if (flatItems[selectedIndex]) handleSelect(flatItems[selectedIndex].section);
    }
  };

  let runningIndex = -1;

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[110] flex items-start justify-center pt-[12vh] px-4"
          onClick={() => setOpen(false)}
        >
          <div className="absolute inset-0 bg-background/60 backdrop-blur-sm" />
          <motion.div
            initial={{ opacity: 0, scale: 0.96, y: -10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.96, y: -10 }}
            transition={{ type: "spring", stiffness: 400, damping: 30 }}
            className="relative w-full max-w-xl glass-strong rounded-2xl shadow-2xl overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Search input */}
            <div className="flex items-center gap-3 px-4 py-3.5 border-b border-border/40">
              <DynamicIcon name="Search" className="h-5 w-5 text-emerald-glow shrink-0" />
              <input
                ref={inputRef}
                value={query}
                onChange={(e) => {
                  setQuery(e.target.value);
                  setSelectedIndex(0);
                }}
                onKeyDown={handleKeyDown}
                placeholder="ابحث في كل البيانات... (مهام، جهات اتصال، ملاحظات، أحداث، مصروفات)"
                className="flex-1 bg-transparent text-sm text-foreground placeholder:text-muted-foreground outline-none"
              />
              {loading && <DynamicIcon name="Loader2" className="h-4 w-4 animate-spin text-emerald-glow" />}
              <kbd className="hidden sm:flex items-center gap-0.5 px-2 py-0.5 rounded-md bg-muted/40 text-[10px] text-muted-foreground font-mono">
                ESC
              </kbd>
            </div>

            {/* Results */}
            <div className="max-h-[55vh] overflow-y-auto custom-scroll p-2">
              {!query.trim() || query.length < 2 ? (
                <div className="flex flex-col items-center justify-center py-12 text-center">
                  <DynamicIcon name="Search" className="h-10 w-10 text-muted-foreground/40 mb-2" />
                  <p className="text-sm text-muted-foreground">ابحث في كل بياناتك</p>
                  <p className="text-[11px] text-muted-foreground/70 mt-1">
                    مهام، جهات اتصال، ملاحظات، أحداث، مناسبات، مصروفات
                  </p>
                </div>
              ) : totalResults === 0 && !loading ? (
                <div className="flex flex-col items-center justify-center py-10 text-center">
                  <DynamicIcon name="Search" className="h-8 w-8 text-muted-foreground/50 mb-2" />
                  <p className="text-sm text-muted-foreground">لا نتائج لـ "{query}"</p>
                </div>
              ) : (
                groups.map((group) => (
                  <div key={group.type} className="mb-2">
                    <p className="px-3 py-1.5 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground/70 flex items-center gap-1.5">
                      <DynamicIcon name={group.icon} className={cn("h-3 w-3", colorMap[group.color].split(" ")[0])} />
                      {group.label} ({group.items.length})
                    </p>
                    {group.items.map((item) => {
                      runningIndex++;
                      const idx = runningIndex;
                      const isSelected = idx === selectedIndex;
                      return (
                        <button
                          key={item.id}
                          onClick={() => handleSelect(item.section)}
                          onMouseEnter={() => setSelectedIndex(idx)}
                          className={cn(
                            "w-full flex items-center gap-3 rounded-xl px-3 py-2.5 text-right transition-all",
                            isSelected ? "bg-emerald-glow/10 border border-emerald-glow/20" : "border border-transparent hover:bg-accent/30"
                          )}
                        >
                          <div className={cn(
                            "flex h-8 w-8 items-center justify-center rounded-lg shrink-0",
                            isSelected ? colorMap[group.color] : "bg-muted/30 text-muted-foreground"
                          )}>
                            <DynamicIcon name={group.icon} className="h-4 w-4" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium text-foreground truncate">{item.title}</p>
                            {item.subtitle && (
                              <p className="text-[11px] text-muted-foreground truncate">{item.subtitle}</p>
                            )}
                          </div>
                          {isSelected && <DynamicIcon name="ChevronLeft" className="h-4 w-4 text-emerald-glow shrink-0" />}
                        </button>
                      );
                    })}
                  </div>
                ))
              )}
            </div>

            {/* Footer */}
            <div className="flex items-center justify-between px-4 py-2 border-t border-border/40 bg-background/30">
              <div className="flex items-center gap-3 text-[10px] text-muted-foreground">
                <span className="flex items-center gap-1">
                  <kbd className="px-1.5 py-0.5 rounded bg-muted/40 font-mono">↑↓</kbd>
                  تنقل
                </span>
                <span className="flex items-center gap-1">
                  <kbd className="px-1.5 py-0.5 rounded bg-muted/40 font-mono">↵</kbd>
                  فتح
                </span>
                {totalResults > 0 && (
                  <span>{totalResults} نتيجة</span>
                )}
              </div>
              <span className="text-[10px] text-muted-foreground">بحث شامل</span>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

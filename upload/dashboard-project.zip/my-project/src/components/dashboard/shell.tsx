"use client";

import * as React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useDashboardStore } from "@/store/use-dashboard-store";
import { DASHBOARD_SECTIONS, USER_PROFILE } from "@/lib/constants";
import { DynamicIcon } from "./icon";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent } from "@/components/ui/sheet";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import { ar } from "date-fns/locale";
import { CommandPalette } from "./command-palette";
import { ThemeToggle } from "./theme-toggle";
import { FloatingActionButton } from "./floating-action-button";
import { KeyboardShortcuts } from "./keyboard-shortcuts";
import { GlobalSearch } from "./global-search";
import { FocusMode } from "./focus-mode";
import { useUIStore } from "@/store/use-ui-store";

function SidebarContent() {
  const { activeSection, setActiveSection } = useDashboardStore();

  return (
    <div className="flex h-full flex-col">
      {/* Logo / Header */}
      <div className="flex items-center gap-3 px-5 py-5 border-b border-border/40">
        <div className="relative">
          <div className="absolute inset-0 rounded-xl bg-emerald-glow/30 blur-md" />
          <div className="relative flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-emerald-glow to-amber-glow text-background font-bold text-xl shadow-lg">
            ع
          </div>
        </div>
        <div className="flex-1 min-w-0">
          <h1 className="text-base font-bold text-foreground truncate">
            {USER_PROFILE.fullName}
          </h1>
          <p className="text-xs text-muted-foreground/90 truncate font-medium">
            {USER_PROFILE.title} • {USER_PROFILE.city}
          </p>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto custom-scroll px-3 py-4">
        <p className="px-3 mb-2.5 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground/80">
          القائمة الرئيسية
        </p>
        <ul className="space-y-1">
          {DASHBOARD_SECTIONS.map((section) => {
            const isActive = activeSection === section.id;
            return (
              <li key={section.id}>
                <button
                  onClick={() => setActiveSection(section.id)}
                  className={cn(
                    "group relative flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-all duration-200",
                    isActive
                      ? "bg-gradient-to-l from-emerald-glow/25 to-emerald-glow/5 text-foreground shadow-sm"
                      : "text-foreground/70 hover:bg-accent/40 hover:text-foreground"
                  )}
                >
                  {isActive && (
                    <motion.div
                      layoutId="active-pill"
                      className="absolute right-0 top-1/2 h-7 w-1 -translate-y-1/2 rounded-l-full bg-gradient-to-b from-emerald-glow to-amber-glow"
                      transition={{ type: "spring", stiffness: 400, damping: 30 }}
                    />
                  )}
                  <DynamicIcon
                    name={section.icon}
                    className={cn(
                      "h-[18px] w-[18px] transition-colors",
                      isActive
                        ? "text-emerald-glow"
                        : "text-muted-foreground group-hover:text-foreground"
                    )}
                  />
                  <span className="flex-1 text-right">{section.label}</span>
                  {isActive && (
                    <span className="h-1.5 w-1.5 rounded-full bg-emerald-glow pulse-glow" />
                  )}
                </button>
              </li>
            );
          })}
        </ul>
      </nav>

      {/* Footer */}
      <div className="border-t border-border/40 px-4 py-3">
        <div className="flex items-center gap-2 text-[11px] text-muted-foreground">
          <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-emerald-glow/10 text-emerald-glow">
            <DynamicIcon name="Clock" className="h-3.5 w-3.5" />
          </div>
          <div className="flex-1">
            <p className="font-medium text-foreground">
              {format(new Date(), "HH:mm", { locale: ar })}
            </p>
            <p>
              {format(new Date(), "EEEE d MMMM", { locale: ar })}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

export function DashboardShell({ children }: { children: React.ReactNode }) {
  const { sidebarOpen, setSidebarOpen, toggleSidebar, activeSection } = useDashboardStore();
  const { focusModeOpen, setFocusModeOpen } = useUIStore();
  const currentSection = DASHBOARD_SECTIONS.find((s) => s.id === activeSection);
  const { toast } = useToast();

  const openCmd = () => window.dispatchEvent(new Event("open-command-palette"));

  // الاستماع لحدث تبديل وضع التركيز
  React.useEffect(() => {
    const toggleFocus = () => setFocusModeOpen(true);
    window.addEventListener("toggle-focus-mode", toggleFocus);
    return () => window.removeEventListener("toggle-focus-mode", toggleFocus);
  }, [setFocusModeOpen]);

  return (
    <div className="relative min-h-screen bg-background aurora-bg">
      {/* Grid pattern overlay */}
      <div className="pointer-events-none fixed inset-0 grid-pattern opacity-40" />

      <div className="relative z-10 flex min-h-screen">
        {/* Desktop Sidebar */}
        <aside className="hidden lg:flex w-72 shrink-0 flex-col border-l border-border/40 glass">
          <SidebarContent />
        </aside>

        {/* Mobile Sidebar (Sheet) */}
        <Sheet open={sidebarOpen} onOpenChange={setSidebarOpen}>
          <SheetContent side="right" className="w-72 p-0 glass-strong border-l">
            <SidebarContent />
          </SheetContent>
        </Sheet>

        {/* Main Content */}
        <main className="flex-1 flex flex-col min-w-0">
          {/* Topbar */}
          <header className="sticky top-0 z-30 flex items-center gap-3 border-b border-border/40 glass-strong px-4 py-3 lg:px-6">
            <Button
              variant="ghost"
              size="icon"
              className="lg:hidden"
              onClick={toggleSidebar}
            >
              <DynamicIcon name="Menu" className="h-5 w-5" />
            </Button>

            <div className="flex items-center gap-2.5 min-w-0">
              <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-emerald-glow/10 text-emerald-glow shrink-0">
                <DynamicIcon name={currentSection?.icon || "LayoutDashboard"} className="h-4.5 w-4.5" />
              </div>
              <div className="min-w-0">
                <h2 className="text-base font-bold text-foreground truncate">
                  {currentSection?.label}
                </h2>
                <p className="text-[11px] text-muted-foreground hidden sm:block">
                  {format(new Date(), "EEEE، d MMMM yyyy", { locale: ar })}
                </p>
              </div>
            </div>

            <div className="flex-1" />

            {/* Global search trigger */}
            <button
              onClick={() => window.dispatchEvent(new Event("open-global-search"))}
              className="hidden sm:flex items-center gap-2 rounded-lg border border-border/40 bg-background/30 px-3 py-1.5 text-xs text-muted-foreground hover:border-emerald-glow/30 hover:text-foreground transition-all"
            >
              <DynamicIcon name="Search" className="h-3.5 w-3.5" />
              <span>بحث شامل</span>
              <kbd className="flex items-center gap-0.5 px-1.5 py-0.5 rounded bg-muted/40 text-[10px] font-mono">
                ⌘⇧F
              </kbd>
            </button>

            {/* Command palette trigger */}
            <Button
              variant="ghost"
              size="icon"
              className="relative h-9 w-9"
              onClick={openCmd}
              title="لوحة الأوامر (⌘K)"
            >
              <DynamicIcon name="Command" className="h-4.5 w-4.5" />
            </Button>

            {/* Quick actions */}
            <div className="flex items-center gap-1">
              <ThemeToggle />
              <Button
                variant="ghost"
                size="icon"
                className="relative h-9 w-9"
                onClick={() => setFocusModeOpen(true)}
                title="وضع التركيز"
              >
                <DynamicIcon name="Target" className="h-4.5 w-4.5" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className="relative h-9 w-9 sm:hidden"
                onClick={() => window.dispatchEvent(new Event("open-global-search"))}
              >
                <DynamicIcon name="Search" className="h-4.5 w-4.5" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className="relative h-9 w-9"
                onClick={() => toast({ title: "لا إشعارات جديدة", description: "أنت على اطلاع دائم" })}
              >
                <DynamicIcon name="Bell" className="h-4.5 w-4.5" />
                <span className="absolute top-1.5 right-1.5 h-2 w-2 rounded-full bg-amber-glow pulse-glow" />
              </Button>
            </div>
          </header>

          {/* Content Area */}
          <div className="flex-1 p-4 lg:p-6 custom-scroll">
            <AnimatePresence mode="wait">
              <motion.div
                key={activeSection}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -8 }}
                transition={{ duration: 0.25, ease: "easeOut" }}
                className="min-h-[calc(100vh-8rem)]"
              >
                {children}
              </motion.div>
            </AnimatePresence>
          </div>

          {/* Footer */}
          <footer className="mt-auto border-t border-border/40 glass px-4 py-3 lg:px-6">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-2 text-[11px] text-muted-foreground">
              <p>
                لوحة التحكم الشخصية • صُممت بعناية لتنظيم يومك
              </p>
              <p className="flex items-center gap-1.5">
                <span className="h-1.5 w-1.5 rounded-full bg-emerald-glow" />
                متصل • حلب، سوريا
              </p>
            </div>
          </footer>
        </main>
      </div>

      {/* Command Palette (manages its own open state) */}
      <CommandPalette />

      {/* Global Search overlay (manages its own open state) */}
      <GlobalSearch />

      {/* Keyboard Shortcuts overlay (manages its own open state) */}
      <KeyboardShortcuts />

      {/* Focus Mode overlay */}
      <FocusMode open={focusModeOpen} onClose={() => setFocusModeOpen(false)} />

      {/* Floating Action Button */}
      <FloatingActionButton />
    </div>
  );
}

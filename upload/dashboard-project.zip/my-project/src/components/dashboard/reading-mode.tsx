"use client";

import * as React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { DynamicIcon } from "./icon";
import { cn } from "@/lib/utils";
import { format } from "date-fns";
import { ar } from "date-fns/locale";

interface Note {
  id: string;
  title: string;
  content: string;
  pinned: boolean;
  createdAt: string;
  updatedAt: string;
}

interface ReadingModeProps {
  note: Note | null;
  open: boolean;
  onClose: () => void;
  notes: Note[];
  onNavigate: (note: Note) => void;
}

export function ReadingMode({ note, open, onClose, notes, onNavigate }: ReadingModeProps) {
  const [fontSize, setFontSize] = React.useState<"sm" | "md" | "lg">("md");

  React.useEffect(() => {
    if (open) {
      const saved = localStorage.getItem("reading-font-size") as "sm" | "md" | "lg" | null;
      if (saved) setFontSize(saved);
    }
  }, [open]);

  React.useEffect(() => {
    if (!open) return;
    const handler = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
      if (e.key === "ArrowLeft") {
        // التالي (RTL)
        const idx = notes.findIndex((n) => n.id === note?.id);
        if (idx < notes.length - 1) onNavigate(notes[idx + 1]);
      }
      if (e.key === "ArrowRight") {
        // السابق (RTL)
        const idx = notes.findIndex((n) => n.id === note?.id);
        if (idx > 0) onNavigate(notes[idx - 1]);
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [open, note, notes, onNavigate, onClose]);

  const fontSizeClass = {
    sm: "text-sm leading-6",
    md: "text-base leading-7",
    lg: "text-lg leading-8",
  };

  const currentIndex = note ? notes.findIndex((n) => n.id === note.id) : -1;

  return (
    <AnimatePresence>
      {open && note && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[150] flex items-center justify-center p-4"
        >
          {/* خلفية داكنة */}
          <div className="absolute inset-0 bg-background/95 backdrop-blur-xl" />

          {/* زر الإغلاق */}
          <button
            onClick={onClose}
            className="absolute top-6 left-6 z-10 flex h-10 w-10 items-center justify-center rounded-xl glass border border-border/40 text-muted-foreground hover:text-foreground transition-colors"
          >
            <DynamicIcon name="X" className="h-5 w-5" />
          </button>

          {/* أزرار التنقل */}
          <div className="absolute top-6 right-6 z-10 flex items-center gap-2">
            <button
              onClick={() => fontSize === "sm" ? setFontSize("md") : fontSize === "md" ? setFontSize("lg") : setFontSize("sm")}
              className="flex h-10 w-10 items-center justify-center rounded-xl glass border border-border/40 text-muted-foreground hover:text-foreground transition-colors"
              title="حجم الخط"
            >
              <DynamicIcon name="Book" className="h-5 w-5" />
            </button>
            <div className="flex items-center gap-1 px-3 py-2 rounded-xl glass border border-border/40">
              <button
                onClick={() => currentIndex > 0 && onNavigate(notes[currentIndex - 1])}
                disabled={currentIndex <= 0}
                className="flex h-7 w-7 items-center justify-center rounded-lg text-muted-foreground hover:text-foreground disabled:opacity-30 transition-colors"
              >
                <DynamicIcon name="ChevronRight" className="h-4 w-4" />
              </button>
              <span className="text-xs text-muted-foreground font-mono px-1">
                {currentIndex + 1} / {notes.length}
              </span>
              <button
                onClick={() => currentIndex < notes.length - 1 && onNavigate(notes[currentIndex + 1])}
                disabled={currentIndex >= notes.length - 1}
                className="flex h-7 w-7 items-center justify-center rounded-lg text-muted-foreground hover:text-foreground disabled:opacity-30 transition-colors"
              >
                <DynamicIcon name="ChevronLeft" className="h-4 w-4" />
              </button>
            </div>
          </div>

          {/* محتوى القراءة */}
          <motion.div
            key={note.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ type: "spring", stiffness: 300, damping: 30 }}
            className="relative w-full max-w-2xl max-h-[80vh] overflow-y-auto custom-scroll"
          >
            <article className="glass-strong rounded-2xl p-8 lg:p-12">
              {/* العنوان */}
              <h1 className="text-2xl lg:text-3xl font-bold text-foreground mb-3 leading-tight">
                {note.title}
              </h1>

              {/* التاريخ */}
              <div className="flex items-center gap-3 mb-6 pb-6 border-b border-border/30">
                <DynamicIcon name="Clock" className="h-4 w-4 text-muted-foreground" />
                <span className="text-xs text-muted-foreground">
                  {format(new Date(note.updatedAt), "EEEE، d MMMM yyyy - HH:mm", { locale: ar })}
                </span>
                {note.pinned && (
                  <span className="flex items-center gap-1 text-[10px] text-amber-glow ml-auto">
                    <DynamicIcon name="Pin" className="h-3 w-3" />
                    مثبّتة
                  </span>
                )}
              </div>

              {/* المحتوى */}
              <div className={cn(
                "text-foreground/90 whitespace-pre-wrap font-arabic",
                fontSizeClass[fontSize]
              )}>
                {note.content}
              </div>

              {/* تذييل */}
              <div className="mt-8 pt-6 border-t border-border/30 flex items-center justify-between text-[10px] text-muted-foreground">
                <span>استخدم الأسهم للتنقل بين الملاحظات</span>
                <span>ESC للإغلاق</span>
              </div>
            </article>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

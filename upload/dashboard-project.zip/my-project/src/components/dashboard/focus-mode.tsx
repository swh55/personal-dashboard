"use client";

import * as React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { DynamicIcon } from "./icon";
import { cn } from "@/lib/utils";

interface FocusModeProps {
  open: boolean;
  onClose: () => void;
}

const DURATIONS = [
  { minutes: 15, label: "15 دقيقة", color: "emerald" },
  { minutes: 25, label: "25 دقيقة", color: "emerald" },
  { minutes: 45, label: "45 دقيقة", color: "amber" },
  { minutes: 60, label: "ساعة", color: "rose" },
];

const colorMap: Record<string, { text: string; bg: string; stroke: string }> = {
  emerald: { text: "text-emerald-glow", bg: "bg-emerald-glow/15", stroke: "#10b981" },
  amber: { text: "text-amber-glow", bg: "bg-amber-glow/15", stroke: "#f59e0b" },
  rose: { text: "text-rose-400", bg: "bg-rose-500/15", stroke: "#f43f5e" },
};

export function FocusMode({ open, onClose }: FocusModeProps) {
  const [selectedDuration, setSelectedDuration] = React.useState(25);
  const [timeLeft, setTimeLeft] = React.useState(25 * 60);
  const [isRunning, setIsRunning] = React.useState(false);
  const [phase, setPhase] = React.useState<"setup" | "running" | "done">("setup");
  const [sessions, setSessions] = React.useState(0);
  const intervalRef = React.useRef<ReturnType<typeof setInterval> | null>(null);

  React.useEffect(() => {
    if (!open) {
      // reset on close
      if (intervalRef.current) clearInterval(intervalRef.current);
      setIsRunning(false);
      setPhase("setup");
      setTimeLeft(selectedDuration * 60);
    }
  }, [open, selectedDuration]);

  React.useEffect(() => {
    if (isRunning && timeLeft > 0) {
      intervalRef.current = setInterval(() => {
        setTimeLeft((t) => {
          if (t <= 1) {
            setIsRunning(false);
            setPhase("done");
            setSessions((s) => s + 1);
            // تنبيه صوتي
            try {
              const audio = new Audio("data:audio/wav;base64,UklGRl9vT19XQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQAAAAA=");
              audio.volume = 0.3;
              audio.play().catch(() => {});
            } catch {}
            return 0;
          }
          return t - 1;
        });
      }, 1000);
    }
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [isRunning, timeLeft]);

  const startFocus = (minutes: number) => {
    setSelectedDuration(minutes);
    setTimeLeft(minutes * 60);
    setIsRunning(true);
    setPhase("running");
  };

  const formatTime = (s: number) => {
    const m = Math.floor(s / 60);
    const sec = s % 60;
    return `${m.toString().padStart(2, "0")}:${sec.toString().padStart(2, "0")}`;
  };

  const progress = phase === "setup" ? 0 : ((selectedDuration * 60 - timeLeft) / (selectedDuration * 60)) * 100;
  const circumference = 2 * Math.PI * 120;
  const strokeDashoffset = circumference - (progress / 100) * circumference;
  const currentColor = DURATIONS.find((d) => d.minutes === selectedDuration)?.color || "emerald";
  const cm = colorMap[currentColor];

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[150] flex items-center justify-center p-4"
        >
          {/* خلفية معتمة بالكامل - وضع خالٍ من التشتت */}
          <div className="absolute inset-0 bg-background/95 backdrop-blur-xl" />

          {/* زر الإغلاق */}
          <button
            onClick={onClose}
            className="absolute top-6 left-6 z-10 flex h-10 w-10 items-center justify-center rounded-xl glass border border-border/40 text-muted-foreground hover:text-foreground transition-colors"
          >
            <DynamicIcon name="X" className="h-5 w-5" />
          </button>

          {/* عداد الجلسات */}
          {sessions > 0 && (
            <div className={cn("absolute top-6 right-6 z-10 flex items-center gap-2 px-3 py-1.5 rounded-full", cm.bg, cm.text)}>
              <DynamicIcon name="Flame" className="h-4 w-4" />
              <span className="text-sm font-bold">{sessions}</span>
              <span className="text-xs">جلسة مكتملة</span>
            </div>
          )}

          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.95, opacity: 0 }}
            className="relative flex flex-col items-center"
          >
            {phase === "setup" && (
              <>
                {/* أيقونة التركيز */}
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ type: "spring", stiffness: 200, delay: 0.1 }}
                  className="relative mb-8"
                >
                  <div className="absolute inset-0 rounded-full bg-emerald-glow/30 blur-2xl animate-pulse" />
                  <div className="relative flex h-20 w-20 items-center justify-center rounded-full bg-gradient-to-br from-emerald-glow to-amber-glow text-background">
                    <DynamicIcon name="Target" className="h-10 w-10" />
                  </div>
                </motion.div>

                <h2 className="text-2xl font-bold text-foreground mb-2">وضع التركيز العميق</h2>
                <p className="text-sm text-muted-foreground mb-8 text-center max-w-sm">
                  اعزل نفسك عن التشتت وركّز على مهمة واحدة. اختر المدة وابدأ الجلسة.
                </p>

                {/* اختيار المدة */}
                <div className="grid grid-cols-2 gap-3 w-full max-w-sm mb-6">
                  {DURATIONS.map((d) => {
                    const dc = colorMap[d.color];
                    const isSelected = selectedDuration === d.minutes;
                    return (
                      <motion.button
                        key={d.minutes}
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                        onClick={() => startFocus(d.minutes)}
                        className={cn(
                          "flex flex-col items-center gap-1 rounded-2xl border-2 p-5 transition-all",
                          isSelected ? cn(dc.bg, "border-current") : "border-border/40 hover:border-emerald-glow/30"
                        )}
                      >
                        <DynamicIcon name="Clock" className={cn("h-6 w-6", dc.text)} />
                        <span className="text-lg font-bold text-foreground">{d.minutes}</span>
                        <span className="text-[11px] text-muted-foreground">دقيقة</span>
                      </motion.button>
                    );
                  })}
                </div>

                <p className="text-[11px] text-muted-foreground/70 text-center max-w-xs">
                  💡 نصيحة: ضع هاتفك في وضع الطيران وأخبر من حولك أنك في وضع التركيز
                </p>
              </>
            )}

            {phase === "running" && (
              <>
                {/* المؤشر الدائري الكبير */}
                <div className="relative h-80 w-80 mb-8">
                  <svg className="absolute inset-0 -rotate-90" viewBox="0 0 280 280">
                    {/* دائرة الخلفية */}
                    <circle
                      cx="140" cy="140" r="120"
                      fill="none"
                      stroke="oklch(0.3 0.015 250 / 20%)"
                      strokeWidth="4"
                    />
                    {/* دائرة التقدم */}
                    <motion.circle
                      cx="140" cy="140" r="120"
                      fill="none"
                      stroke={cm.stroke}
                      strokeWidth="4"
                      strokeLinecap="round"
                      strokeDasharray={circumference}
                      animate={{ strokeDashoffset }}
                      transition={{ duration: 0.5, ease: "easeOut" }}
                      style={{ filter: `drop-shadow(0 0 8px ${cm.stroke}40)` }}
                    />
                  </svg>
                  <div className="absolute inset-0 flex flex-col items-center justify-center">
                    <p className={cn("text-6xl font-mono font-bold tabular-nums", cm.text)}>
                      {formatTime(timeLeft)}
                    </p>
                    <p className="text-xs text-muted-foreground mt-2">وقت التركيز المتبقي</p>
                  </div>
                </div>

                <p className="text-sm text-foreground/80 mb-6 text-center max-w-sm">
                  🎯 ركّز على مهمتك الحالية فقط
                </p>

                {/* أزرار التحكم */}
                <div className="flex items-center gap-3">
                  <button
                    onClick={() => {
                      setIsRunning(!isRunning);
                    }}
                    className={cn(
                      "flex h-14 w-14 items-center justify-center rounded-full shadow-lg transition-all",
                      isRunning
                        ? "bg-rose-500/20 text-rose-400 hover:bg-rose-500/30"
                        : cn(cm.bg, cm.text, "hover:scale-105")
                    )}
                  >
                    <DynamicIcon name={isRunning ? "Pause" : "Play"} className="h-6 w-6" />
                  </button>
                  <button
                    onClick={() => {
                      if (intervalRef.current) clearInterval(intervalRef.current);
                      setIsRunning(false);
                      setPhase("setup");
                      setTimeLeft(selectedDuration * 60);
                    }}
                    className="flex h-12 w-12 items-center justify-center rounded-full glass border border-border/40 text-muted-foreground hover:text-foreground transition-colors"
                  >
                    <DynamicIcon name="RotateCcw" className="h-5 w-5" />
                  </button>
                </div>
              </>
            )}

            {phase === "done" && (
              <>
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ type: "spring", stiffness: 200 }}
                  className="relative mb-6"
                >
                  <div className="absolute inset-0 rounded-full bg-emerald-glow/40 blur-2xl" />
                  <div className="relative flex h-24 w-24 items-center justify-center rounded-full bg-gradient-to-br from-emerald-glow to-amber-glow text-background">
                    <DynamicIcon name="Trophy" className="h-12 w-12" />
                  </div>
                </motion.div>

                <motion.h2
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="text-3xl font-bold text-foreground mb-2"
                >
                  أحسنت! 🎉
                </motion.h2>
                <p className="text-sm text-muted-foreground mb-8 text-center">
                  أكملت جلسة تركيز مدتها {selectedDuration} دقيقة
                </p>

                <div className="flex gap-3">
                  <button
                    onClick={() => startFocus(selectedDuration)}
                    className="flex items-center gap-2 rounded-xl bg-emerald-glow hover:bg-emerald-glow/90 text-background px-5 py-3 text-sm font-medium transition-all"
                  >
                    <DynamicIcon name="RotateCcw" className="h-4 w-4" />
                    جلسة أخرى
                  </button>
                  <button
                    onClick={onClose}
                    className="flex items-center gap-2 rounded-xl glass border border-border/40 text-foreground px-5 py-3 text-sm font-medium hover:border-emerald-glow/30 transition-all"
                  >
                    <DynamicIcon name="Check" className="h-4 w-4" />
                    إنهاء
                  </button>
                </div>
              </>
            )}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

"use client";

import * as React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { DynamicIcon } from "./icon";
import { useDashboardStore } from "@/store/use-dashboard-store";
import { DASHBOARD_SECTIONS } from "@/lib/constants";
import { cn } from "@/lib/utils";

interface Shortcut {
  keys: string[];
  label: string;
  section?: string;
  icon?: string;
}

const SHORTCUTS: Shortcut[] = [
  { keys: ["⌘", "K"], label: "فتح لوحة الأوامر", icon: "Command" },
  { keys: ["⌘", "⇧", "F"], label: "البحث الشامل", icon: "Search" },
  { keys: ["F"], label: "وضع التركيز العميق", icon: "Target" },
  { keys: ["?"], label: "عرض اختصارات لوحة المفاتيح", icon: "Keyboard" },
  { keys: ["G", "O"], label: "الذهاب لنظرة عامة", section: "overview", icon: "LayoutDashboard" },
  { keys: ["G", "C"], label: "الذهاب للتقويم", section: "calendar", icon: "Calendar" },
  { keys: ["G", "P"], label: "الذهاب للاتصال السريع", section: "callpad", icon: "Phone" },
  { keys: ["G", "U"], label: "الذهاب لجهات الاتصال", section: "contacts", icon: "Users" },
  { keys: ["G", "T"], label: "الذهاب للمهام", section: "tasks", icon: "CheckSquare" },
  { keys: ["G", "H"], label: "الذهاب للعادات", section: "habits", icon: "RefreshCw" },
  { keys: ["G", "E"], label: "الذهاب للمصروفات", section: "expenses", icon: "Receipt" },
  { keys: ["G", "W"], label: "الذهاب للمالية", section: "finances", icon: "Wallet" },
  { keys: ["G", "A"], label: "الذهاب للحسابات", section: "accounts", icon: "Globe" },
  { keys: ["G", "N"], label: "الذهاب للملاحظات", section: "notes", icon: "StickyNote" },
  { keys: ["ESC"], label: "إغلاق النوافذ المنبثقة", icon: "X" },
];

export function KeyboardShortcuts() {
  const [open, setOpen] = React.useState(false);
  const { setActiveSection } = useDashboardStore();
  const pressedKey = React.useRef<string | null>(null);
  const timeoutRef = React.useRef<ReturnType<typeof setTimeout> | null>(null);

  React.useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      // تجاهل إذا كان المستخدم يكتب في حقل
      const target = e.target as HTMLElement;
      if (target.tagName === "INPUT" || target.tagName === "TEXTAREA" || target.isContentEditable) {
        return;
      }

      // فتح/إغلاق ال overlay بـ ?
      if (e.key === "?" && !e.ctrlKey && !e.metaKey) {
        e.preventDefault();
        setOpen((o) => !o);
        return;
      }

      // F لفتح وضع التركيز
      if (e.key.toLowerCase() === "f" && !e.ctrlKey && !e.metaKey && !e.shiftKey && pressedKey.current !== "g") {
        e.preventDefault();
        window.dispatchEvent(new Event("toggle-focus-mode"));
        return;
      }

      if (e.key === "Escape" && open) {
        setOpen(false);
        return;
      }

      // اختصارات G + letter للتنقل
      if (e.key.toLowerCase() === "g" && !e.ctrlKey && !e.metaKey) {
        pressedKey.current = "g";
        if (timeoutRef.current) clearTimeout(timeoutRef.current);
        timeoutRef.current = setTimeout(() => {
          pressedKey.current = null;
        }, 800);
        return;
      }

      if (pressedKey.current === "g") {
        const map: Record<string, string> = {
          o: "overview",
          c: "calendar",
          p: "callpad",
          u: "contacts",
          t: "tasks",
          h: "habits",
          e: "expenses",
          w: "finances",
          a: "accounts",
          n: "notes",
        };
        const section = map[e.key.toLowerCase()];
        if (section) {
          e.preventDefault();
          setActiveSection(section as never);
          pressedKey.current = null;
          if (timeoutRef.current) clearTimeout(timeoutRef.current);
        }
      }
    };

    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [open, setActiveSection]);

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[110] flex items-center justify-center p-4"
          onClick={() => setOpen(false)}
        >
          <div className="absolute inset-0 bg-background/60 backdrop-blur-sm" />
          <motion.div
            initial={{ opacity: 0, scale: 0.96, y: 10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.96, y: 10 }}
            transition={{ type: "spring", stiffness: 400, damping: 30 }}
            className="relative w-full max-w-lg glass-strong rounded-2xl shadow-2xl overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header */}
            <div className="flex items-center justify-between px-5 py-4 border-b border-border/40">
              <div className="flex items-center gap-2.5">
                <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-emerald-glow/15 text-emerald-glow">
                  <DynamicIcon name="Keyboard" className="h-4.5 w-4.5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-foreground">اختصارات لوحة المفاتيح</h3>
                  <p className="text-[11px] text-muted-foreground">تنقل سريع عبر اللوحة</p>
                </div>
              </div>
              <button
                onClick={() => setOpen(false)}
                className="flex h-8 w-8 items-center justify-center rounded-lg hover:bg-accent/40 text-muted-foreground"
              >
                <DynamicIcon name="X" className="h-4 w-4" />
              </button>
            </div>

            {/* Shortcuts list */}
            <div className="p-3 max-h-[60vh] overflow-y-auto custom-scroll">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
                {SHORTCUTS.map((shortcut, i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, y: 4 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.02 }}
                    className={cn(
                      "flex items-center gap-3 rounded-lg p-2.5 hover:bg-accent/30 transition-colors",
                      shortcut.section && "cursor-pointer"
                    )}
                    onClick={() => {
                      if (shortcut.section) {
                        setActiveSection(shortcut.section as never);
                        setOpen(false);
                      }
                    }}
                  >
                    {shortcut.icon && (
                      <div className="flex h-7 w-7 items-center justify-center rounded-md bg-muted/30 text-muted-foreground shrink-0">
                        <DynamicIcon name={shortcut.icon} className="h-3.5 w-3.5" />
                      </div>
                    )}
                    <span className="text-xs text-foreground flex-1">{shortcut.label}</span>
                    <div className="flex items-center gap-1 shrink-0">
                      {shortcut.keys.map((key, ki) => (
                        <React.Fragment key={ki}>
                          {ki > 0 && <span className="text-[10px] text-muted-foreground">+</span>}
                          <kbd className="px-1.5 py-0.5 rounded-md bg-muted/40 border border-border/40 text-[10px] font-mono font-semibold text-foreground min-w-[20px] text-center">
                            {key}
                          </kbd>
                        </React.Fragment>
                      ))}
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>

            {/* Footer */}
            <div className="px-5 py-3 border-t border-border/40 bg-background/30">
              <p className="text-[10px] text-muted-foreground text-center">
                اضغط <kbd className="px-1 py-0.5 rounded bg-muted/40 font-mono">?</kbd> في أي وقت لعرض هذه القائمة
              </p>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

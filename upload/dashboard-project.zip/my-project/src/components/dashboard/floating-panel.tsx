"use client";

import * as React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { DynamicIcon } from "./icon";
import { cn } from "@/lib/utils";

interface FloatingPanelProps {
  id: string;
  title: string;
  icon: string;
  iconColor?: string;
  children: React.ReactNode;
  width?: "sm" | "md" | "lg" | "xl";
  position?: "center" | "bottom";
}

const widthMap = {
  sm: "max-w-sm",
  md: "max-w-md",
  lg: "max-w-lg",
  xl: "max-w-2xl",
};

// Check if a click target is inside a Radix portal
function isInsideRadixPortal(target: Node): boolean {
  if (!(target instanceof Element)) return false;
  return !!target.closest(
    '[data-radix-popper-content-wrapper], ' +
    '[role="listbox"], ' +
    '[role="dialog"], ' +
    '[data-radix-portal], ' +
    '[cmdk-root]'
  );
}

// ═══ M3 Expressive: Spring physics for entrance ═══
const springEntrance = {
  type: "spring" as const,
  stiffness: 300,
  damping: 20,
};

const springExit = {
  type: "spring" as const,
  stiffness: 400,
  damping: 28,
};

export function FloatingPanel({
  id,
  title,
  icon,
  iconColor = "#4285F4",
  children,
  width = "lg",
  position = "center",
}: FloatingPanelProps) {
  const contentRef = React.useRef<HTMLDivElement>(null);

  return (
    <AnimatePresence>
      {id && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.2 }}
          className="fixed inset-0 z-[100] flex items-center justify-center p-2"
          onClick={(e) => {
            if (contentRef.current && contentRef.current.contains(e.target as Node)) return;
            if (isInsideRadixPortal(e.target as Node)) return;
            window.dispatchEvent(new CustomEvent("close-floating-panel"));
          }}
        >
          {/* Scrim */}
          <div className="absolute inset-0 bg-black/50" />

          {/* ═══ M3 Expressive: Elastic entrance with spring physics ═══ */}
          <motion.div
            ref={contentRef}
            initial={{ opacity: 0, scale: 0.88, y: 24 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.92, y: 12 }}
            transition={springEntrance}
            className={cn(
              "relative w-full overflow-hidden flex flex-col elevation-3",
              widthMap[width],
              "max-h-[92vh]",
            )}
            style={{
              backgroundColor: "var(--surface-container)",
              borderRadius: "28px",           /* M3 Expressive: extra-large radius */
            }}
          >
            {/* Header — compact */}
            <div
              className="flex items-center justify-between px-4 py-3 shrink-0"
              style={{ borderBottom: "1px solid var(--sidebar-border)" }}
            >
              <div className="flex items-center gap-2">
                <div
                  className="flex h-8 w-8 items-center justify-center"
                  style={{
                    backgroundColor: iconColor + "22",
                    borderRadius: "9999px",  /* M3 Expressive: pill */
                  }}
                >
                  <DynamicIcon name={icon} className="h-4 w-4" style={{ color: iconColor }} />
                </div>
                <h3 className="text-sm font-medium text-foreground">{title}</h3>
              </div>
              <motion.button
                whileTap={{ scale: 0.88 }}
                transition={{ type: "spring", stiffness: 400, damping: 17 }}
                onClick={() => window.dispatchEvent(new CustomEvent("close-floating-panel"))}
                className="flex h-8 w-8 items-center justify-center text-on-surface-variant hover:text-foreground"
                style={{
                  color: "var(--on-surface-variant)",
                  borderRadius: "9999px",  /* M3 Expressive: pill */
                }}
              >
                <DynamicIcon name="X" className="h-4 w-4" />
              </motion.button>
            </div>

            {/* Content */}
            <div className="flex-1 overflow-y-auto custom-scroll px-3 pb-2">
              {children}
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

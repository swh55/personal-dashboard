"use client";

import * as React from "react";
import { DynamicIcon } from "./icon";
import { useAccentColor } from "@/hooks/use-accent-color";
import { cn } from "@/lib/utils";

// M3 seed colors (tone 40 - generates full tonal palette)
const M3_SEEDS = [
  { id: "teal",    label: "أخضر مزرق", primary: "oklch(0.50 0.10 175)", secondary: "oklch(0.55 0.08 75)",  hex: "#00897b" },
  { id: "blue",    label: "أزرق",      primary: "oklch(0.55 0.15 250)", secondary: "oklch(0.55 0.10 30)",  hex: "#1565c0" },
  { id: "purple",  label: "بنفسجي",    primary: "oklch(0.52 0.18 310)", secondary: "oklch(0.55 0.12 150)", hex: "#6a1b9a" },
  { id: "rose",    label: "وردي",      primary: "oklch(0.55 0.20 15)",  secondary: "oklch(0.55 0.10 250)", hex: "#c2185b" },
  { id: "green",   label: "أخضر",      primary: "oklch(0.52 0.14 145)", secondary: "oklch(0.55 0.10 75)",  hex: "#2e7d32" },
  { id: "orange",  label: "برتقالي",   primary: "oklch(0.60 0.16 55)",  secondary: "oklch(0.55 0.10 250)", hex: "#e65100" },
];

// Override the useAccentColor hook colors inline
const COLORS = M3_SEEDS.map(s => ({ id: s.id, primary: s.primary, secondary: s.secondary }));

export function ColorCustomizer() {
  const [selected, setSelected] = React.useState("teal");

  const applyColor = React.useCallback((colorId: string) => {
    const color = COLORS.find((c) => c.id === colorId);
    if (!color) return;
    const root = document.documentElement;
    root.style.setProperty("--accent-primary", color.primary);
    root.style.setProperty("--accent-secondary", color.secondary);
    root.style.setProperty("--emerald-glow", color.primary);
    root.style.setProperty("--amber-glow", color.secondary);
  }, []);

  React.useEffect(() => {
    const saved = localStorage.getItem("dashboard-accent-color");
    if (saved) {
      setSelected(saved);
      applyColor(saved);
    }
  }, [applyColor]);

  const handleSelect = (colorId: string) => {
    setSelected(colorId);
    localStorage.setItem("dashboard-accent-color", colorId);
    applyColor(colorId);
  };

  return (
    <div>
      <p className="text-[11px] text-muted-foreground mb-2 font-medium">لون لوحة التحكم (Material You)</p>
      <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
        {M3_SEEDS.map((color) => (
          <button
            key={color.id}
            onClick={() => handleSelect(color.id)}
            className={cn(
              "flex flex-col items-center gap-1.5 p-2 rounded-2xl border-2 transition-all",
              selected === color.id
                ? "border-primary bg-primary/10"
                : "border-transparent hover:bg-surface-container-high"
            )}
          >
            <div
              className="h-9 w-9 rounded-full shadow-sm"
              style={{ background: color.hex }}
            />
            <span className={cn(
              "text-[10px]",
              selected === color.id ? "text-primary font-bold" : "text-muted-foreground"
            )}>
              {color.label}
            </span>
            {selected === color.id && (
              <DynamicIcon name="Check" className="h-3 w-3 text-primary" />
            )}
          </button>
        ))}
      </div>
      <p className="text-[10px] text-muted-foreground/70 mt-2">
        ألوان مستوحاة من Material You — كل لون يولّد لوحة كاملة
      </p>
    </div>
  );
}

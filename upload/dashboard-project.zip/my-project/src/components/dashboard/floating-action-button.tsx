"use client";

import * as React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { DynamicIcon } from "./icon";
import { useDashboardStore } from "@/store/use-dashboard-store";
import { cn } from "@/lib/utils";

interface QuickAction {
  id: string;
  label: string;
  icon: string;
  section: string;
  color: string;
}

const ACTIONS: QuickAction[] = [
  { id: "task", label: "مهمة", icon: "Plus", section: "tasks", color: "emerald" },
  { id: "event", label: "حدث", icon: "Calendar", section: "calendar", color: "amber" },
  { id: "call", label: "اتصال", icon: "Phone", section: "callpad", color: "teal" },
  { id: "note", label: "ملاحظة", icon: "StickyNote", section: "notes", color: "rose" },
  { id: "habit", label: "عادة", icon: "RefreshCw", section: "habits", color: "emerald" },
];

const colorMap: Record<string, string> = {
  emerald: "bg-emerald-glow/15 text-emerald-glow hover:bg-emerald-glow/25",
  amber: "bg-amber-glow/15 text-amber-glow hover:bg-amber-glow/25",
  teal: "bg-teal-500/15 text-teal-400 hover:bg-teal-500/25",
  rose: "bg-rose-500/15 text-rose-400 hover:bg-rose-500/25",
};

export function FloatingActionButton() {
  const [open, setOpen] = React.useState(false);
  const { setActiveSection } = useDashboardStore();

  const handleAction = (action: QuickAction) => {
    setActiveSection(action.section as never);
    setOpen(false);
  };

  return (
    <div className="fixed bottom-6 left-6 z-50 flex flex-col items-start gap-2">
      <AnimatePresence>
        {open && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-40"
              onClick={() => setOpen(false)}
            />
            {ACTIONS.map((action, i) => (
              <motion.button
                key={action.id}
                initial={{ opacity: 0, scale: 0, y: 10 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0, y: 10 }}
                transition={{ delay: i * 0.04, type: "spring", stiffness: 400, damping: 25 }}
                onClick={() => handleAction(action)}
                className={cn(
                  "relative flex items-center gap-2 rounded-full pl-3 pr-4 py-2.5 glass-strong shadow-lg z-50 group",
                  "transition-all hover:scale-105"
                )}
              >
                <div className={cn("flex h-8 w-8 items-center justify-center rounded-full", colorMap[action.color])}>
                  <DynamicIcon name={action.icon} className="h-4 w-4" />
                </div>
                <span className="text-xs font-medium text-foreground whitespace-nowrap">
                  {action.label}
                </span>
              </motion.button>
            ))}
          </>
        )}
      </AnimatePresence>

      <motion.button
        whileTap={{ scale: 0.9 }}
        onClick={() => setOpen(!open)}
        className={cn(
          "flex h-14 w-14 items-center justify-center rounded-full shadow-2xl z-50 transition-all",
          open
            ? "bg-rose-500/20 text-rose-400"
            : "bg-gradient-to-br from-emerald-glow to-amber-glow text-background"
        )}
      >
        <motion.div
          animate={{ rotate: open ? 45 : 0 }}
          transition={{ type: "spring", stiffness: 300, damping: 20 }}
        >
          <DynamicIcon name="Plus" className="h-6 w-6" />
        </motion.div>
      </motion.button>
    </div>
  );
}

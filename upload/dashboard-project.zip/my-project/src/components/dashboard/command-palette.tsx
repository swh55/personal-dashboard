"use client";

import * as React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { DynamicIcon } from "./icon";
import { useDashboardStore } from "@/store/use-dashboard-store";
import { DASHBOARD_SECTIONS } from "@/lib/constants";
import { cn } from "@/lib/utils";

interface CommandItem {
  id: string;
  label: string;
  description: string;
  icon: string;
  section: string;
  keywords?: string;
}

export function CommandPalette() {
  const [open, setOpen] = React.useState(false);
  const [query, setQuery] = React.useState("");
  const [selectedIndex, setSelectedIndex] = React.useState(0);
  const { setActiveSection } = useDashboardStore();
  const inputRef = React.useRef<HTMLInputElement>(null);
  const listRef = React.useRef<HTMLDivElement>(null);

  const commands: CommandItem[] = React.useMemo(() => {
    const navCommands = DASHBOARD_SECTIONS.map((s) => ({
      id: `nav-${s.id}`,
      label: s.label,
      description: "الانتقال إلى قسم",
      icon: s.icon,
      section: s.id,
      keywords: s.label,
    }));

    const actionCommands: CommandItem[] = [
      { id: "quick-call", label: "اتصال سريع", description: "افتح لوحة الاتصال", icon: "Phone", section: "callpad", keywords: "اتصال هاتف dial" },
      { id: "add-task", label: "إضافة مهمة جديدة", description: "إنشاء مهمة", icon: "Plus", section: "tasks", keywords: "مهمة task add" },
      { id: "add-event", label: "إضافة حدث للتقويم", description: "جدولة حدث جديد", icon: "Calendar", section: "calendar", keywords: "حدث تقويم event" },
      { id: "add-contact", label: "إضافة جهة اتصال", description: "حفظ رقم جديد", icon: "UserPlus", section: "contacts", keywords: "اتصال contact" },
      { id: "add-note", label: "كتابة ملاحظة", description: "ملاحظة سريعة", icon: "StickyNote", section: "notes", keywords: "ملاحظة note" },
      { id: "view-finances", label: "عرض المالية", description: "الأصول والعملات", icon: "Wallet", section: "finances", keywords: "مال ذهب دولار" },
      { id: "view-occasions", label: "المناسبات القادمة", description: "أعياد الميلاد", icon: "Cake", section: "occasions", keywords: "ميلاد عيد مناسبة" },
      { id: "track-habit", label: "تتبع العادات", description: "سجل عاداتك اليومية", icon: "RefreshCw", section: "habits", keywords: "عادة habit" },
      { id: "view-suggestions", label: "استكشاف 100 ميزة", description: "أفكار للتطوير", icon: "Sparkles", section: "suggestions", keywords: "اقتراحات features" },
    ];

    return [...actionCommands, ...navCommands];
  }, []);

  const filtered = React.useMemo(() => {
    if (!query) return commands;
    const q = query.toLowerCase();
    return commands.filter(
      (c) =>
        c.label.toLowerCase().includes(q) ||
        c.description.toLowerCase().includes(q) ||
        c.keywords?.toLowerCase().includes(q)
    );
  }, [query, commands]);

  React.useEffect(() => {
    setSelectedIndex(0);
  }, [query]);

  // Keyboard shortcut Cmd+K / Ctrl+K and custom event trigger
  React.useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === "k") {
        e.preventDefault();
        setOpen((o) => !o);
      }
      if (e.key === "Escape" && open) {
        setOpen(false);
      }
    };
    const openHandler = () => setOpen(true);
    window.addEventListener("keydown", handler);
    window.addEventListener("open-command-palette", openHandler);
    return () => {
      window.removeEventListener("keydown", handler);
      window.removeEventListener("open-command-palette", openHandler);
    };
  }, [open]);

  React.useEffect(() => {
    if (open) {
      setTimeout(() => inputRef.current?.focus(), 50);
      setQuery("");
    }
  }, [open]);

  const executeCommand = (cmd: CommandItem) => {
    setActiveSection(cmd.section as never);
    setOpen(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "ArrowDown") {
      e.preventDefault();
      setSelectedIndex((i) => Math.min(i + 1, filtered.length - 1));
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setSelectedIndex((i) => Math.max(i - 1, 0));
    } else if (e.key === "Enter") {
      e.preventDefault();
      if (filtered[selectedIndex]) executeCommand(filtered[selectedIndex]);
    }
  };

  // Scroll selected into view
  React.useEffect(() => {
    const el = listRef.current?.querySelector(`[data-idx="${selectedIndex}"]`);
    el?.scrollIntoView({ block: "nearest" });
  }, [selectedIndex]);

  return (
    <>
      {/* Trigger button - rendered by parent */}
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[110] flex items-start justify-center pt-[15vh] px-4"
            onClick={() => setOpen(false)}
          >
            <div className="absolute inset-0 bg-background/60 backdrop-blur-sm" />
            <motion.div
              initial={{ opacity: 0, scale: 0.96, y: -10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.96, y: -10 }}
              transition={{ type: "spring", stiffness: 400, damping: 30 }}
              className="relative w-full max-w-xl glass-strong rounded-2xl shadow-2xl overflow-hidden"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Search input */}
              <div className="flex items-center gap-3 px-4 py-3.5 border-b border-border/40">
                <DynamicIcon name="Search" className="h-5 w-5 text-emerald-glow shrink-0" />
                <input
                  ref={inputRef}
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  onKeyDown={handleKeyDown}
                  placeholder="ابحث أو اكتب أمراً..."
                  className="flex-1 bg-transparent text-sm text-foreground placeholder:text-muted-foreground outline-none"
                />
                <kbd className="hidden sm:flex items-center gap-1 px-2 py-0.5 rounded-md bg-muted/40 text-[10px] text-muted-foreground font-mono">
                  ESC
                </kbd>
              </div>

              {/* Results */}
              <div ref={listRef} className="max-h-[50vh] overflow-y-auto custom-scroll p-2">
                {filtered.length === 0 ? (
                  <div className="flex flex-col items-center justify-center py-10 text-center">
                    <DynamicIcon name="Search" className="h-8 w-8 text-muted-foreground/50 mb-2" />
                    <p className="text-sm text-muted-foreground">لا نتائج لـ "{query}"</p>
                  </div>
                ) : (
                  <>
                    {query && (
                      <p className="px-3 py-1.5 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground/60">
                        نتائج البحث ({filtered.length})
                      </p>
                    )}
                    {filtered.map((cmd, i) => (
                      <button
                        key={cmd.id}
                        data-idx={i}
                        onClick={() => executeCommand(cmd)}
                        onMouseEnter={() => setSelectedIndex(i)}
                        className={cn(
                          "w-full flex items-center gap-3 rounded-xl px-3 py-2.5 text-right transition-all",
                          i === selectedIndex
                            ? "bg-emerald-glow/10 border border-emerald-glow/20"
                            : "border border-transparent hover:bg-accent/30"
                        )}
                      >
                        <div className={cn(
                          "flex h-9 w-9 items-center justify-center rounded-lg shrink-0",
                          i === selectedIndex ? "bg-emerald-glow/15 text-emerald-glow" : "bg-muted/30 text-muted-foreground"
                        )}>
                          <DynamicIcon name={cmd.icon} className="h-4 w-4" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className={cn(
                            "text-sm font-medium truncate",
                            i === selectedIndex ? "text-foreground" : "text-foreground/90"
                          )}>
                            {cmd.label}
                          </p>
                          <p className="text-[11px] text-muted-foreground truncate">
                            {cmd.description}
                          </p>
                        </div>
                        {i === selectedIndex && (
                          <DynamicIcon name="ChevronLeft" className="h-4 w-4 text-emerald-glow shrink-0" />
                        )}
                      </button>
                    ))}
                  </>
                )}
              </div>

              {/* Footer */}
              <div className="flex items-center justify-between px-4 py-2 border-t border-border/40 bg-background/30">
                <div className="flex items-center gap-3 text-[10px] text-muted-foreground">
                  <span className="flex items-center gap-1">
                    <kbd className="px-1.5 py-0.5 rounded bg-muted/40 font-mono">↑↓</kbd>
                    تنقل
                  </span>
                  <span className="flex items-center gap-1">
                    <kbd className="px-1.5 py-0.5 rounded bg-muted/40 font-mono">↵</kbd>
                    اختيار
                  </span>
                </div>
                <span className="text-[10px] text-muted-foreground">
                  لوحة الأوامر
                </span>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}

"use client";

import * as React from "react";
import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { DynamicIcon } from "../icon";
import { cn } from "@/lib/utils";
import { subDays, isSameDay, format } from "date-fns";
import { ar } from "date-fns/locale";

interface Habit {
  id: string;
  name: string;
  color: string;
  target: number;
  logs: Array<{ date: string; count: number }>;
}

export function HabitsHeatmapWidget() {
  const [habits, setHabits] = React.useState<Habit[]>([]);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    fetch("/api/habits")
      .then((r) => r.json())
      .then((json) => {
        if (json.success) setHabits(json.data);
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  const today = new Date();
  today.setHours(0, 0, 0, 0);

  // آخر 30 يوماً
  const last30Days = Array.from({ length: 30 }, (_, i) => {
    const date = subDays(today, 29 - i);
    return { date, dayNum: format(date, "d"), month: format(date, "MMM", { locale: ar }) };
  });

  // أسابيع (5 أعمدة × 7 أيام تقريباً) - سنعرضها كصفوف: كل عادة صف، الأيام أعمدة
  const isHabitDone = (habit: Habit, date: Date) => {
    return habit.logs.some((l) => isSameDay(new Date(l.date), date) && l.count >= habit.target);
  };

  // إحصائيات
  const totalDone = habits.reduce((sum, h) => {
    return sum + last30Days.filter((d) => isHabitDone(h, d.date)).length;
  }, 0);
  const maxPossible = habits.length * 30;
  const completionRate = maxPossible > 0 ? Math.round((totalDone / maxPossible) * 100) : 0;

  const colorMap: Record<string, { done: string; partial: string }> = {
    emerald: { done: "bg-emerald-glow", partial: "bg-emerald-glow/20" },
    amber: { done: "bg-amber-glow", partial: "bg-amber-glow/20" },
    rose: { done: "bg-rose-400", partial: "bg-rose-400/20" },
    teal: { done: "bg-teal-400", partial: "bg-teal-400/20" },
  };

  if (loading) {
    return (
      <Card className="glass p-2">
        <Skeleton className="h-6 w-40 mb-1.5" />
        <Skeleton className="h-16 rounded-xl" />
      </Card>
    );
  }

  if (habits.length === 0) return null;

  return (
    <Card className="glass p-2 relative overflow-hidden">
      <div className="absolute -top-12 -right-12 h-16 w-32 rounded-full bg-teal-500/10 blur-3xl" />

      <div className="relative">
        <div className="flex items-center justify-between mb-1.5">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-teal-500/15 text-teal-400">
              <DynamicIcon name="Flame" className="h-4 w-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-foreground">خريطة العادات</h3>
              <p className="text-[10px] text-muted-foreground">آخر 30 يوماً</p>
            </div>
          </div>
          <div className="text-left">
            <p className="text-lg font-bold text-gradient-emerald">{completionRate}%</p>
            <p className="text-[9px] text-muted-foreground">إنجاز</p>
          </div>
        </div>

        {/* Heatmap grid */}
        <div className="space-y-1.5">
          {habits.slice(0, 5).map((habit) => {
            const colors = colorMap[habit.color] || colorMap.emerald;
            return (
              <div key={habit.id} className="flex items-center gap-2">
                <span className="text-[10px] text-muted-foreground w-20 truncate shrink-0" title={habit.name}>
                  {habit.name}
                </span>
                <div className="flex gap-0.5 flex-1 overflow-hidden">
                  {last30Days.map((day, i) => {
                    const done = isHabitDone(habit, day.date);
                    const isToday = isSameDay(day.date, today);
                    return (
                      <motion.div
                        key={i}
                        initial={{ opacity: 0, scale: 0.5 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ delay: i * 0.01 }}
                        className={cn(
                          "h-3.5 w-3.5 rounded-sm shrink-0 transition-all",
                          done ? colors.done : "bg-muted/30",
                          isToday && "ring-1 ring-emerald-glow/50"
                        )}
                        title={`${day.date.toLocaleDateString("ar-SY")} - ${done ? "منجز" : "غير منجز"}`}
                      />
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>

        {/* Legend */}
        <div className="flex items-center justify-between mt-1.5 pt-3 border-t border-border/30">
          <div className="flex items-center gap-2 text-[9px] text-muted-foreground">
            <span className="flex items-center gap-1">
              <span className="h-2.5 w-2.5 rounded-sm bg-emerald-glow" />
              منجز
            </span>
            <span className="flex items-center gap-1">
              <span className="h-2.5 w-2.5 rounded-sm bg-muted/30" />
              غير منجز
            </span>
          </div>
          <span className="text-[9px] text-muted-foreground">
            {totalDone} / {maxPossible} إنجاز
          </span>
        </div>
      </div>
    </Card>
  );
}

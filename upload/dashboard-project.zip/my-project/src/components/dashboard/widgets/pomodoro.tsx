"use client";

import * as React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { DynamicIcon } from "../icon";
import { usePomodoroStore } from "@/store/use-pomodoro-store";
import { cn } from "@/lib/utils";

type Mode = "focus" | "shortBreak" | "longBreak";

const MODES: Record<Mode, { label: string; duration: number; color: string; bg: string }> = {
  focus: { label: "تركيز", duration: 25, color: "text-emerald-glow", bg: "from-emerald-glow/15 to-transparent" },
  shortBreak: { label: "راحة قصيرة", duration: 5, color: "text-amber-glow", bg: "from-amber-glow/15 to-transparent" },
  longBreak: { label: "راحة طويلة", duration: 15, color: "text-teal-400", bg: "from-teal-500/15 to-transparent" },
};

const DURATIONS = [
  { minutes: 15, label: "15 دقيقة", color: "emerald" },
  { minutes: 25, label: "25 دقيقة", color: "emerald" },
  { minutes: 45, label: "45 دقيقة", color: "amber" },
  { minutes: 60, label: "ساعة", color: "rose" },
];

const GOOGLE_COLORS = {
  blue: "#4285F4",
  red: "#EA4335",
  yellow: "#FBBC04",
  green: "#34A853",
  orange: "#FF6D00",
  teal: "#00897B",
};

const colorHex: Record<string, string> = {
  emerald: GOOGLE_COLORS.green,
  amber: GOOGLE_COLORS.yellow,
  rose: GOOGLE_COLORS.red,
  teal: GOOGLE_COLORS.teal,
};

export function PomodoroWidget() {
  const { mode, timeLeft, isRunning, sessions, start, pause, resume, reset } = usePomodoroStore();
  const [phase, setPhase] = React.useState<"setup" | "running" | "done">("setup");

  // Sync phase with store state
  React.useEffect(() => {
    if (isRunning) setPhase("running");
    else if (timeLeft === 0 && (sessions > 0 || phase === "running")) setPhase("done");
  }, [isRunning, timeLeft, sessions, phase]);

  // Reset to setup when mode changes
  React.useEffect(() => {
    setPhase("setup");
  }, [mode]);

  const startFocus = (minutes: number) => {
    start(minutes);
    setPhase("running");
  };

  const formatTime = (s: number) => {
    const m = Math.floor(s / 60);
    const sec = s % 60;
    return `${m.toString().padStart(2, "0")}:${sec.toString().padStart(2, "0")}`;
  };

  const progress = phase === "setup" ? 0 : ((usePomodoroStore.getState().selectedDuration * 60 - timeLeft) / (usePomodoroStore.getState().selectedDuration * 60)) * 100;
  const circumference = 2 * Math.PI * 120;
  const strokeDashoffset = circumference - (progress / 100) * circumference;
  const currentDuration = DURATIONS.find((d) => d.minutes === usePomodoroStore.getState().selectedDuration);
  const currentColor = currentDuration ? colorHex[currentDuration.color] : GOOGLE_COLORS.green;

  return (
    <div className="flex flex-col items-center py-2">
      {phase === "setup" && (
        <>
          {/* Icon */}
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: "spring", stiffness: 200, delay: 0.1 }}
            className="relative mb-1.5"
          >
            <div className="flex h-8 w-8 items-center justify-center rounded-full" style={{ backgroundColor: GOOGLE_COLORS.red + "22" }}>
              <DynamicIcon name="Target" className="h-8 w-8" style={{ color: GOOGLE_COLORS.red }} />
            </div>
          </motion.div>

          <h2 className="text-lg font-medium text-foreground mb-1">وضع التركيز العميق</h2>
          <p className="text-xs text-on-surface-variant mb-1.5 text-center">
            اختر المدة وابدأ الجلسة
          </p>

          {/* Duration selection */}
          <div className="grid grid-cols-2 gap-2 w-full mb-1.5">
            {DURATIONS.map((d) => {
              const dc = colorHex[d.color];
              return (
                <motion.button
                  key={d.minutes}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => startFocus(d.minutes)}
                  className="flex flex-col items-center gap-1 rounded-xl border p-2 transition-all hover:scale-[1.02]"
                  style={{ borderColor: dc + "44" }}
                >
                  <DynamicIcon name="Clock" className="h-5 w-5" style={{ color: dc }} />
                  <span className="text-base font-medium text-foreground">{d.minutes}</span>
                  <span className="text-[10px] text-on-surface-variant">دقيقة</span>
                </motion.button>
              );
            })}
          </div>

          <p className="text-[10px] text-on-surface-variant/70 text-center max-w-xs">
            💡 ضع هاتفك في وضع الطيران وأخبر من حولك أنك في وضع التركيز
          </p>
        </>
      )}

      {phase === "running" && (
        <>
          {/* Circular timer */}
          <div className="relative h-40 w-40 mb-1.5">
            <svg className="absolute inset-0 -rotate-90" viewBox="0 0 280 280">
              <circle cx="140" cy="140" r="120" fill="none" stroke="var(--surface-container-high)" strokeWidth="4" />
              <motion.circle
                cx="140" cy="140" r="120"
                fill="none"
                stroke={currentColor}
                strokeWidth="4"
                strokeLinecap="round"
                strokeDasharray={circumference}
                animate={{ strokeDashoffset }}
                transition={{ duration: 0.5, ease: "easeOut" }}
                style={{ filter: `drop-shadow(0 0 6px ${currentColor}40)` }}
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <p className="text-5xl font-mono font-bold tabular-nums" style={{ color: currentColor }}>
                {formatTime(timeLeft)}
              </p>
              <p className="text-xs text-on-surface-variant mt-1">وقت التركيز المتبقي</p>
              {sessions > 0 && (
                <p className="text-[10px] mt-2 flex items-center gap-1" style={{ color: GOOGLE_COLORS.orange }}>
                  <DynamicIcon name="Flame" className="h-3 w-3" />
                  {sessions} جلسة
                </p>
              )}
            </div>
          </div>

          <p className="text-sm text-foreground/80 mb-1.5 text-center">
            🎯 ركّز على مهمتك الحالية فقط
          </p>

          {/* Controls */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                if (isRunning) {
                  pause();
                } else {
                  resume();
                }
              }}
              className="flex h-8 w-8 items-center justify-center rounded-full shadow-lg transition-all"
              style={{
                backgroundColor: isRunning ? GOOGLE_COLORS.red + "22" : currentColor + "22",
                color: isRunning ? GOOGLE_COLORS.red : currentColor,
              }}
            >
              <DynamicIcon name={isRunning ? "Pause" : "Play"} className="h-5 w-5" />
            </button>
            <button
              onClick={() => {
                reset();
                setPhase("setup");
              }}
              className="flex h-7 w-7 items-center justify-center rounded-full border border-border text-on-surface-variant hover:text-foreground transition-colors"
            >
              <DynamicIcon name="RotateCcw" className="h-4 w-4" />
            </button>
          </div>
        </>
      )}

      {phase === "done" && (
        <>
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: "spring", stiffness: 200 }}
            className="relative mb-1.5"
          >
            <div className="flex h-20 w-20 items-center justify-center rounded-full" style={{ backgroundColor: GOOGLE_COLORS.green + "22" }}>
              <DynamicIcon name="Trophy" className="h-7 w-7" style={{ color: GOOGLE_COLORS.green }} />
            </div>
          </motion.div>

          <h2 className="text-2xl font-bold text-foreground mb-1">أحسنت! 🎉</h2>
          <p className="text-sm text-on-surface-variant mb-1.5 text-center">
            أكملت جلسة تركيز مدتها {usePomodoroStore.getState().selectedDuration} دقيقة
          </p>

          <div className="flex gap-2">
            <button
              onClick={() => startFocus(usePomodoroStore.getState().selectedDuration)}
              className="flex items-center gap-2 rounded-xl px-4 py-2 text-sm font-medium transition-all text-white"
              style={{ backgroundColor: GOOGLE_COLORS.green }}
            >
              <DynamicIcon name="RotateCcw" className="h-4 w-4" />
              جلسة أخرى
            </button>
            <button
              onClick={() => { reset(); setPhase("setup"); }}
              className="flex items-center gap-2 rounded-xl border border-border px-4 py-2 text-sm font-medium text-foreground hover:bg-surface-container-high transition-colors"
            >
              <DynamicIcon name="Check" className="h-4 w-4" />
              إنهاء
            </button>
          </div>
        </>
      )}
    </div>
  );
}

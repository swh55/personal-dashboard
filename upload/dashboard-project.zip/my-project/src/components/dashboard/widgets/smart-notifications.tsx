"use client";

import * as React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { DynamicIcon } from "../icon";
import { useDashboardStore } from "@/store/use-dashboard-store";
import { cn } from "@/lib/utils";

interface Notification {
  id: string;
  type: "info" | "warning" | "success" | "reminder";
  icon: string;
  title: string;
  description: string;
  color: string;
  action?: string;
}

const colorMap: Record<string, { text: string; bg: string; border: string }> = {
  emerald: { text: "text-emerald-glow", bg: "bg-emerald-glow/15", border: "border-emerald-glow/30" },
  amber: { text: "text-amber-glow", bg: "bg-amber-glow/15", border: "border-amber-glow/30" },
  rose: { text: "text-rose-400", bg: "bg-rose-500/15", border: "border-rose-500/30" },
  teal: { text: "text-teal-400", bg: "bg-teal-500/15", border: "border-teal-500/30" },
  purple: { text: "text-purple-400", bg: "bg-purple-500/15", border: "border-purple-500/30" },
};

export function SmartNotificationsWidget() {
  const [notifications, setNotifications] = React.useState<Notification[]>([]);
  const [loading, setLoading] = React.useState(true);
  const { setActiveSection } = useDashboardStore();

  const fetchNotifications = React.useCallback(async () => {
    try {
      const res = await fetch("/api/notifications");
      const json = await res.json();
      if (json.success) setNotifications(json.data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, []);

  React.useEffect(() => {
    fetchNotifications();
    const interval = setInterval(fetchNotifications, 5 * 60 * 1000); // كل 5 دقائق
    return () => clearInterval(interval);
  }, [fetchNotifications]);

  return (
    <Card className="glass p-2 relative overflow-hidden">
      <div className="absolute -top-12 -left-12 h-16 w-32 rounded-full bg-amber-glow/10 blur-3xl" />

      <div className="relative">
        <div className="flex items-center justify-between mb-1.5">
          <div className="flex items-center gap-2">
            <div className="relative">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-amber-glow/15 text-amber-glow">
                <DynamicIcon name="Bell" className="h-4 w-4" />
              </div>
              {notifications.length > 0 && (
                <span className="absolute -top-1 -right-1 h-4 w-4 rounded-full bg-rose-500 text-white text-[9px] font-bold flex items-center justify-center pulse-glow">
                  {notifications.length}
                </span>
              )}
            </div>
            <div>
              <h3 className="text-sm font-bold text-foreground">إشعارات ذكية</h3>
              <p className="text-[10px] text-muted-foreground">{notifications.length} تنبيه</p>
            </div>
          </div>
        </div>

        {loading ? (
          <div className="space-y-2">
            {Array.from({ length: 3 }).map((_, i) => (
              <Skeleton key={i} className="h-8 rounded-lg" />
            ))}
          </div>
        ) : notifications.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-3 text-center">
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-emerald-glow/10 mb-2">
              <DynamicIcon name="CheckCircle" className="h-6 w-6 text-emerald-glow" />
            </div>
            <p className="text-sm font-medium text-foreground">كل شيء على ما يرام!</p>
            <p className="text-xs text-muted-foreground mt-1">لا إشعارات حالياً</p>
          </div>
        ) : (
          <div className="space-y-2 max-h-80 overflow-y-auto custom-scroll">
            <AnimatePresence>
              {notifications.map((notif, i) => {
                const colors = colorMap[notif.color] || colorMap.amber;
                return (
                  <motion.button
                    key={notif.id}
                    layout
                    initial={{ opacity: 0, x: 8 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    transition={{ delay: i * 0.04 }}
                    onClick={() => notif.action && setActiveSection(notif.action as never)}
                    className={cn(
                      "w-full flex items-start gap-2 rounded-xl border p-2 text-right transition-all hover:scale-[1.01]",
                      colors.bg, colors.border
                    )}
                  >
                    <div className={cn("flex h-8 w-8 items-center justify-center rounded-lg shrink-0", colors.bg, colors.text)}>
                      <DynamicIcon name={notif.icon} className="h-4 w-4" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-bold text-foreground">{notif.title}</p>
                      {notif.description && (
                        <p className="text-[10px] text-muted-foreground mt-0.5 truncate">{notif.description}</p>
                      )}
                    </div>
                    {notif.action && (
                      <DynamicIcon name="ChevronLeft" className={cn("h-3.5 w-3.5 shrink-0 mt-1", colors.text)} />
                    )}
                  </motion.button>
                );
              })}
            </AnimatePresence>
          </div>
        )}
      </div>
    </Card>
  );
}

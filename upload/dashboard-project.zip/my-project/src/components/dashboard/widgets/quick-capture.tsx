"use client";

import * as React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { DynamicIcon } from "../icon";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

type CaptureType = "task" | "note" | "expense";

interface CaptureOption {
  id: CaptureType;
  label: string;
  icon: string;
  placeholder: string;
  color: string;
}

const OPTIONS: CaptureOption[] = [
  { id: "task", label: "مهمة", icon: "CheckSquare", placeholder: "أضف مهمة سريعة...", color: "emerald" },
  { id: "note", label: "ملاحظة", icon: "StickyNote", placeholder: "اكتب ملاحظة سريعة...", color: "amber" },
  { id: "expense", label: "مصروف", icon: "Receipt", placeholder: "أضف مصروف سريع...", color: "rose" },
];

const colorMap: Record<string, { text: string; bg: string; border: string }> = {
  emerald: { text: "text-emerald-glow", bg: "bg-emerald-glow/15", border: "border-emerald-glow/30" },
  amber: { text: "text-amber-glow", bg: "bg-amber-glow/15", border: "border-amber-glow/30" },
  rose: { text: "text-rose-400", bg: "bg-rose-500/15", border: "border-rose-500/30" },
};

export function QuickCaptureWidget() {
  const [activeType, setActiveType] = React.useState<CaptureType>("task");
  const [value, setValue] = React.useState("");
  const [expenseAmount, setExpenseAmount] = React.useState("");
  const [submitting, setSubmitting] = React.useState(false);
  const inputRef = React.useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const activeOption = OPTIONS.find((o) => o.id === activeType)!;

  const handleSubmit = async () => {
    if (!value.trim()) {
      toast({ title: "الرجاء إدخال قيمة", variant: "destructive" });
      return;
    }

    setSubmitting(true);
    try {
      if (activeType === "task") {
        await fetch("/api/tasks", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ title: value, category: "home", priority: "medium" }),
        });
        toast({ title: "تمت إضافة المهمة ✅" });
      } else if (activeType === "note") {
        await fetch("/api/notes", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ title: value.slice(0, 40), content: value }),
        });
        toast({ title: "تمت إضافة الملاحظة ✅" });
      } else if (activeType === "expense") {
        const amount = parseFloat(expenseAmount);
        if (!amount || amount <= 0) {
          toast({ title: "أدخل مبلغاً صحيحاً", variant: "destructive" });
          setSubmitting(false);
          return;
        }
        await fetch("/api/expenses", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ amount, currency: "syp", category: "other", description: value }),
        });
        toast({ title: "تمت إضافة المصروف ✅" });
        setExpenseAmount("");
      }
      setValue("");
      inputRef.current?.focus();
    } catch {
      toast({ title: "فشل الإضافة", variant: "destructive" });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Card className="glass p-2 relative overflow-hidden">
      <div className="absolute -top-12 -left-12 h-16 w-32 rounded-full bg-emerald-glow/10 blur-3xl" />

      <div className="relative">
        <div className="flex items-center justify-between mb-1.5">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-emerald-glow/15 text-emerald-glow">
              <DynamicIcon name="Zap" className="h-4 w-4" />
            </div>
            <h3 className="text-sm font-bold text-foreground">إضافة سريعة</h3>
          </div>
          <span className="text-[10px] text-muted-foreground">Enter للحفظ</span>
        </div>

        {/* Type selector */}
        <div className="flex gap-1.5 mb-1.5">
          {OPTIONS.map((opt) => {
            const colors = colorMap[opt.color];
            const isActive = activeType === opt.id;
            return (
              <button
                key={opt.id}
                onClick={() => {
                  setActiveType(opt.id);
                  setValue("");
                  setExpenseAmount("");
                  inputRef.current?.focus();
                }}
                className={cn(
                  "flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg border text-xs font-medium transition-all",
                  isActive
                    ? cn(colors.bg, colors.border, colors.text)
                    : "border-border/40 text-muted-foreground hover:border-emerald-glow/20"
                )}
              >
                <DynamicIcon name={opt.icon} className="h-3.5 w-3.5" />
                {opt.label}
              </button>
            );
          })}
        </div>

        {/* Input area */}
        <AnimatePresence mode="wait">
          <motion.div
            key={activeType}
            initial={{ opacity: 0, y: 4 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -4 }}
            transition={{ duration: 0.15 }}
            className="space-y-2"
          >
            {activeType === "expense" && (
              <Input
                type="number"
                value={expenseAmount}
                onChange={(e) => setExpenseAmount(e.target.value)}
                placeholder="المبلغ بالليرة السورية"
                dir="ltr"
                className="bg-background/50 font-bold"
              />
            )}
            <div className="flex gap-2">
              <Input
                ref={inputRef}
                value={value}
                onChange={(e) => setValue(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && !e.shiftKey) {
                    e.preventDefault();
                    handleSubmit();
                  }
                }}
                placeholder={activeOption.placeholder}
                className="bg-background/50 flex-1"
              />
              <Button
                onClick={handleSubmit}
                disabled={submitting || !value.trim()}
                className={cn(
                  "shrink-0",
                  activeType === "task" && "bg-emerald-glow hover:bg-emerald-glow/90 text-background",
                  activeType === "note" && "bg-amber-glow hover:bg-amber-glow/90 text-background",
                  activeType === "expense" && "bg-rose-500 hover:bg-rose-600 text-white"
                )}
              >
                <DynamicIcon name={submitting ? "Loader2" : "Plus"} className={cn("h-4 w-4", submitting && "animate-spin")} />
              </Button>
            </div>
          </motion.div>
        </AnimatePresence>

        <p className="text-[10px] text-muted-foreground/70 mt-2 text-center">
          التقط أفكارك ومهامك بسرعة دون مغادرة الصفحة
        </p>
      </div>
    </Card>
  );
}

"use client";

import * as React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { DynamicIcon } from "../icon";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { getActiveDynamicShortcuts, DEFAULT_STATIC_SHORTCUTS } from "@/lib/shortcuts";

const GOOGLE_COLORS = {
  blue: "#4285F4", red: "#EA4335", yellow: "#FBBC04", green: "#34A853",
  orange: "#FF6D00", purple: "#A142F4", teal: "#00897B", gray: "#5F6368",
};

export function ShortcutsWidget() {
  const [completedToday, setCompletedToday] = React.useState<Set<string>>(new Set());
  const [activeDynamic, setActiveDynamic] = React.useState<ReturnType<typeof getActiveDynamicShortcuts>>([]);
  const { toast } = useToast();

  // تحديث الاختصارات الديناميكية كل دقيقة
  React.useEffect(() => {
    const update = () => setActiveDynamic(getActiveDynamicShortcuts(new Date()));
    update();
    const interval = setInterval(update, 60000);
    return () => clearInterval(interval);
  }, []);

  // جلب الاختصارات المنجزة اليوم
  React.useEffect(() => {
    fetch("/api/shortcut-log")
      .then((r) => r.json())
      .then((json) => {
        if (json.success) {
          setCompletedToday(new Set(json.data.completedToday));
        }
      })
      .catch(() => {});
  }, []);

  const handleStaticAction = (shortcut: typeof DEFAULT_STATIC_SHORTCUTS[0]) => {
    if (shortcut.action === "navigate") {
      // محاولة الحصول على الموقع الحالي أولاً
      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
          (pos) => {
            const { latitude, longitude } = pos.coords;
            // استخراج الوجهة من actionData
            const destMatch = shortcut.actionData.match(/destination=([\d.\-]+),([\d.\-]+)/);
            if (destMatch) {
              const url = `https://www.google.com/maps/dir/?api=1&origin=${latitude},${longitude}&destination=${destMatch[1]},${destMatch[2]}`;
              window.open(url, "_blank");
            } else {
              window.open(shortcut.actionData, "_blank");
            }
          },
          () => {
            window.open(shortcut.actionData, "_blank");
          }
        );
      } else {
        window.open(shortcut.actionData, "_blank");
      }
      toast({ title: `فتح الخريطة: ${shortcut.label}` });
    } else if (shortcut.action === "call") {
      window.open(shortcut.actionData, "_self");
      toast({ title: shortcut.label });
    } else if (shortcut.action === "message") {
      // إرسال الموقع الحالي
      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
          (pos) => {
            const { latitude, longitude } = pos.coords;
            const mapsUrl = `https://www.google.com/maps?q=${latitude},${longitude}`;
            const message = `موقعي الحالي: ${mapsUrl}`;
            // نسخ الرابط
            navigator.clipboard.writeText(message);
            // فتح واتساب
            window.open(`https://wa.me/?text=${encodeURIComponent(message)}`, "_blank");
            toast({ title: "تم نسخ الموقع وفتح واتساب" });
          },
          () => {
            toast({ title: "تعذر الحصول على الموقع", variant: "destructive" });
          }
        );
      } else {
        toast({ title: "المتصفح لا يدعم تحديد الموقع", variant: "destructive" });
      }
    }
  };

  const handleDynamicAction = async (shortcut: { id: string; label: string }) => {
    try {
      await fetch("/api/shortcut-log", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ shortcutId: shortcut.id, label: shortcut.label }),
      });
      setCompletedToday((prev) => new Set(prev).add(shortcut.id));
      toast({ title: `${shortcut.label} ✓` });
    } catch {
      toast({ title: "فشل التسجيل", variant: "destructive" });
    }
  };

  return (
    <div className="space-y-1">
      {/* الاختصارات الثابتة */}
      <div className="grid grid-cols-4 gap-1">
        {DEFAULT_STATIC_SHORTCUTS.map((s) => (
          <button
            key={s.id}
            onClick={() => handleStaticAction(s)}
            className="flex flex-col items-center gap-0.5 p-1 rounded-lg transition-all hover:scale-105"
            style={{ backgroundColor: s.color + "12" }}
          >
            <div className="flex h-7 w-7 items-center justify-center rounded-full" style={{ backgroundColor: s.color + "22" }}>
              <DynamicIcon name={s.icon} className="h-3.5 w-3.5" style={{ color: s.color }} />
            </div>
            <span className="text-[8px] text-foreground text-center leading-tight">{s.label}</span>
          </button>
        ))}
      </div>

      {/* الاختصارات الديناميكية */}
      <AnimatePresence>
        {activeDynamic.length > 0 && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden"
          >
            <div className="flex items-center gap-1 mb-0.5">
              <span className="text-[9px] text-on-surface-variant">اختصارات الآن</span>
              <span className="h-1 w-1 rounded-full animate-pulse" style={{ backgroundColor: GOOGLE_COLORS.red }} />
            </div>
            <div className="grid grid-cols-2 gap-1">
              {activeDynamic.map((s) => {
                const done = completedToday.has(s.id);
                return (
                  <motion.button
                    key={s.id}
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.9 }}
                    onClick={() => !done && handleDynamicAction(s)}
                    disabled={done}
                    className={cn(
                      "flex items-center gap-1.5 p-1.5 rounded-lg transition-all",
                      done ? "opacity-50" : "hover:scale-[1.02]"
                    )}
                    style={{
                      backgroundColor: done ? "var(--surface-container)" : s.color + "15",
                      border: `1px solid ${s.color}33`,
                    }}
                  >
                    <div
                      className="flex h-6 w-6 items-center justify-center rounded-full shrink-0"
                      style={{ backgroundColor: done ? GOOGLE_COLORS.green + "22" : s.color + "22" }}
                    >
                      <DynamicIcon
                        name={done ? "Check" : s.icon}
                        className="h-3 w-3"
                        style={{ color: done ? GOOGLE_COLORS.green : s.color }}
                      />
                    </div>
                    <span className={cn(
                      "text-[10px] truncate",
                      done ? "text-on-surface-variant line-through" : "text-foreground"
                    )}>
                      {s.label}
                    </span>
                  </motion.button>
                );
              })}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

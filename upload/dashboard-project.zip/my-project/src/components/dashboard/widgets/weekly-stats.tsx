"use client";

import * as React from "react";
import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { DynamicIcon } from "../icon";
import { cn } from "@/lib/utils";

interface DailyStat {
  day: string;
  date: string;
  tasks: number;
  expenses: number;
  habits: number;
  isToday: boolean;
}

interface WeeklyStats {
  tasksDoneThisWeek: number;
  tasksCreatedThisWeek: number;
  totalExpensesSYP: number;
  todayExpensesSYP: number;
  habitsCompletedThisWeek: number;
  eventsThisWeek: number;
  callsThisWeek: number;
  dailyStats: DailyStat[];
}

const formatAmount = (amount: number) => {
  if (amount >= 1000000) return (amount / 1000000).toFixed(1) + "M";
  if (amount >= 1000) return (amount / 1000).toFixed(1) + "K";
  return amount.toLocaleString("en-US", { maximumFractionDigits: 0 });
};

export function WeeklyStatsWidget() {
  const [data, setData] = React.useState<WeeklyStats | null>(null);
  const [loading, setLoading] = React.useState(true);
  const [period, setPeriod] = React.useState<"week" | "month">("week");

  React.useEffect(() => {
    setLoading(true);
    fetch(`/api/stats?period=${period}`)
      .then((r) => r.json())
      .then((json) => {
        if (json.success) setData(json.data);
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  }, [period]);

  const maxTasks = Math.max(...(data?.dailyStats.map((d) => d.tasks) || [1]), 1);

  if (loading) {
    return (
      <Card className="glass p-2">
        <Skeleton className="h-6 w-32 mb-1.5" />
        <Skeleton className="h-16 rounded-xl" />
      </Card>
    );
  }

  if (!data) return null;

  return (
    <Card className="glass p-2 relative overflow-hidden">
      <div className="absolute -top-12 -left-12 h-16 w-32 rounded-full bg-emerald-glow/10 blur-3xl" />

      <div className="relative">
        <div className="flex items-center justify-between mb-1.5">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-emerald-glow/15 text-emerald-glow">
              <DynamicIcon name="BarChart3" className="h-4 w-4" />
            </div>
            <h3 className="text-sm font-bold text-foreground">الإحصائيات</h3>
          </div>
          {/* Period toggle */}
          <div className="flex rounded-lg bg-muted/30 p-0.5">
            <button
              onClick={() => setPeriod("week")}
              className={cn(
                "px-2.5 py-1 text-[10px] rounded-md transition-all font-medium",
                period === "week" ? "bg-emerald-glow/15 text-emerald-glow" : "text-muted-foreground"
              )}
            >
              أسبوع
            </button>
            <button
              onClick={() => setPeriod("month")}
              className={cn(
                "px-2.5 py-1 text-[10px] rounded-md transition-all font-medium",
                period === "month" ? "bg-emerald-glow/15 text-emerald-glow" : "text-muted-foreground"
              )}
            >
              شهر
            </button>
          </div>
        </div>

        {/* Stats grid */}
        <div className="grid grid-cols-2 gap-2 mb-1.5">
          <div className="rounded-xl bg-emerald-glow/10 border border-emerald-glow/20 p-2">
            <div className="flex items-center gap-2 mb-1">
              <DynamicIcon name="CheckCircle" className="h-3.5 w-3.5 text-emerald-glow" />
              <span className="text-[10px] text-muted-foreground">مهام منجزة</span>
            </div>
            <p className="text-xl font-bold text-emerald-glow">{data.tasksDoneThisWeek}</p>
          </div>
          <div className="rounded-xl bg-amber-glow/10 border border-amber-glow/20 p-2">
            <div className="flex items-center gap-2 mb-1">
              <DynamicIcon name="Receipt" className="h-3.5 w-3.5 text-amber-glow" />
              <span className="text-[10px] text-muted-foreground">المصروفات</span>
            </div>
            <p className="text-xl font-bold text-amber-glow">{formatAmount(data.totalExpensesSYP)}</p>
          </div>
          <div className="rounded-xl bg-teal-500/10 border border-teal-500/20 p-2">
            <div className="flex items-center gap-2 mb-1">
              <DynamicIcon name="RefreshCw" className="h-3.5 w-3.5 text-teal-400" />
              <span className="text-[10px] text-muted-foreground">عادات منجزة</span>
            </div>
            <p className="text-xl font-bold text-teal-400">{data.habitsCompletedThisWeek}</p>
          </div>
          <div className="rounded-xl bg-rose-500/10 border border-rose-500/20 p-2">
            <div className="flex items-center gap-2 mb-1">
              <DynamicIcon name="Phone" className="h-3.5 w-3.5 text-rose-400" />
              <span className="text-[10px] text-muted-foreground">مكالمات</span>
            </div>
            <p className="text-xl font-bold text-rose-400">{data.callsThisWeek}</p>
          </div>
        </div>

        {/* Daily tasks chart */}
        <div>
          <p className="text-[11px] text-muted-foreground mb-2 font-medium">
            المهام المنجزة {period === "week" ? "يومياً" : "شهرياً"}
          </p>
          <div className={cn(
            "flex items-end justify-between gap-1",
            period === "month" ? "h-20" : "h-16"
          )}>
            {data.dailyStats.map((day, i) => {
              const heightPercent = (day.tasks / maxTasks) * 100;
              return (
                <div key={i} className="flex-1 flex flex-col items-center gap-1 min-w-0">
                  <div className="w-full flex-1 flex items-end">
                    <motion.div
                      initial={{ height: 0 }}
                      animate={{ height: `${Math.max(heightPercent, 3)}%` }}
                      transition={{ delay: Math.min(i * 0.02, 0.5), type: "spring", stiffness: 200 }}
                      className={cn(
                        "w-full rounded-t-sm relative group cursor-pointer",
                        day.isToday
                          ? "bg-gradient-to-t from-emerald-glow to-amber-glow"
                          : "bg-gradient-to-t from-emerald-glow/40 to-emerald-glow/20"
                      )}
                    >
                      <div className="absolute -top-2 left-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-opacity bg-background/90 rounded px-1.5 py-0.5 text-[9px] font-bold text-foreground whitespace-nowrap border border-border/40 z-10">
                        {day.tasks}
                      </div>
                    </motion.div>
                  </div>
                  {(period === "week" || i % 5 === 0 || i === data.dailyStats.length - 1) && (
                    <span className={cn(
                      "text-[8px] sm:text-[9px]",
                      day.isToday ? "text-emerald-glow font-bold" : "text-muted-foreground"
                    )}>
                      {day.day}
                    </span>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </Card>
  );
}

"use client";

import * as React from "react";
import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { DynamicIcon } from "../icon";
import { cn } from "@/lib/utils";

interface PrayerTime {
  key: string;
  time: string;
  name: string;
  isPrayer: boolean;
}

interface PrayerData {
  timings: PrayerTime[];
  nextPrayer: PrayerTime | null;
  timeUntilNext: string;
  hijriDate: string;
  gregorianDate: string;
  city: string;
}

const prayerIcons: Record<string, string> = {
  Imsak: "Moon",
  Fajr: "Sunrise",
  Sunrise: "Sunrise",
  Dhuhr: "Sun",
  Asr: "Sun",
  Maghrib: "Sunset",
  Isha: "Moon",
  Midnight: "Moon",
};

export function PrayerTimesWidget() {
  const [data, setData] = React.useState<PrayerData | null>(null);
  const [loading, setLoading] = React.useState(true);

  const fetchPrayers = React.useCallback(async () => {
    try {
      const res = await fetch("/api/prayer-times");
      const json = await res.json();
      if (json.success) setData(json.data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, []);

  React.useEffect(() => {
    fetchPrayers();
    const interval = setInterval(fetchPrayers, 60 * 1000); // كل دقيقة
    return () => clearInterval(interval);
  }, [fetchPrayers]);

  if (loading) {
    return (
      <Card className="glass p-2">
        <Skeleton className="h-6 w-32 mb-1.5" />
        <div className="grid grid-cols-3 gap-2">
          {Array.from({ length: 6 }).map((_, i) => (
            <Skeleton key={i} className="h-10 rounded-lg" />
          ))}
        </div>
      </Card>
    );
  }

  if (!data) {
    return (
      <Card className="glass p-2">
        <p className="text-sm text-muted-foreground">تعذر تحميل مواقيت الصلاة</p>
      </Card>
    );
  }

  const prayers = data.timings.filter((t) => t.isPrayer);

  return (
    <Card className="glass p-2 relative overflow-hidden group">
      {/* Glow background */}
      <div className="absolute -top-12 -left-12 h-20 w-20 rounded-full bg-emerald-glow/10 blur-3xl" />

      <div className="relative">
        <div className="flex items-start justify-between mb-1">
          <div>
            <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-emerald-glow/15 text-emerald-glow">
                <DynamicIcon name="Sparkles" className="h-4 w-4" />
              </div>
              <h3 className="text-sm font-bold text-foreground">مواقيت الصلاة</h3>
            </div>
            <p className="text-[11px] text-muted-foreground mt-1">
              {data.city} • {data.hijriDate}
            </p>
          </div>
        </div>

        {/* Next prayer highlight */}
        {data.nextPrayer && (
          <motion.div
            initial={{ opacity: 0, scale: 0.96 }}
            animate={{ opacity: 1, scale: 1 }}
            className="mb-1.5 rounded-xl bg-gradient-to-l from-emerald-glow/15 via-emerald-glow/5 to-transparent border border-emerald-glow/20 p-2"
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-[10px] uppercase tracking-wider text-emerald-glow/80 font-semibold">
                  الصلاة القادمة
                </p>
                <p className="text-base font-bold text-foreground">
                  {data.nextPrayer.name}
                </p>
              </div>
              <div className="text-left">
                <p className="text-lg font-mono font-bold text-gradient-emerald">
                  {data.nextPrayer.time}
                </p>
                {data.timeUntilNext && (
                  <p className="text-[10px] text-muted-foreground">
                    بعد {data.timeUntilNext}
                  </p>
                )}
              </div>
            </div>
          </motion.div>
        )}

        {/* Prayer grid */}
        <div className="grid grid-cols-3 gap-2">
          {prayers.map((prayer, i) => {
            const isNext = data.nextPrayer?.key === prayer.key;
            return (
              <motion.div
                key={prayer.key}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
                className={cn(
                  "rounded-xl border p-2.5 text-center transition-all",
                  isNext
                    ? "bg-emerald-glow/10 border-emerald-glow/30"
                    : "bg-background/40 border-border/40 hover:border-emerald-glow/20"
                )}
              >
                <DynamicIcon
                  name={prayerIcons[prayer.key] || "Sparkles"}
                  className={cn(
                    "h-4 w-4 mx-auto mb-1",
                    isNext ? "text-emerald-glow" : "text-muted-foreground"
                  )}
                />
                <p className="text-[10px] text-muted-foreground mb-0.5">
                  {prayer.name}
                </p>
                <p className={cn(
                  "text-sm font-mono font-bold",
                  isNext ? "text-emerald-glow" : "text-foreground"
                )}>
                  {prayer.time}
                </p>
              </motion.div>
            );
          })}
        </div>
      </div>
    </Card>
  );
}

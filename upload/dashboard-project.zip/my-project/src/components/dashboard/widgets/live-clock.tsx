"use client";

import * as React from "react";
import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { DynamicIcon } from "../icon";
import { aleppoTimeString, hourInAleppo } from "@/lib/aleppo-time";
import { formatSyrianAleppo } from "@/lib/syrian-date";

export function LiveClockWidget() {
  const [, setTick] = React.useState(0);

  React.useEffect(() => {
    const interval = setInterval(() => setTick(t => t + 1), 1000);
    return () => clearInterval(interval);
  }, []);

  const now = new Date();
  const hours = hourInAleppo(now);
  const timeStr = aleppoTimeString(now);
  const dateStr = formatSyrianAleppo(now, "EEEE d MMMM yyyy");

  // Parse time string to get hours/minutes/seconds
  const timeParts = timeStr.match(/(\d+):(\d+)/);
  const displayHours = timeParts ? timeParts[1] : "00";
  const minutes = timeParts ? timeParts[2] : "00";
  const isAM = hours < 12;

  // لحظة اليوم
  const period = hours < 6 ? "ليلاً" : hours < 12 ? "صباحاً" : hours < 15 ? "ظهراً" : hours < 18 ? "عصراً" : hours < 21 ? "مساءً" : "ليلاً";
  const greeting = hours < 6 ? "ليلة هادئة" : hours < 12 ? "صباح الخير" : hours < 15 ? "يوم سعيد" : hours < 18 ? "عصر جميل" : hours < 21 ? "مساء النور" : "ليلة مباركة";

  return (
    <Card className="glass p-2 relative overflow-hidden">
      <div className="relative">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <div className="flex h-7 w-7 items-center justify-center rounded-lg" style={{ backgroundColor: "var(--accent-primary)" + "22" }}>
              <DynamicIcon name={isAM ? "Sunrise" : "Moon"} className="h-4 w-4" style={{ color: "var(--accent-primary)" }} />
            </div>
            <div>
              <h3 className="text-xs font-bold text-foreground">{greeting}</h3>
              <p className="text-[9px] text-on-surface-variant">{period} • توقيت حلب</p>
            </div>
          </div>
        </div>

        {/* Big clock */}
        <div className="flex items-center justify-center my-1">
          <div className="font-mono font-bold tabular-nums flex items-baseline gap-1">
            <motion.span
              key={`hours-${displayHours}`}
              initial={{ y: -4, opacity: 0.5 }}
              animate={{ y: 0, opacity: 1 }}
              className="text-3xl"
              style={{ color: "var(--accent-primary)" }}
            >
              {displayHours}
            </motion.span>
            <motion.span
              animate={{ opacity: [1, 0.3, 1] }}
              transition={{ duration: 1, repeat: Infinity }}
              className="text-2xl text-on-surface-variant"
            >
              :
            </motion.span>
            <motion.span
              key={`minutes-${minutes}`}
              initial={{ y: -4, opacity: 0.5 }}
              animate={{ y: 0, opacity: 1 }}
              className="text-3xl"
              style={{ color: "var(--accent-primary)" }}
            >
              {minutes}
            </motion.span>
            <span className="text-xs text-on-surface-variant mr-1">
              {isAM ? "ص" : "م"}
            </span>
          </div>
        </div>

        {/* Date */}
        <div className="text-center">
          <p className="text-[10px] text-on-surface-variant">{dateStr}</p>
        </div>
      </div>
    </Card>
  );
}

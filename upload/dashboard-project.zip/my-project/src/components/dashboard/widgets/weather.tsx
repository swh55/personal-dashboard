"use client";

import * as React from "react";
import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { DynamicIcon } from "../icon";
import { cn } from "@/lib/utils";

interface WeatherData {
  current: {
    temperature: number;
    apparentTemperature: number;
    humidity: number;
    windSpeed: number;
    windDirection: number;
    pressure: number;
    weatherCode: number;
    weatherDescription: string;
    weatherIcon: string;
  };
  forecast: Array<{
    date: string;
    maxTemp: number;
    minTemp: number;
    weather: { ar: string; icon: string };
    sunrise: string;
    sunset: string;
  }>;
  city: string;
}

export function WeatherWidget() {
  const [data, setData] = React.useState<WeatherData | null>(null);
  const [loading, setLoading] = React.useState(true);

  const fetchWeather = React.useCallback(async () => {
    try {
      const res = await fetch("/api/weather");
      const json = await res.json();
      if (json.success) setData(json.data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, []);

  React.useEffect(() => {
    fetchWeather();
    const interval = setInterval(fetchWeather, 30 * 60 * 1000);
    return () => clearInterval(interval);
  }, [fetchWeather]);

  if (loading) {
    return (
      <Card className="glass p-2">
        <Skeleton className="h-6 w-32 mb-1.5" />
        <Skeleton className="h-16 rounded-xl" />
      </Card>
    );
  }

  if (!data) {
    return (
      <Card className="glass p-2">
        <p className="text-sm text-muted-foreground">تعذر تحميل حالة الطقس</p>
      </Card>
    );
  }

  const c = data.current;

  return (
    <Card className="glass p-2 relative overflow-hidden">
      <div className="absolute -top-12 -right-12 h-20 w-20 rounded-full bg-amber-glow/10 blur-3xl" />

      <div className="relative">
        <div className="flex items-start justify-between mb-1.5">
          <div>
            <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-amber-glow/15 text-amber-glow">
                <DynamicIcon name="Cloud" className="h-4 w-4" />
              </div>
              <h3 className="text-sm font-bold text-foreground">حالة الطقس</h3>
            </div>
            <p className="text-[11px] text-muted-foreground mt-1">
              {data.city} • الآن
            </p>
          </div>
        </div>

        {/* Current weather */}
        <motion.div
          initial={{ opacity: 0, scale: 0.96 }}
          animate={{ opacity: 1, scale: 1 }}
          className="rounded-xl bg-gradient-to-l from-amber-glow/10 via-amber-glow/5 to-transparent border border-amber-glow/20 p-2 mb-1.5"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <DynamicIcon
                name={c.weatherIcon}
                className="h-8 w-8 text-amber-glow"
              />
              <div>
                <p className="text-3xl font-bold text-foreground">
                  {c.temperature}°
                  <span className="text-base text-muted-foreground">C</span>
                </p>
                <p className="text-xs text-muted-foreground">
                  {c.weatherDescription}
                </p>
              </div>
            </div>
            <div className="text-left space-y-1">
              <div className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
                <DynamicIcon name="Droplets" className="h-3 w-3" />
                <span>{c.humidity}%</span>
              </div>
              <div className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
                <DynamicIcon name="Wind" className="h-3 w-3" />
                <span>{c.windSpeed} كم/س</span>
              </div>
              <div className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
                <DynamicIcon name="Gauge" className="h-3 w-3" />
                <span>{c.pressure} hPa</span>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Forecast */}
        <div className="grid grid-cols-4 gap-2">
          {data.forecast.slice(0, 4).map((day, i) => {
            const date = new Date(day.date);
            const dayName = ["الأحد", "الإثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت"][date.getDay()];
            const isToday = i === 0;
            return (
              <div
                key={day.date}
                className={cn(
                  "rounded-lg border p-2 text-center transition-all",
                  isToday
                    ? "bg-amber-glow/10 border-amber-glow/30"
                    : "bg-background/40 border-border/40"
                )}
              >
                <p className="text-[10px] text-muted-foreground mb-1">
                  {isToday ? "اليوم" : dayName}
                </p>
                <DynamicIcon
                  name={day.weather.icon}
                  className={cn(
                    "h-4 w-4 mx-auto mb-1",
                    isToday ? "text-amber-glow" : "text-muted-foreground"
                  )}
                />
                <p className="text-xs font-bold text-foreground">
                  {day.maxTemp}°
                </p>
                <p className="text-[10px] text-muted-foreground">
                  {day.minTemp}°
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </Card>
  );
}

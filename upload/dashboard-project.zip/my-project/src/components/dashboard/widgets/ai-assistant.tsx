"use client";

import * as React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { DynamicIcon } from "../icon";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

interface Message {
  role: "user" | "assistant";
  content: string;
}

const SUGGESTIONS = [
  { icon: "Calendar", text: "ما جدولي اليوم؟", color: "emerald" },
  { icon: "Lightbulb", text: "اقترح 3 طرق لتنظيم وقتي", color: "amber" },
  { icon: "TrendingUp", text: "كيف أزيد إنتاجيتي؟", color: "teal" },
  { icon: "Heart", text: "نصيحة للتوازن بين العمل والعائلة", color: "rose" },
];

const colorMap: Record<string, string> = {
  emerald: "text-emerald-glow bg-emerald-glow/10",
  amber: "text-amber-glow bg-amber-glow/10",
  teal: "text-teal-400 bg-teal-500/10",
  rose: "text-rose-400 bg-rose-500/10",
};

export function AIAssistantWidget() {
  const [messages, setMessages] = React.useState<Message[]>([]);
  const [input, setInput] = React.useState("");
  const [loading, setLoading] = React.useState(false);
  const [expanded, setExpanded] = React.useState(false);
  const scrollRef = React.useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  React.useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const sendMessage = async (text: string) => {
    if (!text.trim() || loading) return;
    const userMsg: Message = { role: "user", content: text };
    setMessages((prev) => [...prev, userMsg]);
    setInput("");
    setLoading(true);

    try {
      const res = await fetch("/api/ai/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: text, context: { includeData: true } }),
      });
      const json = await res.json();
      const aiMsg: Message = {
        role: "assistant",
        content: json.response || json.error || "عذراً، لم أتمكن من الرد",
      };
      setMessages((prev) => [...prev, aiMsg]);
    } catch {
      setMessages((prev) => [...prev, { role: "assistant", content: "عذراً، حدث خطأ في الاتصال" }]);
      toast({ title: "فشل الاتصال بالمساعد", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card className="glass p-2 relative overflow-hidden">
      <div className="absolute -top-12 -right-12 h-16 w-32 rounded-full bg-gradient-to-br from-emerald-glow/20 to-amber-glow/10 blur-3xl" />

      <div className="relative">
        <div className="flex items-center justify-between mb-1.5">
          <div className="flex items-center gap-2">
            <div className="relative">
              <div className="absolute inset-0 rounded-lg bg-emerald-glow/30 blur-md" />
              <div className="relative flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-emerald-glow to-amber-glow text-background">
                <DynamicIcon name="Sparkles" className="h-4 w-4" />
              </div>
            </div>
            <div>
              <h3 className="text-sm font-bold text-foreground">المساعد الذكي</h3>
              <p className="text-[10px] text-muted-foreground flex items-center gap-1">
                <span className="h-1.5 w-1.5 rounded-full bg-emerald-glow pulse-glow" />
                متصل
              </p>
            </div>
          </div>
          <Button
            variant="ghost"
            size="icon"
            className="h-7 w-7"
            onClick={() => setExpanded(!expanded)}
          >
            <DynamicIcon name={expanded ? "Minimize2" : "Maximize2"} className="h-3.5 w-3.5" />
          </Button>
        </div>

        {/* Messages area */}
        <div
          ref={scrollRef}
          className={cn(
            "space-y-2.5 overflow-y-auto custom-scroll transition-all",
            expanded ? "max-h-96" : "max-h-48"
          )}
        >
          {messages.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-2 text-center">
              <div className="flex h-8 w-8 items-center justify-center rounded-full bg-emerald-glow/10 mb-2">
                <DynamicIcon name="Sparkles" className="h-6 w-6 text-emerald-glow" />
              </div>
              <p className="text-xs text-foreground font-medium">مرحباً! أنا مساعدك الشخصي</p>
              <p className="text-[10px] text-muted-foreground mt-1">اسألني أي شيء عن جدولك ومهامك</p>
            </div>
          ) : (
            <AnimatePresence>
              {messages.map((msg, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={cn(
                    "flex gap-2",
                    msg.role === "user" ? "flex-row-reverse" : "flex-row"
                  )}
                >
                  <div className={cn(
                    "flex h-7 w-7 items-center justify-center rounded-full shrink-0",
                    msg.role === "user"
                      ? "bg-amber-glow/15 text-amber-glow"
                      : "bg-emerald-glow/15 text-emerald-glow"
                  )}>
                    <DynamicIcon name={msg.role === "user" ? "User" : "Sparkles"} className="h-3.5 w-3.5" />
                  </div>
                  <div className={cn(
                    "rounded-2xl px-3 py-2 text-xs max-w-[85%] leading-relaxed",
                    msg.role === "user"
                      ? "bg-amber-glow/10 text-foreground rounded-tr-sm"
                      : "bg-emerald-glow/10 text-foreground rounded-tl-sm"
                  )}>
                    <p className="whitespace-pre-wrap">{msg.content}</p>
                  </div>
                </motion.div>
              ))}
              {loading && (
                <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex gap-2">
                  <div className="flex h-7 w-7 items-center justify-center rounded-full bg-emerald-glow/15 text-emerald-glow shrink-0">
                    <DynamicIcon name="Sparkles" className="h-3.5 w-3.5" />
                  </div>
                  <div className="bg-emerald-glow/10 rounded-2xl rounded-tl-sm px-3 py-3 flex items-center gap-1">
                    {[0, 1, 2].map((d) => (
                      <motion.span
                        key={d}
                        animate={{ opacity: [0.3, 1, 0.3] }}
                        transition={{ duration: 1, repeat: Infinity, delay: d * 0.2 }}
                        className="h-1.5 w-1.5 rounded-full bg-emerald-glow"
                      />
                    ))}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          )}
        </div>

        {/* Suggestions */}
        {messages.length === 0 && (
          <div className="grid grid-cols-2 gap-1.5 mt-1.5">
            {SUGGESTIONS.map((s) => (
              <button
                key={s.text}
                onClick={() => sendMessage(s.text)}
                className="flex items-center gap-1.5 rounded-lg border border-border/40 bg-background/30 p-2 text-right hover:border-emerald-glow/30 transition-all"
              >
                <DynamicIcon name={s.icon} className={cn("h-3.5 w-3.5 shrink-0", colorMap[s.color].split(" ")[0])} />
                <span className="text-[10px] text-foreground leading-tight">{s.text}</span>
              </button>
            ))}
          </div>
        )}

        {/* Input */}
        <div className="flex gap-2 mt-1.5">
          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                sendMessage(input);
              }
            }}
            placeholder="اكتب سؤالك..."
            className="bg-background/50 text-xs h-9"
            disabled={loading}
          />
          <Button
            size="icon"
            className="h-9 w-9 shrink-0 bg-emerald-glow hover:bg-emerald-glow/90 text-background"
            onClick={() => sendMessage(input)}
            disabled={loading || !input.trim()}
          >
            <DynamicIcon name={loading ? "Loader2" : "Send"} className={cn("h-4 w-4", loading && "animate-spin")} />
          </Button>
        </div>
      </div>
    </Card>
  );
}

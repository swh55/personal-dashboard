"use client";

import * as React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { DynamicIcon } from "./icon";
import { FloatingPanel } from "./floating-panel";
import { useFloatingPanelStore } from "@/store/use-floating-panel";
import { usePomodoroStore, usePomodoroTimer } from "@/store/use-pomodoro-store";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { format } from "date-fns";
import { ar } from "date-fns/locale";
import { aleppoTimeString } from "@/lib/aleppo-time";
import { formatSyrianAleppo, SYRIAN_WEEKDAYS } from "@/lib/syrian-date";
import { ShortcutsWidget } from "./widgets/shortcuts";

// Google brand colors for colorful icons
const GOOGLE_COLORS = {
  blue: "#4285F4",
  red: "#EA4335",
  yellow: "#FBBC04",
  green: "#34A853",
  orange: "#FF6D00",
  purple: "#A142F4",
  teal: "#00897B",
  pink: "#E91E63",
  cyan: "#00BCD4",
  indigo: "#3F51B5",
  gray: "#5F6368",
};

// ===== Top Bar Weather Widget =====
function TopBarWeather() {
  const [data, setData] = React.useState<{ temp: number; desc: string; icon: string } | null>(null);

  React.useEffect(() => {
    fetch("/api/weather")
      .then((r) => r.json())
      .then((json) => {
        if (json.success) {
          const c = json.data.current;
          setData({ temp: c.temperature, desc: c.weatherDescription, icon: c.weatherIcon });
        }
      })
      .catch(() => {});
  }, []);

  return (
    <div className="flex items-center gap-1 px-2 py-1">
      <DynamicIcon name={data?.icon || "Cloud"} className="h-4 w-4" style={{ color: GOOGLE_COLORS.yellow }} />
      {data && <span className="text-xs text-foreground">{data.temp}°</span>}
    </div>
  );
}

// ===== Top Bar Clock — Aleppo Timezone =====
function TopBarClock() {
  const [, setTick] = React.useState(0);

  React.useEffect(() => {
    const interval = setInterval(() => setTick(t => t + 1), 1000);
    return () => clearInterval(interval);
  }, []);

  const now = new Date();
  const dayName = formatSyrianAleppo(now, "EEEE");
  const dateStr = formatSyrianAleppo(now, "d/M");
  const timeStr = aleppoTimeString(now);

  return (
    <div className="flex items-center gap-1.5 px-2 py-1">
      <span className="text-xs text-on-surface-variant">{dayName}</span>
      <span className="text-xs font-medium text-foreground">{dateStr}</span>
      <span className="text-sm font-medium text-foreground tabular-nums">{timeStr}</span>
    </div>
  );
}

// ===== Top Bar Prayer =====
function TopBarPrayer() {
  const [data, setData] = React.useState<{ name: string; time: string } | null>(null);

  React.useEffect(() => {
    fetch("/api/prayer-times")
      .then((r) => r.json())
      .then((json) => {
        if (json.success && json.data.nextPrayer) {
          setData({ name: json.data.nextPrayer.name, time: json.data.nextPrayer.time });
        }
      })
      .catch(() => {});
  }, []);

  if (!data) return null;

  return (
    <div className="flex items-center gap-1 px-2 py-1">
      <DynamicIcon name="Sparkles" className="h-3.5 w-3.5" style={{ color: GOOGLE_COLORS.green }} />
      <span className="text-[11px] text-on-surface-variant">{data.name}</span>
      <span className="text-xs font-medium text-foreground" dir="ltr">{data.time}</span>
    </div>
  );
}

// ===== Top Bar Task Count =====
function TopBarTaskCount() {
  const [count, setCount] = React.useState(0);

  React.useEffect(() => {
    fetch("/api/tasks")
      .then((r) => r.json())
      .then((json) => {
        if (json.success) {
          setCount(json.data.filter((t: { status: string }) => t.status !== "done").length);
        }
      })
      .catch(() => {});
  }, []);

  return (
    <button
      onClick={() => useFloatingPanelStore.getState().openPanel("tasks")}
      className="flex items-center gap-1 px-2 py-1 rounded-full hover:bg-opacity-10 transition-colors"
    >
      <DynamicIcon name="CheckSquare" className="h-4 w-4" style={{ color: GOOGLE_COLORS.blue }} />
      <span className="text-xs font-medium text-foreground">{count}</span>
    </button>
  );
}

// ===== Dock Icon — Google Style (Colorful Filled) =====
interface DockIconProps {
  id: string;
  icon: string;
  label: string;
  badge?: number;
  color: string; // hex color
}

function DockIcon({ id, icon, label, badge, color }: DockIconProps) {
  const { activePanel, togglePanel } = useFloatingPanelStore();
  const isActive = activePanel === id;

  return (
    <motion.button
      onClick={() => togglePanel(id)}
      whileTap={{ scale: 0.88 }}
      transition={{ type: "spring", stiffness: 400, damping: 17 }}
      className="dock-bounce relative flex flex-col items-center gap-0.5 shrink-0 px-1"
    >
      <motion.div
        whileHover={{ scale: 1.12 }}
        transition={{ type: "spring", stiffness: 300, damping: 20 }}
        className="flex h-10 w-10 items-center justify-center"
        style={{
          backgroundColor: isActive ? color + "22" : "transparent",
          borderRadius: "9999px",  /* M3 Expressive: pill */
        }}
      >
        <DynamicIcon
          name={icon}
          className="h-5 w-5"
          style={{ color: color }}
        />
      </motion.div>
      {badge !== undefined && badge > 0 && (
        <span
          className="absolute top-0 right-0 flex h-4 min-w-4 items-center justify-center text-white text-[9px] font-bold px-1"
          style={{ backgroundColor: GOOGLE_COLORS.red, borderRadius: "9999px" }}
        >
          {badge}
        </span>
      )}
      <span className={cn(
        "text-[9px] whitespace-nowrap transition-colors leading-tight",
        isActive ? "text-foreground font-medium" : "text-on-surface-variant"
      )}>
        {label}
      </span>
    </motion.button>
  );
}

// ===== Main Dashboard Summary — Responsive =====
function MainSummary() {
  const [data, setData] = React.useState<{
    todayEvents: Array<{ id: string; title: string; startDate: string; type: string; location?: string | null }>;
    taskStats: { pending: number; done: number; total: number };
    contactStats: { total: number; favorites: number };
    recentCalls: Array<{ id: string; name: string; phone: string; type: string; createdAt: string }>;
    upcomingHolidays: Array<{ date: string; name: string; daysUntil: number }>;
  } | null>(null);
  const [notifications, setNotifications] = React.useState<Array<{ id: string; icon: string; title: string; description: string; color: string; action?: string }>>([]);

  React.useEffect(() => {
    fetch("/api/dashboard")
      .then((r) => r.json())
      .then((json) => { if (json.success) setData(json.data); })
      .catch(() => {});

    fetch("/api/notifications")
      .then((r) => r.json())
      .then((json) => { if (json.success) setNotifications(json.data.slice(0, 4)); })
      .catch(() => {});
  }, []);

  const cardStyle = { backgroundColor: "var(--surface-container)" };

  return (
    <>
      {/* ===== MOBILE LAYOUT (shshat hatf) — Single column scrollable ===== */}
      <div className="sm:hidden h-full overflow-y-auto custom-scroll space-y-2 pb-2">
        {/* Quick stats row */}
        <div className="grid grid-cols-4 gap-1.5">
          {[
            { icon: "CheckSquare", label: "مهام", value: data?.taskStats.pending || 0, color: GOOGLE_COLORS.blue },
            { icon: "Users", label: "جهات", value: data?.contactStats.total || 0, color: GOOGLE_COLORS.green },
            { icon: "CheckCircle", label: "منجز", value: data?.taskStats.done || 0, color: GOOGLE_COLORS.teal },
            { icon: "Bell", label: "تنبيه", value: notifications.length, color: GOOGLE_COLORS.red },
          ].map((s) => (
            <div key={s.label} className="rounded-xl p-1.5 text-center" style={cardStyle}>
              <div className="flex h-6 w-6 items-center justify-center rounded-full mx-auto mb-0.5" style={{ backgroundColor: s.color + "22" }}>
                <DynamicIcon name={s.icon} className="h-3.5 w-3.5" style={{ color: s.color }} />
              </div>
              <p className="text-sm font-medium text-foreground leading-tight">{s.value}</p>
              <p className="text-[8px] text-on-surface-variant">{s.label}</p>
            </div>
          ))}
        </div>

        {/* Quick Capture */}
        {/* Shortcuts */}
        <ShortcutsWidget />
        <QuickCaptureCompact />

        {/* Today's schedule */}
        <div className="rounded-xl p-2.5" style={cardStyle}>
          <div className="flex items-center gap-2 mb-1.5">
            <DynamicIcon name="Calendar" className="h-4 w-4" style={{ color: GOOGLE_COLORS.blue }} />
            <h3 className="text-xs font-medium text-foreground">جدول اليوم</h3>
          </div>
          <div className="space-y-1">
            {data?.todayEvents && data.todayEvents.length > 0 ? (
              data.todayEvents.slice(0, 4).map((event) => {
                const time = new Date(event.startDate);
                return (
                  <div key={event.id} className="flex items-center gap-2 rounded-lg px-2 py-1" style={{ backgroundColor: "var(--background)" }}>
                    <span className="text-[10px] font-medium tabular-nums w-10 shrink-0" style={{ color: GOOGLE_COLORS.blue }}>
                      {format(time, "HH:mm")}
                    </span>
                    <span className="text-[11px] text-foreground truncate">{event.title}</span>
                  </div>
                );
              })
            ) : (
              <p className="text-[11px] text-on-surface-variant text-center py-2">لا أحداث اليوم</p>
            )}
          </div>
        </div>

        {/* Notifications */}
        <div className="rounded-xl p-2.5" style={cardStyle}>
          <div className="flex items-center gap-2 mb-1.5">
            <DynamicIcon name="Bell" className="h-4 w-4" style={{ color: GOOGLE_COLORS.orange }} />
            <h3 className="text-xs font-medium text-foreground">تنبيهات</h3>
            {notifications.length > 0 && (
              <span className="text-[9px] px-1.5 rounded-full text-white font-bold" style={{ backgroundColor: GOOGLE_COLORS.red }}>
                {notifications.length}
              </span>
            )}
          </div>
          <div className="space-y-1">
            {notifications.length > 0 ? (
              notifications.map((n) => (
                <div key={n.id} className="flex items-start gap-2 rounded-lg px-2 py-1" style={{ backgroundColor: "var(--background)" }}>
                  <DynamicIcon name={n.icon} className="h-3.5 w-3.5 shrink-0 mt-0.5" style={{ color: GOOGLE_COLORS.orange }} />
                  <div className="min-w-0">
                    <p className="text-[11px] font-medium text-foreground truncate">{n.title}</p>
                    {n.description && <p className="text-[9px] text-on-surface-variant truncate">{n.description}</p>}
                  </div>
                </div>
              ))
            ) : (
              <p className="text-[11px] text-on-surface-variant text-center py-2">كل شيء على ما يرام</p>
            )}
          </div>
        </div>

        {/* Favorite contacts */}
        <FavoriteContactsBar />

        {/* Recent calls */}
        <div className="rounded-xl p-2.5" style={cardStyle}>
          <div className="flex items-center gap-2 mb-1.5">
            <DynamicIcon name="Phone" className="h-4 w-4" style={{ color: GOOGLE_COLORS.green }} />
            <h3 className="text-xs font-medium text-foreground">آخر المكالمات</h3>
          </div>
          <div className="space-y-1">
            {data?.recentCalls && data.recentCalls.length > 0 ? (
              data.recentCalls.slice(0, 3).map((call) => (
                <div key={call.id} className="flex items-center gap-2 rounded-lg px-2 py-1" style={{ backgroundColor: "var(--background)" }}>
                  <div className="flex h-6 w-6 items-center justify-center rounded-full shrink-0" style={{ backgroundColor: GOOGLE_COLORS.gray + "22" }}>
                    <DynamicIcon name={call.type === "whatsapp" ? "MessageCircle" : "Phone"} className="h-3 w-3" style={{ color: GOOGLE_COLORS.gray }} />
                  </div>
                  <span className="text-[11px] font-medium text-foreground truncate flex-1">{call.name}</span>
                </div>
              ))
            ) : (
              <p className="text-[11px] text-on-surface-variant text-center py-2">لا مكالمات</p>
            )}
          </div>
        </div>
      </div>

      {/* ===== DESKTOP LAYOUT — 3 columns wide dashboard ===== */}
      <div className="hidden sm:flex h-full grid-cols-3 gap-2 overflow-hidden">
        {/* Left: Today's Schedule + Notifications */}
        <div className="space-y-2 overflow-hidden flex flex-col">
          {/* Today's schedule */}
          <div className="rounded-xl p-3 flex-1 overflow-hidden flex flex-col" style={cardStyle}>
            <div className="flex items-center gap-2 mb-2 shrink-0">
              <DynamicIcon name="Calendar" className="h-4 w-4" style={{ color: GOOGLE_COLORS.blue }} />
              <h3 className="text-sm font-medium text-foreground">جدول اليوم</h3>
            </div>
            <div className="flex-1 overflow-y-auto custom-scroll space-y-1">
              {data?.todayEvents && data.todayEvents.length > 0 ? (
                data.todayEvents.map((event) => {
                  const time = new Date(event.startDate);
                  return (
                    <div key={event.id} className="flex items-center gap-2 rounded-lg px-2 py-1.5" style={{ backgroundColor: "var(--background)" }}>
                      <span className="text-[10px] font-medium tabular-nums w-10 shrink-0" style={{ color: GOOGLE_COLORS.blue }}>
                        {format(time, "HH:mm")}
                      </span>
                      <span className="text-xs text-foreground truncate">{event.title}</span>
                    </div>
                  );
                })
              ) : (
                <div className="flex items-center justify-center h-full">
                  <p className="text-xs text-on-surface-variant">لا أحداث اليوم</p>
                </div>
              )}
            </div>
          </div>

          {/* Smart notifications */}
          <div className="rounded-xl p-3 max-h-[40%] overflow-hidden flex flex-col" style={cardStyle}>
            <div className="flex items-center gap-2 mb-2 shrink-0">
              <DynamicIcon name="Bell" className="h-4 w-4" style={{ color: GOOGLE_COLORS.orange }} />
              <h3 className="text-sm font-medium text-foreground">تنبيهات</h3>
              {notifications.length > 0 && (
                <span className="text-[10px] px-1.5 rounded-full text-white font-bold" style={{ backgroundColor: GOOGLE_COLORS.red }}>
                  {notifications.length}
                </span>
              )}
            </div>
            <div className="flex-1 overflow-y-auto custom-scroll space-y-1">
              {notifications.length > 0 ? (
                notifications.map((n) => (
                  <div key={n.id} className="flex items-start gap-2 rounded-lg px-2 py-1.5" style={{ backgroundColor: "var(--background)" }}>
                    <DynamicIcon name={n.icon} className="h-3.5 w-3.5 shrink-0 mt-0.5" style={{ color: GOOGLE_COLORS.orange }} />
                    <div className="min-w-0">
                      <p className="text-[11px] font-medium text-foreground truncate">{n.title}</p>
                      {n.description && <p className="text-[9px] text-on-surface-variant truncate">{n.description}</p>}
                    </div>
                  </div>
                ))
              ) : (
                <div className="flex items-center justify-center h-full">
                  <p className="text-[11px] text-on-surface-variant">كل شيء على ما يرام</p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Center: Quick Stats + Quick Capture */}
        <div className="space-y-2 overflow-hidden flex flex-col">
          {/* Quick stats grid */}
          <div className="grid grid-cols-2 gap-2 shrink-0">
            {[
              { icon: "CheckSquare", label: "مهام معلّقة", value: data?.taskStats.pending || 0, color: GOOGLE_COLORS.blue },
              { icon: "Users", label: "جهات اتصال", value: data?.contactStats.total || 0, color: GOOGLE_COLORS.green },
              { icon: "CheckCircle", label: "مهام منجزة", value: data?.taskStats.done || 0, color: GOOGLE_COLORS.teal },
              { icon: "Bell", label: "تنبيهات", value: notifications.length, color: GOOGLE_COLORS.red },
            ].map((s) => (
              <div key={s.label} className="rounded-xl p-2.5" style={cardStyle}>
                <div className="flex h-7 w-7 items-center justify-center rounded-full mb-1" style={{ backgroundColor: s.color + "22" }}>
                  <DynamicIcon name={s.icon} className="h-4 w-4" style={{ color: s.color }} />
                </div>
                <p className="text-lg font-medium text-foreground leading-tight">{s.value}</p>
                <p className="text-[10px] text-on-surface-variant">{s.label}</p>
              </div>
            ))}
          </div>

          {/* Quick Capture */}
          {/* Shortcuts */}
          <ShortcutsWidget />
          <QuickCaptureCompact />

          {/* Upcoming holidays */}
          <div className="rounded-xl p-3 flex-1 overflow-hidden flex flex-col" style={cardStyle}>
            <div className="flex items-center gap-2 mb-2 shrink-0">
              <DynamicIcon name="CalendarDays" className="h-4 w-4" style={{ color: GOOGLE_COLORS.purple }} />
              <h3 className="text-sm font-medium text-foreground">العطل القادمة</h3>
            </div>
            <div className="flex-1 overflow-y-auto custom-scroll space-y-1">
              {data?.upcomingHolidays && data.upcomingHolidays.length > 0 ? (
                data.upcomingHolidays.slice(0, 4).map((h) => (
                  <div key={h.date} className="flex items-center gap-2 rounded-lg px-2 py-1.5" style={{ backgroundColor: "var(--background)" }}>
                    <div className="flex h-6 w-6 flex-col items-center justify-center rounded-full shrink-0" style={{ backgroundColor: GOOGLE_COLORS.purple + "22" }}>
                      <span className="text-[10px] font-bold leading-none" style={{ color: GOOGLE_COLORS.purple }}>{h.daysUntil}</span>
                      <span className="text-[6px] leading-none text-on-surface-variant">يوم</span>
                    </div>
                    <span className="text-[11px] text-foreground truncate">{h.name}</span>
                  </div>
                ))
              ) : (
                <p className="text-[11px] text-on-surface-variant text-center py-4">لا عطل قريبة</p>
              )}
            </div>
          </div>
        </div>

        {/* Right: Quick contacts + Weekly stats */}
        <div className="space-y-2 overflow-hidden flex flex-col">
          {/* Favorite contacts quick dial */}
          <FavoriteContactsBar />

          {/* Weekly stats mini */}
          <WeeklyStatsMini />

          {/* Recent calls */}
          <div className="rounded-xl p-3 flex-1 overflow-hidden flex flex-col" style={cardStyle}>
            <div className="flex items-center gap-2 mb-2 shrink-0">
              <DynamicIcon name="Phone" className="h-4 w-4" style={{ color: GOOGLE_COLORS.green }} />
              <h3 className="text-sm font-medium text-foreground">آخر المكالمات</h3>
            </div>
            <div className="flex-1 overflow-y-auto custom-scroll space-y-1">
              {data?.recentCalls && data.recentCalls.length > 0 ? (
                data.recentCalls.slice(0, 5).map((call) => (
                  <div key={call.id} className="flex items-center gap-2 rounded-lg px-2 py-1.5" style={{ backgroundColor: "var(--background)" }}>
                    <div className="flex h-6 w-6 items-center justify-center rounded-full shrink-0" style={{ backgroundColor: GOOGLE_COLORS.gray + "22" }}>
                      <DynamicIcon name={call.type === "whatsapp" ? "MessageCircle" : "Phone"} className="h-3 w-3" style={{ color: GOOGLE_COLORS.gray }} />
                    </div>
                    <span className="text-[11px] font-medium text-foreground truncate flex-1">{call.name}</span>
                  </div>
                ))
              ) : (
                <p className="text-[11px] text-on-surface-variant text-center py-4">لا مكالمات</p>
              )}
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

// ===== Favorite Contacts Bar =====
function FavoriteContactsBar() {
  const [contacts, setContacts] = React.useState<Array<{ id: string; name: string; phone: string; favorite: boolean; relation: string }>>([]);

  React.useEffect(() => {
    fetch("/api/contacts?favorite=true")
      .then((r) => r.json())
      .then((json) => { if (json.success) setContacts(json.data); })
      .catch(() => {});
  }, []);

  const handleCall = (phone: string, name: string) => {
    if (!phone || phone === "—") return;
    window.open(`tel:${phone.replace(/[^0-9+]/g, "")}`, "_self");
    fetch("/api/calllogs", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, phone, type: "call", direction: "outgoing" }),
    }).catch(() => {});
  };

  const avatarColors = [GOOGLE_COLORS.blue, GOOGLE_COLORS.red, GOOGLE_COLORS.yellow, GOOGLE_COLORS.green, GOOGLE_COLORS.purple, GOOGLE_COLORS.orange];

  return (
    <div className="rounded-xl p-3" style={{ backgroundColor: "var(--surface-container)" }}>
      <div className="flex items-center gap-2 mb-2">
        <DynamicIcon name="Users" className="h-4 w-4" style={{ color: GOOGLE_COLORS.green }} />
        <h3 className="text-sm font-medium text-foreground">جهات سريعة</h3>
      </div>
      <div className="flex items-center gap-1.5 flex-wrap">
        {contacts.slice(0, 6).map((c, i) => (
          <button
            key={c.id}
            onClick={() => handleCall(c.phone, c.name)}
            className="flex h-8 w-8 items-center justify-center rounded-full text-xs font-medium transition-transform hover:scale-110"
            style={{ backgroundColor: avatarColors[i % avatarColors.length] + "22", color: avatarColors[i % avatarColors.length] }}
            title={`${c.name} - ${c.phone}`}
          >
            {c.name[0]}
          </button>
        ))}
        <button
          onClick={() => useFloatingPanelStore.getState().openPanel("contacts")}
          className="flex h-8 w-8 items-center justify-center rounded-full text-on-surface-variant hover:text-foreground transition-colors"
          title="كل جهات الاتصال"
        >
          <DynamicIcon name="Phone" className="h-4 w-4" style={{ color: GOOGLE_COLORS.green }} />
        </button>
      </div>
    </div>
  );
}

// ===== Weekly Stats Mini =====
function WeeklyStatsMini() {
  const [stats, setStats] = React.useState<{ tasksDoneThisWeek: number; totalExpensesSYP: number; habitsCompletedThisWeek: number; callsThisWeek: number; dailyStats: Array<{ day: string; tasks: number; isToday: boolean }> } | null>(null);

  React.useEffect(() => {
    fetch("/api/stats?period=week")
      .then((r) => r.json())
      .then((json) => { if (json.success) setStats(json.data); })
      .catch(() => {});
  }, []);

  if (!stats) return null;

  const maxTasks = Math.max(...stats.dailyStats.map((d) => d.tasks), 1);

  return (
    <div className="rounded-xl p-3" style={{ backgroundColor: "var(--surface-container)" }}>
      <div className="flex items-center gap-2 mb-2">
        <DynamicIcon name="BarChart3" className="h-4 w-4" style={{ color: GOOGLE_COLORS.blue }} />
        <h3 className="text-sm font-medium text-foreground">إحصائيات الأسبوع</h3>
      </div>
      <div className="grid grid-cols-4 gap-1 mb-2">
        <div className="text-center rounded-lg py-1" style={{ backgroundColor: GOOGLE_COLORS.blue + "18" }}>
          <p className="text-sm font-medium" style={{ color: GOOGLE_COLORS.blue }}>{stats.tasksDoneThisWeek}</p>
          <p className="text-[8px] text-on-surface-variant">مهام</p>
        </div>
        <div className="text-center rounded-lg py-1" style={{ backgroundColor: GOOGLE_COLORS.yellow + "18" }}>
          <p className="text-sm font-medium" style={{ color: GOOGLE_COLORS.yellow }}>{(stats.totalExpensesSYP / 1000).toFixed(0)}K</p>
          <p className="text-[8px] text-on-surface-variant">مصروف</p>
        </div>
        <div className="text-center rounded-lg py-1" style={{ backgroundColor: GOOGLE_COLORS.green + "18" }}>
          <p className="text-sm font-medium" style={{ color: GOOGLE_COLORS.green }}>{stats.habitsCompletedThisWeek}</p>
          <p className="text-[8px] text-on-surface-variant">عادات</p>
        </div>
        <div className="text-center rounded-lg py-1" style={{ backgroundColor: GOOGLE_COLORS.red + "18" }}>
          <p className="text-sm font-medium" style={{ color: GOOGLE_COLORS.red }}>{stats.callsThisWeek}</p>
          <p className="text-[8px] text-on-surface-variant">مكالمات</p>
        </div>
      </div>
      {/* Mini bar chart */}
      <div className="flex items-end justify-between gap-1 h-10">
        {stats.dailyStats.map((day, i) => (
          <div key={i} className="flex-1 flex flex-col items-center gap-0.5">
            <div className="w-full flex-1 flex items-end">
              <div
                className="w-full rounded-t-sm transition-all"
                style={{
                  height: `${Math.max((day.tasks / maxTasks) * 100, 8)}%`,
                  backgroundColor: day.isToday ? GOOGLE_COLORS.blue : GOOGLE_COLORS.blue + "40",
                }}
              />
            </div>
            <span className={cn("text-[7px]", day.isToday ? "font-bold" : "")} style={{ color: day.isToday ? GOOGLE_COLORS.blue : undefined }}>
              {day.day}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

// ===== Quick Capture Compact =====
function QuickCaptureCompact() {
  const [value, setValue] = React.useState("");
  const { toast } = useToast();

  const handleSubmit = async () => {
    if (!value.trim()) return;
    try {
      await fetch("/api/tasks", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title: value, category: "home", priority: "medium" }),
      });
      toast({ title: "تمت إضافة المهمة ✓" });
      setValue("");
    } catch {
      toast({ title: "فشل الإضافة", variant: "destructive" });
    }
  };

  return (
    <div className="rounded-xl p-3" style={{ backgroundColor: "var(--surface-container)" }}>
      <div className="flex items-center gap-2 mb-2">
        <DynamicIcon name="Zap" className="h-4 w-4" style={{ color: GOOGLE_COLORS.yellow }} />
        <h3 className="text-sm font-medium text-foreground">إضافة سريعة</h3>
      </div>
      <div className="flex gap-1.5">
        <input
          value={value}
          onChange={(e) => setValue(e.target.value)}
          onKeyDown={(e) => { if (e.key === "Enter") handleSubmit(); }}
          placeholder="أضف مهمة سريعة..."
          className="flex-1 h-8 rounded-lg border border-border px-2.5 text-xs text-foreground placeholder:text-on-surface-variant outline-none focus:border-primary"
        />
        <button
          onClick={handleSubmit}
          className="flex h-8 w-8 items-center justify-center rounded-full shrink-0"
          style={{ backgroundColor: GOOGLE_COLORS.blue, color: "white" }}
        >
          <DynamicIcon name="Plus" className="h-4 w-4" />
        </button>
      </div>
    </div>
  );
}

// ===== Main Shell =====
export function SingleScreenShell({ children }: { children: React.ReactNode }) {
  const { activePanel, closePanel, openPanel } = useFloatingPanelStore();
  const { toast } = useToast();
  const pomodoroIsRunning = usePomodoroStore((s) => s.isRunning);
  const pomodoroTimeLeft = usePomodoroStore((s) => s.timeLeft);

  // Run pomodoro timer globally — works even when panel is closed
  usePomodoroTimer();

  React.useEffect(() => {
    const handler = () => closePanel();
    window.addEventListener("close-floating-panel", handler);
    window.addEventListener("keydown", (e) => {
      if (e.key === "Escape") closePanel();
    });
    return () => {
      window.removeEventListener("close-floating-panel", handler);
    };
  }, [closePanel]);

  return (
    <div className="fixed inset-0 flex flex-col bg-background overflow-hidden">
      {/* ===== Top Bar — Google Style (responsive) ===== */}
      <header className="relative z-20 flex items-center justify-between gap-1 px-2 py-1.5 shrink-0 bg-background border-b border-sidebar-border">
        {/* Right (RTL start) - Logo */}
        <div className="flex items-center gap-1.5 shrink-0">
          <div className="flex h-7 w-7 items-center justify-center rounded-lg" style={{ background: `linear-gradient(135deg, ${GOOGLE_COLORS.blue}, ${GOOGLE_COLORS.green}, ${GOOGLE_COLORS.yellow}, ${GOOGLE_COLORS.red})` }}>
            <span className="text-white font-bold text-xs">ع</span>
          </div>
        </div>

        {/* Center - Clock + Prayer (hidden on mobile) */}
        <div className="hidden sm:flex items-center gap-2">
          <TopBarClock />
          <span className="text-border">|</span>
          <TopBarPrayer />
        </div>

        {/* Mobile clock - compact */}
        <div className="sm:hidden flex items-center gap-1">
          <TopBarClock />
        </div>

        {/* Left - Weather + Tasks + Pomodoro + Notifications */}
        <div className="flex items-center gap-0.5 shrink-0">
          <TopBarWeather />
          <span className="hidden sm:inline text-border">|</span>
          <TopBarTaskCount />
          {/* Pomodoro indicator — shows running timer even when panel is closed */}
          <button
            onClick={() => openPanel("pomodoro")}
            className="flex items-center gap-1 px-1.5 h-8 rounded-full hover:bg-opacity-10 transition-colors"
            title="مؤقت بومودورو"
          >
            {pomodoroIsRunning ? (
              <>
                <span className="relative flex h-2 w-2">
                  <span className="absolute inline-flex h-full w-full rounded-full opacity-75 animate-ping" style={{ backgroundColor: GOOGLE_COLORS.red }} />
                  <span className="relative inline-flex h-2 w-2 rounded-full" style={{ backgroundColor: GOOGLE_COLORS.red }} />
                </span>
                <span className="text-[10px] font-mono font-bold text-foreground tabular-nums">
                  {Math.floor(pomodoroTimeLeft / 60).toString().padStart(2, "0")}:{(pomodoroTimeLeft % 60).toString().padStart(2, "0")}
                </span>
              </>
            ) : (
              <DynamicIcon name="Clock" className="h-4 w-4" style={{ color: GOOGLE_COLORS.red }} />
            )}
          </button>
          <button
            onClick={() => openPanel("notifications")}
            className="relative flex h-8 w-8 items-center justify-center rounded-full hover:bg-opacity-10 transition-colors"
          >
            <DynamicIcon name="Bell" className="h-4 w-4" style={{ color: GOOGLE_COLORS.orange }} />
            <span className="absolute top-1 right-1 h-2 w-2 rounded-full" style={{ backgroundColor: GOOGLE_COLORS.red }} />
          </button>
        </div>
      </header>

      {/* ===== Main Content Area ===== */}
      <main className="relative z-10 flex-1 overflow-hidden p-1.5 sm:p-2">
        <MainSummary />
      </main>

      {/* ===== Bottom Dock — Mobile: Grid / Desktop: Scrollable bar ===== */}
      {/* Mobile: 5 columns grid */}
      <div className="sm:hidden relative z-20 shrink-0 border-t border-sidebar-border bg-background p-1">
        <div className="grid grid-cols-5 gap-0.5">
          <DockIcon id="calendar" icon="Calendar" label="تقويم" color={GOOGLE_COLORS.blue} />
          <DockIcon id="tasks" icon="CheckSquare" label="مهام" color={GOOGLE_COLORS.blue} />
          <DockIcon id="contacts" icon="Users" label="جهات" color={GOOGLE_COLORS.green} />
          <DockIcon id="callpad" icon="Phone" label="اتصال" color={GOOGLE_COLORS.green} />
          <DockIcon id="notes" icon="StickyNote" label="ملاحظات" color={GOOGLE_COLORS.yellow} />
          <DockIcon id="habits" icon="RefreshCw" label="عادات" color={GOOGLE_COLORS.purple} />
          <DockIcon id="expenses" icon="Receipt" label="مصاريف" color={GOOGLE_COLORS.red} />
          <DockIcon id="finances" icon="Wallet" label="مالية" color={GOOGLE_COLORS.green} />
          <DockIcon id="debts" icon="HandCoins" label="ديون" color={GOOGLE_COLORS.orange} />
          <DockIcon id="projects" icon="Briefcase" label="مشاريع" color={GOOGLE_COLORS.indigo} />
          <DockIcon id="meetings" icon="Users" label="اجتماعات" color={GOOGLE_COLORS.teal} />
          <DockIcon id="islamic" icon="Moon" label="إسلامي" color={GOOGLE_COLORS.green} />
          <DockIcon id="health" icon="Heart" label="صحة" color={GOOGLE_COLORS.red} />
          <DockIcon id="diary" icon="Book" label="مذكرات" color={GOOGLE_COLORS.purple} />
          <DockIcon id="occasions" icon="Cake" label="مناسبات" color={GOOGLE_COLORS.pink} />
          <DockIcon id="accounts" icon="Globe" label="حسابات" color={GOOGLE_COLORS.cyan} />
          <DockIcon id="activity" icon="History" label="نشاط" color={GOOGLE_COLORS.gray} />
          <DockIcon id="maps" icon="MapPin" label="خرائط" color={GOOGLE_COLORS.green} />
          <DockIcon id="aiinsights" icon="Sparkles" label="تحليلات" color={GOOGLE_COLORS.blue} />
          <DockIcon id="budget" icon="PieChart" label="ميزانية" color={GOOGLE_COLORS.yellow} />
          <DockIcon id="automation" icon="Zap" label="أتمتة" color={GOOGLE_COLORS.orange} />
          <DockIcon id="integrations" icon="Globe" label="تكاملات" color={GOOGLE_COLORS.teal} />
          <DockIcon id="scheduledmsgs" icon="MessageCircle" label="رسائل" color={GOOGLE_COLORS.green} />
          <DockIcon id="reminders" icon="BellRing" label="تذكيرات" color={GOOGLE_COLORS.red} />
          <DockIcon id="analytics" icon="BarChart3" label="تحليلات" color={GOOGLE_COLORS.purple} />
          <DockIcon id="gamification" icon="Trophy" label="إنجازات" color={GOOGLE_COLORS.yellow} />
          <DockIcon id="smartnotifs" icon="Bell" label="إشعارات" color={GOOGLE_COLORS.orange} />
          <DockIcon id="home" icon="Home" label="منزل" color={GOOGLE_COLORS.green} />
          <DockIcon id="shopping" icon="ShoppingCart" label="تسوق" color={GOOGLE_COLORS.teal} />
          <DockIcon id="appearance" icon="Palette" label="مظهر" color={GOOGLE_COLORS.purple} />
          <DockIcon id="waitinglist" icon="Clock" label="انتظار" color={GOOGLE_COLORS.gray} />
          <DockIcon id="ai" icon="Sparkles" label="مساعد" color={GOOGLE_COLORS.blue} />
          <DockIcon id="settings" icon="Settings" label="إعدادات" color={GOOGLE_COLORS.gray} />
        </div>
      </div>

      {/* Desktop: Horizontal scrollable bar */}
      <div className="hidden sm:block relative z-20 shrink-0 border-t border-sidebar-border bg-background">
        <div className="flex items-center gap-0.5 px-2 py-1.5 overflow-x-auto no-scrollbar">
          <DockIcon id="calendar" icon="Calendar" label="التقويم" color={GOOGLE_COLORS.blue} />
          <DockIcon id="tasks" icon="CheckSquare" label="المهام" color={GOOGLE_COLORS.blue} />
          <DockIcon id="contacts" icon="Users" label="جهات الاتصال" color={GOOGLE_COLORS.green} />
          <DockIcon id="callpad" icon="Phone" label="اتصال سريع" color={GOOGLE_COLORS.green} />
          <DockIcon id="notes" icon="StickyNote" label="الملاحظات" color={GOOGLE_COLORS.yellow} />
          <DockIcon id="habits" icon="RefreshCw" label="العادات" color={GOOGLE_COLORS.purple} />
          <DockIcon id="expenses" icon="Receipt" label="المصروفات" color={GOOGLE_COLORS.red} />
          <DockIcon id="finances" icon="Wallet" label="المالية" color={GOOGLE_COLORS.green} />
          <DockIcon id="debts" icon="HandCoins" label="الديون" color={GOOGLE_COLORS.orange} />
          <DockIcon id="projects" icon="Briefcase" label="المشاريع" color={GOOGLE_COLORS.indigo} />
          <DockIcon id="meetings" icon="Users" label="الاجتماعات" color={GOOGLE_COLORS.teal} />
          <DockIcon id="islamic" icon="Moon" label="إسلامي" color={GOOGLE_COLORS.green} />
          <DockIcon id="health" icon="Heart" label="الصحة" color={GOOGLE_COLORS.red} />
          <DockIcon id="diary" icon="Book" label="المذكرات" color={GOOGLE_COLORS.purple} />
          <DockIcon id="occasions" icon="Cake" label="المناسبات" color={GOOGLE_COLORS.pink} />
          <DockIcon id="accounts" icon="Globe" label="الحسابات" color={GOOGLE_COLORS.cyan} />
          <DockIcon id="activity" icon="History" label="النشاط" color={GOOGLE_COLORS.gray} />
          <DockIcon id="maps" icon="MapPin" label="الخرائط" color={GOOGLE_COLORS.green} />
          <DockIcon id="aiinsights" icon="Sparkles" label="تحليلات ذكية" color={GOOGLE_COLORS.blue} />
          <DockIcon id="budget" icon="PieChart" label="الميزانية" color={GOOGLE_COLORS.yellow} />
          <DockIcon id="automation" icon="Zap" label="الأتمتة" color={GOOGLE_COLORS.orange} />
          <DockIcon id="integrations" icon="Globe" label="التكاملات" color={GOOGLE_COLORS.teal} />
          <DockIcon id="scheduledmsgs" icon="MessageCircle" label="رسائل مجدولة" color={GOOGLE_COLORS.green} />
          <DockIcon id="reminders" icon="BellRing" label="تذكيرات التواصل" color={GOOGLE_COLORS.red} />
          <DockIcon id="analytics" icon="BarChart3" label="التحليلات" color={GOOGLE_COLORS.purple} />
          <DockIcon id="gamification" icon="Trophy" label="الإنجازات" color={GOOGLE_COLORS.yellow} />
          <DockIcon id="smartnotifs" icon="Bell" label="إشعارات ذكية" color={GOOGLE_COLORS.orange} />
          <DockIcon id="home" icon="Home" label="إدارة المنزل" color={GOOGLE_COLORS.green} />
          <DockIcon id="shopping" icon="ShoppingCart" label="التسوق" color={GOOGLE_COLORS.teal} />
          <DockIcon id="appearance" icon="Palette" label="المظهر" color={GOOGLE_COLORS.purple} />
          <DockIcon id="waitinglist" icon="Clock" label="قائمة الانتظار" color={GOOGLE_COLORS.gray} />
          <DockIcon id="ai" icon="Sparkles" label="المساعد" color={GOOGLE_COLORS.blue} />
          <DockIcon id="settings" icon="Settings" label="الإعدادات" color={GOOGLE_COLORS.gray} />
        </div>
      </div>

      {/* ===== Floating Panels ===== */}
      <FloatingPanel id={activePanel || ""} title={getPanelTitle(activePanel)} icon={getPanelIcon(activePanel)} iconColor={getPanelIconColor(activePanel)} width={getPanelWidth(activePanel)}>
        {children}
      </FloatingPanel>
    </div>
  );
}

function getPanelTitle(id: string | null): string {
  const map: Record<string, string> = {
    calendar: "التقويم", tasks: "المهام", contacts: "جهات الاتصال", callpad: "الاتصال السريع",
    notes: "الملاحظات", habits: "العادات", expenses: "المصروفات", finances: "المالية",
    debts: "الديون", projects: "المشاريع", meetings: "الاجتماعات", islamic: "الأدوات الإسلامية",
    health: "الصحة", diary: "المذكرات", occasions: "المناسبات", accounts: "الحسابات",
    activity: "سجل النشاط", ai: "المساعد الذكي", pomodoro: "مؤقت بومودورو",
    notifications: "التنبيهات", settings: "الإعدادات",
    maps: "الخرائط والملاحة", aiinsights: "التحليلات الذكية", budget: "الميزانية الشهرية",
    integrations: "التكاملات الخارجية", automation: "قواعد الأتمتة",
    scheduledmsgs: "الرسائل المجدولة", waitinglist: "قائمة الانتظار",
    reminders: "تذكيرات التواصل",
    appearance: "المظهر والتخصيص", home: "إدارة المنزل",
    gamification: "الإنجازات والنقاط", analytics: "التحليلات والرؤى",
    smartnotifs: "الإشعارات الذكية", shopping: "قائمة التسوق",
  };
  return map[id || ""] || "";
}

function getPanelIcon(id: string | null): string {
  const map: Record<string, string> = {
    calendar: "Calendar", tasks: "CheckSquare", contacts: "Users", callpad: "Phone",
    notes: "StickyNote", habits: "RefreshCw", expenses: "Receipt", finances: "Wallet",
    debts: "HandCoins", projects: "Briefcase", meetings: "Users", islamic: "Moon",
    health: "Heart", diary: "Book", occasions: "Cake", accounts: "Globe",
    activity: "History", ai: "Sparkles", pomodoro: "Clock", notifications: "Bell",
    settings: "Settings", maps: "MapPin", aiinsights: "Sparkles", budget: "PieChart",
    integrations: "Globe", automation: "Zap", scheduledmsgs: "MessageCircle",
    waitinglist: "Clock", reminders: "BellRing",
    appearance: "Palette", home: "Home", gamification: "Trophy",
    analytics: "BarChart3", smartnotifs: "Bell", shopping: "ShoppingCart",
  };
  return map[id || ""] || "Sparkles";
}

function getPanelIconColor(id: string | null): string {
  const map: Record<string, string> = {
    calendar: GOOGLE_COLORS.blue, tasks: GOOGLE_COLORS.blue, contacts: GOOGLE_COLORS.green,
    callpad: GOOGLE_COLORS.green, notes: GOOGLE_COLORS.yellow, habits: GOOGLE_COLORS.purple,
    expenses: GOOGLE_COLORS.red, finances: GOOGLE_COLORS.green, debts: GOOGLE_COLORS.orange,
    projects: GOOGLE_COLORS.indigo, meetings: GOOGLE_COLORS.teal, islamic: GOOGLE_COLORS.green,
    health: GOOGLE_COLORS.red, diary: GOOGLE_COLORS.purple, occasions: GOOGLE_COLORS.pink,
    accounts: GOOGLE_COLORS.cyan, activity: GOOGLE_COLORS.gray, ai: GOOGLE_COLORS.blue,
    pomodoro: GOOGLE_COLORS.red, notifications: GOOGLE_COLORS.orange, settings: GOOGLE_COLORS.gray,
    maps: GOOGLE_COLORS.green, aiinsights: GOOGLE_COLORS.blue, budget: GOOGLE_COLORS.yellow,
    integrations: GOOGLE_COLORS.teal, automation: GOOGLE_COLORS.orange,
    scheduledmsgs: GOOGLE_COLORS.green, waitinglist: GOOGLE_COLORS.gray,
    reminders: GOOGLE_COLORS.red,
    appearance: GOOGLE_COLORS.purple, home: GOOGLE_COLORS.green,
    gamification: GOOGLE_COLORS.yellow, analytics: GOOGLE_COLORS.purple,
    smartnotifs: GOOGLE_COLORS.orange, shopping: GOOGLE_COLORS.teal,
  };
  return map[id || ""] || GOOGLE_COLORS.blue;
}

function getPanelWidth(id: string | null): "sm" | "md" | "lg" | "xl" {
  const map: Record<string, "sm" | "md" | "lg" | "xl"> = {
    calendar: "xl", tasks: "lg", contacts: "lg", callpad: "md",
    notes: "lg", habits: "lg", expenses: "xl", finances: "lg",
    debts: "lg", projects: "xl", meetings: "lg", islamic: "lg",
    health: "lg", diary: "lg", occasions: "lg", accounts: "lg",
    activity: "lg", ai: "md", pomodoro: "sm", notifications: "md",
    settings: "lg", maps: "xl", aiinsights: "xl", budget: "lg",
    integrations: "lg", automation: "lg", scheduledmsgs: "lg",
    waitinglist: "md", reminders: "lg",
    appearance: "lg", home: "xl", gamification: "lg",
    analytics: "xl", smartnotifs: "lg", shopping: "md",
  };
  return map[id || ""] || "lg";
}

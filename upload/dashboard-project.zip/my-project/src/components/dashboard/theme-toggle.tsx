"use client";

import * as React from "react";
import { useTheme } from "next-themes";
import { Button } from "@/components/ui/button";
import { DynamicIcon } from "./icon";

export function ThemeToggle() {
  const { theme, setTheme } = useTheme();
  const [mounted, setMounted] = React.useState(false);

  React.useEffect(() => setMounted(true), []);

  if (!mounted) {
    return <div className="h-9 w-9" />;
  }

  const isDark = theme === "dark";

  return (
    <Button
      variant="ghost"
      size="icon"
      className="h-9 w-9 relative overflow-hidden"
      onClick={() => setTheme(isDark ? "light" : "dark")}
      title={isDark ? "الوضع النهاري" : "الوضع الليلي"}
    >
      <DynamicIcon
        name={isDark ? "Sun" : "Moon"}
        className="h-4.5 w-4.5 transition-transform duration-300 hover:rotate-12"
      />
    </Button>
  );
}

"use client";

import { create } from "zustand";

interface UIState {
  focusModeOpen: boolean;
  setFocusModeOpen: (open: boolean) => void;
  toggleFocusMode: () => void;
}

export const useUIStore = create<UIState>((set) => ({
  focusModeOpen: false,
  setFocusModeOpen: (open) => set({ focusModeOpen: open }),
  toggleFocusMode: () => set((s) => ({ focusModeOpen: !s.focusModeOpen })),
}));

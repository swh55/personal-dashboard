"use client";

import { create } from "zustand";

interface FloatingPanelState {
  activePanel: string | null;
  openPanel: (id: string) => void;
  closePanel: () => void;
  togglePanel: (id: string) => void;
}

export const useFloatingPanelStore = create<FloatingPanelState>((set) => ({
  activePanel: null,
  openPanel: (id) => set({ activePanel: id }),
  closePanel: () => set({ activePanel: null }),
  togglePanel: (id) =>
    set((s) => ({ activePanel: s.activePanel === id ? null : id })),
}));

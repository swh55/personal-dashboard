"use client";

import { create } from "zustand";

type Mode = "focus" | "shortBreak" | "longBreak";

interface PomodoroState {
  mode: Mode;
  timeLeft: number; // seconds
  isRunning: boolean;
  sessions: number;
  selectedDuration: number; // minutes
  lastUpdate: number; // timestamp for persistence
  setMode: (mode: Mode) => void;
  setTimeLeft: (time: number) => void;
  setRunning: (running: boolean) => void;
  tick: () => void;
  setSessions: (sessions: number) => void;
  setSelectedDuration: (duration: number) => void;
  reset: () => void;
  start: (minutes: number) => void;
  pause: () => void;
  resume: () => void;
}

const DURATIONS: Record<Mode, number> = {
  focus: 25 * 60,
  shortBreak: 5 * 60,
  longBreak: 15 * 60,
};

export const usePomodoroStore = create<PomodoroState>((set, get) => ({
  mode: "focus",
  timeLeft: DURATIONS.focus,
  isRunning: false,
  sessions: 0,
  selectedDuration: 25,
  lastUpdate: 0,

  setMode: (mode) => set({ mode, timeLeft: DURATIONS[mode], isRunning: false }),
  setTimeLeft: (time) => set({ timeLeft: time }),
  setRunning: (running) => set({ isRunning: running, lastUpdate: running ? Date.now() : 0 }),
  setSessions: (sessions) => set({ sessions }),
  setSelectedDuration: (duration) => set({ selectedDuration: duration }),
  reset: () => {
    const state = get();
    set({ timeLeft: DURATIONS[state.mode], isRunning: false, lastUpdate: 0 });
  },
  start: (minutes) => {
    const seconds = minutes * 60;
    set({
      mode: minutes === 15 ? "longBreak" : minutes === 5 ? "shortBreak" : "focus",
      timeLeft: seconds,
      isRunning: true,
      selectedDuration: minutes,
      lastUpdate: Date.now(),
    });
  },
  pause: () => set({ isRunning: false, lastUpdate: 0 }),
  resume: () => set({ isRunning: true, lastUpdate: Date.now() }),
  tick: () => {
    const state = get();
    if (!state.isRunning) return;

    // Calculate elapsed time based on real timestamp
    const now = Date.now();
    if (state.lastUpdate > 0) {
      const elapsed = Math.floor((now - state.lastUpdate) / 1000);
      if (elapsed > 0) {
        const newTime = state.timeLeft - elapsed;
        if (newTime <= 0) {
          // Timer finished
          if (state.mode === "focus") {
            set({
              timeLeft: 0,
              isRunning: false,
              sessions: state.sessions + 1,
              lastUpdate: 0,
            });
          } else {
            set({ timeLeft: 0, isRunning: false, lastUpdate: 0 });
          }
          // Play sound
          try {
            const audio = new Audio("data:audio/wav;base64,UklGRl9vT19XQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQAAAAA=");
            audio.volume = 0.3;
            audio.play().catch(() => {});
          } catch {}
        } else {
          set({ timeLeft: newTime, lastUpdate: now });
        }
      }
    } else {
      // First tick — set lastUpdate
      set({ lastUpdate: now });
    }
  },
}));

// Hook to run the timer globally (call once in the app)
export function usePomodoroTimer() {
  const tick = usePomodoroStore((s) => s.tick);
  const isRunning = usePomodoroStore((s) => s.isRunning);

  React.useEffect(() => {
    if (!isRunning) return;
    const interval = setInterval(() => tick(), 1000);
    return () => clearInterval(interval);
  }, [isRunning, tick]);
}

import * as React from "react";

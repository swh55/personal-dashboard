"use client";

import { create } from "zustand";
import type { SectionId } from "@/lib/constants";

interface DashboardState {
  activeSection: SectionId;
  sidebarOpen: boolean;
  setActiveSection: (section: SectionId) => void;
  setSidebarOpen: (open: boolean) => void;
  toggleSidebar: () => void;
}

export const useDashboardStore = create<DashboardState>((set) => ({
  activeSection: "overview",
  sidebarOpen: false,
  setActiveSection: (section) =>
    set({ activeSection: section, sidebarOpen: false }),
  setSidebarOpen: (open) => set({ sidebarOpen: open }),
  toggleSidebar: () => set((s) => ({ sidebarOpen: !s.sidebarOpen })),
}));

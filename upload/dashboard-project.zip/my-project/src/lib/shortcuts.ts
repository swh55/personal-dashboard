// نظام الاختصارات الديناميكية — تظهر بناءً على الوقت واليوم

import { hourInAleppo, minutesInAleppo } from "./aleppo-time";

export interface DynamicShortcut {
  id: string;
  label: string;
  icon: string;
  color: string;
  // متى تظهر
  showCondition: (now: Date) => boolean;
  // نوع الإجراء
  action: "log" | "navigate" | "call" | "message";
  // بيانات إضافية
  actionData?: string;
}

// أوقات الصلاة التقريبية (ستُحدّث من API)
const PRAYER_TIMES: Array<{ hour: number; minute: number; name: string }> = [
  { hour: 3, minute: 30, name: "الفجر" },
  { hour: 12, minute: 15, name: "الظهر" },
  { hour: 15, minute: 30, name: "العصر" },
  { hour: 17, minute: 45, name: "المغرب" },
  { hour: 19, minute: 15, name: "العشاء" },
];

// فحص ما إذا كان الوقت الحالي ضمن نافذة صلاة (30 دقيقة بعد الأذان)
function isPrayerTime(now: Date): { active: boolean; prayerName?: string } {
  const hour = hourInAleppo(now);
  const minute = minutesInAleppo(now);
  const currentMinutes = hour * 60 + minute;

  for (const prayer of PRAYER_TIMES) {
    const prayerMinutes = prayer.hour * 60 + prayer.minute;
    const diff = currentMinutes - prayerMinutes;
    // تظهر من 5 دقائق قبل الأذان إلى 45 دقيقة بعد
    if (diff >= -5 && diff <= 45) {
      return { active: true, prayerName: prayer.name };
    }
  }
  return { active: false };
}

// التحقق من اليوم
function getDayOfWeek(now: Date): number {
  // استخدام توقيت حلب لتحديد اليوم
  const aleppoStr = new Intl.DateTimeFormat("en-US", {
    timeZone: "Asia/Damascus",
    weekday: "short",
  }).format(now);
  const dayMap: Record<string, number> = {
    Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6,
  };
  return dayMap[aleppoStr] ?? 0;
}

// جميع الاختصارات الديناميكية
export const DYNAMIC_SHORTCUTS: DynamicShortcut[] = [
  // === اختصارات الصلاة ===
  {
    id: "prayer-fajr",
    label: "قمت بصلاة الفجر",
    icon: "Sunrise",
    color: "#4285F4",
    showCondition: (now) => {
      const p = isPrayerTime(now);
      return p.active && p.prayerName === "الفجر";
    },
    action: "log",
  },
  {
    id: "prayer-dhuhr",
    label: "قمت بصلاة الظهر",
    icon: "Sun",
    color: "#FBBC04",
    showCondition: (now) => {
      const p = isPrayerTime(now);
      return p.active && p.prayerName === "الظهر";
    },
    action: "log",
  },
  {
    id: "prayer-asr",
    label: "قمت بصلاة العصر",
    icon: "Sun",
    color: "#FF6D00",
    showCondition: (now) => {
      const p = isPrayerTime(now);
      return p.active && p.prayerName === "العصر";
    },
    action: "log",
  },
  {
    id: "prayer-maghrib",
    label: "قمت بصلاة المغرب",
    icon: "Sunset",
    color: "#EA4335",
    showCondition: (now) => {
      const p = isPrayerTime(now);
      return p.active && p.prayerName === "المغرب";
    },
    action: "log",
  },
  {
    id: "prayer-isha",
    label: "قمت بصلاة العشاء",
    icon: "Moon",
    color: "#A142F4",
    showCondition: (now) => {
      const p = isPrayerTime(now);
      return p.active && p.prayerName === "العشاء";
    },
    action: "log",
  },

  // === اختصارات العمل ===
  {
    id: "arrived-work",
    label: "وصلت العمل",
    icon: "Briefcase",
    color: "#34A853",
    showCondition: (now) => {
      const h = hourInAleppo(now);
      const m = minutesInAleppo(now);
      const mins = h * 60 + m;
      // تظهر من 7:30 صباحاً إلى 9:00 صباحاً
      return mins >= 450 && mins <= 540;
    },
    action: "log",
  },
  {
    id: "left-work",
    label: "غادرت العمل",
    icon: "Briefcase",
    color: "#5F6368",
    showCondition: (now) => {
      const h = hourInAleppo(now);
      const m = minutesInAleppo(now);
      const mins = h * 60 + m;
      // تظهر من 2:45 ظهراً إلى 4:00 عصراً
      return mins >= 885 && mins <= 960;
    },
    action: "log",
  },

  // === اختصارات العائلة ===
  {
    id: "call-family",
    label: "قمت بالاتصال بالعائلة",
    icon: "Heart",
    color: "#EA4335",
    showCondition: (now) => {
      const h = hourInAleppo(now);
      const m = minutesInAleppo(now);
      const mins = h * 60 + m;
      // تظهر من 8:30 مساءً إلى 10:00 مساءً
      return mins >= 1230 && mins <= 1320;
    },
    action: "log",
  },

  // === اختصارات أسبوعية ===
  {
    id: "laundry-thursday",
    label: "قمت بتنظيف ملابسي",
    icon: "Shirt",
    color: "#00897B",
    showCondition: (now) => {
      const day = getDayOfWeek(now);
      const h = hourInAleppo(now);
      // يوم الخميس مساءً (بعد 5 مساءً)
      return day === 4 && h >= 17;
    },
    action: "log",
  },
  {
    id: "shave-friday",
    label: "قمت بحلاقة ذقني",
    icon: "Scissors",
    color: "#A142F4",
    showCondition: (now) => {
      const day = getDayOfWeek(now);
      const h = hourInAleppo(now);
      // يوم الجمعة (من 6 صباحاً إلى 12 ظهراً)
      return day === 5 && h >= 6 && h < 12;
    },
    action: "log",
  },
];

// الحصول على الاختصارات النشطة حالياً
export function getActiveDynamicShortcuts(now: Date = new Date()): DynamicShortcut[] {
  return DYNAMIC_SHORTCUTS.filter((s) => s.showCondition(now));
}

// الاختصارات الثابتة (دائماً تظهر)
export interface StaticShortcut {
  id: string;
  label: string;
  icon: string;
  color: string;
  action: "navigate" | "call" | "message";
  actionData: string; // URL, phone number, etc.
}

export const DEFAULT_STATIC_SHORTCUTS: StaticShortcut[] = [
  {
    id: "navigate-work",
    label: "القيادة إلى العمل",
    icon: "Briefcase",
    color: "#34A853",
    action: "navigate",
    actionData: "https://www.google.com/maps/dir/?api=1&destination=36.2021,37.1343&destination_place_id=work",
  },
  {
    id: "navigate-home",
    label: "القيادة إلى المنزل",
    icon: "Home",
    color: "#4285F4",
    action: "navigate",
    actionData: "https://www.google.com/maps/dir/?api=1&destination=36.2021,37.1343&destination_place_id=home",
  },
  {
    id: "call-wife",
    label: "الاتصال بالزوجة",
    icon: "Phone",
    color: "#EA4335",
    action: "call",
    actionData: "tel:",
  },
  {
    id: "send-location",
    label: "إرسال موقعي الحالي",
    icon: "MapPin",
    color: "#FF6D00",
    action: "message",
    actionData: "",
  },
];

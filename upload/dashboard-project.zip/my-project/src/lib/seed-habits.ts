import { db } from "@/lib/db";

async function seedHabits() {
  const count = await db.habit.count();
  if (count > 0) {
    console.log("ℹ️  العادات موجودة بالفعل");
    return;
  }

  const defaultHabits = [
    { name: "صلاة الفجر في وقتها", description: "أداء صلاة الفجر جماعة", icon: "Sunrise", color: "emerald", target: 1 },
    { name: "قراءة القرآن", description: "قراءة صفحة واحدة على الأقل", icon: "Book", color: "teal", target: 1 },
    { name: "ممارسة الرياضة", description: "30 دقيقة مشي أو تمارين", icon: "Activity", color: "amber", target: 1 },
    { name: "شرب 8 أكواب ماء", description: "الترطيب اليومي", icon: "Droplets", color: "teal", target: 8 },
    { name: "مراجعة الأهداف", description: "مراجعة أهداف اليوم", icon: "Target", color: "rose", target: 1 },
    { name: "الاتصال بالعائلة", description: "الاطمئنان على العائلة", icon: "Heart", color: "rose", target: 1 },
  ];

  for (const habit of defaultHabits) {
    await db.habit.create({ data: habit });
  }
  console.log("✅ تم إضافة العادات الافتراضية");
}

seedHabits()
  .catch(console.error)
  .finally(() => db.$disconnect());

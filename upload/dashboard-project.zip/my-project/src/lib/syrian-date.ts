// أسماء الأشهر السورية (الشامية)
export const SYRIAN_MONTHS = [
  "كانون الثاني", "شباط", "آذار", "نيسان", "أيار", "حزيران",
  "تموز", "آب", "أيلول", "تشرين الأول", "تشرين الثاني", "كانون الأول",
];

// أيام الأسبوع بالعربية (تبدأ بالسبت)
export const SYRIAN_WEEKDAYS = [
  "السبت", "الأحد", "الإثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة",
];

export const SYRIAN_WEEKDAYS_SHORT = [
  "السبت", "الأحد", "الإثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة",
];

// تنسيق التاريخ بأسماء الأشهر السورية
export function formatSyrianDate(date: Date | string, formatStr: string = "d MMMM yyyy"): string {
  const d = typeof date === "string" ? new Date(date) : date;
  const day = d.getDate();
  const monthIndex = d.getMonth();
  const year = d.getFullYear();
  const monthName = SYRIAN_MONTHS[monthIndex];

  if (formatStr === "d MMMM yyyy") return `${day} ${monthName} ${year}`;
  if (formatStr === "d MMMM") return `${day} ${monthName}`;
  if (formatStr === "MMMM yyyy") return `${monthName} ${year}`;
  if (formatStr === "d MMM") return `${day} ${monthName}`;
  if (formatStr === "d/M") return `${day}/${monthIndex + 1}`;
  if (formatStr === "EEEE d MMMM yyyy") {
    const dayName = SYRIAN_WEEKDAYS[d.getDay() === 6 ? 0 : d.getDay() + 1]; // Saturday = 0
    return `${dayName} ${day} ${monthName} ${year}`;
  }
  if (formatStr === "EEEE d MMMM") {
    const dayName = SYRIAN_WEEKDAYS[d.getDay() === 6 ? 0 : d.getDay() + 1];
    return `${dayName} ${day} ${monthName}`;
  }
  if (formatStr === "EEEE") {
    return SYRIAN_WEEKDAYS[d.getDay() === 6 ? 0 : d.getDay() + 1];
  }
  if (formatStr === "d MMMM yyyy، HH:mm") {
    const h = d.getHours().toString().padStart(2, "0");
    const m = d.getMinutes().toString().padStart(2, "0");
    return `${day} ${monthName} ${year}، ${h}:${m}`;
  }

  return `${day} ${monthName} ${year}`;
}

// تنسيق بتوقيت حلب مع أسماء الأشهر السورية
export function formatSyrianAleppo(date: Date | string, formatStr: string = "d MMMM yyyy"): string {
  const d = typeof date === "string" ? new Date(date) : date;
  // تحويل لتوقيت حلب
  const aleppoStr = new Intl.DateTimeFormat("en-US", {
    timeZone: "Asia/Damascus",
    day: "numeric",
    month: "numeric",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  }).formatToParts(d);

  const parts: Record<string, string> = {};
  aleppoStr.forEach(p => { parts[p.type] = p.value; });

  const day = parseInt(parts.day || "1");
  const monthIndex = parseInt(parts.month || "1") - 1;
  const year = parseInt(parts.year || "2026");
  const monthName = SYRIAN_MONTHS[monthIndex];

  if (formatStr === "d MMMM yyyy") return `${day} ${monthName} ${year}`;
  if (formatStr === "d MMMM") return `${day} ${monthName}`;
  if (formatStr === "d/M") return `${day}/${monthIndex + 1}`;
  if (formatStr === "EEEE d MMMM yyyy") {
    // حساب اليوم بالاعتماد على توقيت حلب
    const aleppoDate = new Date(d.toLocaleString("en-US", { timeZone: "Asia/Damascus" }));
    const jsDay = aleppoDate.getDay();
    const dayName = SYRIAN_WEEKDAYS[jsDay === 6 ? 0 : jsDay + 1];
    return `${dayName} ${day} ${monthName} ${year}`;
  }
  if (formatStr === "EEEE") {
    const aleppoDate = new Date(d.toLocaleString("en-US", { timeZone: "Asia/Damascus" }));
    const jsDay = aleppoDate.getDay();
    return SYRIAN_WEEKDAYS[jsDay === 6 ? 0 : jsDay + 1];
  }

  return `${day} ${monthName} ${year}`;
}

// بداية الأسبوع = السبت (weekStartsOn = 6 in date-fns)
export const WEEK_STARTS_ON = 6 as const;

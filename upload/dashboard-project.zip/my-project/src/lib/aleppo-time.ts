// Aleppo timezone helper — Asia/Damascus (UTC+3)
// All times in the app should be displayed in Aleppo time

export const ALEPPO_TIMEZONE = "Asia/Damascus";

// Format a date in Aleppo timezone
export function formatInAleppo(date: Date | string, options: Intl.DateTimeFormatOptions = {}): string {
  const d = typeof date === "string" ? new Date(date) : date;
  return new Intl.DateTimeFormat("ar-SY", {
    timeZone: ALEPPO_TIMEZONE,
    ...options,
  }).format(d);
}

// Get current time in Aleppo
export function nowInAleppo(): Date {
  const now = new Date();
  // Convert to Aleppo time (UTC+3)
  const utc = now.getTime() + now.getTimezoneOffset() * 60000;
  return new Date(utc + 3 * 3600000);
}

// Format time only (HH:mm) in Aleppo
export function timeInAleppo(date: Date | string): string {
  return formatInAleppo(date, { hour: "2-digit", minute: "2-digit", hour12: false });
}

// Format time with AM/PM in Aleppo
export function timeWithPeriodInAleppo(date: Date | string): string {
  const d = typeof date === "string" ? new Date(date) : date;
  const time = formatInAleppo(d, { hour: "2-digit", minute: "2-digit", hour12: true });
  const hour = formatInAleppo(d, { hour: "numeric", hour12: false });
  const isAM = parseInt(hour) < 12;
  return `${time} ${isAM ? "ص" : "م"}`;
}

// Format date only in Aleppo
export function dateInAleppo(date: Date | string): string {
  return formatInAleppo(date, { day: "numeric", month: "numeric", year: "numeric" });
}

// Format full date in Aleppo (Arabic)
export function fullDateInAleppo(date: Date | string): string {
  return formatInAleppo(date, {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
  });
}

// Format date and time in Aleppo
export function dateTimeInAleppo(date: Date | string): string {
  return formatInAleppo(date, {
    day: "numeric",
    month: "long",
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  });
}

// Get Aleppo hour (0-23)
export function hourInAleppo(date: Date | string): number {
  const d = typeof date === "string" ? new Date(date) : date;
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone: ALEPPO_TIMEZONE,
    hour: "numeric",
    hour12: false,
  }).formatToParts(d);
  return parseInt(parts.find((p) => p.type === "hour")?.value || "0");
}

// Get Aleppo minutes
export function minutesInAleppo(date: Date | string): number {
  const d = typeof date === "string" ? new Date(date) : date;
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone: ALEPPO_TIMEZONE,
    minute: "numeric",
  }).formatToParts(d);
  return parseInt(parts.find((p) => p.type === "minute")?.value || "0");
}

// Get day name in Aleppo
export function dayNameInAleppo(date: Date | string): string {
  return formatInAleppo(date, { weekday: "long" });
}

// Check if date is today in Aleppo
export function isTodayInAleppo(date: Date | string): boolean {
  const d = typeof date === "string" ? new Date(date) : date;
  const today = nowInAleppo();
  const aleppoDate = new Date(formatInAleppo(d, { year: "numeric", month: "numeric", day: "numeric" }));
  const todayDate = new Date(formatInAleppo(today, { year: "numeric", month: "numeric", day: "numeric" }));
  return aleppoDate.getTime() === todayDate.getTime();
}

// Get Aleppo time string for display (HH:mm ص/م)
export function aleppoTimeString(date: Date | string): string {
  const d = typeof date === "string" ? new Date(date) : date;
  // Use Intl to get time parts directly
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone: ALEPPO_TIMEZONE,
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  }).formatToParts(d);

  const hourPart = parts.find(p => p.type === "hour")?.value || "00";
  const minutePart = parts.find(p => p.type === "minute")?.value || "00";

  const hours = parseInt(hourPart);
  const displayHours = (hours % 12 || 12).toString().padStart(2, "0");
  const isAM = hours < 12;

  return `${displayHours}:${minutePart} ${isAM ? "ص" : "م"}`;
}

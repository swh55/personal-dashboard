import { db } from "@/lib/db";

async function seedExpenses() {
  const count = await db.expense.count();
  if (count > 0) {
    console.log("ℹ️  المصروفات موجودة بالفعل");
    return;
  }

  const now = new Date();
  const sampleExpenses = [
    { amount: 25000, currency: "syp", category: "food", description: "غداء في المطعم", daysAgo: 0 },
    { amount: 15000, currency: "syp", category: "transport", description: "وقود السيارة", daysAgo: 0 },
    { amount: 50000, currency: "syp", category: "bills", description: "فاتورة الكهرباء", daysAgo: 1 },
    { amount: 30000, currency: "syp", category: "food", description: "تسوق بقالة", daysAgo: 1 },
    { amount: 100, currency: "usd", category: "business", description: "قرطاسية مكتبية", daysAgo: 2 },
    { amount: 20000, currency: "syp", category: "health", description: "دواء", daysAgo: 2 },
    { amount: 45000, currency: "syp", category: "shopping", description: "ملابس", daysAgo: 3 },
    { amount: 18000, currency: "syp", category: "food", description: "إفطار", daysAgo: 3 },
    { amount: 35000, currency: "syp", category: "transport", description: "تاكسي", daysAgo: 4 },
    { amount: 60000, currency: "syp", category: "bills", description: "فاتورة الإنترنت", daysAgo: 5 },
    { amount: 22000, currency: "syp", category: "entertainment", description: "قهوة مع الأصدقاء", daysAgo: 5 },
    { amount: 40000, currency: "syp", category: "food", description: "عشاء عائلي", daysAgo: 6 },
  ];

  for (const e of sampleExpenses) {
    const date = new Date(now);
    date.setDate(now.getDate() - e.daysAgo);
    date.setHours(12, 0, 0, 0);
    await db.expense.create({
      data: {
        amount: e.amount,
        currency: e.currency,
        category: e.category,
        description: e.description,
        date,
      },
    });
  }
  console.log("✅ تم إضافة المصروفات التجريبية");
}

seedExpenses()
  .catch(console.error)
  .finally(() => db.$disconnect());

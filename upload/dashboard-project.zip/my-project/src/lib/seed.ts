import { db } from "@/lib/db";
import {
  WORK_FRIENDS,
  FAMILY,
  INTERNET_ACCOUNTS,
  ASSETS,
  OCCASIONS,
  DAILY_SCHEDULE,
} from "@/lib/constants";

async function seed() {
  console.log("🌱 بدء تهيئة قاعدة البيانات...");

  // التحقق من وجود بيانات مسبقاً
  const existingContacts = await db.contact.count();
  if (existingContacts > 0) {
    console.log("ℹ️  قاعدة البيانات تحتوي على بيانات بالفعل. تخطي التهيئة.");
    return;
  }

  // 1. إضافة جهات الاتصال (أصدقاء العمل)
  console.log("👥 إضافة أصدقاء العمل...");
  for (const friend of WORK_FRIENDS) {
    await db.contact.create({
      data: {
        name: friend.name,
        phone: friend.phone || "—",
        relation: "work",
        category: "work-friends",
        note: "صديق في العمل",
        favorite: ["منصور", "باسل", "شادي"].includes(friend.name),
      },
    });
  }

  // 2. إضافة العائلة
  console.log("👨‍👩‍👧 إضافة أفراد العائلة...");
  for (const member of FAMILY) {
    await db.contact.create({
      data: {
        name: member.name,
        phone: member.phone || "—",
        relation: "family",
        category: "family",
        note: member.relation,
        favorite: true,
      },
    });
  }

  // 3. إضافة الحسابات
  console.log("🌐 إضافة الحسابات على الإنترنت...");
  for (const account of INTERNET_ACCOUNTS) {
    await db.account.create({
      data: {
        name: account.name,
        platform: account.platform,
        username: account.username,
        url: account.url,
        icon: account.icon,
        category: account.category,
      },
    });
  }

  // 4. إضافة الأصول المالية
  console.log("💰 إضافة الأصول المالية...");
  for (const asset of ASSETS) {
    await db.asset.create({
      data: {
        type: asset.type,
        amount: asset.amount,
        unit: asset.unit,
        note: asset.note,
      },
    });
  }

  // 5. إضافة المناسبات
  console.log("🎂 إضافة المناسبات...");
  for (const occasion of OCCASIONS) {
    await db.occasion.create({
      data: {
        title: occasion.title,
        date: new Date(occasion.date),
        type: occasion.type,
        note: occasion.note,
        recurring: true,
      },
    });
  }

  // 6. إضافة أحداث متكررة (الدوام، الاستيقاظ، الكشف الحسي)
  console.log("📅 إضافة الأحداث المتكررة...");

  // دوام السجل التجاري - يومي
  const today = new Date();
  for (let i = -7; i < 60; i++) {
    const date = new Date(today);
    date.setDate(today.getDate() + i);
    const dayOfWeek = date.getDay();
    // العطل: الجمعة (5) والسبت (6)
    if (dayOfWeek === 5 || dayOfWeek === 6) continue;

    const start = new Date(date);
    start.setHours(8, 0, 0, 0);
    const end = new Date(date);
    end.setHours(15, 0, 0, 0);

    await db.event.create({
      data: {
        title: "دوام السجل التجاري",
        description: "ساعات العمل الرسمية في السجل التجاري",
        startDate: start,
        endDate: end,
        type: "work",
        color: "emerald",
        location: "السجل التجاري",
      },
    });
  }

  // الكشف الحسي على المتاجر - يوم الأربعاء
  for (let i = -7; i < 60; i++) {
    const date = new Date(today);
    date.setDate(today.getDate() + i);
    if (date.getDay() !== DAILY_SCHEDULE.inspectionDay) continue;

    const start = new Date(date);
    start.setHours(10, 0, 0, 0);
    const end = new Date(date);
    end.setHours(12, 0, 0, 0);

    await db.event.create({
      data: {
        title: "الكشف الحسي على المتاجر",
        description: "جولة تفتيش ميدانية على المتاجر",
        startDate: start,
        endDate: end,
        type: "inspection",
        color: "rose",
        recurring: "weekly",
        location: "المتاجر",
      },
    });
  }

  // 7. مهام تجريبية
  console.log("✅ إضافة مهام تجريبية...");
  const sampleTasks = [
    { title: "شراء حليب وخبز", category: "shopping", priority: "high" },
    { title: "شراء قرطاسية للمكتب", category: "supplies", priority: "medium" },
    { title: "إصلاح صنبور المطبخ", category: "home", priority: "medium" },
    { title: "مراجعة معاملات اليوم", category: "registry", priority: "high" },
    { title: "شراء فاكهة", category: "shopping", priority: "low" },
    { title: "ترتيب المستودع", category: "home", priority: "low" },
    { title: "تحديث السجلات الأسبوعية", category: "registry", priority: "medium" },
    { title: "شراء حبر للطابعة", category: "supplies", priority: "low" },
  ];
  for (const task of sampleTasks) {
    await db.task.create({
      data: {
        title: task.title,
        category: task.category,
        priority: task.priority,
        status: "todo",
      },
    });
  }

  // 8. ملاحظات تجريبية
  console.log("📝 إضافة ملاحظات تجريبية...");
  await db.note.create({
    data: {
      title: "أهداف الشهر",
      content: "1. زيادة المبيعات بنسبة 15%\n2. افتتاح فرع جديد\n3. تجديد رخصة السجل التجاري",
      pinned: true,
    },
  });
  await db.note.create({
    data: {
      title: "أفكار",
      content: "دراسة جدوى لمشروع تجاري جديد في سوق حلب الجديد",
    },
  });

  console.log("✅ تمت التهيئة بنجاح!");
}

seed()
  .catch((e) => {
    console.error("❌ خطأ في التهيئة:", e);
    process.exit(1);
  })
  .finally(async () => {
    await db.$disconnect();
  });

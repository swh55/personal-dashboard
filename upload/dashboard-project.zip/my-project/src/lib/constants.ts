// ثوابت التطبيق - بيانات عامة (تمت إزالة البيانات الشخصية)

export const USER_PROFILE = {
  name: "المستخدم",
  fullName: "المستخدم",
  title: "مستخدم",
  birthday: "",
  city: "حلب",
  country: "سوريا",
  timezone: "Asia/Damascus",
  lat: 36.2021,
  lng: 37.1343,
};

export const DAILY_SCHEDULE = {
  wakeUp: "07:00",
  workStart: "08:00",
  workEnd: "15:00",
  inspectionDay: 3,
  inspectionTime: "10:00",
};

export const FAMILY: { name: string; relation: string; birthday: string; phone: string }[] = [];
export const WORK_FRIENDS: { name: string; phone: string }[] = [];
export const INTERNET_ACCOUNTS: { name: string; platform: string; username: string; url: string; icon: string; category: string }[] = [];
export const ASSETS: { type: string; amount: number; unit: string; note: string }[] = [];
export const OCCASIONS: { title: string; date: string; type: string; note: string }[] = [];

export const TASK_CATEGORIES = [
  { id: "shopping", label: "سلة التسوق", icon: "ShoppingCart", color: "emerald" },
  { id: "supplies", label: "مستلزمات", icon: "Package", color: "blue" },
  { id: "home", label: "منزل", icon: "Home", color: "amber" },
  { id: "registry", label: "سجل", icon: "BookOpen", color: "rose" },
  { id: "other", label: "أخرى", icon: "MoreHorizontal", color: "gray" },
];

export const PRAYER_NAMES: Record<string, string> = {
  Fajr: "الفجر",
  Sunrise: "الشروق",
  Dhuhr: "الظهر",
  Asr: "العصر",
  Maghrib: "المغرب",
  Isha: "العشاء",
  Imsak: "الإمساك",
  Midnight: "منتصف الليل",
};

export const CURRENCY_RATES = {
  goldPerGramSYP: 0,
  goldPerGramUSD: 0,
  usdToSYP: 0,
};

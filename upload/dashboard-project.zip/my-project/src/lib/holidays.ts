// العطل الرسمية في الجمهورية العربية السورية + العطل الإسلامية

export interface Holiday {
  name: string;
  month: number; // 1-12 (gregorian for fixed, hijri for islamic)
  day: number;
  type: "fixed" | "islamic" | "weekly";
  duration?: number; // days
}

// العطل الرسمية الثابتة في سوريا (تاريخ ميلادي)
export const SYRIAN_FIXED_HOLIDAYS: Holiday[] = [
  { name: "رأس السنة الميلادية", month: 1, day: 1, type: "fixed" },
  { name: "عيد الثورة", month: 3, day: 8, type: "fixed" },
  { name: "عيد الأم", month: 3, day: 21, type: "fixed" },
  { name: "عيد الجلاء", month: 4, day: 17, type: "fixed" },
  { name: "عيد العمال", month: 5, day: 1, type: "fixed" },
  { name: "عيد الشهداء (أحد الشهداء)", month: 6, day: 6, type: "fixed" },
  { name: "ذكرى قيام ثورة 8 آذار — عيد الجلاء الوطني", month: 4, day: 17, type: "fixed" },
  { name: "عيد الاستقلال (الجلاء)", month: 4, day: 17, type: "fixed" },
  { name: "عيد المعلم", month: 3, day: 21, type: "fixed" },
  { name: "عيد الشجرة", month: 1, day: 30, type: "fixed" },
  { name: "ذكرى حركة التصحيح", month: 11, day: 16, type: "fixed" },
  { name: "عيد الجيش", month: 8, day: 1, type: "fixed" },
  { name: "ذكرى 8 آذار", month: 3, day: 8, type: "fixed" },
  { name: "يوم العلم", month: 7, day: 11, type: "fixed" },
  { name: "عيد المرأة", month: 3, day: 8, type: "fixed" },
  { name: "العيد الوطني للطفل", month: 11, day: 20, type: "fixed" },
  { name: "رأس السنة الهجرية", month: 1, day: 1, type: "islamic" },
  { name: "المولد النبوي الشريف", month: 3, day: 12, type: "islamic" },
  { name: "ليلة الإسراء والمعراج", month: 7, day: 27, type: "islamic" },
  { name: "منتصف شعبان", month: 8, day: 15, type: "islamic" },
  { name: "أول أيام شهر رمضان المبارك", month: 9, day: 1, type: "islamic" },
  { name: "ليلة القدر", month: 9, day: 27, type: "islamic" },
  { name: "عيد الفطر المبارك (3 أيام)", month: 10, day: 1, type: "islamic", duration: 3 },
  { name: "يوم عرفة", month: 12, day: 9, type: "islamic" },
  { name: "عيد الأضحى المبارك (4 أيام)", month: 12, day: 10, type: "islamic", duration: 4 },
];

// أيام العطل الأسبوعية
export const WEEKLY_HOLIDAYS = [5]; // 0=Sunday, 5=Friday (الجمعة)

// إضافة أيام الجمعة والسبت كعطلة في سوريا (الجمعة والسبت رسمياً)
export const WEEKEND_DAYS = [5, 6]; // Friday + Saturday

// تحويل التقويم الهجري إلى ميلادي بشكل تقريبي للأعوام القادمة
// ملاحظة: التواريخ الإسلامية تقريبية وقد تختلف بيوم حسب رؤية الهلال
const HIJRI_OFFSET: Record<string, { gregorianMonth: number; gregorianDay: number }> = {
  // 1447 هـ - 2025/2026
  "1447-1-1": { gregorianMonth: 7, gregorianDay: 6 },   // رأس السنة الهجرية
  "1447-3-12": { gregorianMonth: 8, gregorianDay: 25 }, // المولد النبوي (تقريبي)
  "1447-7-27": { gregorianMonth: 1, gregorianDay: 8 },  // الإسراء والمعراج (تقريبي 1448)
  "1447-8-15": { gregorianMonth: 2, gregorianDay: 25 }, // منتصف شعبان
  "1447-9-1": { gregorianMonth: 3, gregorianDay: 11 },  // أول رمضان (تقريبي)
  "1447-9-27": { gregorianMonth: 4, gregorianDay: 6 },  // ليلة القدر
  "1447-10-1": { gregorianMonth: 4, gregorianDay: 10 }, // عيد الفطر
  "1447-12-9": { gregorianMonth: 6, gregorianDay: 16 }, // يوم عرفة
  "1447-12-10": { gregorianMonth: 6, gregorianDay: 17 }, // عيد الأضحى
};

// قائمة أعياد 2025 ميلادية (تواريخ نهائية معروفة)
export const HOLIDAYS_2025: { date: string; name: string }[] = [
  { date: "2025-01-01", name: "رأس السنة الميلادية" },
  { date: "2025-03-08", name: "عيد الثورة" },
  { date: "2025-03-21", name: "عيد الأم" },
  { date: "2025-04-17", name: "عيد الجلاء" },
  { date: "2025-05-01", name: "عيد العمال" },
  { date: "2025-05-06", name: "عيد الشهداء" },
  { date: "2025-06-26", name: "ليلة الإسراء والمعراج" },
  { date: "2025-07-06", name: "رأس السنة الهجرية" },
  { date: "2025-08-25", name: "المولد النبوي الشريف" },
  { date: "2025-08-01", name: "عيد الجيش" },
  { date: "2025-11-16", name: "ذكرى حركة التصحيح" },
];

// قائمة أعياد 2026 ميلادية
export const HOLIDAYS_2026: { date: string; name: string }[] = [
  { date: "2026-01-01", name: "رأس السنة الميلادية" },
  { date: "2026-03-08", name: "عيد الثورة" },
  { date: "2026-03-21", name: "عيد الأم" },
  { date: "2026-03-11", name: "أول رمضان (تقريبي)" },
  { date: "2026-04-10", name: "عيد الفطر المبارك" },
  { date: "2026-04-17", name: "عيد الجلاء" },
  { date: "2026-05-01", name: "عيد العمال" },
  { date: "2026-05-06", name: "عيد الشهداء" },
  { date: "2026-05-26", name: "ليلة الإسراء والمعراج (تقريبي)" },
  { date: "2026-06-16", name: "يوم عرفة (تقريبي)" },
  { date: "2026-06-17", name: "عيد الأضحى المبارك" },
  { date: "2026-07-06", name: "رأس السنة الهجرية (تقريبي)" },
  { date: "2026-08-01", name: "عيد الجيش" },
  { date: "2026-08-25", name: "المولد النبوي الشريف (تقريبي)" },
  { date: "2026-11-16", name: "ذكرى حركة التصحيح" },
];

// قائمة أعياد 2027 ميلادية
export const HOLIDAYS_2027: { date: string; name: string }[] = [
  { date: "2027-01-01", name: "رأس السنة الميلادية" },
  { date: "2027-03-08", name: "عيد الثورة" },
  { date: "2027-03-21", name: "عيد الأم" },
  { date: "2027-03-01", name: "أول رمضان (تقريبي)" },
  { date: "2027-03-31", name: "عيد الفطر المبارك (تقريبي)" },
  { date: "2027-04-17", name: "عيد الجلاء" },
  { date: "2027-05-01", name: "عيد العمال" },
  { date: "2027-05-06", name: "عيد الشهداء" },
  { date: "2027-05-16", name: "ليلة الإسراء والمعراج (تقريبي)" },
  { date: "2027-06-06", name: "يوم عرفة (تقريبي)" },
  { date: "2027-06-07", name: "عيد الأضحى المبارك (تقريبي)" },
  { date: "2027-06-26", name: "رأس السنة الهجرية (تقريبي)" },
  { date: "2027-08-01", name: "عيد الجيش" },
  { date: "2027-08-14", name: "المولد النبوي الشريف (تقريبي)" },
  { date: "2027-11-16", name: "ذكرى حركة التصحيح" },
];

export const ALL_HOLIDAYS: { date: string; name: string }[] = [
  ...HOLIDAYS_2025,
  ...HOLIDAYS_2026,
  ...HOLIDAYS_2027,
];

// التحقق إن كان يوم معين عطلة
export function isHoliday(date: Date): { isHoliday: boolean; name?: string } {
  const dateStr = date.toISOString().split("T")[0];
  const holiday = ALL_HOLIDAYS.find((h) => h.date === dateStr);
  if (holiday) {
    return { isHoliday: true, name: holiday.name };
  }
  // فحص أيام الجمعة والسبت
  const day = date.getDay();
  if (WEEKEND_DAYS.includes(day)) {
    return { isHoliday: true, name: day === 5 ? "عطلة الجمعة" : "عطلة السبت" };
  }
  return { isHoliday: false };
}

// الحصول على العطل القادمة
export function getUpcomingHolidays(count: number = 5): { date: string; name: string; daysUntil: number }[] {
  const now = new Date();
  now.setHours(0, 0, 0, 0);
  return ALL_HOLIDAYS
    .map((h) => {
      const d = new Date(h.date);
      const diff = Math.ceil((d.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
      return { ...h, daysUntil: diff };
    })
    .filter((h) => h.daysUntil >= 0)
    .sort((a, b) => a.daysUntil - b.daysUntil)
    .slice(0, count);
}

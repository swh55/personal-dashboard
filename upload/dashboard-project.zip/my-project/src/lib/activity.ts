import { db } from "@/lib/db";

export type ActionType = "create" | "update" | "delete" | "login" | "export" | "toggle";

export async function logActivity(
  action: ActionType,
  entity: string,
  title: string,
  details?: string,
  entityId?: string
) {
  try {
    await db.activityLog.create({
      data: { action, entity, title, details, entityId },
    });
  } catch (error) {
    console.error("Failed to log activity:", error);
  }
}

import { PrismaClient } from '@prisma/client'

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined
  prismaSchemaVersion: string | undefined
}

// إصدار مخطط Prisma — يُزاد عند إضافة نماذج جديدة لتفريغ ذاكرة العميل القديم
// هذا يضمن أن العميل المخزّن مؤقتاً عالمياً يحتوي على النماذج الجديدة
const SCHEMA_VERSION = 'v3-2025-gamification-routes'

function createClient() {
  return new PrismaClient({
    log: ['query'],
  })
}

let db: PrismaClient
if (
  globalForPrisma.prisma &&
  globalForPrisma.prismaSchemaVersion === SCHEMA_VERSION &&
  // تحقق إضافي: العميل المخزّن يحتوي على نماذج حديثة
  typeof (globalForPrisma.prisma as unknown as { postureLog?: unknown }).postureLog !== 'undefined'
) {
  db = globalForPrisma.prisma
} else {
  // إما أول تشغيل أو تغيّر الإصدار أو العميل قديم — أنشئ عميلاً جديداً
  // (نتجاهل disconnect على القديم لأنه قد يكون قيد الاستخدام)
  db = createClient()
  if (process.env.NODE_ENV !== 'production') {
    globalForPrisma.prisma = db
    globalForPrisma.prismaSchemaVersion = SCHEMA_VERSION
  }
}

// تصحيح: طباعة نسخة العميل النشطة
const allModelKeys = Object.keys(db as object).filter(
  (k) => !k.startsWith('_') && !k.startsWith('$') && k !== 'constructor'
)
console.log('[db.ts] using prisma client with postureLog:', typeof (db as unknown as { postureLog?: unknown }).postureLog)
console.log('[db.ts] models count:', allModelKeys.length, 'has postureLog:', allModelKeys.includes('postureLog'))
console.log('[db.ts] sample models:', allModelKeys.slice(0, 10).join(','))

export { db }

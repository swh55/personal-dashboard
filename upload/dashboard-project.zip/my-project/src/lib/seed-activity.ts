import { db } from "@/lib/db";

async function seedActivity() {
  const count = await db.activityLog.count();
  if (count > 0) {
    console.log("ℹ️  سجل النشاط موجود");
    return;
  }

  const now = new Date();
  const samples = [
    { action: "create", entity: "task", title: "أضيف مهمة: شراء حليب وخبز", daysAgo: 0, hoursAgo: 2 },
    { action: "create", entity: "expense", title: "أضيف مصروف: غداء في المطعم (25,000 ل.س)", daysAgo: 0, hoursAgo: 3 },
    { action: "toggle", entity: "habit", title: "تم إنجاز عادة: صلاة الفجر في وقتها", daysAgo: 0, hoursAgo: 5 },
    { action: "create", entity: "contact", title: "أضيف جهة اتصال: منصور", daysAgo: 1, hoursAgo: 10 },
    { action: "update", entity: "event", title: "تم تعديل حدث: دوام السجل التجاري", daysAgo: 1, hoursAgo: 12 },
    { action: "create", entity: "note", title: "أضيف ملاحظة: أهداف الشهر", daysAgo: 2, hoursAgo: 8 },
    { action: "delete", entity: "task", title: "حُذفت مهمة: ترتيب المستودع", daysAgo: 2, hoursAgo: 14 },
    { action: "export", entity: "data", title: "تم تصدير البيانات (JSON)", daysAgo: 3, hoursAgo: 6 },
    { action: "create", entity: "expense", title: "أضيف مصروف: وقود السيارة (15,000 ل.س)", daysAgo: 3, hoursAgo: 9 },
    { action: "toggle", entity: "habit", title: "تم إنجاز عادة: قراءة القرآن", daysAgo: 4, hoursAgo: 7 },
  ];

  for (const s of samples) {
    const date = new Date(now);
    date.setDate(now.getDate() - s.daysAgo);
    date.setHours(now.getHours() - s.hoursAgo);
    await db.activityLog.create({
      data: {
        action: s.action,
        entity: s.entity,
        title: s.title,
        createdAt: date,
      },
    });
  }
  console.log("✅ تم إضافة سجلات النشاط");
}

seedActivity()
  .catch(console.error)
  .finally(() => db.$disconnect());

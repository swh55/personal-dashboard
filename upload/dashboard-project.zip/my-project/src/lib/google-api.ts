import { db } from "@/lib/db";

interface GoogleTokens {
  access_token: string;
  refresh_token: string | null;
  expires_at: number | null;
  user_email: string;
}

// الحصول على tokens من قاعدة البيانات
export async function getGoogleTokens(service: string): Promise<GoogleTokens | null> {
  const integration = await db.integration.findUnique({
    where: { service },
  });

  if (!integration || !integration.connected || !integration.config) {
    return null;
  }

  return JSON.parse(integration.config);
}

// تحديث الـ token إذا انتهت صلاحيته
export async function refreshGoogleToken(refreshToken: string): Promise<{ access_token: string; expires_in: number } | null> {
  // اقرأ بيانات الاعتماد من قاعدة البيانات
  const settings = await db.setting.findMany({
    where: { key: { in: ["google_client_id", "google_client_secret"] } },
  });
  const config: Record<string, string> = {};
  for (const s of settings) config[s.key] = s.value;

  const clientId = config.google_client_id || process.env.GOOGLE_CLIENT_ID;
  const clientSecret = config.google_client_secret || process.env.GOOGLE_CLIENT_SECRET;

  if (!clientId || !clientSecret) return null;

  try {
    const res = await fetch("https://oauth2.googleapis.com/token", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        client_id: clientId,
        client_secret: clientSecret,
        refresh_token: refreshToken,
        grant_type: "refresh_token",
      }),
    });

    if (!res.ok) return null;

    const data = await res.json();
    return { access_token: data.access_token, expires_in: data.expires_in };
  } catch {
    return null;
  }
}

// الحصول على access token صالح (مع تحديث تلقائي)
export async function getValidAccessToken(service: string): Promise<string | null> {
  const tokens = await getGoogleTokens(service);
  if (!tokens) return null;

  // تحقق من انتهاء الصلاحية (مع هامش 5 دقائق)
  const now = Date.now();
  if (tokens.expires_at && tokens.expires_at > now + 300000) {
    return tokens.access_token;
  }

  // يحتاج تحديث
  if (tokens.refresh_token) {
    const refreshed = await refreshGoogleToken(tokens.refresh_token);
    if (refreshed) {
      // حدّث في قاعدة البيانات
      const newConfig: GoogleTokens = {
        ...tokens,
        access_token: refreshed.access_token,
        expires_at: now + refreshed.expires_in * 1000,
      };
      await db.integration.update({
        where: { service },
        data: { config: JSON.stringify(newConfig) },
      });
      return refreshed.access_token;
    }
  }

  // استخدم الـ token الحالي كحل أخير
  return tokens.access_token;
}

// استدعاء Google Calendar API
export async function listGoogleCalendarEvents(accessToken: string, maxResults = 50): Promise<any[]> {
  const now = new Date();
  const timeMin = now.toISOString();
  const future = new Date();
  future.setMonth(future.getMonth() + 3);
  const timeMax = future.toISOString();

  const res = await fetch(
    `https://www.googleapis.com/calendar/v3/calendars/primary/events?timeMin=${timeMin}&timeMax=${timeMax}&maxResults=${maxResults}&singleEvents=true&orderBy=startTime`,
    { headers: { Authorization: `Bearer ${accessToken}` } }
  );

  if (!res.ok) {
    console.error("Calendar API error:", await res.text());
    return [];
  }

  const data = await res.json();
  return data.items || [];
}

// إنشاء حدث في Google Calendar
export async function createGoogleCalendarEvent(accessToken: string, event: {
  title: string;
  description?: string;
  startDate: string;
  endDate?: string;
  location?: string;
}): Promise<any | null> {
  const res = await fetch("https://www.googleapis.com/calendar/v3/calendars/primary/events", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${accessToken}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      summary: event.title,
      description: event.description,
      location: event.location,
      start: {
        dateTime: event.startDate,
        timeZone: "Asia/Damascus",
      },
      end: {
        dateTime: event.endDate || event.startDate,
        timeZone: "Asia/Damascus",
      },
    }),
  });

  if (!res.ok) return null;
  return res.json();
}

// استدعاء Google Contacts API (People API)
export async function listGoogleContacts(accessToken: string, maxResults = 100): Promise<any[]> {
  const res = await fetch(
    `https://people.googleapis.com/v1/people/me/connections?personFields=names,phoneNumbers,emailAddresses&pageSize=${maxResults}`,
    { headers: { Authorization: `Bearer ${accessToken}` } }
  );

  if (!res.ok) {
    console.error("People API error:", await res.text());
    return [];
  }

  const data = await res.json();
  return data.connections || [];
}

// رفع ملف إلى Google Drive
export async function uploadToGoogleDrive(accessToken: string, filename: string, content: string, mimeType = "application/json"): Promise<string | null> {
  const boundary = "-------314159265358979323846";
  const body = [
    `--${boundary}`,
    `Content-Type: application/json; charset=UTF-8`,
    ``,
    JSON.stringify({ name: filename, mimeType }),
    `--${boundary}`,
    `Content-Type: ${mimeType}`,
    ``,
    content,
    `--${boundary}--`,
  ].join("\r\n");

  const res = await fetch("https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${accessToken}`,
      "Content-Type": `multipart/related; boundary="${boundary}"`,
    },
    body,
  });

  if (!res.ok) {
    console.error("Drive API error:", await res.text());
    return null;
  }

  const data = await res.json();
  return data.id;
}

// قائمة ملفات Google Drive
export async function listGoogleDriveFiles(accessToken: string, maxResults = 10): Promise<any[]> {
  const res = await fetch(
    `https://www.googleapis.com/drive/v3/files?pageSize=${maxResults}&fields=files(id,name,mimeType,modifiedTime,size)&orderBy=modifiedTime desc`,
    { headers: { Authorization: `Bearer ${accessToken}` } }
  );

  if (!res.ok) return [];
  const data = await res.json();
  return data.files || [];
}

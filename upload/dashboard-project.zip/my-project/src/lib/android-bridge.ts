// Android Bridge — يربط واجهة الويب بميزات الأندرويد الأصلية
// يعمل فقط داخل تطبيق الأندرويد (WebView)؛ يجد fallback للويب إن لزم.

export const isAndroidApp =
  typeof window !== "undefined" &&
  !!(window as any).Android &&
  typeof (window as any).Android.getDeviceInfo === "function";

interface InstalledApp {
  packageName: string;
  label: string;
  className?: string;
  icon?: string;
  isSystem?: boolean;
}

interface ContactInfo {
  name: string;
  phone: string;
  type?: number;
}

interface DeviceInfo {
  deviceId?: string;
  model?: string;
  manufacturer?: string;
  brand?: string;
  androidVersion?: string;
  sdkVersion?: number;
  appVersion?: string;
  batteryLevel?: number;
  isCharging?: boolean;
  networkType?: string;
  locale?: string;
}

interface LocationInfo {
  success: boolean;
  latitude?: number;
  longitude?: number;
  accuracy?: number;
  altitude?: number;
  error?: string;
}

function A(): any {
  return (window as any).Android;
}

export const androidBridge = {
  // ============ الاتصالات والرسائل ============
  makeCall(phoneNumber: string): boolean {
    if (isAndroidApp) {
      A().makeCall(phoneNumber);
      return true;
    }
    window.location.href = `tel:${phoneNumber}`;
    return false;
  },

  dialNumber(phoneNumber: string): void {
    if (isAndroidApp) A().dialNumber(phoneNumber);
    else window.location.href = `tel:${phoneNumber}`;
  },

  sendSMS(phoneNumber: string, message: string): boolean {
    if (isAndroidApp) {
      A().sendSMS(phoneNumber, message);
      return true;
    }
    window.location.href = `sms:${phoneNumber}?body=${encodeURIComponent(message)}`;
    return false;
  },

  openSMS(phoneNumber: string, message = ""): void {
    if (isAndroidApp) A().openSMS(phoneNumber, message);
    else window.location.href = `smsto:${phoneNumber}`;
  },

  openWhatsApp(phoneNumber: string): void {
    if (isAndroidApp) {
      A().openWhatsApp(phoneNumber);
    } else {
      let clean = phoneNumber.replace(/[^0-9]/g, "");
      if (clean.startsWith("0")) clean = "963" + clean.slice(1);
      window.open(`https://wa.me/${clean}`, "_blank");
    }
  },

  openWhatsAppWithText(phoneNumber: string, text: string): void {
    if (isAndroidApp) A().openWhatsAppWithText(phoneNumber, text);
    else {
      const clean = phoneNumber.replace(/[^0-9]/g, "");
      window.open(`https://wa.me/${clean}?text=${encodeURIComponent(text)}`, "_blank");
    }
  },

  navigateTo(lat: number, lng: number): void {
    if (isAndroidApp) A().navigateTo(lat.toString(), lng.toString());
    else window.open(`https://www.google.com/maps/dir/?api=1&destination=${lat},${lng}`, "_blank");
  },

  // ============ جهات الاتصال ============
  getContacts(): ContactInfo[] {
    if (isAndroidApp) {
      try {
        return JSON.parse(A().getContacts() || "[]");
      } catch {
        return [];
      }
    }
    return [];
  },

  addContact(name: string, phone: string, email = ""): void {
    if (isAndroidApp) A().addContact(name, phone, email);
  },

  // ============ التطبيقات (Launcher) ============
  getInstalledApps(): InstalledApp[] {
    if (isAndroidApp) {
      try {
        return JSON.parse(A().getInstalledApps() || "[]");
      } catch {
        return [];
      }
    }
    return [];
  },

  launchApp(packageName: string): void {
    if (isAndroidApp) A().launchApp(packageName);
  },

  uninstallApp(packageName: string): void {
    if (isAndroidApp) A().uninstallApp(packageName);
  },

  openAppMarket(packageName: string): void {
    if (isAndroidApp) A().openAppMarket(packageName);
    else window.open(`https://play.google.com/store/apps/details?id=${packageName}`, "_blank");
  },

  // ============ الموقع ============
  getCurrentLocation(callbackName?: string): Promise<LocationInfo> {
    if (isAndroidApp) {
      return new Promise((resolve) => {
        const cb = "__loc_" + Date.now();
        (window as any)[cb] = (data: LocationInfo) => {
          resolve(data);
          delete (window as any)[cb];
        };
        A().getCurrentLocation(callbackName || cb);
      });
    }
    return Promise.resolve({ success: false, error: "not_android" });
  },

  // ============ النظام والجهاز ============
  getBatteryLevel(): number {
    if (isAndroidApp) return A().getBatteryLevel();
    return -1;
  },

  isCharging(): boolean {
    if (isAndroidApp) return A().isCharging();
    return false;
  },

  isNetworkAvailable(): boolean {
    if (isAndroidApp) return A().isNetworkAvailable();
    return navigator.onLine;
  },

  getNetworkType(): string {
    if (isAndroidApp) return A().getNetworkType();
    return navigator.onLine ? "other" : "none";
  },

  getDeviceInfo(): DeviceInfo {
    if (isAndroidApp) {
      try {
        return JSON.parse(A().getDeviceInfo() || "{}");
      } catch {
        return {};
      }
    }
    return {
      model: navigator.userAgent,
      androidVersion: "web",
    };
  },

  getDeviceId(): string {
    if (isAndroidApp) return A().getDeviceId();
    return "web-" + Math.random().toString(36).substring(2, 11);
  },

  isDefaultLauncher(): boolean {
    if (isAndroidApp) return A().isDefaultLauncher();
    return false;
  },

  setAsDefaultLauncher(): void {
    if (isAndroidApp) A().setAsDefaultLauncher();
  },

  // ============ الإشعارات والاهتزاز ============
  sendNotification(title: string, message: string, channel?: string): void {
    if (isAndroidApp) A().sendNotification(title, message, channel || "dashboard_notifications");
  },

  vibrate(duration = 200): void {
    if (isAndroidApp) A().vibrate(duration);
    else if ("vibrate" in navigator) navigator.vibrate(duration);
  },

  vibratePattern(pattern: number[]): void {
    if (isAndroidApp) A().vibratePattern(JSON.stringify(pattern));
    else if ("vibrate" in navigator) navigator.vibrate(pattern);
  },

  playNotificationSound(): void {
    if (isAndroidApp) A().playNotificationSound();
  },

  // ============ الإعدادات والنظام ============
  openAppSettings(): void {
    if (isAndroidApp) A().openAppSettings();
  },

  openLocationSettings(): void {
    if (isAndroidApp) A().openLocationSettings();
  },

  openWifiSettings(): void {
    if (isAndroidApp) A().openWifiSettings();
  },

  openBluetoothSettings(): void {
    if (isAndroidApp) A().openBluetoothSettings();
  },

  openDisplaySettings(): void {
    if (isAndroidApp) A().openDisplaySettings();
  },

  openSoundSettings(): void {
    if (isAndroidApp) A().openSoundSettings();
  },

  openSecuritySettings(): void {
    if (isAndroidApp) A().openSecuritySettings();
  },

  openSettings(): void {
    if (isAndroidApp) A().openSettings();
  },

  openDialer(): void {
    if (isAndroidApp) A().openDialer();
    else window.location.href = "tel:";
  },

  openMessages(): void {
    if (isAndroidApp) A().openMessages();
  },

  openCamera(): void {
    if (isAndroidApp) A().openCamera();
  },

  openBrowser(): void {
    if (isAndroidApp) A().openBrowser();
    else window.open("https://google.com", "_blank");
  },

  expandStatusBar(): void {
    if (isAndroidApp) A().expandStatusBar();
  },

  keepScreenOn(keep: boolean): void {
    if (isAndroidApp) A().keepScreenOn(keep);
  },

  openExternalUrl(url: string): void {
    if (isAndroidApp) A().openExternalUrl(url);
    else window.open(url, "_blank");
  },

  shareText(text: string): void {
    if (isAndroidApp) A().shareText(text);
    else if (navigator.share) navigator.share({ text });
  },

  setWallpaper(imageBase64: string): void {
    if (isAndroidApp) A().setWallpaper(imageBase64);
  },

  // ============ التخزين المحلي (SharedPrefs) ============
  storeData(key: string, value: string): void {
    if (isAndroidApp) A().storeData(key, value);
    else localStorage.setItem("dash_" + key, value);
  },

  getData(key: string, defaultValue = ""): string {
    if (isAndroidApp) return A().getData(key, defaultValue);
    return localStorage.getItem("dash_" + key) || defaultValue;
  },

  removeData(key: string): void {
    if (isAndroidApp) A().removeData(key);
    else localStorage.removeItem("dash_" + key);
  },

  clearData(): void {
    if (isAndroidApp) A().clearData();
    else Object.keys(localStorage).filter((k) => k.startsWith("dash_")).forEach((k) => localStorage.removeItem(k));
  },

  // ============ الأذونات ============
  hasPermission(permission: string): boolean {
    if (isAndroidApp) return A().hasPermission(permission);
    return true;
  },

  requestPermission(permission: string): void {
    if (isAndroidApp) A().requestPermission(permission);
  },

  requestAllPermissions(): void {
    if (isAndroidApp) A().requestAllPermissions();
  },

  getPermissionStatus(): Record<string, boolean> {
    if (isAndroidApp) {
      try {
        return JSON.parse(A().getPermissionStatus() || "{}");
      } catch {
        return {};
      }
    }
    return {};
  },

  // ============ أدوات مساعدة ============
  showToast(message: string): void {
    if (isAndroidApp) A().showToast(message);
  },

  showToastLong(message: string): void {
    if (isAndroidApp) A().showToastLong(message);
  },
};

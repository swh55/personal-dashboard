"use client";

import * as React from "react";

interface AppSettings {
  pinEnabled: boolean;
  pinCode: string;
  autoNightMode: boolean;
  weekStartDay: string;
  loaded: boolean;
}

const DEFAULT_SETTINGS: AppSettings = {
  pinEnabled: false,
  pinCode: "",
  autoNightMode: false,
  weekStartDay: "6",
  loaded: false,
};

const INACTIVITY_TIMEOUT = 5 * 60 * 1000; // 5 دقائق

export function useAppSettings() {
  const [settings, setSettings] = React.useState<AppSettings>(DEFAULT_SETTINGS);
  const [unlocked, setUnlocked] = React.useState(false);
  const lastActivityRef = React.useRef<number>(Date.now());

  React.useEffect(() => {
    // Timeout safety net: if settings fetch hangs (e.g. cold compile),
    // force-load the app after 6 seconds so it never stays stuck on loading.
    const safetyTimer = setTimeout(() => {
      setSettings((s) =>
        s.loaded ? s : { ...s, loaded: true }
      );
      setUnlocked(true);
    }, 6000);

    // Fetch with its own 5s abort so we don't rely solely on the safety timer.
    const controller = new AbortController();
    const fetchTimer = setTimeout(() => controller.abort(), 5000);

    fetch("/api/settings", { signal: controller.signal })
      .then((r) => r.json())
      .then((json) => {
        clearTimeout(fetchTimer);
        clearTimeout(safetyTimer);
        if (json.success && json.data) {
          const data = json.data;
          setSettings({
            pinEnabled: data.pinEnabled === "true",
            pinCode: data.pinCode || "",
            autoNightMode: data.autoNightMode === "true",
            weekStartDay: data.weekStartDay || "6",
            loaded: true,
          });
          if (data.pinEnabled !== "true") {
            setUnlocked(true);
          }
        } else {
          setSettings((s) => ({ ...s, loaded: true }));
          setUnlocked(true);
        }
      })
      .catch(() => {
        clearTimeout(fetchTimer);
        clearTimeout(safetyTimer);
        setSettings((s) => ({ ...s, loaded: true }));
        setUnlocked(true);
      });

    return () => {
      clearTimeout(fetchTimer);
      clearTimeout(safetyTimer);
      controller.abort();
    };
  }, []);

  // إعادة قفل تلقائي بعد فترة عدم نشاط (5 دقائق)
  React.useEffect(() => {
    if (!settings.pinEnabled || !unlocked) return;

    const events = ["mousedown", "keydown", "touchstart", "scroll"];

    const updateActivity = () => {
      lastActivityRef.current = Date.now();
    };

    events.forEach((e) => window.addEventListener(e, updateActivity, { passive: true }));

    const interval = setInterval(() => {
      const inactive = Date.now() - lastActivityRef.current;
      if (inactive >= INACTIVITY_TIMEOUT) {
        setUnlocked(false);
      }
    }, 30000); // فحص كل 30 ثانية

    return () => {
      events.forEach((e) => window.removeEventListener(e, updateActivity));
      clearInterval(interval);
    };
  }, [settings.pinEnabled, unlocked]);

  const unlock = React.useCallback(() => {
    lastActivityRef.current = Date.now();
    setUnlocked(true);
  }, []);
  const lock = React.useCallback(() => setUnlocked(false), []);

  return { settings, unlocked, unlock, lock };
}

"use client";

import * as React from "react";

interface AccentColor {
  id: string;
  primary: string;
  secondary: string;
}

const COLORS: AccentColor[] = [
  { id: "emerald", primary: "#10b981", secondary: "#f59e0b" },
  { id: "blue", primary: "#3b82f6", secondary: "#06b6d4" },
  { id: "purple", primary: "#8b5cf6", secondary: "#ec4899" },
  { id: "rose", primary: "#f43f5e", secondary: "#f97316" },
  { id: "teal", primary: "#14b8a6", secondary: "#84cc16" },
  { id: "indigo", primary: "#6366f1", secondary: "#a855f7" },
];

// تحويل hex إلى oklch للتطبيق على متغيرات CSS
function hexToOklch(hex: string): string {
  // تحويل بسيط - نستخدم hex مباشرة مع oklch fallback
  return hex;
}

export function useAccentColor() {
  const [accentColor, setAccentColor] = React.useState<AccentColor>(COLORS[0]);

  const applyColor = React.useCallback((color: AccentColor) => {
    const root = document.documentElement;
    root.style.setProperty("--accent-primary", color.primary);
    root.style.setProperty("--accent-secondary", color.secondary);
    root.style.setProperty("--emerald-glow", hexToOklch(color.primary));
    root.style.setProperty("--amber-glow", hexToOklch(color.secondary));
  }, []);

  React.useEffect(() => {
    const saved = localStorage.getItem("dashboard-accent-color");
    if (saved) {
      const color = COLORS.find((c) => c.id === saved);
      if (color) {
        setAccentColor(color);
        applyColor(color);
      }
    }
  }, [applyColor]);

  const setColor = React.useCallback((colorId: string) => {
    const color = COLORS.find((c) => c.id === colorId);
    if (color) {
      setAccentColor(color);
      localStorage.setItem("dashboard-accent-color", colorId);
      applyColor(color);
    }
  }, [applyColor]);

  return { accentColor, setColor, colors: COLORS };
}
